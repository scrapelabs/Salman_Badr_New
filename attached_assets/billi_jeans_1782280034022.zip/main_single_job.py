
# '''
# call python manage.py runscript scripts.college_dual_match_scraper.main --script-args 392 "College Dual Match Scraper" "C:\Users\vmadmin\Desktop\Salman_Bader\spiders_app\static\files" 5

# call python manage.py runscript scripts.ioncourt.main --script-args 6 "Ioncourt" "D:\_work_khemiri\Salman_Bader\spiders_app\static\files" 5
# call python manage.py runscript scripts.college_dual_match_scraper_ai.main --script-args 1 "College Dual Match Scraper Ai" "D:\_work_khemiri\Salman_Bader\spiders_app\static\files" 5
# call python manage.py runscript scripts.sweden_league.main --script-args 14 "Sweden League" "D:\_work_khemiri\Salman_Bader\spiders_app\static\files" 5
# call python manage.py runscript scripts.wtatennis.main --script-args 3 "Wtatennis" "D:\_work_khemiri\Salman_Bader\spiders_app\static\files" 5
# '''

import subprocess, sys, os
from os.path import dirname, abspath
from app_spiders.models import jobsModel

from rich.console import Console
from rich.prompt import IntPrompt

console = Console()

def run():
    # ── Job ID input ─────────────────────────────────────────
    while True:
        try:
            id = IntPrompt.ask("  [bold yellow]➜  Enter Job ID[/bold yellow]")
            break
        except Exception:
            console.print("  [bold red]✗  Invalid — please enter a number[/bold red]")

    console.print()

    # ── Resolve job ──────────────────────────────────────────
    max_workers = 5
    folder_path = os.path.join(dirname(dirname(abspath(__file__))), 'static', 'files')
    os.makedirs(folder_path, exist_ok=True)

    try:
        job_obj        = jobsModel.objects.get(id=id)
        job_id         = job_obj.id
        spider_name    = job_obj.spider_name
        runscript_name = spider_name.lower().replace(" ", "_")

        # ── Launch ────────────────────────────────────────────
        cmd = [
            sys.executable, "manage.py", "runscript",
            f"scripts.{runscript_name}.main",
            "--script-args",
            str(job_id), spider_name, folder_path, str(max_workers),
        ]

        subprocess.Popen(cmd)

        console.print(f"  [bold green]✔  {spider_name} launched successfully[/bold green]")
        console.print(f"  [dim]job_id={job_id} | workers={max_workers}[/dim]")
        console.print()

    except jobsModel.DoesNotExist:
        console.print(f"\n  [bold red]✗  No job found with ID {id}[/bold red]")
        console.print("  [dim]Check the database and try again.[/dim]\n")

    except Exception:
        console.print("\n  [bold red]✗  Unexpected error — see logs for details[/bold red]\n")
