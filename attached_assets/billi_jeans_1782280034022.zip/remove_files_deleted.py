import time, os
from assets.fct.fctlog import logger
from django.conf import settings
from app_spiders.models import jobsModel

start_dt = time.time()

def run():
    files_dir = os.path.join(settings.BASE_DIR, 'static', 'files')

    if not os.path.exists(files_dir):
        logger.info(f'Directory not found: {files_dir}')
        return

    # Collect all filenames referenced in the DB (non-empty values only)
    file_fields = ['job_items_file', 'job_logs_file', 'job_requests_file', 'job_errors_file']
    db_files = set()

    for job in jobsModel.objects.all().values(*file_fields):
        for field in file_fields:
            value = job.get(field, '')
            if value and value.strip():
                db_files.add(value.strip())

    logger.info(f'Found {len(db_files)} file references in DB.')

    deleted = 0
    for filename in os.listdir(files_dir):
        filepath = os.path.join(files_dir, filename)
        if not os.path.isfile(filepath):
            continue

        if filename not in db_files:
            os.remove(filepath)
            logger.info(f'Deleted: {filename}')
            deleted += 1

    logger.info(f'\nDone. {deleted} file(s) deleted.')
    logger.info(f'script take {round(time.time()-start_dt, 2)} sec to finished')
