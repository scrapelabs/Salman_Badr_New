import pandas as pd
import traceback, json, psutil, requests, re, os, glob, time, hashlib
from bs4 import BeautifulSoup
from assets.requests.fctrequest import get_requests_df
from assets.fct.fctlog import logger, get_logs_df, get_errors_df
import translators as ts  # pip install translators
from urllib.parse import urlparse
from django.utils import timezone
from django.apps import apps
from datetime import datetime, timedelta
from app_spiders.models import jobsModel, collegesModel

def should_run_job(job_obj):
    now = timezone.now()
    current_day = now.strftime("%A")

    spider_name = job_obj.spider_name
    spider_type = job_obj.spider_type
    job_time = job_obj.job_schedule_time.strftime("%H:%M") if job_obj.job_schedule_time else ''
    job_day = job_obj.job_schedule_day
    job_type = job_obj.job_schedule_type

    logger.info(f'spider_name: {spider_name} | spider_type: {spider_type} | job_time: {job_time} | job_day: {job_day} | job_type: {job_type}')

    if spider_type == 'manuel':
        job_obj.job_start_time = timezone.now()
        job_obj.job_status = 'running'
        job_obj.save()
        return True

    if spider_type == 'automatic':
        # FIX: Replace exact HH:MM == match with a 2-minute window.
        # If the cron is delayed even by 1 minute the exact match misses entirely.
        # Now we check if the scheduled time falls within [now, now + 2 minutes].
        def is_within_2_minutes(job_time_str):
            if not job_time_str:
                return False
            scheduled = now.replace(
                hour=int(job_time_str.split(":")[0]),
                minute=int(job_time_str.split(":")[1]),
                second=0,
                microsecond=0
            )
            diff = (now - scheduled).total_seconds()
            return 0 <= diff < 120  # within 2 minutes after scheduled time

        if job_type == "daily":
            if is_within_2_minutes(job_time):
                job_obj.job_start_time = timezone.now()
                job_obj.job_status = 'running'
                job_obj.save()
                return True

        if job_type == "weekly":
            if is_within_2_minutes(job_time) and job_day.lower() == current_day.lower():
                job_obj.job_start_time = timezone.now()
                job_obj.job_status = 'running'
                job_obj.save()
                return True

    return False


def get_official_college_name(input_name, ai_client):
    college_name = 'Unknown'
    try:
        if input_name:
            collegesObj = collegesModel.objects.filter(input_name__iexact=input_name)
            if not collegesObj.exists():
                logger.info(f'new: get_official_college_name input_name: {input_name}')

                system_prompt = """
                You are a data standardization assistant. Your job is to identify the official, full, 
                formal name of a college or university based on a user-provided name, nickname, 
                abbreviation, or partial text. 
                Return only the official institution name used by the college itself. 
                If multiple institutions match, return the most common U.S. one. 
                If you can't determine with high confidence, return "Unknown".

                Return results as:
                {"official_name": "<name>"}
                """

                user_prompt = f'Convert this college name to its official full name: "{input_name}"'

                logger.info(f'system_prompt: {system_prompt}')
                logger.info(f'user_prompt: {user_prompt}')

                response = ai_client.chat.completions.create(
                    model="gpt-4.1-mini",  # Cheap + fast. Change model as desired.
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ]
                )

                results_ai = response.choices[0].message.content
                logger.info(f'results_ai: {results_ai}')

                if results_ai:
                    college_name = json.loads(results_ai).get('official_name', '')

                    logger.info(f'final | get_official_college_name | input_name: {input_name} | college_name: {college_name}')

                    if college_name:
                        collegesModel(input_name=input_name, college_name=college_name).save()

            else:
                college_name = collegesObj.first().college_name
                logger.warning(f'exist from db | get_official_college_name | input_name: {input_name} | college_name: {college_name}')

    except:
        logger.error(traceback.format_exc())

    return college_name


def convert_college_name(input_college_1, input_college_2, output_college_1, output_college_2, ai_client):
    results_json = {}
    try:
        if input_college_1 and input_college_2 and output_college_1 and output_college_2:
            system_prompt = f"""
                In the context of this college match: '{output_college_1} vs {output_college_2}' provide me with the official college names for the texts: '{input_college_1}' and '{input_college_2}'. Your response for each text should be either '{output_college_1}' or '{output_college_2}'. Your response should not be the same for both texts. In your response just list the two texts as key followed by the names of the colleges as value in JSON format.

                Return results as:
                {{
                    "<college_name_1_abbreviation>": "<college_name_1>",
                    "<college_name_2_abbreviation>": "<college_name_2>",
                }}
            """

            logger.info(f'system_prompt: {system_prompt}')

            response = ai_client.chat.completions.create(
                model="gpt-4.1-mini",  # Cheap + fast. Change model as desired.
                messages=[
                    {"role": "system", "content": system_prompt},
                ]
            )

            results_ai = response.choices[0].message.content
            logger.info(f'results_ai: {results_ai}')

            results_json = {}
            if results_ai:
                results_json = json.loads(results_ai.replace("```", "").replace("json", "").strip())

    except:
        logger.error(traceback.format_exc())

    return results_json

def get_gender_from_players_list_gpt(players_names, ai_client):
    gender = ''
    try:
        if players_names:
            players_list = "; ".join(p for p in players_names if p)

            system_prompt = f'''
                In context of this list of player names: "{players_list}", provide me with the gender of the list as a whole. Your response must be in JSON format. The JSON object you return must have a key of `Gender`. The value attached to the `Gender` key should only either be `Male` or `Female`.
            '''

            logger.info(f'system_prompt: {system_prompt}')

            response = ai_client.chat.completions.create(
                model="gpt-4.1-mini",  # Cheap + fast. Change model as desired.
                messages=[
                    {"role": "system", "content": system_prompt},
                ]
            )


            results_ai = response.choices[0].message.content
            logger.info(f'results_ai: {results_ai}')

            results_json = {}
            if results_ai:
                results_json = json.loads(results_ai.replace("```", "").replace("json", "").strip())

                if results_json:
                    gender = str(results_json['Gender']).title()

            logger.info(f'get_gender_from_gpt | results_json: {results_json} | gender: {gender}')

    except:
        logger.error(traceback.format_exc())

    return gender

def kill_proccess(pid: int):
    if not pid:
        logger.warning("No PID provided")
        return False

    try:
        proc = psutil.Process(pid)

        # kill children first
        for child in proc.children(recursive=True):
            try:
                child.kill()
            except psutil.NoSuchProcess:
                pass

        proc.terminate()
        proc.wait(timeout=5)

        logger.info(f"Process terminated | pid={pid}")
        return True

    except psutil.NoSuchProcess:
        logger.info(f"Process already stopped | pid={pid}")
        return False

    except psutil.TimeoutExpired:
        proc.kill()
        logger.info(f"Process force-killed | pid={pid}")
        return True

    except Exception as e:
        logger.error(f"Kill failed | pid={pid} | error={e}")
        return False


def is_pid_running(pid: int) -> bool:
    """
    Returns True if PID exists and is running, False otherwise.
    Works on Windows / Linux / macOS.
    """
    if pid:
        try:
            p = psutil.Process(pid)
            return p.is_running() and p.status() != psutil.STATUS_ZOMBIE
        except psutil.NoSuchProcess:
            return False
        except Exception:
            return False
    return False


def _parse_part_range_date(s):
    FORMATS = (
        "%b %d %Y",
        "%b %d",
        "%d %b %Y",
        "%d %b",
        "%B %d %Y",   # September 1 2025
        "%B %d",      # September 1
        "%d %B %Y",   # 1 September 2025
        "%d %B",      # 1 September
    )

    for f in FORMATS:
        try:
            return datetime.strptime(s, f)
        except ValueError:
            continue

    raise ValueError(f"Unsupported date format: {s}")

def parse_tournament_range_date(s, format="%m/%d/%Y"):
    s = s.strip()
    s = s.replace(" - ", " to ")  # normalize separator

    current_year = datetime.now().year

    # ---------- CASE 1: SINGLE DATE ----------
    if " to " not in s:
        dt = _parse_part_range_date(s)
        if dt.year == 1900:
            dt = dt.replace(year=current_year)
        return dt.strftime(format), dt.strftime(format)

    # ---------- CASE 2: DATE RANGE ----------
    start_part, end_part = map(str.strip, s.split(" to "))

    start_dt = _parse_part_range_date(start_part)
    end_dt = _parse_part_range_date(end_part)

    if start_dt.year == 1900 and end_dt.year == 1900:
        if start_dt.month > end_dt.month:
            start_dt = start_dt.replace(year=current_year - 1)
            end_dt = end_dt.replace(year=current_year)
        else:
            start_dt = start_dt.replace(year=current_year)
            end_dt = end_dt.replace(year=current_year)

    elif start_dt.year == 1900:
        start_year = end_dt.year - 1 if start_dt.month > end_dt.month else end_dt.year
        start_dt = start_dt.replace(year=start_year)

    elif end_dt.year == 1900:
        end_dt = end_dt.replace(year=start_dt.year)

    return start_dt.strftime(format), end_dt.strftime(format)


def clean_name(s: str) -> str:
    s = s.strip()
    # remove leading "(number,"
    s = re.sub(r'^\(\s*\d+\s*,\s*', '', s)
    # allow letters, spaces, hyphen AND comma
    s = re.sub(r'[^A-Za-zÀ-ÖØ-öø-ÿ,\s-]', '', s)
    # normalize spaces (but keep comma position)
    s = re.sub(r'\s+', ' ', s)
    return s.strip()


def extract_google_sheet_id(url: str) -> str:
    match = re.search(r"/d/([a-zA-Z0-9-_]+)", url)
    return match.group(1) if match else ""


def normalize_url(url: str) -> str:
    url = url.strip()
    parsed = urlparse(url)

    if not parsed.scheme:
        return f"https://{url}"

    return url


def translate_text(text):
    return ts.translate_text(text, translator='bing', to_language='en')


def cleanup_old_files(folder_path, spider_name, job_id):
    pattern = os.path.join(folder_path, f'items__{spider_name}__{job_id}*.csv')
    files = glob.glob(pattern)

    if len(files) <= 1:
        return

    # Sort by modification time, newest last
    files.sort(key=lambda f: os.path.getmtime(f))

    for f in files[:-1]:
        os.remove(f)
        logger.info(f"Deleted old file: {f}")


def get_model_by_table_name(table_name):
    for model in apps.get_models():
        if model._meta.db_table == table_name:
            return model
    return None


def finalize_items_from_db(job_obj, folder_path, base_file):
    table_name = re.sub(r"\s+", "_", job_obj.spider_name.lower())
    table_name = f'app_{table_name}__items'
    model = get_model_by_table_name(table_name)
    items = model.objects.filter(job_id=job_obj.id)

    if items.exists():
        logger.info(f'items: {items.count()}')
        items_file = f'items__{base_file}'

        exclude_fields = {'id', 'job_id', 'spider_id', 'created_at'}
        fields = [f.name for f in model._meta.fields if f.name not in exclude_fields]

        df_items = pd.DataFrame(list(items.values(*fields)))
        df_items = df_items.drop_duplicates()

        if table_name in ['app_atptour__items', 'app_wtatennis__items']:
            df_items = df_items.rename(columns={'player_id': 'id'})

        df_items = df_items.astype(str).replace({'None': '', 'nan': '', '<NA>': ''})  # convert everything to string
        df_items.columns = [col.replace("_", " ").title() for col in df_items.columns]
        df_items.to_csv(os.path.join(folder_path, items_file), index=False, encoding="utf-8-sig")#encoding="utf-8"

        job_obj.job_items_count = items.count()
        job_obj.job_items_file = items_file
        job_obj.save()

        if job_obj.spider_name not in ['College Dual Match Scraper', 'College Dual Match Scraper Ai']:
            model.objects.filter(job_id=job_obj.id).delete()


def finalize_items(job_obj, df_items, base_file, folder_path):
    if not df_items.empty:
        logger.info(f'df_items: {len(df_items)}')
        items_file = f'items__{base_file}'
        df_items = df_items.drop_duplicates()
        df_items.columns = [col.replace("_", " ").title() for col in df_items.columns]
        df_items.to_csv(os.path.join(folder_path, items_file), index=False, encoding="utf-8-sig")#encoding="utf-8"
        job_obj.job_items_count = len(df_items)
        job_obj.job_items_file = items_file
        job_obj.save()


def reschedule_job(job):
    if job.job_schedule_type == 'daily':
        delta = timedelta(days=1)
        new_start_time = job.job_start_time + delta

    elif job.job_schedule_type == 'weekly':
        delta = timedelta(weeks=1)
        new_start_time = job.job_start_time + delta

    else:
        return  # manual jobs don't reschedule

    old_settings = job.job_settings or {}
    new_settings = dict(old_settings)  # copy everything as-is

    bi_weekly = old_settings.get("bi_weekly", 0)

    if bi_weekly and bi_weekly > 0:
        # bi_weekly takes priority — recompute range_date fresh from new_start_time
        if "range_date" in old_settings:
            end_date = new_start_time
            start_date = end_date - timedelta(days=bi_weekly)
            new_settings["range_date"] = f"{start_date.strftime('%m/%d/%Y')} to {end_date.strftime('%m/%d/%Y')}"

        if "single_date" in old_settings:  # ✅ only if it existed before
            new_settings["single_date"] = new_start_time.strftime('%m/%d/%Y')

    else:
        if "range_date" in old_settings:
            try:
                start_str, end_str = [d.strip() for d in old_settings["range_date"].split("to")]
                start_dt = datetime.strptime(start_str, "%m/%d/%Y") + delta
                end_dt = datetime.strptime(end_str, "%m/%d/%Y") + delta
                new_settings["range_date"] = f"{start_dt.strftime('%m/%d/%Y')} to {end_dt.strftime('%m/%d/%Y')}"
            except Exception:
                pass

        if "single_date" in old_settings:  # ✅ only if it existed before
            try:
                dt = datetime.strptime(old_settings["single_date"], "%m/%d/%Y") + delta
                new_settings["single_date"] = dt.strftime("%m/%d/%Y")
            except Exception:
                pass

    jobsModel.objects.create(
        spider_id=job.spider_id,
        spider_name=job.spider_name,
        spider_type=job.spider_type,
        job_schedule_time=job.job_schedule_time,
        job_schedule_day=job.job_schedule_day,
        job_schedule_type=job.job_schedule_type,
        job_start_time=new_start_time,
        job_settings=new_settings,
        job_status='queued',
    )


def finalize_job(job_obj, base_file, folder_path):
    df_requests = get_requests_df()
    if not df_requests.empty:
        requests_file = f'requests__{base_file}'
        df_requests.to_csv(os.path.join(folder_path, requests_file), index=False, encoding="utf-8")
        job_obj.job_requests_count = len(df_requests)
        job_obj.job_requests_file = requests_file

    df_errors = get_errors_df()
    if not df_errors.empty:
        errors_file = f'errors__{base_file}'
        df_errors.to_csv(os.path.join(folder_path, errors_file), index=False, encoding="utf-8")
        job_obj.job_errors_count = len(df_errors)
        job_obj.job_errors_file = errors_file

    df_logs = get_logs_df()
    if not df_logs.empty:
        logs_file = f'logs__{base_file}'
        df_logs.to_csv(os.path.join(folder_path, logs_file), index=False, encoding="utf-8")
        job_obj.job_logs_count = len(df_logs)
        job_obj.job_logs_file = logs_file

    logger.info(f'df_requests: {len(df_requests)}')
    logger.info(f'df_errors: {len(df_errors)}')
    logger.info(f'df_logs: {len(df_logs)}')

    job_obj.save()
    time.sleep(3*60) # for cronjob

    job_obj.job_finish_time = timezone.now()
    job_obj.job_status = 'completed'
    job_obj.save()

    reschedule_job(job_obj)


def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def _clean(raw: str) -> str:
    soup = BeautifulSoup(raw, "html.parser")
    for t in soup(["script","style","link","meta","noscript","iframe",
                    "svg","img","picture","video","audio","canvas","head","footer","nav","aside"]):
        t.decompose()
    for t in soup.find_all(True):
        t.attrs = {k: v for k, v in t.attrs.items() if any(k.startswith(a) for a in ["href","id","class","data-","name"])}
    cleaned = re.sub(r'[ \t]+', ' ', re.sub(r'\n\s*\n+', '\n', str(soup))).strip()
    logger.info(f"🧹 HTML: {len(raw):,} → {len(cleaned):,} chars ({100 - int(len(cleaned)/len(raw)*100)}% reduced)")
    return cleaned

def clean_html(path: str) -> str:
    """Clean HTML from a file path."""
    raw = _read(path)
    return _clean(raw)

def clean_html_string(content: str) -> str:
    """Clean raw HTML string directly — no file path needed."""
    return _clean(content)

def clean_xml(path: str) -> str:
    raw     = _read(path)
    cleaned = re.sub(r'[ \t]+', ' ', re.sub(r'\n\s*\n+', '\n', str(BeautifulSoup(raw, "xml")))).strip()
    logger.info(f"🧹 XML: {len(raw):,} → {len(cleaned):,} chars ({100 - int(len(cleaned)/len(raw)*100)}% reduced)")
    return cleaned


def get_match_gender_claude(players_list, api_key):
    """
    Determine match gender from a list of players in the same match.
    Returns 'M', 'F', or '' on failure.
    """
    gender = ''
    try:
        prompt = f'''
            The following tennis players participated in the same match:

                Players:
                {players_list}

                There are NO mixed-gender matches in this dataset.

                Determine the gender of the match.

                Return ONLY valid JSON with exactly one key:
                - "gender": "M" or "F"

                Do not include any extra text.
            '''

        response = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json"
            },
            json={
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 20,
                "messages": [{"role": "user", "content": prompt}]
            }
        )

        data = response.json()
        if "error" in data:
            raise RuntimeError(f"API error {response.status_code}: {data['error']}")

        result = {}
        try:
            result = json.loads(data["content"][0]["text"].strip())
        except Exception:
            logger.error(traceback.format_exc())

        gender = result.get('gender', '')

        logger.info(f'get_match_gender_claude | players: {players_list} | gender: {gender}')

    except Exception:
        logger.error(traceback.format_exc())

    return gender


def format_name_gender_claude(input_name, api_key):
    full_name = ''
    gender = ''
    try:
        if input_name and api_key:
            response = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json"
                },
                json={
                    "model": "claude-sonnet-4-20250514",
                    "max_tokens": 100,
                    "system": (
                        "You are a name formatter. Given a full name, return a JSON object with two fields:\n"
                        "- 'formatted': the name in 'Lastname, Firstname' format, handling compound/double surnames correctly (e.g. Hispanic names, particles like van/de/O').\n"
                        "- 'gender': the likely gender based on the first name, either 'M' or 'F'.\n"
                        "Return ONLY valid JSON, nothing else. Example: {\"formatted\": \"Murphy, David\", \"gender\": \"M\"}"
                    ),
                    "messages": [{"role": "user", "content": input_name}]
                }
            )
            data = response.json()
            if "error" in data:
                raise RuntimeError(f"API error {response.status_code}: {data['error']}")

            results_ai = {}
            try:
                results_ai = json.loads(data["content"][0]["text"].strip())
            except Exception:
                logger.error(traceback.format_exc())

            try:
                full_name = results_ai['formatted']
            except Exception:
                ''
            try:
                gender = results_ai['gender']
            except Exception:
                ''

            logger.info(f'format_name_gender_claude | name: {input_name} | results_ai: {results_ai} | full_name: {full_name} | gender: {gender}')

    except Exception:
        logger.error(traceback.format_exc())

    return full_name, gender


def get_country_from_claude(input_name, api_key):
    country_code = ''
    try:
        response = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json"
            },
            json={
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 100,
                "system": (
                    "You are a country code resolver. Given a country name, return a JSON object with one field:\n"
                    "- 'country_code': the ISO 3166-1 alpha-3 uppercase country code (e.g. 'FRA', 'USA', 'MAR').\n"
                    "Return ONLY valid JSON, nothing else. Example: {\"country_code\": \"FRA\"}"
                ),
                "messages": [{"role": "user", "content": input_name}]
            }
        )
        data = response.json()
        if "error" in data:
            raise RuntimeError(f"API error {response.status_code}: {data['error']}")

        results_ai = {}
        try:
            results_ai = json.loads(data["content"][0]["text"].strip())
        except Exception:
            logger.error(traceback.format_exc())

        try:
            country_code = results_ai['country_code']
        except Exception:
            ''

        logger.info(f'format_name_gender_claude | name: {input_name} | results_ai: {results_ai} | country_code: {country_code}')

    except Exception:
        logger.error(traceback.format_exc())

    return country_code

def remove_chinese(text):
    # Remove Chinese characters using Unicode range
    return re.sub(r'[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]', '', text).strip()

def sha256_id(s):
    digest = hashlib.sha256(s.encode('utf-8')).digest()
    return 'local_'+str(int.from_bytes(digest[:8], 'big'))