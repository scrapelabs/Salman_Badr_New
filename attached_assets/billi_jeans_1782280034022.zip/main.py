import subprocess, traceback, time, sys, os
import concurrent.futures
from os.path import dirname, abspath
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn
from django.db import close_old_connections
from assets.fct import fctcore
from assets.fct.fctlog import logger
from scripts import helper
from app_spiders.models import jobsModel

start_dt = time.time()

# '''
# call python manage.py runscript scripts.college_dual_match_scraper.main --script-args 392 "College Dual Match Scraper" "C:\Users\vmadmin\Desktop\Salman_Bader\spiders_app\static\files" 5

# call python manage.py runscript scripts.ioncourt.main --script-args 6 "Ioncourt" "D:\_work_khemiri\Salman_Bader\spiders_app\static\files" 5
# call python manage.py runscript scripts.college_dual_match_scraper_ai.main --script-args 1 "College Dual Match Scraper Ai" "D:\_work_khemiri\Salman_Bader\spiders_app\static\files" 5
# call python manage.py runscript scripts.sweden_league.main --script-args 14 "Sweden League" "D:\_work_khemiri\Salman_Bader\spiders_app\static\files" 5
# call python manage.py runscript scripts.wtatennis.main --script-args 3 "Wtatennis" "D:\_work_khemiri\Salman_Bader\spiders_app\static\files" 5
# '''

def _run_job(jobs_chunk, main_task, thread_task, folder_path, progress, max_workers):
    try:
        for id in jobs_chunk:
            progress.update(main_task, advance=1)
            progress.update(thread_task, advance=1)
            close_old_connections()

            try:
                job_obj = jobsModel.objects.get(id=id)
                job_id = job_obj.id
                spider_name = job_obj.spider_name
                job_pid = job_obj.job_pid

                is_pid_running = helper.is_pid_running(job_pid)

                if not is_pid_running and job_obj.job_status == 'running':
                    logger.warning(f"Dead process detected | spider_name: {spider_name} | job_id: {job_id} | PID={job_pid} — resetting to queued")
                    job_obj.job_status = 'queued'
                    job_obj.job_pid = None
                    job_obj.save()

                should_run_job = helper.should_run_job(job_obj)

                if not is_pid_running and should_run_job:
                    logger.info(f"spider_name: {spider_name} | job_id {job_id} | is_pid_running {is_pid_running} | PID={job_pid} | should_run_job={should_run_job}")
                    runscript_name = spider_name.lower().replace(" ", "_")

                    cmd = [
                        sys.executable,
                        "manage.py",
                        "runscript",
                        f"scripts.{runscript_name}.main",
                        "--script-args",
                        str(job_id),
                        spider_name,
                        folder_path,
                        str(max_workers),
                    ]

                    process = subprocess.Popen(
                        cmd,
                        creationflags=subprocess.CREATE_NEW_CONSOLE,  # optional if you want a new window
                    )

                    # Save PID to DB
                    job_pid = process.pid
                    job_obj.job_pid = job_pid
                    job_obj.save()

                    logger.info(f"Started {spider_name} | PID={job_pid} | job_id={job_id} | folder_path={folder_path}")

                else:
                    logger.warning(f"spider_name: {spider_name} | job_id {job_id} | is_pid_running {is_pid_running} | PID={job_pid} | should_run_job={should_run_job}")

            except:
                logger.error(traceback.format_exc())
    except:
        logger.error(traceback.format_exc())


def run():
    main_max_workers = 3
    thread_max_workers = 5

    jobs_list = list(jobsModel.objects.filter(job_status__in=["queued", "running"]).values_list('id', flat=True))
    jobs_count = len(jobs_list)
    logger.info(f"Found {jobs_count} running jobs")

    if jobs_count == 0:
        return

    job_counter = 0
    job_pids = list(jobsModel.objects.filter(job_status__in=["queued", "running"]).values_list('job_pid', flat=True))
    for job_pid in job_pids:
        if helper.is_pid_running(job_pid):
            job_counter += 1

    if job_counter >= 5:
        return

    jobs_chunks = list(fctcore.split_list_into_chunks(lst=jobs_list, max_workers=main_max_workers))
    if main_max_workers > len(jobs_chunks): main_max_workers = len(jobs_chunks)
    logger.info(f"main_max_workers: {main_max_workers}")
    logger.info(f"thread_max_workers: {thread_max_workers}")

    folder_path = os.path.join(dirname(dirname(abspath(__file__))), 'static', 'files')
    os.makedirs(folder_path, exist_ok=True)

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(), TextColumn("{task.completed}/{task.total}"), TimeElapsedColumn(), TimeRemainingColumn(), transient=False) as progress:
        with concurrent.futures.ThreadPoolExecutor(max_workers=main_max_workers) as executor:
            futures = []
            main_task = progress.add_task(description=f'spiders', total=jobs_count)
            for thread_id, jobs_chunk in enumerate(jobs_chunks):
                thread_task = progress.add_task(f"Thread {thread_id + 1}", total=len(jobs_chunk))
                future = executor.submit(_run_job, jobs_chunk, main_task, thread_task, folder_path, progress, thread_max_workers)
                futures.append(future)

            results = []
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                results.append(result)
