import os
from assets.fct.fctsheet import fctsheet
from assets.fct.fctcore import preg_repace

def run():
    sheet_name = 'Sheet1'
    sheet_key = '1GYmFDC9aKh1T5R63DEJsS-APHEc0IFq7eC6TATCXpCw'
    output_file = r'_0_bat/run_scripts/generated_columns.py'

    fsheet = fctsheet(sheet_key=sheet_key)
    rows = fsheet.get_all_values(sheet_name)

    inisial_columns = []
    logging_columns = []
    df_columns = []
    for r in rows:
        columns = preg_repace(patt=" +", repl="_", subj=preg_repace(patt="\s+", repl=" ", subj=r['Columns'].strip())).lower()
        comments = preg_repace(patt="\s+", repl=" ", subj=r['Comments'].strip())
        sample = preg_repace(patt="\s+", repl=" ", subj=r['Sample data'].strip())

        inisial_columns.append(f'{columns} = "" #Comments: {comments} #Sample: {sample}')
        logging_columns.append("logger.info(f'"+columns+": {"+columns+"}')")
        df_columns.append('\t'+columns+'='+columns+',')

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("\n".join(inisial_columns))
        f.write("\n\n")
        f.write("\n".join(logging_columns))
        f.write("\nlogger.info('*' * 50)\n\n")
        f.write("\nJobsItemsModel(\n")
        f.write("\tspider_id=spider_id,\n")
        f.write("\tjob_id=job_id,\n")
        f.write("\n".join(df_columns))
        f.write("\n).save()")
        f.write("\n")

    print(f"Saved to {os.path.abspath(output_file)}")

