import time
import concurrent.futures
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn
from assets.fct.fctlog import logger
from assets.fct import fctcore
from scripts.billiejeankingcup.parser.details import DetailsParser
from scripts import helper
from app_spiders.models import jobsModel

start_dt = time.time()

def run(*args):
    params = list(args)
    job_id = int(params[0])
    spider_name = params[1]
    folder_path = params[2]
    max_workers = int(params[3])

    base_file = f'{spider_name}__{job_id}__{fctcore.current_date("%Y-%m-%d_%H-%M")}.csv'

    job_obj = jobsModel.objects.get(id=job_id)
    spider_id = job_obj.spider_id
    job_settings = job_obj.job_settings
    job_rank_year = job_settings.get('rank_year', '')
    logger.info(f'job_spider: {spider_name} | job_id: {job_id} | job_rank_year: {job_rank_year}')

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(), TextColumn("{task.completed}/{task.total}"), TimeElapsedColumn(), TimeRemainingColumn(), transient=False) as progress:
        df_ties = DetailsParser(progress).parse_ties(job_id, job_rank_year)
        logger.info(f'df_ties: {len(df_ties)}')

        if not df_ties.empty:
            ties_list = df_ties.to_dict("records")
            ties_chunks = list(fctcore.split_list_into_chunks(lst=ties_list, max_workers=max_workers))
            if max_workers > len(ties_chunks): max_workers=len(ties_chunks)

            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                main_task = progress.add_task(description=f'{spider_name}_results', total=len(ties_list))
                for thread_id, ties_chunk in enumerate(ties_chunks):
                    thread_task = progress.add_task(f"Thread {thread_id + 1}", total=len(ties_chunk))
                    executor.submit(DetailsParser(progress).parse_site, spider_id, job_id, ties_chunk, main_task, thread_task, progress)

        helper.finalize_items_from_db(job_obj, folder_path, base_file)
        helper.finalize_job(job_obj, base_file, folder_path)

    logger.info(f'script take {round(time.time()-start_dt, 2)} sec to finished')
