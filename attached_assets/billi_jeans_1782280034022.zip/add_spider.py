import traceback, time, os
import concurrent.futures
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn
from django.db import close_old_connections
from assets.fct import fctcore
from assets.fct.fctlog import logger
from app_spiders.models import spidersModel

start_dt = time.time()

def _create_spider(spiders_chunk, main_task, thread_task, progress):
    try:
        for spider_name in spiders_chunk:
            progress.update(main_task, advance=1)
            progress.update(thread_task, advance=1)
            close_old_connections()

            try:
                if not spidersModel.objects.filter(spider_name=spider_name).exists():
                    logger.info(f"new: spider_name: {spider_name}")
                    spidersModel(
                        spider_name=spider_name,
                        spider_type='manuel',
                    ).save()

                else:
                    logger.warning(f"exist: spider_name: {spider_name}")

            except:
                logger.error(traceback.format_exc())
    except:
        logger.error(traceback.format_exc())


def run():
    max_workers = 5

    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    EXCLUDE = {"itftennis", "__pycache__", ".git", ".venv", ".idea"}
    spiders_list = [name.replace('_', ' ').title() for name in os.listdir(BASE_DIR) if os.path.isdir(os.path.join(BASE_DIR, name)) and name not in EXCLUDE]
    logger.info(f'spiders: {spiders_list}')

    spiders_count = len(spiders_list)
    logger.info(f"Found {spiders_count} spiders")

    if spiders_count == 0:
        return

    spiders_chunks = list(fctcore.split_list_into_chunks(lst=spiders_list, max_workers=max_workers))
    if max_workers > len(spiders_chunks): main_max_workers = len(spiders_chunks)

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(), TextColumn("{task.completed}/{task.total}"), TimeElapsedColumn(), TimeRemainingColumn(), transient=False) as progress:
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = []
            main_task = progress.add_task(description=f'spiders', total=spiders_count)
            for thread_id, spiders_chunk in enumerate(spiders_chunks):
                thread_task = progress.add_task(f"Thread {thread_id + 1}", total=len(spiders_chunk))
                future = executor.submit(_create_spider, spiders_chunk, main_task, thread_task, progress)
                futures.append(future)

            results = []
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                results.append(result)
