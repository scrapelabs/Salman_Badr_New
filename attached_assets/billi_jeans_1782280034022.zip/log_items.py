import threading
import pandas as pd
from assets.fct.fctlog import logger


class ItemsLogger:

    def __init__(self):
        self._lock = threading.Lock()
        self._rows = []                 # store rows in memory

    def log(self, data: dict):
        try:
            with self._lock:
                # keep in memory
                self._rows.append(data)

        except Exception as e:
            logger.error(f"[ItemsLogger] log() failed: {e}")


    def get_df(self) -> pd.DataFrame:
        try:
            with self._lock:
                return pd.DataFrame(self._rows)
        except Exception as e:
            logger.error(f"[ItemsLogger] get_df() failed: {e}")
            return pd.DataFrame()