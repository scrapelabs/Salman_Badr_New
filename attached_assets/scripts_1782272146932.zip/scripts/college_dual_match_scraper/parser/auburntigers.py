import traceback, random
import xml.etree.ElementTree as ET
from openai import OpenAI
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts import helper
from scrapy.selector import Selector
from urllib.parse import urlparse
from app_spiders.models import JobsItemsCollegeDualMatchScraperModel

class auburntigersParser:

    def __init__(self):
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=False, use_proxy=self.use_proxy)
        self.api_key = random.choice(settings.API_KEYS)
        self.ai_client = OpenAI(api_key=self.api_key)


    def parse_site(self, spider_id, job_id, job_tournament_url):
        items_found = False
        try:
            logger.info(f'auburntigers | job_tournament_url: {job_tournament_url}')

            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }
            response1 = self.fctrequest.request(method='GET', link=job_tournament_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    winner_team, loser_team, team_score = self.parse_team_data(html1)
                    logger.info(f'winner_team: {winner_team}')
                    logger.info(f'loser_team: {loser_team}')
                    logger.info(f'team_score: {team_score}')

                    if winner_team and loser_team and team_score:
                        tournament_name_pre = f"Dual Match: {winner_team} vs {loser_team}"
                        logger.info(f'tournament_name_pre: {tournament_name_pre}')

                        tournament_date = fctcore.convert_string_to_date_format(fctcore.parse_field('//div[@class="boxscore-game-info-item" and span[@class="boxscore-game-info-item__name" and text()="Date"]]/span[@class="boxscore-game-info-item__value"]', html1), in_format='%a, %b. %d (%Y)', out_format='%m/%d/%Y', job_tournament_url=job_tournament_url)
                        logger.info(f'tournament_date: {tournament_date}')

                        items_found = self.parse_table_api(spider_id, job_id, job_tournament_url, tournament_date, tournament_name_pre, winner_team, loser_team, team_score)

        except Exception:
            logger.error(traceback.format_exc())

        return items_found

    def parse_table_api(self, spider_id, job_id, job_tournament_url, tournament_date, tournament_name_pre, winner_team, loser_team, team_score):
        items_found = False
        try:
            tournament_id = ''
            try:
                path_parts = urlparse(job_tournament_url).path.strip("/").split("/")
                idx = path_parts.index("boxscore")
                tournament_id = path_parts[idx + 1]
            except Exception:
                ''
            logger.info(f'tournament_id: {tournament_id}')

            job_tournament_url_api = f'https://stats.{fctcore.extract_domain(job_tournament_url)}/api/v1/game/xml/{tournament_id}'
            logger.info(f'job_tournament_url_api: {job_tournament_url_api}')

            headers = {
                'accept': 'application/json, text/plain, */*',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }
            response1 = self.fctrequest.request(method='GET', link=job_tournament_url_api, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    matchs_data = self.parse_all(response1.text)

                    players_names = []
                    for match_data in matchs_data:
                        winner_1_name = match_data.get('winner_1_name', '')
                        winner_2_name = match_data.get('winner_2_name', '')
                        loser_1_name = match_data.get('loser_1_name', '')
                        loser_2_name = match_data.get('loser_2_name', '')
                        if winner_1_name: players_names.append(winner_1_name)
                        if winner_2_name: players_names.append(winner_2_name)
                        if loser_1_name: players_names.append(loser_1_name)
                        if loser_2_name: players_names.append(loser_2_name)

                    players_names = list(set(players_names))
                    logger.info(f'players_names: {players_names}')

                    draw_gender = helper.get_gender_from_players_list_gpt(players_names, self.ai_client)
                    logger.info(f'draw_gender: {draw_gender}')

                    for match_data in matchs_data:
                        items_found = self.parse_page(spider_id, job_id, job_tournament_url, tournament_date, tournament_name_pre, winner_team, loser_team, team_score, draw_gender, match_data)

        except Exception:
            logger.error(traceback.format_exc())

        return items_found


    def parse_page(self, spider_id, job_id, job_tournament_url, tournament_date, tournament_name_pre, winner_team, loser_team, team_score, draw_gender, match_data):
        items_found = False
        try:
            match_id = ""
            ball_type = "Yellow"
            draw_bracket_value = ""
            draw_name = ""
            draw_team_type = ""
            tournament_name = ""
            date = tournament_date
            score = ""
            winner_1_name = ""
            winner_1_gender = ""
            winner_1_third_party_id = ""
            winner_1_city = ""
            winner_1_country = ""
            winner_1_state = ""
            winner_2_name = ""
            winner_2_gender = ""
            winner_2_third_party_id = ""
            winner_2_city = ""
            winner_2_state = ""
            loser_1_name = ""
            loser_1_gender = ""
            loser_1_third_party_id = ""
            loser_1_city = ""
            loser_1_state = ""
            loser_1_country = ""
            loser_2_name = ""
            loser_2_gender = ""
            loser_2_third_party_id = ""
            loser_2_city = ""
            loser_2_state = ""
            outcome = "Completed"
            id_type = ""
            draw_bracket_type = ""
            draw_type = ""
            tournament_city = ""
            tournament_state = ""
            tournament_country_code = "USA"
            tournament_host = ""
            tournament_location_type = ""
            tournament_surface = ""
            tournament_event_category = ""
            tournament_event_grade = ""
            tournament_import_source = "College"
            tournament_sanction_body = "College"
            winner_2_country = ""
            winner_2_college = ""
            loser_2_country = ""
            loser_2_college = ""
            tournament_event_type = "Dual Match"
            winner_1_college = ""
            loser_1_college = ""
            tournament_url = job_tournament_url
            winner_1_dob = ""
            winner_2_dob = ""
            loser_1_dob = ""
            loser_2_dob = ""
            tournament_country = "USA"
            tournament_start_date = tournament_date
            tournament_end_date = tournament_date
            winner_team_type = "College"
            loser_team_type = "College"

            draw_name = match_data.get('draw_name', '')
            draw_team_type = match_data.get('draw_team_type', '')
            score = match_data.get('score', '')
            winner_1_name = match_data.get('winner_1_name', '')
            winner_2_name = match_data.get('winner_2_name', '')
            loser_1_name = match_data.get('loser_1_name', '')
            loser_2_name = match_data.get('loser_2_name', '')
            winner_college = match_data.get('winner_college', '')
            loser_college = match_data.get('loser_college', '')

            if winner_1_name and loser_1_name:
                results_colleges = helper.convert_college_name(input_college_1=winner_college, input_college_2=loser_college, output_college_1=winner_team, output_college_2=loser_team, ai_client=self.ai_client)
                logger.info(f'results_colleges: {results_colleges}')

                winner_college_formatted = results_colleges.get(winner_college, '')
                loser_college_formatted = results_colleges.get(loser_college, '')

                winner_1_college = winner_2_college = winner_college_formatted
                loser_1_college = loser_2_college = loser_college_formatted

                player_gender = ''
                tournament_gender = ''
                if draw_gender == "Male":
                    player_gender = 'M'
                    tournament_gender = 'Men'

                elif draw_gender == "Female":
                    player_gender = 'F'
                    tournament_gender = 'Women'

                if player_gender:
                    if winner_1_name:
                        winner_1_gender = player_gender

                    if winner_2_name:
                        winner_2_gender = player_gender

                    if loser_1_name:
                        loser_1_gender = player_gender

                    if loser_2_name:
                        loser_2_gender = player_gender

                if draw_team_type == 'Singles':
                    winner_2_college = loser_2_college = ''
                    winner_2_gender = loser_2_gender = ''

                if tournament_gender:
                    tournament_name = f'{tournament_name_pre} - {tournament_gender}'
                else:
                    tournament_name = tournament_name_pre

                logger.info(f'match_id: {match_id}')
                logger.info(f'ball_type: {ball_type}')
                logger.info(f'draw_bracket_value: {draw_bracket_value}')
                logger.info(f'draw_name: {draw_name}')
                logger.info(f'draw_team_type: {draw_team_type}')
                logger.info(f'tournament_name: {tournament_name}')
                logger.info(f'date: {date}')
                logger.info(f'score: {score}')
                logger.info(f'winner_1_name: {winner_1_name}')
                logger.info(f'winner_1_gender: {winner_1_gender}')
                logger.info(f'winner_1_third_party_id: {winner_1_third_party_id}')
                logger.info(f'winner_1_city: {winner_1_city}')
                logger.info(f'winner_1_country: {winner_1_country}')
                logger.info(f'winner_1_state: {winner_1_state}')
                logger.info(f'winner_2_name: {winner_2_name}')
                logger.info(f'winner_2_gender: {winner_2_gender}')
                logger.info(f'winner_2_third_party_id: {winner_2_third_party_id}')
                logger.info(f'winner_2_city: {winner_2_city}')
                logger.info(f'winner_2_state: {winner_2_state}')
                logger.info(f'loser_1_name: {loser_1_name}')
                logger.info(f'loser_1_gender: {loser_1_gender}')
                logger.info(f'loser_1_third_party_id: {loser_1_third_party_id}')
                logger.info(f'loser_1_city: {loser_1_city}')
                logger.info(f'loser_1_state: {loser_1_state}')
                logger.info(f'loser_1_country: {loser_1_country}')
                logger.info(f'loser_2_name: {loser_2_name}')
                logger.info(f'loser_2_gender: {loser_2_gender}')
                logger.info(f'loser_2_third_party_id: {loser_2_third_party_id}')
                logger.info(f'loser_2_city: {loser_2_city}')
                logger.info(f'loser_2_state: {loser_2_state}')
                logger.info(f'outcome: {outcome}')
                logger.info(f'id_type: {id_type}')
                logger.info(f'draw_gender: {draw_gender}')
                logger.info(f'draw_bracket_type: {draw_bracket_type}')
                logger.info(f'draw_type: {draw_type}')
                logger.info(f'tournament_city: {tournament_city}')
                logger.info(f'tournament_state: {tournament_state}')
                logger.info(f'tournament_country_code: {tournament_country_code}')
                logger.info(f'tournament_host: {tournament_host}')
                logger.info(f'tournament_location_type: {tournament_location_type}')
                logger.info(f'tournament_surface: {tournament_surface}')
                logger.info(f'tournament_event_category: {tournament_event_category}')
                logger.info(f'tournament_event_grade: {tournament_event_grade}')
                logger.info(f'tournament_import_source: {tournament_import_source}')
                logger.info(f'tournament_sanction_body: {tournament_sanction_body}')
                logger.info(f'winner_2_country: {winner_2_country}')
                logger.info(f'winner_2_college: {winner_2_college}')
                logger.info(f'loser_2_country: {loser_2_country}')
                logger.info(f'loser_2_college: {loser_2_college}')
                logger.info(f'tournament_event_type: {tournament_event_type}')
                logger.info(f'winner_1_college: {winner_1_college}')
                logger.info(f'loser_1_college: {loser_1_college}')
                logger.info(f'tournament_url: {tournament_url}')
                logger.info(f'winner_1_dob: {winner_1_dob}')
                logger.info(f'winner_2_dob: {winner_2_dob}')
                logger.info(f'loser_1_dob: {loser_1_dob}')
                logger.info(f'loser_2_dob: {loser_2_dob}')
                logger.info(f'tournament_country: {tournament_country}')
                logger.info(f'tournament_start_date: {tournament_start_date}')
                logger.info(f'tournament_end_date: {tournament_end_date}')
                logger.info(f'winner_team: {winner_team}')
                logger.info(f'loser_team: {loser_team}')
                logger.info(f'team_score: {team_score}')
                logger.info(f'winner_team_type: {winner_team_type}')
                logger.info(f'loser_team_type: {loser_team_type}')
                logger.info('*' * 50)

                if winner_team and loser_team and team_score and winner_1_name and loser_1_name:
                    items_found = True
                    JobsItemsCollegeDualMatchScraperModel(
                        spider_id=spider_id,
                        job_id=job_id,
                        match_id=match_id,
                        ball_type=ball_type,
                        draw_bracket_value=draw_bracket_value,
                        draw_name=draw_name,
                        draw_team_type=draw_team_type,
                        tournament_name=tournament_name,
                        date=date,
                        score=score,
                        winner_1_name=winner_1_name,
                        winner_1_gender=winner_1_gender,
                        winner_1_third_party_id=winner_1_third_party_id,
                        winner_1_city=winner_1_city,
                        winner_1_country=winner_1_country,
                        winner_1_state=winner_1_state,
                        winner_2_name=winner_2_name,
                        winner_2_gender=winner_2_gender,
                        winner_2_third_party_id=winner_2_third_party_id,
                        winner_2_city=winner_2_city,
                        winner_2_state=winner_2_state,
                        loser_1_name=loser_1_name,
                        loser_1_gender=loser_1_gender,
                        loser_1_third_party_id=loser_1_third_party_id,
                        loser_1_city=loser_1_city,
                        loser_1_state=loser_1_state,
                        loser_1_country=loser_1_country,
                        loser_2_name=loser_2_name,
                        loser_2_gender=loser_2_gender,
                        loser_2_third_party_id=loser_2_third_party_id,
                        loser_2_city=loser_2_city,
                        loser_2_state=loser_2_state,
                        outcome=outcome,
                        id_type=id_type,
                        draw_gender=draw_gender,
                        draw_bracket_type=draw_bracket_type,
                        draw_type=draw_type,
                        tournament_city=tournament_city,
                        tournament_state=tournament_state,
                        tournament_country_code=tournament_country_code,
                        tournament_host=tournament_host,
                        tournament_location_type=tournament_location_type,
                        tournament_surface=tournament_surface,
                        tournament_event_category=tournament_event_category,
                        tournament_event_grade=tournament_event_grade,
                        tournament_import_source=tournament_import_source,
                        tournament_sanction_body=tournament_sanction_body,
                        winner_2_country=winner_2_country,
                        winner_2_college=winner_2_college,
                        loser_2_country=loser_2_country,
                        loser_2_college=loser_2_college,
                        tournament_event_type=tournament_event_type,
                        winner_1_college=winner_1_college,
                        loser_1_college=loser_1_college,
                        tournament_url=tournament_url,
                        winner_1_dob=winner_1_dob,
                        winner_2_dob=winner_2_dob,
                        loser_1_dob=loser_1_dob,
                        loser_2_dob=loser_2_dob,
                        tournament_country=tournament_country,
                        tournament_start_date=tournament_start_date,
                        tournament_end_date=tournament_end_date,
                        winner_team=winner_team,
                        loser_team=loser_team,
                        team_score=team_score,
                        winner_team_type=winner_team_type,
                        loser_team_type=loser_team_type,
                    ).save()

        except Exception:
            logger.error(traceback.format_exc())

        return items_found

    def _fmt_name(self, name):
        name = name.strip()
        if "," in name:
            return name
        parts = name.split()
        return f"{parts[-1]}, {' '.join(parts[:-1])}"

    def _get_colleges(self, root):
        colleges = {}
        for team in root.findall("team"):
            colleges[team.get("vh")] = team.get("name")
        return colleges

    def _build_score(self, winner, loser):
        parts = []
        for i in range(1, 6):
            w = winner.get(f"set_{i}")
            l = loser.get(f"set_{i}")
            if w is None or l is None:
                break
            parts.append(f"{w}-{l}")
        return " ".join(parts) + ";"

    def parse_singles(self, root, colleges):
        results = []

        for match in root.findall(".//singles_match"):
            scores = match.findall("singles_score")
            if len(scores) != 2:
                continue

            a, b = scores

            def wins(x, y):
                c = 0
                for i in range(1, 6):
                    sx, sy = x.get(f"set_{i}"), y.get(f"set_{i}")
                    if sx and sy and int(sx) > int(sy):
                        c += 1
                return c

            winner, loser = (a, b) if wins(a, b) > wins(b, a) else (b, a)

            results.append({
                "draw_team_type": "Singles",
                "draw_name": f"#{match.get('match')} Singles",
                "winner_1_name": helper.clean_name(self._fmt_name(winner.get("name"))),
                "winner_2_name": "",
                "loser_1_name": helper.clean_name(self._fmt_name(loser.get("name"))),
                "loser_2_name": "",
                "winner_college": colleges[winner.get("vh")],
                "loser_college": colleges[loser.get("vh")],
                "score": self._build_score(winner, loser),
            })

        return results

    def parse_doubles(self, root, colleges):
        results = []

        for match in root.findall(".//doubles_match"):
            scores = match.findall("doubles_score")
            if len(scores) != 2:
                continue

            a, b = scores
            winner, loser = (a, b) if int(a.get("set_1")) > int(b.get("set_1")) else (b, a)

            results.append({
                "draw_team_type": "Doubles",
                "draw_name": f"#{match.get('match')} Doubles",
                "winner_1_name": helper.clean_name(self._fmt_name(winner.get("name_1"))),
                "winner_2_name": helper.clean_name(self._fmt_name(winner.get("name_2"))),
                "loser_1_name": helper.clean_name(self._fmt_name(loser.get("name_1"))),
                "loser_2_name": helper.clean_name(self._fmt_name(loser.get("name_2"))),
                "winner_college": colleges[winner.get("vh")],
                "loser_college": colleges[loser.get("vh")],
                "score": f"{winner.get('set_1')}-{loser.get('set_1')};",
            })

        return results

    def parse_all(self, xml_text):
        root = ET.fromstring(xml_text)
        colleges = self._get_colleges(root)
        return self.parse_doubles(root, colleges) + self.parse_singles(root, colleges)

    def parse_team_data(self, html1):
        teams = html1.xpath('//div[contains(@class,"boxscore-teams-info__team")]')

        names = teams.xpath('.//img/@alt').getall()

        score_txt = html1.xpath(
            '//div[contains(@class,"boxscore-teams-info__score-points")]/text()'
        ).get()

        if not score_txt or len(names) != 2:
            return "", "", ""

        # score like "7-0"
        try:
            s1, s2 = map(int, score_txt.strip().split('-'))
        except ValueError:
            return "", "", ""

        team1, team2 = names[0].strip(), names[1].strip()

        if s1 > s2:
            winner_team, loser_team = team1, team2
            team_score = f"{s1}-{s2};"
        else:
            winner_team, loser_team = team2, team1
            team_score = f"{s2}-{s1};"

        winner_team = helper.get_official_college_name(winner_team, self.ai_client)
        loser_team = helper.get_official_college_name(loser_team, self.ai_client)

        return winner_team, loser_team, team_score
