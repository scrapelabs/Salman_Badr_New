import traceback, random, re
from openai import OpenAI
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts import helper
from scrapy.selector import Selector
from app_spiders.models import JobsItemsCollegeDualMatchScraperModel

class albertusfalconsParser:

    def __init__(self):
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=False, use_proxy=self.use_proxy)
        self.api_key = random.choice(settings.API_KEYS)
        self.ai_client = OpenAI(api_key=self.api_key)


    def parse_site(self, spider_id, job_id, job_tournament_url):
        items_found = False
        try:
            logger.info(f'albertusfalcons | job_tournament_url: {job_tournament_url}')

            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }
            response1 = self.fctrequest.request(method='GET', link=job_tournament_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    winner_team, loser_team, team_score = self.parse_team_data(html1)
                    logger.info(f'winner_team: {winner_team}')
                    logger.info(f'loser_team: {loser_team}')
                    logger.info(f'team_score: {team_score}')

                    if winner_team and loser_team and team_score:
                        tournament_name_pre = f"Dual Match: {winner_team} vs {loser_team}"
                        logger.info(f'tournament_name_pre: {tournament_name_pre}')

                        tournament_date = fctcore.convert_string_to_date_format(fctcore.parse_field('//div[contains(@class,"align-center")]/text()[contains(normalize-space(.), " at ")]', html1).split(' at ')[0].strip(), list_in_format=['%b %d, %Y', '%m/%d/%Y'], out_format='%m/%d/%Y', job_tournament_url=job_tournament_url)
                        logger.info(f'tournament_date: {tournament_date}')

                        players_names = []
                        for d1 in html1.xpath('//div[contains(@class, "stats-halfbox")]//table'):
                            for res in self.extract_all_player_names(d1):
                                players_names.append(res)
                        players_names = list(set(players_names))
                        logger.info(f'players_names: {players_names}')

                        draw_gender = helper.get_gender_from_players_list_gpt(players_names, self.ai_client)
                        logger.info(f'draw_gender: {draw_gender}')

                        for d1 in html1.xpath('//div[contains(@class, "stats-halfbox")]//table'):
                            items_found = self.parse_page(spider_id, job_id, job_tournament_url, tournament_date, tournament_name_pre, winner_team, loser_team, team_score, draw_gender, d1)

        except Exception:
            logger.error(traceback.format_exc())

        return items_found


    def parse_page(self, spider_id, job_id, job_tournament_url, tournament_date, tournament_name_pre, winner_team, loser_team, team_score, draw_gender, d1):
        items_found = False
        try:
            match_id = ""
            ball_type = "Yellow"
            draw_bracket_value = ""
            draw_name = ""
            draw_team_type = ""
            tournament_name = ""
            date = tournament_date
            score = ""
            winner_1_name = ""
            winner_1_gender = ""
            winner_1_third_party_id = ""
            winner_1_city = ""
            winner_1_country = ""
            winner_1_state = ""
            winner_2_name = ""
            winner_2_gender = ""
            winner_2_third_party_id = ""
            winner_2_city = ""
            winner_2_state = ""
            loser_1_name = ""
            loser_1_gender = ""
            loser_1_third_party_id = ""
            loser_1_city = ""
            loser_1_state = ""
            loser_1_country = ""
            loser_2_name = ""
            loser_2_gender = ""
            loser_2_third_party_id = ""
            loser_2_city = ""
            loser_2_state = ""
            outcome = "Completed"
            id_type = ""
            draw_bracket_type = ""
            draw_type = ""
            tournament_city = ""
            tournament_state = ""
            tournament_country_code = "USA"
            tournament_host = ""
            tournament_location_type = ""
            tournament_surface = ""
            tournament_event_category = ""
            tournament_event_grade = ""
            tournament_import_source = "College"
            tournament_sanction_body = "College"
            winner_2_country = ""
            winner_2_college = ""
            loser_2_country = ""
            loser_2_college = ""
            tournament_event_type = "Dual Match"
            winner_1_college = ""
            loser_1_college = ""
            tournament_url = job_tournament_url
            winner_1_dob = ""
            winner_2_dob = ""
            loser_1_dob = ""
            loser_2_dob = ""
            tournament_country = "USA"
            tournament_start_date = tournament_date
            tournament_end_date = tournament_date
            winner_team_type = "College"
            loser_team_type = "College"

            match_data = self.parse_match(d1)
            logger.info(f'match_data: {match_data}')

            draw_name = match_data.get('draw_name', '')
            draw_team_type = match_data.get('draw_team_type', '')
            score = match_data.get('score', '')
            winner_1_name = match_data.get('winner_1_name', '')
            winner_2_name = match_data.get('winner_2_name', '')
            loser_1_name = match_data.get('loser_1_name', '')
            loser_2_name = match_data.get('loser_2_name', '')
            winner_college = match_data.get('winner_college', '')
            loser_college = match_data.get('loser_college', '')

            if winner_1_name and loser_1_name:
                results_colleges = helper.convert_college_name(input_college_1=winner_college, input_college_2=loser_college, output_college_1=winner_team, output_college_2=loser_team, ai_client=self.ai_client)
                logger.info(f'results_colleges: {results_colleges}')

                winner_college_formatted = results_colleges.get(winner_college, '')
                loser_college_formatted = results_colleges.get(loser_college, '')

                winner_1_college = winner_2_college = winner_college_formatted
                loser_1_college = loser_2_college = loser_college_formatted

                player_gender = ''
                tournament_gender = ''
                if draw_gender == "Male":
                    player_gender = 'M'
                    tournament_gender = 'Men'

                elif draw_gender == "Female":
                    player_gender = 'F'
                    tournament_gender = 'Women'

                if player_gender:
                    if winner_1_name:
                        winner_1_gender = player_gender

                    if winner_2_name:
                        winner_2_gender = player_gender

                    if loser_1_name:
                        loser_1_gender = player_gender

                    if loser_2_name:
                        loser_2_gender = player_gender

                if draw_team_type == 'Singles':
                    winner_2_college = loser_2_college = ''
                    winner_2_gender = loser_2_gender = ''

                if tournament_gender:
                    tournament_name = f'{tournament_name_pre} - {tournament_gender}'
                else:
                    tournament_name = tournament_name_pre

                logger.info(f'match_id: {match_id}')
                logger.info(f'ball_type: {ball_type}')
                logger.info(f'draw_bracket_value: {draw_bracket_value}')
                logger.info(f'draw_name: {draw_name}')
                logger.info(f'draw_team_type: {draw_team_type}')
                logger.info(f'tournament_name: {tournament_name}')
                logger.info(f'date: {date}')
                logger.info(f'score: {score}')
                logger.info(f'winner_1_name: {winner_1_name}')
                logger.info(f'winner_1_gender: {winner_1_gender}')
                logger.info(f'winner_1_third_party_id: {winner_1_third_party_id}')
                logger.info(f'winner_1_city: {winner_1_city}')
                logger.info(f'winner_1_country: {winner_1_country}')
                logger.info(f'winner_1_state: {winner_1_state}')
                logger.info(f'winner_2_name: {winner_2_name}')
                logger.info(f'winner_2_gender: {winner_2_gender}')
                logger.info(f'winner_2_third_party_id: {winner_2_third_party_id}')
                logger.info(f'winner_2_city: {winner_2_city}')
                logger.info(f'winner_2_state: {winner_2_state}')
                logger.info(f'loser_1_name: {loser_1_name}')
                logger.info(f'loser_1_gender: {loser_1_gender}')
                logger.info(f'loser_1_third_party_id: {loser_1_third_party_id}')
                logger.info(f'loser_1_city: {loser_1_city}')
                logger.info(f'loser_1_state: {loser_1_state}')
                logger.info(f'loser_1_country: {loser_1_country}')
                logger.info(f'loser_2_name: {loser_2_name}')
                logger.info(f'loser_2_gender: {loser_2_gender}')
                logger.info(f'loser_2_third_party_id: {loser_2_third_party_id}')
                logger.info(f'loser_2_city: {loser_2_city}')
                logger.info(f'loser_2_state: {loser_2_state}')
                logger.info(f'outcome: {outcome}')
                logger.info(f'id_type: {id_type}')
                logger.info(f'draw_gender: {draw_gender}')
                logger.info(f'draw_bracket_type: {draw_bracket_type}')
                logger.info(f'draw_type: {draw_type}')
                logger.info(f'tournament_city: {tournament_city}')
                logger.info(f'tournament_state: {tournament_state}')
                logger.info(f'tournament_country_code: {tournament_country_code}')
                logger.info(f'tournament_host: {tournament_host}')
                logger.info(f'tournament_location_type: {tournament_location_type}')
                logger.info(f'tournament_surface: {tournament_surface}')
                logger.info(f'tournament_event_category: {tournament_event_category}')
                logger.info(f'tournament_event_grade: {tournament_event_grade}')
                logger.info(f'tournament_import_source: {tournament_import_source}')
                logger.info(f'tournament_sanction_body: {tournament_sanction_body}')
                logger.info(f'winner_2_country: {winner_2_country}')
                logger.info(f'winner_2_college: {winner_2_college}')
                logger.info(f'loser_2_country: {loser_2_country}')
                logger.info(f'loser_2_college: {loser_2_college}')
                logger.info(f'tournament_event_type: {tournament_event_type}')
                logger.info(f'winner_1_college: {winner_1_college}')
                logger.info(f'loser_1_college: {loser_1_college}')
                logger.info(f'tournament_url: {tournament_url}')
                logger.info(f'winner_1_dob: {winner_1_dob}')
                logger.info(f'winner_2_dob: {winner_2_dob}')
                logger.info(f'loser_1_dob: {loser_1_dob}')
                logger.info(f'loser_2_dob: {loser_2_dob}')
                logger.info(f'tournament_country: {tournament_country}')
                logger.info(f'tournament_start_date: {tournament_start_date}')
                logger.info(f'tournament_end_date: {tournament_end_date}')
                logger.info(f'winner_team: {winner_team}')
                logger.info(f'loser_team: {loser_team}')
                logger.info(f'team_score: {team_score}')
                logger.info(f'winner_team_type: {winner_team_type}')
                logger.info(f'loser_team_type: {loser_team_type}')
                logger.info('*' * 50)

                if winner_team and loser_team and team_score and winner_1_name and loser_1_name:
                    items_found = True
                    JobsItemsCollegeDualMatchScraperModel(
                        spider_id=spider_id,
                        job_id=job_id,
                        match_id=match_id,
                        ball_type=ball_type,
                        draw_bracket_value=draw_bracket_value,
                        draw_name=draw_name,
                        draw_team_type=draw_team_type,
                        tournament_name=tournament_name,
                        date=date,
                        score=score,
                        winner_1_name=winner_1_name,
                        winner_1_gender=winner_1_gender,
                        winner_1_third_party_id=winner_1_third_party_id,
                        winner_1_city=winner_1_city,
                        winner_1_country=winner_1_country,
                        winner_1_state=winner_1_state,
                        winner_2_name=winner_2_name,
                        winner_2_gender=winner_2_gender,
                        winner_2_third_party_id=winner_2_third_party_id,
                        winner_2_city=winner_2_city,
                        winner_2_state=winner_2_state,
                        loser_1_name=loser_1_name,
                        loser_1_gender=loser_1_gender,
                        loser_1_third_party_id=loser_1_third_party_id,
                        loser_1_city=loser_1_city,
                        loser_1_state=loser_1_state,
                        loser_1_country=loser_1_country,
                        loser_2_name=loser_2_name,
                        loser_2_gender=loser_2_gender,
                        loser_2_third_party_id=loser_2_third_party_id,
                        loser_2_city=loser_2_city,
                        loser_2_state=loser_2_state,
                        outcome=outcome,
                        id_type=id_type,
                        draw_gender=draw_gender,
                        draw_bracket_type=draw_bracket_type,
                        draw_type=draw_type,
                        tournament_city=tournament_city,
                        tournament_state=tournament_state,
                        tournament_country_code=tournament_country_code,
                        tournament_host=tournament_host,
                        tournament_location_type=tournament_location_type,
                        tournament_surface=tournament_surface,
                        tournament_event_category=tournament_event_category,
                        tournament_event_grade=tournament_event_grade,
                        tournament_import_source=tournament_import_source,
                        tournament_sanction_body=tournament_sanction_body,
                        winner_2_country=winner_2_country,
                        winner_2_college=winner_2_college,
                        loser_2_country=loser_2_country,
                        loser_2_college=loser_2_college,
                        tournament_event_type=tournament_event_type,
                        winner_1_college=winner_1_college,
                        loser_1_college=loser_1_college,
                        tournament_url=tournament_url,
                        winner_1_dob=winner_1_dob,
                        winner_2_dob=winner_2_dob,
                        loser_1_dob=loser_1_dob,
                        loser_2_dob=loser_2_dob,
                        tournament_country=tournament_country,
                        tournament_start_date=tournament_start_date,
                        tournament_end_date=tournament_end_date,
                        winner_team=winner_team,
                        loser_team=loser_team,
                        team_score=team_score,
                        winner_team_type=winner_team_type,
                        loser_team_type=loser_team_type,
                    ).save()

        except Exception:
            logger.error(traceback.format_exc())

        return items_found

    def format_lastname_firstname(self, name):
        parts = name.strip().split()
        if len(parts) < 2:
            return name.strip()
        return f"{' '.join(parts[1:])}, {parts[0]}"

    def extract_players(self, raw):
        """
        Handles:
        - Singles / Doubles
        - Nested colleges like (Regis (Mass.))
        - Does NOT corrupt names
        """
        raw = re.sub(r'\s+', ' ', raw).strip()

        # split doubles players
        parts = [p.strip() for p in raw.split('/') if p.strip()]
        players = []

        for p in parts:
            # ---- extract college (last parentheses block, supports nested) ----
            college = ""
            matches = re.findall(r'\(([^()]*(?:\([^()]*\)[^()]*)*)\)', raw)
            if matches:
                college = matches[-1].strip()

            # ---- clean name safely ----
            if '(' in p:
                name_only = p[:p.find('(')].strip()
            else:
                name_only = p.strip()

            name_fmt = self.format_lastname_firstname(name_only)

            players.append({
                "name": name_fmt,
                "college": college
            })

        return players

    def extract_scores(self, row):
        scores = []
        for td in row.xpath('.//td[contains(@class,"align-center")]'):
            txt = td.xpath('normalize-space(text())').get()
            if txt and txt.isdigit():
                scores.append(txt)
        return scores


    def parse_match(self, table_html):
        sel = Selector(text=table_html.get())

        title = sel.xpath(
            './/tr[contains(@class,"title-row")]//span[1]/text()'
        ).get(default='').strip()

        rows = sel.xpath('.//tr[td and not(contains(@class,"title-row"))]')
        if len(rows) != 2:
            return {
                "draw_name": "",
                "draw_team_type": "",
                "winner_1_name": "",
                "winner_2_name": "",
                "winner_college": "",
                "loser_1_name": "",
                "loser_2_name": "",
                "loser_college": "",
                "score": "",
            }

        entries = []
        for row in rows:
            is_winner = bool(row.xpath('.//strong[contains(text(),">")]'))

            raw_name = ' '.join(
                t.strip()
                for t in row.xpath('.//td[1]//text()').getall()
                if t.strip() and t.strip() != '>'
            )

            entries.append({
                "players": self.extract_players(raw_name),
                "scores": self.extract_scores(row),
                "is_winner": is_winner
            })

        win = entries[0] if entries[0]["is_winner"] else entries[1]
        los = entries[1] if entries[0]["is_winner"] else entries[0]

        match_type = "Doubles" if len(win["players"]) == 2 else "Singles"

        score = ' '.join(
            f"{a}-{b}" for a, b in zip(win["scores"], los["scores"])
        ) + ';'

        return {
            "draw_name": title.title(),
            "draw_team_type": match_type.title(),

            "winner_1_name": helper.clean_name(win["players"][0]["name"]),
            "winner_2_name": helper.clean_name(win["players"][1]["name"]) if match_type == "Doubles" else "",
            "winner_college": win["players"][0]["college"],

            "loser_1_name": helper.clean_name(los["players"][0]["name"]),
            "loser_2_name": helper.clean_name(los["players"][1]["name"]) if match_type == "Doubles" else "",
            "loser_college": los["players"][0]["college"],

            "score": score
        }

    def extract_all_player_names(self, table_html: Selector):
        rows = table_html.xpath('.//tr[td and not(contains(@class,"title-row"))]')
        entries = []

        for row in rows:
            raw_name = ' '.join(
                t.strip()
                for t in row.xpath('.//td[1]//text()').getall()
                if t.strip() and t.strip() != '>'
            )

            if not raw_name:
                continue

            players = self.extract_players(raw_name)
            for player in players:
                entries.append(player['name'])

        return entries

    def parse_team_data(self, html1):
        cells = html1.xpath('//table//tr/td')
        parsed = []

        for td in cells:
            texts = td.xpath('.//span[@class="stats-header"]/text()').getall()
            if len(texts) >= 2:
                name = texts[0].strip()
                score_txt = texts[1].strip()
                if name and score_txt.isdigit():
                    parsed.append((name, int(score_txt)))

        if len(parsed) != 2:
            return "", "", ""

        winner, loser = sorted(parsed, key=lambda x: x[1], reverse=True)
        winner_team = winner[0]
        loser_team = loser[0]
        team_score = f"{winner[1]}-{loser[1]};"

        winner_team = helper.get_official_college_name(winner_team, self.ai_client)
        loser_team = helper.get_official_college_name(loser_team, self.ai_client)

        return winner_team, loser_team, team_score
