import traceback, random, re
from io import BytesIO
import pdfplumber  # pip install pdfplumber
from openai import OpenAI
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts import helper
from scrapy.selector import Selector
from app_spiders.models import jobsModel, JobsItemsCollegeDualMatchScraperModel

class arizonawildcatsParser:

    def __init__(self):
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=False, use_proxy=self.use_proxy)
        self.api_key = random.choice(settings.API_KEYS)
        self.ai_client = OpenAI(api_key=self.api_key)


    def parse_site(self, spider_id, job_id, job_tournament_url):
        items_found = False
        try:
            logger.info(f'arizonawildcats | job_tournament_url: {job_tournament_url}')

            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }
            response1 = self.fctrequest.request(method='GET', link=job_tournament_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    pdf_link = fctcore.parse_field('//li[@id="ctl00_cplhMainContent_btnOpen"]/a/@href', html1)
                    logger.info(f'pdf_link: {pdf_link}')

                    if pdf_link:
                        items_found = self.parse_pdf(spider_id, job_id, job_tournament_url, pdf_link)

        except Exception:
            logger.error(traceback.format_exc())

        return items_found


    def parse_pdf(self, spider_id, job_id, job_tournament_url, pdf_link):
        items_found = False
        try:
            logger.info(f'arizonawildcats | pdf_link: {pdf_link}')

            pdf_text = self.get_pdf_text(pdf_link)
            logger.info(f'pdf_text: {pdf_text}')

            if pdf_text:
                winner_team, loser_team, team_score, tournament_date = self.parse_team_data(pdf_text, job_tournament_url)
                logger.info(f'winner_team: {winner_team}')
                logger.info(f'loser_team: {loser_team}')
                logger.info(f'team_score: {team_score}')
                logger.info(f'tournament_date: {tournament_date}')

                if winner_team and loser_team and team_score:
                    tournament_name_pre = f"Dual Match: {winner_team} vs {loser_team}"
                    logger.info(f'tournament_name_pre: {tournament_name_pre}')

                    matches_data = self.parse_matches(pdf_text)
                    logger.info(f'matches_data: {matches_data}')

                    players_names = self.extract_all_player_names(matches_data)
                    logger.info(f'players_names: {players_names}')

                    draw_gender = helper.get_gender_from_players_list_gpt(players_names, self.ai_client)
                    logger.info(f'draw_gender: {draw_gender}')

                    items_found = self.parse_page(spider_id, job_id, job_tournament_url, tournament_date, tournament_name_pre, winner_team, loser_team, team_score, draw_gender, matches_data)

        except Exception:
            logger.error(traceback.format_exc())

        return items_found


    def get_pdf_text(self, pdf_link):
        pdf_text = ''
        try:
            logger.info(f'pdf_link: {pdf_link}')

            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=pdf_link, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    pdf_bytes = BytesIO(response1.content)  # memory only, no file
                    with pdfplumber.open(pdf_bytes) as pdf:
                        pdf_text = "\n".join(page.extract_text() or "" for page in pdf.pages)

        except Exception:
            logger.error(traceback.format_exc())

        return pdf_text


    def parse_page(self, spider_id, job_id, job_tournament_url, tournament_date, tournament_name_pre, winner_team, loser_team, team_score, draw_gender, matches_data):
        items_found = False
        try:
            match_id = ""
            ball_type = "Yellow"
            draw_bracket_value = ""
            draw_name = ""
            draw_team_type = ""
            tournament_name = ""
            date = tournament_date
            score = ""
            winner_1_name = ""
            winner_1_gender = ""
            winner_1_third_party_id = ""
            winner_1_city = ""
            winner_1_country = ""
            winner_1_state = ""
            winner_2_name = ""
            winner_2_gender = ""
            winner_2_third_party_id = ""
            winner_2_city = ""
            winner_2_state = ""
            loser_1_name = ""
            loser_1_gender = ""
            loser_1_third_party_id = ""
            loser_1_city = ""
            loser_1_state = ""
            loser_1_country = ""
            loser_2_name = ""
            loser_2_gender = ""
            loser_2_third_party_id = ""
            loser_2_city = ""
            loser_2_state = ""
            outcome = "Completed"
            id_type = ""
            draw_bracket_type = ""
            draw_type = ""
            tournament_city = ""
            tournament_state = ""
            tournament_country_code = "USA"
            tournament_host = ""
            tournament_location_type = ""
            tournament_surface = ""
            tournament_event_category = ""
            tournament_event_grade = ""
            tournament_import_source = "College"
            tournament_sanction_body = "College"
            winner_2_country = ""
            winner_2_college = ""
            loser_2_country = ""
            loser_2_college = ""
            tournament_event_type = "Dual Match"
            winner_1_college = ""
            loser_1_college = ""
            tournament_url = job_tournament_url
            winner_1_dob = ""
            winner_2_dob = ""
            loser_1_dob = ""
            loser_2_dob = ""
            tournament_country = "USA"
            tournament_start_date = tournament_date
            tournament_end_date = tournament_date
            winner_team_type = "College"
            loser_team_type = "College"

            for match_data in matches_data:
                logger.info(f'match_data: {match_data}')

                draw_name = match_data.get("draw_name", "")
                draw_team_type = match_data.get("draw_team_type", "")
                score = match_data.get("score", "")
                winner_1_name = match_data.get('winner_1_name', '')
                winner_2_name = match_data.get('winner_2_name', '')
                loser_1_name = match_data.get('loser_1_name', '')
                loser_2_name = match_data.get('loser_2_name', '')
                winner_college = match_data.get('winner_college', '')
                loser_college = match_data.get('loser_college', '')
                outcome = match_data.get('outcome', '')

                if winner_1_name and loser_1_name:
                    results_colleges = helper.convert_college_name(input_college_1=winner_college, input_college_2=loser_college, output_college_1=winner_team, output_college_2=loser_team, ai_client=self.ai_client)
                    logger.info(f'results_colleges: {results_colleges}')

                    winner_college_formatted = results_colleges.get(winner_college, '')
                    loser_college_formatted = results_colleges.get(loser_college, '')

                    winner_1_college = winner_2_college = winner_college_formatted
                    loser_1_college = loser_2_college = loser_college_formatted

                    player_gender = ''
                    tournament_gender = ''
                    if draw_gender == "Male":
                        player_gender = 'M'
                        tournament_gender = 'Men'

                    elif draw_gender == "Female":
                        player_gender = 'F'
                        tournament_gender = 'Women'

                    if player_gender:
                        if winner_1_name:
                            winner_1_gender = player_gender

                        if winner_2_name:
                            winner_2_gender = player_gender

                        if loser_1_name:
                            loser_1_gender = player_gender

                        if loser_2_name:
                            loser_2_gender = player_gender

                    if draw_team_type == 'Singles':
                        winner_2_college = loser_2_college = ''
                        winner_2_gender = loser_2_gender = ''

                    if tournament_gender:
                        tournament_name = f'{tournament_name_pre} - {tournament_gender}'
                    else:
                        tournament_name = tournament_name_pre

                    logger.info(f'match_id: {match_id}')
                    logger.info(f'ball_type: {ball_type}')
                    logger.info(f'draw_bracket_value: {draw_bracket_value}')
                    logger.info(f'draw_name: {draw_name}')
                    logger.info(f'draw_team_type: {draw_team_type}')
                    logger.info(f'tournament_name: {tournament_name}')
                    logger.info(f'date: {date}')
                    logger.info(f'score: {score}')
                    logger.info(f'winner_1_name: {winner_1_name}')
                    logger.info(f'winner_1_gender: {winner_1_gender}')
                    logger.info(f'winner_1_third_party_id: {winner_1_third_party_id}')
                    logger.info(f'winner_1_city: {winner_1_city}')
                    logger.info(f'winner_1_country: {winner_1_country}')
                    logger.info(f'winner_1_state: {winner_1_state}')
                    logger.info(f'winner_2_name: {winner_2_name}')
                    logger.info(f'winner_2_gender: {winner_2_gender}')
                    logger.info(f'winner_2_third_party_id: {winner_2_third_party_id}')
                    logger.info(f'winner_2_city: {winner_2_city}')
                    logger.info(f'winner_2_state: {winner_2_state}')
                    logger.info(f'loser_1_name: {loser_1_name}')
                    logger.info(f'loser_1_gender: {loser_1_gender}')
                    logger.info(f'loser_1_third_party_id: {loser_1_third_party_id}')
                    logger.info(f'loser_1_city: {loser_1_city}')
                    logger.info(f'loser_1_state: {loser_1_state}')
                    logger.info(f'loser_1_country: {loser_1_country}')
                    logger.info(f'loser_2_name: {loser_2_name}')
                    logger.info(f'loser_2_gender: {loser_2_gender}')
                    logger.info(f'loser_2_third_party_id: {loser_2_third_party_id}')
                    logger.info(f'loser_2_city: {loser_2_city}')
                    logger.info(f'loser_2_state: {loser_2_state}')
                    logger.info(f'outcome: {outcome}')
                    logger.info(f'id_type: {id_type}')
                    logger.info(f'draw_gender: {draw_gender}')
                    logger.info(f'draw_bracket_type: {draw_bracket_type}')
                    logger.info(f'draw_type: {draw_type}')
                    logger.info(f'tournament_city: {tournament_city}')
                    logger.info(f'tournament_state: {tournament_state}')
                    logger.info(f'tournament_country_code: {tournament_country_code}')
                    logger.info(f'tournament_host: {tournament_host}')
                    logger.info(f'tournament_location_type: {tournament_location_type}')
                    logger.info(f'tournament_surface: {tournament_surface}')
                    logger.info(f'tournament_event_category: {tournament_event_category}')
                    logger.info(f'tournament_event_grade: {tournament_event_grade}')
                    logger.info(f'tournament_import_source: {tournament_import_source}')
                    logger.info(f'tournament_sanction_body: {tournament_sanction_body}')
                    logger.info(f'winner_2_country: {winner_2_country}')
                    logger.info(f'winner_2_college: {winner_2_college}')
                    logger.info(f'loser_2_country: {loser_2_country}')
                    logger.info(f'loser_2_college: {loser_2_college}')
                    logger.info(f'tournament_event_type: {tournament_event_type}')
                    logger.info(f'winner_1_college: {winner_1_college}')
                    logger.info(f'loser_1_college: {loser_1_college}')
                    logger.info(f'tournament_url: {tournament_url}')
                    logger.info(f'winner_1_dob: {winner_1_dob}')
                    logger.info(f'winner_2_dob: {winner_2_dob}')
                    logger.info(f'loser_1_dob: {loser_1_dob}')
                    logger.info(f'loser_2_dob: {loser_2_dob}')
                    logger.info(f'tournament_country: {tournament_country}')
                    logger.info(f'tournament_start_date: {tournament_start_date}')
                    logger.info(f'tournament_end_date: {tournament_end_date}')
                    logger.info(f'winner_team: {winner_team}')
                    logger.info(f'loser_team: {loser_team}')
                    logger.info(f'team_score: {team_score}')
                    logger.info(f'winner_team_type: {winner_team_type}')
                    logger.info(f'loser_team_type: {loser_team_type}')
                    logger.info('*' * 50)

                    if winner_team and loser_team and team_score and winner_1_name and loser_1_name:
                        items_found = True
                        JobsItemsCollegeDualMatchScraperModel(
                            spider_id=spider_id,
                            job_id=job_id,
                            match_id=match_id,
                            ball_type=ball_type,
                            draw_bracket_value=draw_bracket_value,
                            draw_name=draw_name,
                            draw_team_type=draw_team_type,
                            tournament_name=tournament_name,
                            date=date,
                            score=score,
                            winner_1_name=winner_1_name,
                            winner_1_gender=winner_1_gender,
                            winner_1_third_party_id=winner_1_third_party_id,
                            winner_1_city=winner_1_city,
                            winner_1_country=winner_1_country,
                            winner_1_state=winner_1_state,
                            winner_2_name=winner_2_name,
                            winner_2_gender=winner_2_gender,
                            winner_2_third_party_id=winner_2_third_party_id,
                            winner_2_city=winner_2_city,
                            winner_2_state=winner_2_state,
                            loser_1_name=loser_1_name,
                            loser_1_gender=loser_1_gender,
                            loser_1_third_party_id=loser_1_third_party_id,
                            loser_1_city=loser_1_city,
                            loser_1_state=loser_1_state,
                            loser_1_country=loser_1_country,
                            loser_2_name=loser_2_name,
                            loser_2_gender=loser_2_gender,
                            loser_2_third_party_id=loser_2_third_party_id,
                            loser_2_city=loser_2_city,
                            loser_2_state=loser_2_state,
                            outcome=outcome,
                            id_type=id_type,
                            draw_gender=draw_gender,
                            draw_bracket_type=draw_bracket_type,
                            draw_type=draw_type,
                            tournament_city=tournament_city,
                            tournament_state=tournament_state,
                            tournament_country_code=tournament_country_code,
                            tournament_host=tournament_host,
                            tournament_location_type=tournament_location_type,
                            tournament_surface=tournament_surface,
                            tournament_event_category=tournament_event_category,
                            tournament_event_grade=tournament_event_grade,
                            tournament_import_source=tournament_import_source,
                            tournament_sanction_body=tournament_sanction_body,
                            winner_2_country=winner_2_country,
                            winner_2_college=winner_2_college,
                            loser_2_country=loser_2_country,
                            loser_2_college=loser_2_college,
                            tournament_event_type=tournament_event_type,
                            winner_1_college=winner_1_college,
                            loser_1_college=loser_1_college,
                            tournament_url=tournament_url,
                            winner_1_dob=winner_1_dob,
                            winner_2_dob=winner_2_dob,
                            loser_1_dob=loser_1_dob,
                            loser_2_dob=loser_2_dob,
                            tournament_country=tournament_country,
                            tournament_start_date=tournament_start_date,
                            tournament_end_date=tournament_end_date,
                            winner_team=winner_team,
                            loser_team=loser_team,
                            team_score=team_score,
                            winner_team_type=winner_team_type,
                            loser_team_type=loser_team_type,
                        ).save()

        except Exception:
            logger.error(traceback.format_exc())

        return items_found

    # -------------------------------------------------
    # JOIN MULTI-LINE MATCHES (CRITICAL FIX)
    # -------------------------------------------------
    def _explode_matches(self, text: str):
        blocks = []
        buf = ""

        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue

            if re.match(r"^\d+\s+", line):
                if buf:
                    blocks.append(buf.strip())
                buf = line
            else:
                buf += " " + line

        if buf:
            blocks.append(buf.strip())

        return blocks

    # -------------------------------------------------
    # PLAYER NORMALIZER
    # -------------------------------------------------
    def _normalize_player(self, name: str) -> str:
        name = helper.clean_name(name)
        if "," in name:
            return name
        parts = name.split()
        return f"{parts[-1]}, {' '.join(parts[:-1])}" if len(parts) >= 2 else name

    # -------------------------------------------------
    # SCORE PARSER
    # -------------------------------------------------
    def _extract_score(self, line: str):
        sets = re.findall(r"\d+-\d+(?:\(\d+\))?", line)
        if "vs." in line.lower():
            sets.append("UF-UF")
        return " ".join(sets) + ";" if sets else ""

    # -------------------------------------------------
    # MAIN
    # -------------------------------------------------
    def parse_matches(self, text: str):
        results = []

        for block in self._explode_matches(text):

            if not ("(" in block and ("def." in block.lower() or "vs." in block.lower())):
                continue

            # match number
            m_num = re.match(r"^(\d+)", block)
            if not m_num:
                continue
            num = int(m_num.group(1))

            # players + colleges (flexible order)
            m = re.search(
                r"""
                ^\d+\s+
                (?P<winners>.+?)\s*\((?P<wcol>[^)]+)\)
                .*?(def\.|vs\.)
                .*?
                (?P<losers>.+?)\s*\((?P<lcol>[^)]+)\)
                """,
                block,
                re.VERBOSE | re.IGNORECASE,
            )
            if not m:
                continue

            winners_raw = m.group("winners")
            losers_raw = m.group("losers")
            w_col = m.group("wcol")
            l_col = m.group("lcol")

            is_doubles = " and " in winners_raw.lower() or "/" in winners_raw
            match_type = "Doubles" if is_doubles else "Singles"

            w_players = re.split(r"/| and ", winners_raw)
            l_players = re.split(r"/| and ", losers_raw)

            w_players = [self._normalize_player(p) for p in w_players]
            l_players = [self._normalize_player(p) for p in l_players]

            score = self._extract_score(block)

            results.append({
                "draw_name": f"#{num} {match_type}".title(),
                "draw_team_type": match_type.title(),
                "winner_1_name": w_players[0].replace(' - ', ' '),
                "winner_2_name": w_players[1].replace(' - ', ' ') if is_doubles and len(w_players) > 1 else "",
                "winner_college": w_col,
                "loser_1_name": l_players[0].replace(' - ', ' '),
                "loser_2_name": l_players[1].replace(' - ', ' ') if is_doubles and len(l_players) > 1 else "",
                "loser_college": l_col,
                "score": score,
                "outcome": "Tie" if "UF-UF" in score else "Completed",
            })

        return results


    def parse_team_data(self, text, job_tournament_url):
        winner_team = loser_team = team_score = ''

        # -----------------------------------
        # TEAM SCORE (both known formats)
        # -----------------------------------
        m = re.search(
            r"#\s*\d+\s+(.+?)\s+(\d+),\s+#\s*\d+\s+(.+?)\s+(\d+)",
            text,
        )
        if not m:
            m = re.search(
                r"Match Score:\s+(.+?)\s+(\d+),\s+(.+?)\s+(\d+)",
                text,
                re.I,
            )

        if m:
            t1, s1, t2, s2 = m.groups()
            if int(s1) > int(s2):
                winner_team, loser_team = t1, t2
                team_score = f"{s1}-{s2};"
            else:
                winner_team, loser_team = t2, t1
                team_score = f"{s2}-{s1};"

        # -----------------------------------
        # DATE (MM/DD/YYYY first)
        # -----------------------------------
        tournament_date = ''
        try:
            m = re.search(r"\b(\d{1,2}/\d{1,2}/\d{2,4})\b", text)
            tournament_date = fctcore.convert_string_to_date_format(m.group(0), list_in_format=['%m/%d/%Y', '%m/%d/%y'], out_format='%m/%d/%Y', job_tournament_url=job_tournament_url)
        except Exception:
            logger.error(f'job_tournament_url: {job_tournament_url} | {traceback.format_exc()}')

        winner_team = helper.get_official_college_name(winner_team, self.ai_client)
        loser_team = helper.get_official_college_name(loser_team, self.ai_client)

        return winner_team, loser_team, team_score, tournament_date


    def extract_all_player_names(self, matches_data):
        players_names = []
        for match_data in matches_data:
            winner_1_name = match_data.get('winner_1_name', '')
            winner_2_name = match_data.get('winner_2_name', '')
            loser_1_name = match_data.get('loser_1_name', '')
            loser_2_name = match_data.get('loser_2_name', '')

            if winner_1_name: players_names.append(winner_1_name)
            if winner_2_name: players_names.append(winner_2_name)
            if loser_1_name: players_names.append(loser_1_name)
            if loser_2_name: players_names.append(loser_2_name)

        players_names = list(set(players_names))

        return players_names