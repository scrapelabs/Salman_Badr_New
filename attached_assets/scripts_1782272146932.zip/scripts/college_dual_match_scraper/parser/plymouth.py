import traceback, random, re
from io import BytesIO
from pdfminer.high_level import extract_text #pip install pdfminer.six
from openai import OpenAI
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts import helper
from scrapy.selector import Selector
from app_spiders.models import JobsItemsCollegeDualMatchScraperModel

class plymouthParser:

    def __init__(self):
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=False, use_proxy=self.use_proxy)
        self.api_key = random.choice(settings.API_KEYS)
        self.ai_client = OpenAI(api_key=self.api_key)


    def parse_site(self, spider_id, job_id, job_tournament_url):
        items_found = False
        try:
            logger.info(f'plymouth | job_tournament_url: {job_tournament_url}')

            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }
            response1 = self.fctrequest.request(method='GET', link=job_tournament_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    pdf_link = fctcore.parse_field('//object[@type="application/pdf"]/@data', html1)
                    logger.info(f'pdf_link: {pdf_link}')

                    if pdf_link:
                        self.parse_pdf(spider_id, job_id, job_tournament_url, pdf_link)

        except Exception:
            logger.error(traceback.format_exc())

        return items_found


    def parse_pdf(self, spider_id, job_id, job_tournament_url, pdf_link):
        items_found = False
        try:
            logger.info(f'pdf_link: {pdf_link}')

            pdf_text = self.get_pdf_text(pdf_link)
            logger.info(f'plymouth | pdf_text: {pdf_text}')

            if pdf_text:
                winner_team, loser_team, team_score, tournament_date = self.parse_team_data(pdf_text, job_tournament_url)
                logger.info(f'winner_team: {winner_team}')
                logger.info(f'loser_team: {loser_team}')
                logger.info(f'team_score: {team_score}')
                logger.info(f'tournament_date: {tournament_date}')

                if winner_team and loser_team and team_score:
                    tournament_name_pre = f"Dual Match: {winner_team} vs {loser_team}"
                    logger.info(f'tournament_name_pre: {tournament_name_pre}')

                    matches_data = self.parse_matches(pdf_text)
                    logger.info(f'matches_data: {matches_data}')

                    players_names = self.extract_all_player_names(matches_data)
                    logger.info(f'players_names: {players_names}')

                    draw_gender = helper.get_gender_from_players_list_gpt(players_names, self.ai_client)
                    logger.info(f'draw_gender: {draw_gender}')

                    items_found = self.parse_page(spider_id, job_id, job_tournament_url, tournament_date, tournament_name_pre, winner_team, loser_team, team_score, draw_gender, matches_data)

        except Exception:
            logger.error(traceback.format_exc())

        return items_found


    def get_pdf_text(self, pdf_link):
        pdf_text = ''
        try:
            logger.info(f'pdf_link: {pdf_link}')

            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=pdf_link, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    pdf_bytes = BytesIO(response1.content)  # memory only, no file
                    pdf_text = extract_text(pdf_bytes)

        except Exception:
            logger.error(traceback.format_exc())

        return pdf_text


    def parse_page(self, spider_id, job_id, job_tournament_url, tournament_date, tournament_name_pre, winner_team, loser_team, team_score, draw_gender, matches_data):
        items_found = False
        try:
            match_id = ""
            ball_type = "Yellow"
            draw_bracket_value = ""
            draw_name = ""
            draw_team_type = ""
            tournament_name = ""
            date = tournament_date
            score = ""
            winner_1_name = ""
            winner_1_gender = ""
            winner_1_third_party_id = ""
            winner_1_city = ""
            winner_1_country = ""
            winner_1_state = ""
            winner_2_name = ""
            winner_2_gender = ""
            winner_2_third_party_id = ""
            winner_2_city = ""
            winner_2_state = ""
            loser_1_name = ""
            loser_1_gender = ""
            loser_1_third_party_id = ""
            loser_1_city = ""
            loser_1_state = ""
            loser_1_country = ""
            loser_2_name = ""
            loser_2_gender = ""
            loser_2_third_party_id = ""
            loser_2_city = ""
            loser_2_state = ""
            outcome = "Completed"
            id_type = ""
            draw_bracket_type = ""
            draw_type = ""
            tournament_city = ""
            tournament_state = ""
            tournament_country_code = "USA"
            tournament_host = ""
            tournament_location_type = ""
            tournament_surface = ""
            tournament_event_category = ""
            tournament_event_grade = ""
            tournament_import_source = "College"
            tournament_sanction_body = "College"
            winner_2_country = ""
            winner_2_college = ""
            loser_2_country = ""
            loser_2_college = ""
            tournament_event_type = "Dual Match"
            winner_1_college = ""
            loser_1_college = ""
            tournament_url = job_tournament_url
            winner_1_dob = ""
            winner_2_dob = ""
            loser_1_dob = ""
            loser_2_dob = ""
            tournament_country = "USA"
            tournament_start_date = tournament_date
            tournament_end_date = tournament_date
            winner_team_type = "College"
            loser_team_type = "College"

            for match_data in matches_data:
                logger.info(f'match_data: {match_data}')

                draw_name = match_data.get("draw_name", "")
                draw_team_type = match_data.get("draw_team_type", "")
                score = match_data.get("score", "")
                winner_1_name = match_data.get('winner_1_name', '')
                winner_2_name = match_data.get('winner_2_name', '')
                loser_1_name = match_data.get('loser_1_name', '')
                loser_2_name = match_data.get('loser_2_name', '')
                winner_college = match_data.get('winner_college', '')
                loser_college = match_data.get('loser_college', '')

                if winner_1_name and loser_1_name:
                    results_colleges = helper.convert_college_name(input_college_1=winner_college, input_college_2=loser_college, output_college_1=winner_team, output_college_2=loser_team, ai_client=self.ai_client)
                    logger.info(f'results_colleges: {results_colleges}')

                    winner_college_formatted = results_colleges.get(winner_college, '')
                    loser_college_formatted = results_colleges.get(loser_college, '')

                    winner_1_college = winner_2_college = winner_college_formatted
                    loser_1_college = loser_2_college = loser_college_formatted

                    player_gender = ''
                    tournament_gender = ''
                    if draw_gender == "Male":
                        player_gender = 'M'
                        tournament_gender = 'Men'

                    elif draw_gender == "Female":
                        player_gender = 'F'
                        tournament_gender = 'Women'

                    if player_gender:
                        if winner_1_name:
                            winner_1_gender = player_gender

                        if winner_2_name:
                            winner_2_gender = player_gender

                        if loser_1_name:
                            loser_1_gender = player_gender

                        if loser_2_name:
                            loser_2_gender = player_gender

                    if draw_team_type == 'Singles':
                        winner_2_college = loser_2_college = ''
                        winner_2_gender = loser_2_gender = ''

                    if tournament_gender:
                        tournament_name = f'{tournament_name_pre} - {tournament_gender}'
                    else:
                        tournament_name = tournament_name_pre

                    logger.info(f'match_id: {match_id}')
                    logger.info(f'ball_type: {ball_type}')
                    logger.info(f'draw_bracket_value: {draw_bracket_value}')
                    logger.info(f'draw_name: {draw_name}')
                    logger.info(f'draw_team_type: {draw_team_type}')
                    logger.info(f'tournament_name: {tournament_name}')
                    logger.info(f'date: {date}')
                    logger.info(f'score: {score}')
                    logger.info(f'winner_1_name: {winner_1_name}')
                    logger.info(f'winner_1_gender: {winner_1_gender}')
                    logger.info(f'winner_1_third_party_id: {winner_1_third_party_id}')
                    logger.info(f'winner_1_city: {winner_1_city}')
                    logger.info(f'winner_1_country: {winner_1_country}')
                    logger.info(f'winner_1_state: {winner_1_state}')
                    logger.info(f'winner_2_name: {winner_2_name}')
                    logger.info(f'winner_2_gender: {winner_2_gender}')
                    logger.info(f'winner_2_third_party_id: {winner_2_third_party_id}')
                    logger.info(f'winner_2_city: {winner_2_city}')
                    logger.info(f'winner_2_state: {winner_2_state}')
                    logger.info(f'loser_1_name: {loser_1_name}')
                    logger.info(f'loser_1_gender: {loser_1_gender}')
                    logger.info(f'loser_1_third_party_id: {loser_1_third_party_id}')
                    logger.info(f'loser_1_city: {loser_1_city}')
                    logger.info(f'loser_1_state: {loser_1_state}')
                    logger.info(f'loser_1_country: {loser_1_country}')
                    logger.info(f'loser_2_name: {loser_2_name}')
                    logger.info(f'loser_2_gender: {loser_2_gender}')
                    logger.info(f'loser_2_third_party_id: {loser_2_third_party_id}')
                    logger.info(f'loser_2_city: {loser_2_city}')
                    logger.info(f'loser_2_state: {loser_2_state}')
                    logger.info(f'outcome: {outcome}')
                    logger.info(f'id_type: {id_type}')
                    logger.info(f'draw_gender: {draw_gender}')
                    logger.info(f'draw_bracket_type: {draw_bracket_type}')
                    logger.info(f'draw_type: {draw_type}')
                    logger.info(f'tournament_city: {tournament_city}')
                    logger.info(f'tournament_state: {tournament_state}')
                    logger.info(f'tournament_country_code: {tournament_country_code}')
                    logger.info(f'tournament_host: {tournament_host}')
                    logger.info(f'tournament_location_type: {tournament_location_type}')
                    logger.info(f'tournament_surface: {tournament_surface}')
                    logger.info(f'tournament_event_category: {tournament_event_category}')
                    logger.info(f'tournament_event_grade: {tournament_event_grade}')
                    logger.info(f'tournament_import_source: {tournament_import_source}')
                    logger.info(f'tournament_sanction_body: {tournament_sanction_body}')
                    logger.info(f'winner_2_country: {winner_2_country}')
                    logger.info(f'winner_2_college: {winner_2_college}')
                    logger.info(f'loser_2_country: {loser_2_country}')
                    logger.info(f'loser_2_college: {loser_2_college}')
                    logger.info(f'tournament_event_type: {tournament_event_type}')
                    logger.info(f'winner_1_college: {winner_1_college}')
                    logger.info(f'loser_1_college: {loser_1_college}')
                    logger.info(f'tournament_url: {tournament_url}')
                    logger.info(f'winner_1_dob: {winner_1_dob}')
                    logger.info(f'winner_2_dob: {winner_2_dob}')
                    logger.info(f'loser_1_dob: {loser_1_dob}')
                    logger.info(f'loser_2_dob: {loser_2_dob}')
                    logger.info(f'tournament_country: {tournament_country}')
                    logger.info(f'tournament_start_date: {tournament_start_date}')
                    logger.info(f'tournament_end_date: {tournament_end_date}')
                    logger.info(f'winner_team: {winner_team}')
                    logger.info(f'loser_team: {loser_team}')
                    logger.info(f'team_score: {team_score}')
                    logger.info(f'winner_team_type: {winner_team_type}')
                    logger.info(f'loser_team_type: {loser_team_type}')
                    logger.info('*' * 50)

                    if winner_team and loser_team and team_score and winner_1_name and loser_1_name:
                        items_found = True
                        JobsItemsCollegeDualMatchScraperModel(
                            spider_id=spider_id,
                            job_id=job_id,
                            match_id=match_id,
                            ball_type=ball_type,
                            draw_bracket_value=draw_bracket_value,
                            draw_name=draw_name,
                            draw_team_type=draw_team_type,
                            tournament_name=tournament_name,
                            date=date,
                            score=score,
                            winner_1_name=winner_1_name,
                            winner_1_gender=winner_1_gender,
                            winner_1_third_party_id=winner_1_third_party_id,
                            winner_1_city=winner_1_city,
                            winner_1_country=winner_1_country,
                            winner_1_state=winner_1_state,
                            winner_2_name=winner_2_name,
                            winner_2_gender=winner_2_gender,
                            winner_2_third_party_id=winner_2_third_party_id,
                            winner_2_city=winner_2_city,
                            winner_2_state=winner_2_state,
                            loser_1_name=loser_1_name,
                            loser_1_gender=loser_1_gender,
                            loser_1_third_party_id=loser_1_third_party_id,
                            loser_1_city=loser_1_city,
                            loser_1_state=loser_1_state,
                            loser_1_country=loser_1_country,
                            loser_2_name=loser_2_name,
                            loser_2_gender=loser_2_gender,
                            loser_2_third_party_id=loser_2_third_party_id,
                            loser_2_city=loser_2_city,
                            loser_2_state=loser_2_state,
                            outcome=outcome,
                            id_type=id_type,
                            draw_gender=draw_gender,
                            draw_bracket_type=draw_bracket_type,
                            draw_type=draw_type,
                            tournament_city=tournament_city,
                            tournament_state=tournament_state,
                            tournament_country_code=tournament_country_code,
                            tournament_host=tournament_host,
                            tournament_location_type=tournament_location_type,
                            tournament_surface=tournament_surface,
                            tournament_event_category=tournament_event_category,
                            tournament_event_grade=tournament_event_grade,
                            tournament_import_source=tournament_import_source,
                            tournament_sanction_body=tournament_sanction_body,
                            winner_2_country=winner_2_country,
                            winner_2_college=winner_2_college,
                            loser_2_country=loser_2_country,
                            loser_2_college=loser_2_college,
                            tournament_event_type=tournament_event_type,
                            winner_1_college=winner_1_college,
                            loser_1_college=loser_1_college,
                            tournament_url=tournament_url,
                            winner_1_dob=winner_1_dob,
                            winner_2_dob=winner_2_dob,
                            loser_1_dob=loser_1_dob,
                            loser_2_dob=loser_2_dob,
                            tournament_country=tournament_country,
                            tournament_start_date=tournament_start_date,
                            tournament_end_date=tournament_end_date,
                            winner_team=winner_team,
                            loser_team=loser_team,
                            team_score=team_score,
                            winner_team_type=winner_team_type,
                            loser_team_type=loser_team_type,
                        ).save()

        except Exception:
            logger.error(traceback.format_exc())

        return items_found

    def _clean_name(self, name: str) -> str:
        name = re.sub(r"^\d+\.\s*", "", name)
        name = re.sub(r"#\d+\s*", "", name)
        name = name.strip()
        parts = name.split()
        if len(parts) >= 2:
            return f"{parts[-1]}, {' '.join(parts[:-1])}"
        return name

    def _clean_score(self, score: str) -> str:
        score = re.sub(r"<[^>]+>", "", score)
        sets = re.findall(r"\d+-\d+", score)
        if "default" in score.lower():
            return "DEF;"
        return " ".join(sets) + ";" if sets else ""

    # =====================================================
    # ORIGINAL PARSER (UNCHANGED LOGIC)
    # =====================================================
    def parse_matches(self, text):

        if "singles competition" not in text.lower():
            return self._parse_second_type_matches(text)

        results = []
        current_type = None
        counter = {"Singles": 0, "Doubles": 0}

        for raw in text.splitlines():
            line = raw.strip()
            if not line:
                continue

            low = line.lower()

            if "singles competition" in low:
                current_type = "Singles"
                continue

            if "doubles competition" in low:
                current_type = "Doubles"
                continue

            # =====================================================
            # NEW CONDITION (ADDED ONLY)
            # Handle: vs. unfinished / vs. dnf
            # =====================================================
            if current_type and "vs." in line.lower() and any(x in line.lower() for x in ["unfinished", "dnf"]):

                m = re.search(
                    r"(.+?)\s*\(([^)]+)\)\s+vs\.\s+(.+?)\s*\(([^)]+)\)\s+(.+)",
                    line,
                    re.IGNORECASE
                )
                if m:
                    p1_raw, col1, p2_raw, col2, score_raw = m.groups()

                    winner_raw, winner_col = p1_raw, col1
                    loser_raw, loser_col = p2_raw, col2

                    winner_players = [self._clean_name(x) for x in winner_raw.split("/")]
                    loser_players = [self._clean_name(x) for x in loser_raw.split("/")]

                    counter[current_type] += 1

                    results.append({
                        "draw_name": f"#{counter[current_type]} {current_type}".title(),
                        "draw_team_type": current_type.title(),

                        "winner_1_name": helper.clean_name(winner_players[0]) if winner_players else "",
                        "winner_2_name": helper.clean_name(winner_players[1]) if len(winner_players) > 1 else "",
                        "winner_college": winner_col,

                        "loser_1_name": helper.clean_name(loser_players[0]) if loser_players else "",
                        "loser_2_name": helper.clean_name(loser_players[1]) if len(loser_players) > 1 else "",
                        "loser_college": loser_col,

                        "score": self._clean_score(score_raw),
                    })

                continue

            # =====================================================
            # ORIGINAL CONDITION (UNCHANGED)
            # =====================================================
            if "def." not in line or not current_type:
                continue

            m = re.search(
                r"(.+?)\s*\(([^)]+)\)\s+def\.\s+(.+?)\s*\(([^)]+)\)\s+(.+)",
                line
            )
            if not m:
                continue

            winner_raw, winner_col, loser_raw, loser_col, score_raw = m.groups()

            winner_players = [self._clean_name(x) for x in winner_raw.split("/")]
            loser_players = [self._clean_name(x) for x in loser_raw.split("/")]

            counter[current_type] += 1

            results.append({
                "draw_name": f"#{counter[current_type]} {current_type}".title(),
                "draw_team_type": current_type.title(),

                "winner_1_name": helper.clean_name(winner_players[0]) if winner_players else "",
                "winner_2_name": helper.clean_name(winner_players[1]) if len(winner_players) > 1 else "",
                "winner_college": winner_col,

                "loser_1_name": helper.clean_name(loser_players[0]) if loser_players else "",
                "loser_2_name": helper.clean_name(loser_players[1]) if len(loser_players) > 1 else "",
                "loser_college": loser_col,

                "score": self._clean_score(score_raw),
            })

        return results


    # =====================================================
    # SECOND TYPE PARSER (UNCHANGED)
    # =====================================================
    def _parse_second_type_matches(self, text):
        results = []
        current_type = None
        counter = {"Singles": 0, "Doubles": 0}

        for raw in text.splitlines():
            line = raw.strip()
            if not line:
                continue

            low = line.lower()

            if low == "singles":
                current_type = "Singles"
                continue

            if low == "doubles":
                current_type = "Doubles"
                continue

            if not current_type:
                continue

            m = re.search(
                r"\d+\.\s+(.+?)\s*\(([^)]+)\)\s+(def\.|vs\.)\s+(.+?)\s*\(([^)]+)\)\s*(.*)",
                line,
                re.IGNORECASE,
            )
            if not m:
                continue

            p1_raw, col1, sep, p2_raw, col2, score_raw = m.groups()
            score_low = score_raw.lower()

            if sep.lower() == "vs." and not any(x in score_low for x in ["dnf", "unfinished"]):
                continue

            winner_raw, winner_col = p1_raw, col1
            loser_raw, loser_col = p2_raw, col2

            winner_players = [self._clean_name(x) for x in winner_raw.split("/")]
            loser_players = [self._clean_name(x) for x in loser_raw.split("/")]

            counter[current_type] += 1

            results.append({
                "draw_name": f"#{counter[current_type]} {current_type}".title(),
                "draw_team_type": current_type,

                "winner_1_name": helper.clean_name(winner_players[0]) if winner_players else "",
                "winner_2_name": helper.clean_name(winner_players[1]) if len(winner_players) > 1 else "",
                "winner_college": winner_col,

                "loser_1_name": helper.clean_name(loser_players[0]) if loser_players else "",
                "loser_2_name": helper.clean_name(loser_players[1]) if len(loser_players) > 1 else "",
                "loser_college": loser_col,

                "score": self._clean_score(score_raw),
            })

        return results


    def parse_team_data(self, text, job_tournament_url):
        winner_team = ""
        loser_team = ""
        team_score = ""
        tournament_date = ""

        # -------------------------------------------------
        # 0) NORMALIZE RAW PDF TEXT (CRITICAL FIX)
        # -------------------------------------------------
        text = text.replace('\xa0', ' ')
        text = text.replace('\r', '\n')
        text = re.sub(r'[ \t]+', ' ', text)
        text = re.sub(r'\n+', '\n', text)

        # -------------------------------------------------
        # 1) TOURNAMENT DATE
        # -------------------------------------------------

        date_match = re.search(
            r"\b("
            r"Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|"
            r"Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|"
            r"Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?"
            r")\s+\d{1,2},\s+\d{4}|\d{1,2}/\d{1,2}/\d{4}\b",
            text
        )

        logger.info(f'date_match: {date_match}')

        if date_match:
            try:
                tournament_date = fctcore.convert_string_to_date_format(date_match.group(0), list_in_format=['%b %d, %Y', '%B %d, %Y', '%m/%d/%Y'], out_format='%m/%d/%Y', job_tournament_url=job_tournament_url)
            except Exception:
                logger.error(f'job_tournament_url: {job_tournament_url} | {traceback.format_exc()}')

        # -------------------------------------------------
        # 2) PRIMARY TEAM SCORE
        # Example: Holy Cross 7, Plymouth State 0
        # -------------------------------------------------
        score_pattern1 = re.compile(
            r"([A-Za-z .&'-]+)\s+(\d+)\s*,\s*([A-Za-z .&'-]+)\s+(\d+)",
            re.MULTILINE
        )

        score_pattern2 = re.compile(
            r"^\s*([A-Za-z .&'-]+?)\s+(\d{1,2})\s*,\s*([A-Za-z .&'-]+?)\s+(\d{1,2})\s*$",
            re.MULTILINE
        )

        score_pattern3 = re.compile(
            r"#?\d*\s*([A-Za-z .&'-]+)\s+(\d+)\s*,\s*#?\d*\s*([A-Za-z .&'-]+)\s+(\d+)",
            re.MULTILINE
        )

        for score_pattern in [score_pattern1, score_pattern2, score_pattern3]:
            score_match = score_pattern.search(text)

            if score_match:
                team1, score1, team2, score2 = score_match.groups()

                team1 = re.sub(r"\s+", " ", team1).strip()
                team2 = re.sub(r"\s+", " ", team2).strip()

                score1 = int(score1)
                score2 = int(score2)

                if score1 > score2:
                    winner_team = team1.strip()
                    loser_team = team2.strip()
                    team_score = f"{score1}-{score2};"
                else:
                    winner_team = team2.strip()
                    loser_team = team1.strip()
                    team_score = f"{score2}-{score1};"

                winner_team = helper.get_official_college_name(winner_team, self.ai_client)
                loser_team = helper.get_official_college_name(loser_team, self.ai_client)

                if winner_team != 'Unknown' and loser_team != 'Unknown':
                    return winner_team, loser_team, team_score, tournament_date

        # -------------------------------------------------
        # 3) FALLBACK — Match Notes Records (1-0 style)
        # -------------------------------------------------
        teams = []

        for raw in text.splitlines():
            line = raw.strip()
            if not line:
                continue

            m = re.match(r"(.+?)\s+(\d+)\s*-\s*(\d+)$", line)
            if not m:
                continue

            team = m.group(1).strip()
            losses = int(m.group(2))
            wins = int(m.group(3))

            teams.append((team, wins))

        if len(teams) == 2:
            winner, loser = sorted(teams, key=lambda x: x[1], reverse=True)
            winner_team = winner[0]
            loser_team = loser[0]
            team_score = f"{winner[1]}-{loser[1]};"


        winner_team = helper.get_official_college_name(winner_team, self.ai_client)
        loser_team = helper.get_official_college_name(loser_team, self.ai_client)

        return winner_team, loser_team, team_score, tournament_date


    def extract_all_player_names(self, matches_data):
        players_names = []
        for match_data in matches_data:
            winner_1_name = match_data.get('winner_1_name', '')
            winner_2_name = match_data.get('winner_2_name', '')
            loser_1_name = match_data.get('loser_1_name', '')
            loser_2_name = match_data.get('loser_2_name', '')

            if winner_1_name: players_names.append(winner_1_name)
            if winner_2_name: players_names.append(winner_2_name)
            if loser_1_name: players_names.append(loser_1_name)
            if loser_2_name: players_names.append(loser_2_name)

        players_names = list(set(players_names))

        return players_names