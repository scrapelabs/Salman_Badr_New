import traceback
from assets.fct.fctlog import logger
from assets.fct import fctcore

class CoreParser:

    def __init__(self, gobarrybucs_parser, auburntigers_parser, albertusfalcons_parser, bsubears_parser, plymouth_parser, usctrojans_parser, gomarquette_parser, gocrimson_parser, arizonawildcats_parser):
        self.gobarrybucs_parser = gobarrybucs_parser
        self.auburntigers_parser = auburntigers_parser
        self.albertusfalcons_parser = albertusfalcons_parser
        self.bsubears_parser = bsubears_parser
        self.plymouth_parser = plymouth_parser
        self.usctrojans_parser = usctrojans_parser
        self.gomarquette_parser = gomarquette_parser
        self.gocrimson_parser = gocrimson_parser
        self.arizonawildcats_parser = arizonawildcats_parser


    def parse_site(self, spider_id, job_id, job_tournament_url):
        items_found = False
        try:
            items_found = False
            job_domain = fctcore.extract_domain(job_tournament_url)

            if 'gobarrybucs.com' in job_domain:
                self.gobarrybucs_parser.parse_site(spider_id, job_id, job_tournament_url)

            elif 'auburntigers.com' in job_domain:
                self.auburntigers_parser.parse_site(spider_id, job_id, job_tournament_url)

            elif 'albertusfalcons.com' in job_domain:
                self.albertusfalcons_parser.parse_site(spider_id, job_id, job_tournament_url)

            elif 'bsubears.com' in job_domain:
                self.bsubears_parser.parse_site(spider_id, job_id, job_tournament_url)

            elif 'plymouth.edu' in job_domain:
                self.plymouth_parser.parse_site(spider_id, job_id, job_tournament_url)

            elif 'usctrojans.com' in job_domain:
                self.usctrojans_parser.parse_site(spider_id, job_id, job_tournament_url)

            elif 'gomarquette.com' in job_domain:
                self.gomarquette_parser.parse_site(spider_id, job_id, job_tournament_url)

            elif 'gocrimson.com' in job_domain:
                self.gocrimson_parser.parse_site(spider_id, job_id, job_tournament_url)

            elif 'arizonawildcats.com' in job_domain:
                self.arizonawildcats_parser.parse_site(spider_id, job_id, job_tournament_url)

            elif 'storage.googleapis.com' in job_domain:
                for cls_parser in [self.plymouth_parser, self.usctrojans_parser, self.gocrimson_parser, self.arizonawildcats_parser]:
                    items_found = cls_parser.parse_pdf(spider_id, job_id, job_tournament_url, pdf_link=job_tournament_url)
                    if items_found:
                        break

            else:
                for cls_parser in [self.gobarrybucs_parser, self.auburntigers_parser, self.albertusfalcons_parser, self.bsubears_parser, self.plymouth_parser, self.usctrojans_parser, self.gomarquette_parser, self.gocrimson_parser, self.arizonawildcats_parser]:
                    items_found = cls_parser.parse_site(spider_id, job_id, job_tournament_url)
                    if items_found:
                        break
        except Exception:
            logger.error(traceback.format_exc())

        return items_found
