str1 = """
    <main id="main-wrapper" role="main" class="main-wrapper bg-dark text-dark">
            <div class="container p-4 border shadow-sm">
                
                
                <div class="page-related-links clearfix">
                                                                                                                                                                                                                                                                                                                                                        
                                <a class="list-group-item bg-primary text-white d-inline-block  font-weight-bold  " href="/sports/wten/2025-26/boxscores/20260201_c9az.xml" aria-label="Women's Tennis event: February 1 03:00 PM: Holy Cross at Marian (IN): Box Score">
                                                                                         <span class="far fa-chart-bar"></span>
                                                                                <span class="recap-label">Box Score</span>
                                </a> 
                                        </div> 
         


<div class="stats-wrapper tngame">

        <div class="align-center">
                    <span class="bold">Holy Cross  at  Marian (IN)</span>
        
        <br>@ Indianapolis
                            <br>02/01/2026
            at 03:00 PM EST                    </div><br>

        
                            
                                            
                                                                                            
        <div class="table-responsive">                                        <table class="table ">
            <tbody><tr>
                                                        
                    <td class="align-center" style="width:50%">

                                                <a href="../teams?id=prjcfsxb0vqt1ccd">
                                                <span class="stats-header">Holy Cross</span>
                                                </a>
                                                <br><span class="stats-header">2</span>
                    </td>
                                                        
                    <td class="align-center" style="width:50%">

                                                <span class="stats-header">Marian (IN)</span>
                                                <br><span class="stats-header">4</span>
                    </td>
                            </tr>
        </tbody></table></div>
    
        
    <div class="clearfix">
                    
                        
        <h2>Doubles</h2>
        
                                                                    
                        
                
                
                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                    
                
                <div class=" stats-halfbox-left ">
                                                            <div class="table-responsive">
                        <table class="table">
                            <tbody><tr>
                                <th class="align-left">FINAL</th>
                                                                                                            <th class="align-center have-sup">1</th>
                                                                                                                                </tr>
                                                            <tr>
                                    <td>
                                        
                                                                                                                                    Virginie Francois
                                                                                        /
                                                                                            Jamison Geofferys
                                                                                    
                                                                                    (Holy Cross)                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                1                                                                                                                                                                        </td>
                                                                                                                                                                                                    </tr>
                                                            <tr>
                                    <td>
                                                                                    <strong>&gt;</strong>
                                        
                                                                                                                                    Liliane Alinquant
                                                                                        /
                                                                                            Ana Barbosa
                                                                                    
                                                                                    (Marian (IN))                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                6                                                                                                                                                                        </td>
                                                                                                                                                                                                    </tr>
                                                        <tr class="title-row stats-highlight">
                                                                                                <td colspan="2">
                                    <div style="display: flex; justify-content: space-between;">
                                        <span>
                                                                                            #1 Doubles
                                                                                    </span>
                                        <span>
                                                                                    </span>
                                    </div>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                </div>
                
                     
                                                                    
                        
                
                
                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                    
                
                <div class=" stats-halfbox-right ">
                                                            <div class="table-responsive">
                        <table class="table">
                            <tbody><tr>
                                <th class="align-left">FINAL</th>
                                                                                                            <th class="align-center have-sup">1</th>
                                                                                                                                </tr>
                                                            <tr>
                                    <td>
                                                                                    <strong>&gt;</strong>
                                        
                                                                                                                                    Nicole Martinez
                                                                                        /
                                                                                            Anna Vanderhyde
                                                                                    
                                                                                    (Holy Cross)                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                7                                                                                                                                <span style="vertical-align: super; font-size: smaller;">
                                                                6
                                                            </span>
                                                                                                                                                            </td>
                                                                                                                                                                                                    </tr>
                                                            <tr>
                                    <td>
                                        
                                                                                                                                    Michelle Irigoyen
                                                                                        /
                                                                                            Jimena Rivera Flores
                                                                                    
                                                                                    (Marian (IN))                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                6                                                                                                                                <span style="vertical-align: super; font-size: smaller;">
                                                                4
                                                            </span>
                                                                                                                                                            </td>
                                                                                                                                                                                                    </tr>
                                                        <tr class="title-row stats-highlight">
                                                                                                <td colspan="2">
                                    <div style="display: flex; justify-content: space-between;">
                                        <span>
                                                                                            #2 Doubles
                                                                                    </span>
                                        <span>
                                                                                    </span>
                                    </div>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                </div>
                                    <div class="clear"></div>
                
                     
                                                                    
                        
                
                
                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                    
                
                <div class=" stats-halfbox-left ">
                                                            <div class="table-responsive">
                        <table class="table">
                            <tbody><tr>
                                <th class="align-left">FINAL</th>
                                                                                                            <th class="align-center have-sup">1</th>
                                                                                                                                </tr>
                                                            <tr>
                                    <td>
                                                                                    <strong>&gt;</strong>
                                        
                                                                                                                                    Viktoria Savvidou
                                                                                        /
                                                                                            Leah Gonzales- Edwards
                                                                                    
                                                                                    (Holy Cross)                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                7                                                                                                                                <span style="vertical-align: super; font-size: smaller;">
                                                                7
                                                            </span>
                                                                                                                                                            </td>
                                                                                                                                                                                                    </tr>
                                                            <tr>
                                    <td>
                                        
                                                                                                                                    Ana Lopez Torres
                                                                                        /
                                                                                            Yasmin Imamniyazova
                                                                                    
                                                                                    (Marian (IN))                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                6                                                                                                                                <span style="vertical-align: super; font-size: smaller;">
                                                                4
                                                            </span>
                                                                                                                                                            </td>
                                                                                                                                                                                                    </tr>
                                                        <tr class="title-row stats-highlight">
                                                                                                <td colspan="2">
                                    <div style="display: flex; justify-content: space-between;">
                                        <span>
                                                                                            #3 Doubles
                                                                                    </span>
                                        <span>
                                                                                    </span>
                                    </div>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                </div>
                
                                      <div class="clear"></div>
            
                
        <h2>Singles</h2>
        
                                                                    
                        
                
                
                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                            
                
                <div class=" stats-halfbox-left ">
                                                            <div class="table-responsive">
                        <table class="table">
                            <tbody><tr>
                                <th class="align-left">FINAL</th>
                                                                                                            <th class="align-center have-sup">1</th>
                                                                            <th class="align-center have-sup">2</th>
                                                                                                                                </tr>
                                                            <tr>
                                    <td>
                                        
                                                                                                                                                                                Viktoria Savvidou
                                                                                    
                                                                                    (Holy Cross)                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                2                                                                                                                                                                        </td>
                                                                                            <td class="align-center have-sup">
                                                                                                                                1                                                                                                                                                                        </td>
                                                                                                                                                                                                    </tr>
                                                            <tr>
                                    <td>
                                                                                    <strong>&gt;</strong>
                                        
                                                                                                                                                                                Yasmin Imamniyazova
                                                                                    
                                                                                    (Marian (IN))                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                6                                                                                                                                                                        </td>
                                                                                            <td class="align-center have-sup">
                                                                                                                                6                                                                                                                                                                        </td>
                                                                                                                                                                                                    </tr>
                                                        <tr class="title-row stats-highlight">
                                                                                                <td colspan="3">
                                    <div style="display: flex; justify-content: space-between;">
                                        <span>
                                                                                            #1 Singles
                                                                                    </span>
                                        <span>
                                                                                    </span>
                                    </div>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                </div>
                
                     
                                                                    
                        
                
                
                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                            
                
                <div class=" stats-halfbox-right ">
                                                            <div class="table-responsive">
                        <table class="table">
                            <tbody><tr>
                                <th class="align-left">FINAL</th>
                                                                                                            <th class="align-center have-sup">1</th>
                                                                            <th class="align-center have-sup">2</th>
                                                                                                                                </tr>
                                                            <tr>
                                    <td>
                                                                                    <strong>&gt;</strong>
                                        
                                                                                                                                                                                Leah Gonzales- Edwards
                                                                                    
                                                                                    (Holy Cross)                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                6                                                                                                                                                                        </td>
                                                                                            <td class="align-center have-sup">
                                                                                                                                6                                                                                                                                                                        </td>
                                                                                                                                                                                                    </tr>
                                                            <tr>
                                    <td>
                                        
                                                                                                                                                                                Michelle Irigoyen
                                                                                    
                                                                                    (Marian (IN))                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                2                                                                                                                                                                        </td>
                                                                                            <td class="align-center have-sup">
                                                                                                                                2                                                                                                                                                                        </td>
                                                                                                                                                                                                    </tr>
                                                        <tr class="title-row stats-highlight">
                                                                                                <td colspan="3">
                                    <div style="display: flex; justify-content: space-between;">
                                        <span>
                                                                                            #2 Singles
                                                                                    </span>
                                        <span>
                                                                                    </span>
                                    </div>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                </div>
                                    <div class="clear"></div>
                
                     
                                                                    
                        
                
                
                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                            
                
                <div class=" stats-halfbox-left ">
                                                            <div class="table-responsive">
                        <table class="table">
                            <tbody><tr>
                                <th class="align-left">FINAL</th>
                                                                                                            <th class="align-center have-sup">1</th>
                                                                            <th class="align-center have-sup">2</th>
                                                                                                                                </tr>
                                                            <tr>
                                    <td>
                                        
                                                                                                                                                                                Sofia Rocha
                                                                                    
                                                                                    (Holy Cross)                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                1                                                                                                                                                                        </td>
                                                                                            <td class="align-center have-sup">
                                                                                                                                3                                                                                                                                                                        </td>
                                                                                                                                                                                                    </tr>
                                                            <tr>
                                    <td>
                                                                                    <strong>&gt;</strong>
                                        
                                                                                                                                                                                Jimena Rivera Flores
                                                                                    
                                                                                    (Marian (IN))                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                6                                                                                                                                                                        </td>
                                                                                            <td class="align-center have-sup">
                                                                                                                                6                                                                                                                                                                        </td>
                                                                                                                                                                                                    </tr>
                                                        <tr class="title-row stats-highlight">
                                                                                                <td colspan="3">
                                    <div style="display: flex; justify-content: space-between;">
                                        <span>
                                                                                            #3 Singles
                                                                                    </span>
                                        <span>
                                                                                    </span>
                                    </div>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                </div>
                
                     
                                                                    
                        
                
                
                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                    
                
                <div class=" stats-halfbox-right ">
                                                            <div class="table-responsive">
                        <table class="table">
                            <tbody><tr>
                                <th class="align-left">FINAL</th>
                                                                                                            <th class="align-center have-sup">1</th>
                                                                            <th class="align-center have-sup">2</th>
                                                                            <th class="align-center have-sup">3</th>
                                                                                                                                </tr>
                                                            <tr>
                                    <td>
                                                                                    <strong>&gt;</strong>
                                        
                                                                                                                                                                                Nicole Martinez
                                                                                    
                                                                                    (Holy Cross)                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                0                                                                                                                                                                        </td>
                                                                                            <td class="align-center have-sup">
                                                                                                                                6                                                                                                                                                                        </td>
                                                                                            <td class="align-center have-sup">
                                                                                                                                4                                                                                                                                                                        </td>
                                                                                                                                                                                                    </tr>
                                                            <tr>
                                    <td>
                                        
                                                                                                                                                                                Ana Lopez Torres
                                                                                    
                                                                                    (Marian (IN))                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                6                                                                                                                                                                        </td>
                                                                                            <td class="align-center have-sup">
                                                                                                                                3                                                                                                                                                                        </td>
                                                                                            <td class="align-center have-sup">
                                                                                                                                0                                                                                                                                                                        </td>
                                                                                                                                                                                                    </tr>
                                                        <tr class="title-row stats-highlight">
                                                                                                <td colspan="4">
                                    <div style="display: flex; justify-content: space-between;">
                                        <span>
                                                                                            #4 Singles
                                                                                    </span>
                                        <span>
                                                                                    </span>
                                    </div>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                </div>
                                    <div class="clear"></div>
                
                     
                                                                    
                        
                
                
                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                            
                
                <div class=" stats-halfbox-left ">
                                                            <div class="table-responsive">
                        <table class="table">
                            <tbody><tr>
                                <th class="align-left">FINAL</th>
                                                                                                            <th class="align-center have-sup">1</th>
                                                                            <th class="align-center have-sup">2</th>
                                                                                                                                </tr>
                                                            <tr>
                                    <td>
                                        
                                                                                                                                                                                Anna Vanderhyde
                                                                                    
                                                                                    (Holy Cross)                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                0                                                                                                                                                                        </td>
                                                                                            <td class="align-center have-sup">
                                                                                                                                4                                                                                                                                                                        </td>
                                                                                                                                                                                                    </tr>
                                                            <tr>
                                    <td>
                                                                                    <strong>&gt;</strong>
                                        
                                                                                                                                                                                Liliane Alinquant
                                                                                    
                                                                                    (Marian (IN))                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                6                                                                                                                                                                        </td>
                                                                                            <td class="align-center have-sup">
                                                                                                                                6                                                                                                                                                                        </td>
                                                                                                                                                                                                    </tr>
                                                        <tr class="title-row stats-highlight">
                                                                                                <td colspan="3">
                                    <div style="display: flex; justify-content: space-between;">
                                        <span>
                                                                                            #5 Singles
                                                                                    </span>
                                        <span>
                                                                                    </span>
                                    </div>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                </div>
                
                     
                                                                    
                        
                
                
                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                            
                
                <div class=" stats-halfbox-right ">
                                                            <div class="table-responsive">
                        <table class="table">
                            <tbody><tr>
                                <th class="align-left">FINAL</th>
                                                                                                            <th class="align-center have-sup">1</th>
                                                                            <th class="align-center have-sup">2</th>
                                                                                                                                </tr>
                                                            <tr>
                                    <td>
                                        
                                                                                                                                                                                Virginie Francois
                                                                                    
                                                                                    (Holy Cross)                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                0                                                                                                                                                                        </td>
                                                                                            <td class="align-center have-sup">
                                                                                                                                1                                                                                                                                                                        </td>
                                                                                                                                                                                                    </tr>
                                                            <tr>
                                    <td>
                                                                                    <strong>&gt;</strong>
                                        
                                                                                                                                                                                Paloma Caceres
                                                                                    
                                                                                    (Marian (IN))                                                                            </td>
                                                                                                                                                                        <td class="align-center have-sup">
                                                                                                                                6                                                                                                                                                                        </td>
                                                                                            <td class="align-center have-sup">
                                                                                                                                4                                                                                                                                                                        </td>
                                                                                                                                                                                                    </tr>
                                                        <tr class="title-row stats-highlight">
                                                                                                <td colspan="3">
                                    <div style="display: flex; justify-content: space-between;">
                                        <span>
                                                                                            #6 Singles
                                                                                    </span>
                                        <span>
                                                                                    </span>
                                    </div>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                </div>
                                    <div class="clear"></div>
                
                                      </div>

    
        
    

</div>     


    



    <script type="text/javascript">
    $(function(){
        $('.stats-wrapper .stats-halfbox-left table, .stats-wrapper .stats-halfbox-right table').each(function(){
            var table = $(this),
                    removed = 0,
                    titleRow;

            table.find('tr:not(:first):not(.title-row):last td:empty').each(function(){
                var index = $(this).index();
                table.find('td:nth-child(' + (index + 1) + '), th:nth-child(' + (index + 1) + ')').remove();
                removed ++;
            })

            if (removed > 0) {
                titleRow = table.find('tr.title-row td');
                titleRow.attr('colspan', Number(titleRow.attr('colspan')) - removed);
            }
        })
    })
</script>

                    

        
        <div id="box_scores_89ddf24b-885c-46a8-8455-a68f77e0c82c" key="googleAdContainer" adspot="PS_WEB/PS_WEB_INTERNAL_LEADERBOARD" sizes="[[728,90],[300,250]]"></div>

<script type="text/javascript" src="/info/ga/include.js" async="" data-uid="UA-1939879-1"></script> 
                 



<div class="sharing-buttons clearfix my-3 container p-0">
    
    <div class="d-flex flex-row gap-2 justify-content-start align-items-center">
        <div class="sharing-button-heading text-small small text-muted nowrap">Share</div>
        <div class="social-sharing-button-group">
            <div class="btn-group btn-group-sm">

                                    <!-- Sharingbutton Facebook -->
                    <a class="btn btn-small btn-link btn-outline-social d-block" href="https://facebook.com/sharer/sharer.php?u=https://www.hcsaints.com/sports/wten/2025-26/boxscores/20260201_c9az.xml" target="_blank" rel="noopener" aria-label="Share this page on Facebook">
                        <span class="fab fa-facebook-f"></span><span class="sr-only">Facebook</span>
                    </a>
                
                                    <!-- Sharingbutton Twitter -->
                    <a class="btn btn-small btn-link btn-outline-social d-block" href="https://twitter.com/intent/tweet/?text=&amp;url=https://www.hcsaints.com/sports/wten/2025-26/boxscores/20260201_c9az.xml" target="_blank" rel="noopener" aria-label="Share this page on Twitter">
                        <span class="fab fa-x-twitter"></span><span class="sr-only">Twitter</span>
                    </a>
                
                                    <!-- Sharingbutton E-Mail -->
                    <a class="btn btn-small btn-link btn-outline-social d-block" href="mailto:?subject=&amp;body=https://www.hcsaints.com/sports/wten/2025-26/boxscores/20260201_c9az.xml" target="_self" rel="noopener" aria-label="Share this page via email">
                        <span class="fas fa-envelope"></span><span class="sr-only">Email</span>
                    </a>
                
                                    <a href="http://hcsaints.prestosports.com/sports/wten/2025-26/boxscores/20260201_c9az.xml?dec=printer-decorator" target="_blank" title="Print" class="printer-share btn btn-small btn-link btn-outline-social d-block" role="button" aria-label="Print this page">
                        <span class="fas fa-print"></span><span class="sr-only">Print</span>
                    </a>
                
            </div>
        </div>
    </div>
    </div>                 
                
                 
            </div>
        </main>
            """

import logging, coloredlogs, re, json, traceback
from scrapy.selector import Selector
from openai import OpenAI
from datetime import datetime

logger = logging.getLogger("scraper")
logger.setLevel(logging.INFO)
coloredlogs.install(level="INFO", logger=logger)
logger.propagate = False



class fctcore:
    @staticmethod
    def convert_string_to_date_format(date_str: str, in_format: str = '%Y-%m-%d', out_format: str = '%Y-%m-%d', job_tournament_url='', list_in_format=None) -> str:
        """
        Converts a date string into a specific date format.

        Args:
            date_str (str): The date string to be converted (e.g., "2024-11-19").
            in_format (str, optional): The desired format for the input date (default is '%Y-%m-%d').
            out_format (str, optional): The desired format for the output date (default is '%Y-%m-%d').

        Returns:
            str: The date in the specified format.

        # Example usage:
        date_str = "2024-11-19T15:30:00Z"
        date_converted = convert_string_to_date_format(date_str, in_format='%Y-%m-%d', out_format='%Y-%m-%d')
        print(date_converted)  # Output: '2024-11-19'
        """
        if date_str:
            if list_in_format:
                for in_format in list_in_format:
                    try:
                        return datetime.strptime(date_str, in_format).strftime(out_format)
                    except Exception:
                        if job_tournament_url:
                            logger.error(f'job_tournament_url: {job_tournament_url} | {traceback.format_exc()}')
                        else:
                            logger.error(traceback.format_exc())
            else:
                try:
                    return datetime.strptime(date_str, in_format).strftime(out_format)
                except Exception:
                    if job_tournament_url:
                        logger.error(f'job_tournament_url: {job_tournament_url} | {traceback.format_exc()}')
                    else:
                        logger.error(traceback.format_exc())
        return ''

    @staticmethod
    def parse_field(selector: str, html_content) -> str:
        """
        Extracts the value from an HTML element using an XPath selector.

        Args:
            selector (str): The XPath selector to locate the element from which to extract the value.
            html_content: The HTML content to parse (e.g., an HTML element or document).

        Returns:
            str: The extracted value from the element. Returns an empty string if no value is found or an error occurs.

        # Example usage:
        selector = "//div[@class='example-class']/text()"
        html_content = response.html  # Assuming response.html is a parsed HTML document
        print(parse_field(selector, html_content))  # Output: Extracted text or empty string
        """

        value = ''
        try:
            value = html_content.xpath(f'normalize-space({selector})').get().strip()
        except Exception:
            logger.error(traceback.format_exc())
            value = ''

        return value

class helper:
    @staticmethod
    def clean_name(s: str) -> str:
        s = s.strip()
        s = re.sub(r'^\(\s*\d+\s*,\s*', '', s)
        s = re.sub(r'[^A-Za-zÀ-ÖØ-öø-ÿ,\s-]', '', s)
        s = re.sub(r'\s+', ' ', s)
        return s.strip()

    @staticmethod
    def get_official_college_name(input_name, ai_client):
        college_name = 'Unknown'
        try:
            if input_name:
                logger.info(f'new: get_official_college_name input_name: {input_name}')

                system_prompt = """
                You are a data standardization assistant. Your job is to identify the official, full, 
                formal name of a college or university based on a user-provided name, nickname, 
                abbreviation, or partial text. 
                Return only the official institution name used by the college itself. 
                If multiple institutions match, return the most common U.S. one. 
                If you can't determine with high confidence, return "Unknown".

                Return results as:
                {"official_name": "<name>"}
                """

                user_prompt = f'Convert this college name to its official full name: "{input_name}"'

                logger.info(f'system_prompt: {system_prompt}')
                logger.info(f'user_prompt: {user_prompt}')

                response = ai_client.chat.completions.create(
                    model="gpt-4.1-mini",  # Cheap + fast. Change model as desired.
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ]
                )

                results_ai = response.choices[0].message.content
                logger.info(f'results_ai: {results_ai}')

                if results_ai:
                    college_name = json.loads(results_ai).get('official_name', '')

                    logger.info(f'final | get_official_college_name | input_name: {input_name} | college_name: {college_name}')

        except:
            logger.error(traceback.format_exc())

        return college_name

    @staticmethod
    def get_gender_from_players_list_gpt(players_names, ai_client):
        gender = ''
        try:
            if players_names:
                players_list = "; ".join(p for p in players_names if p)

                system_prompt = f'''
                    In context of this list of player names: "{players_list}", provide me with the gender of the list as a whole. Your response must be in JSON format. The JSON object you return must have a key of `Gender`. The value attached to the `Gender` key should only either be `Male` or `Female`.
                '''

                logger.info(f'system_prompt: {system_prompt}')

                response = ai_client.chat.completions.create(
                    model="gpt-4.1-mini",  # Cheap + fast. Change model as desired.
                    messages=[
                        {"role": "system", "content": system_prompt},
                    ]
                )

                results_ai = response.choices[0].message.content
                logger.info(f'results_ai: {results_ai}')

                results_json = {}
                if results_ai:
                    results_json = json.loads(results_ai.replace("```", "").replace("json", "").strip())

                    if results_json:
                        gender = str(results_json['Gender']).title()

                logger.info(f'get_gender_from_gpt | results_json: {results_json} | gender: {gender}')

        except:
            logger.error(traceback.format_exc())

        return gender




class Parser:
    def __init__(self):
        self.api_key = 'sk-YOrJGpvshTTqKR9_IaG-THyz42g02VFulq5PlAgRs7T3BlbkFJskLA-n-fn7jSaEEXIK1UzD0XxYfwM4VfXqXaX6-KAA'
        self.ai_client = OpenAI(api_key=self.api_key)




    def format_lastname_firstname(self, name):
        parts = name.strip().split()
        if len(parts) < 2:
            return name.strip()
        return f"{' '.join(parts[1:])}, {parts[0]}"

    def extract_players(self, raw):
        """
        Handles:
        - Singles / Doubles
        - Nested colleges like (Regis (Mass.))
        - Does NOT corrupt names
        """
        raw = re.sub(r'\s+', ' ', raw).strip()

        # split doubles players
        parts = [p.strip() for p in raw.split('/') if p.strip()]
        players = []

        for p in parts:
            # ---- extract college (last parentheses block, supports nested) ----
            college = ""
            matches = re.findall(r'\(([^()]*(?:\([^()]*\)[^()]*)*)\)', raw)
            if matches:
                college = matches[-1].strip()

            # ---- clean name safely ----
            if '(' in p:
                name_only = p[:p.find('(')].strip()
            else:
                name_only = p.strip()

            name_fmt = self.format_lastname_firstname(name_only)

            players.append({
                "name": name_fmt,
                "college": college
            })

        return players

    def extract_scores(self, row):
        scores = []
        for td in row.xpath('.//td[contains(@class,"align-center")]'):
            txt = td.xpath('normalize-space(text())').get()
            if txt and txt.isdigit():
                scores.append(txt)
        return scores


    def parse_match(self, table_html):
        sel = Selector(text=table_html.get())

        title = sel.xpath(
            './/tr[contains(@class,"title-row")]//span[1]/text()'
        ).get(default='').strip()

        rows = sel.xpath('.//tr[td and not(contains(@class,"title-row"))]')
        if len(rows) != 2:
            return {
                "draw_name": "",
                "draw_team_type": "",
                "winner_1_name": "",
                "winner_2_name": "",
                "winner_college": "",
                "loser_1_name": "",
                "loser_2_name": "",
                "loser_college": "",
                "score": "",
            }

        entries = []
        for row in rows:
            is_winner = bool(row.xpath('.//strong[contains(text(),">")]'))

            raw_name = ' '.join(
                t.strip()
                for t in row.xpath('.//td[1]//text()').getall()
                if t.strip() and t.strip() != '>'
            )

            entries.append({
                "players": self.extract_players(raw_name),
                "scores": self.extract_scores(row),
                "is_winner": is_winner
            })

        win = entries[0] if entries[0]["is_winner"] else entries[1]
        los = entries[1] if entries[0]["is_winner"] else entries[0]

        match_type = "Doubles" if len(win["players"]) == 2 else "Singles"

        score = ' '.join(
            f"{a}-{b}" for a, b in zip(win["scores"], los["scores"])
        ) + ';'

        return {
            "draw_name": title.title(),
            "draw_team_type": match_type.title(),

            "winner_1_name": helper.clean_name(win["players"][0]["name"]),
            "winner_2_name": helper.clean_name(win["players"][1]["name"]) if match_type == "Doubles" else "",
            "winner_college": win["players"][0]["college"],

            "loser_1_name": helper.clean_name(los["players"][0]["name"]),
            "loser_2_name": helper.clean_name(los["players"][1]["name"]) if match_type == "Doubles" else "",
            "loser_college": los["players"][0]["college"],

            "score": score
        }

    def extract_all_player_names(self, table_html: Selector):
        rows = table_html.xpath('.//tr[td and not(contains(@class,"title-row"))]')
        entries = []

        for row in rows:
            raw_name = ' '.join(
                t.strip()
                for t in row.xpath('.//td[1]//text()').getall()
                if t.strip() and t.strip() != '>'
            )

            if not raw_name:
                continue

            players = self.extract_players(raw_name)
            for player in players:
                entries.append(player['name'])

        return entries

    def parse_team_data(self, html1):
        cells = html1.xpath('//table//tr/td')
        parsed = []

        for td in cells:
            texts = td.xpath('.//span[@class="stats-header"]/text()').getall()
            if len(texts) >= 2:
                name = texts[0].strip()
                score_txt = texts[1].strip()
                if name and score_txt.isdigit():
                    parsed.append((name, int(score_txt)))

        if len(parsed) != 2:
            return "", "", ""

        winner, loser = sorted(parsed, key=lambda x: x[1], reverse=True)
        winner_team = winner[0]
        loser_team = loser[0]
        team_score = f"{winner[1]}-{loser[1]};"

        winner_team = helper.get_official_college_name(winner_team, self.ai_client)
        loser_team = helper.get_official_college_name(loser_team, self.ai_client)

        return winner_team, loser_team, team_score


if __name__ == "__main__":
    html1 = Selector(text=str1)
    parser = Parser()

    winner_team, loser_team, team_score = parser.parse_team_data(html1)
    logger.info(f'winner_team: {winner_team}')
    logger.info(f'loser_team: {loser_team}')
    logger.info(f'team_score: {team_score}')

    job_tournament_url = ''
    tournament_name_pre = f"Dual Match: {winner_team} vs {loser_team}"
    logger.info(f'tournament_name_pre: {tournament_name_pre}')

    tournament_date = fctcore.convert_string_to_date_format(
        fctcore.parse_field('//div[contains(@class,"align-center")]/text()[contains(normalize-space(.), " at ")]', html1).split(' at ')[0].strip(), list_in_format=['%b %d, %Y', '%m/%d/%Y'],
        out_format='%m/%d/%Y', job_tournament_url=job_tournament_url)
    logger.info(f'tournament_date: {tournament_date}')

    players_names = []
    for d1 in html1.xpath('//div[contains(@class, "stats-halfbox")]/table'):
        for res in parser.extract_all_player_names(d1):
            players_names.append(res)
    players_names = list(set(players_names))
    logger.info(f'players_names: {players_names}')

    draw_gender = helper.get_gender_from_players_list_gpt(players_names, parser.ai_client)
    logger.info(f'draw_gender: {draw_gender}')

    for d1 in html1.xpath('//div[contains(@class, "stats-halfbox")]//table'):
        match_data = parser.parse_match(d1)
        logger.info(f'match_data: {match_data}')
