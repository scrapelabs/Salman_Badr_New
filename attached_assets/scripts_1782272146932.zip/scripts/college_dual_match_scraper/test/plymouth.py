import logging, coloredlogs, os, re, traceback, json, requests
from datetime import datetime
from openai import OpenAI
from io import BytesIO

logger = logging.getLogger("scraper")
logger.setLevel(logging.INFO)
coloredlogs.install(level="INFO", logger=logger)
logger.propagate = False


class fctcore:
    @staticmethod
    def convert_string_to_date_format(date_str: str, in_format: str = '%Y-%m-%d', out_format: str = '%Y-%m-%d', job_tournament_url='', list_in_format=None) -> str:
        """
        Converts a date string into a specific date format.

        Args:
            date_str (str): The date string to be converted (e.g., "2024-11-19").
            in_format (str, optional): The desired format for the input date (default is '%Y-%m-%d').
            out_format (str, optional): The desired format for the output date (default is '%Y-%m-%d').

        Returns:
            str: The date in the specified format.

        # Example usage:
        date_str = "2024-11-19T15:30:00Z"
        date_converted = convert_string_to_date_format(date_str, in_format='%Y-%m-%d', out_format='%Y-%m-%d')
        print(date_converted)  # Output: '2024-11-19'
        """
        if date_str:
            if list_in_format:
                for in_format in list_in_format:
                    try:
                        return datetime.strptime(date_str, in_format).strftime(out_format)
                    except Exception:
                        if job_tournament_url:
                            logger.error(f'job_tournament_url: {job_tournament_url} | {traceback.format_exc()}')
                        else:
                            logger.error(traceback.format_exc())
            else:
                try:
                    return datetime.strptime(date_str, in_format).strftime(out_format)
                except Exception:
                    if job_tournament_url:
                        logger.error(f'job_tournament_url: {job_tournament_url} | {traceback.format_exc()}')
                    else:
                        logger.error(traceback.format_exc())
        return ''


class helper:
    @staticmethod
    def clean_name(s: str) -> str:
        s = s.strip()
        s = re.sub(r'^\(\s*\d+\s*,\s*', '', s)
        s = re.sub(r'[^A-Za-zÀ-ÖØ-öø-ÿ,\s-]', '', s)
        s = re.sub(r'\s+', ' ', s)
        return s.strip()


    @staticmethod
    def get_official_college_name(input_name, ai_client):
        college_name = 'Unknown'
        try:
            if input_name:
                logger.info(f'new: get_official_college_name input_name: {input_name}')

                system_prompt = """
                You are a data standardization assistant. Your job is to identify the official, full, 
                formal name of a college or university based on a user-provided name, nickname, 
                abbreviation, or partial text. 
                Return only the official institution name used by the college itself. 
                If multiple institutions match, return the most common U.S. one. 
                If you can't determine with high confidence, return "Unknown".

                Return results as:
                {"official_name": "<name>"}
                """

                user_prompt = f'Convert this college name to its official full name: "{input_name}"'

                logger.info(f'system_prompt: {system_prompt}')
                logger.info(f'user_prompt: {user_prompt}')

                response = ai_client.chat.completions.create(
                    model="gpt-4.1-mini",  # Cheap + fast. Change model as desired.
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ]
                )

                results_ai = response.choices[0].message.content
                logger.info(f'results_ai: {results_ai}')

                if results_ai:
                    college_name = json.loads(results_ai).get('official_name', '')

                    logger.info(f'final | get_official_college_name | input_name: {input_name} | college_name: {college_name}')

        except:
            logger.error(traceback.format_exc())

        return college_name

class Parser:
    def __init__(self):
        self.api_key = 'sk-YOrJGpvshTTqKR9_IaG-THyz42g02VFulq5PlAgRs7T3BlbkFJskLA-n-fn7jSaEEXIK1UzD0XxYfwM4VfXqXaX6-KAA'
        self.ai_client = OpenAI(api_key=self.api_key)


    def _clean_name(self, name: str) -> str:
        name = re.sub(r"^\d+\.\s*", "", name)
        name = re.sub(r"#\d+\s*", "", name)
        name = name.strip()
        parts = name.split()
        if len(parts) >= 2:
            return f"{parts[-1]}, {' '.join(parts[:-1])}"
        return name

    def _clean_score(self, score: str) -> str:
        score = re.sub(r"<[^>]+>", "", score)
        sets = re.findall(r"\d+-\d+", score)
        if "default" in score.lower():
            return "DEF;"
        return " ".join(sets) + ";" if sets else ""

    # =====================================================
    # ORIGINAL PARSER (UNCHANGED LOGIC)
    # =====================================================
    def parse_matches(self, text):

        if "singles competition" not in text.lower():
            return self._parse_second_type_matches(text)

        results = []
        current_type = None
        counter = {"Singles": 0, "Doubles": 0}

        for raw in text.splitlines():
            line = raw.strip()
            if not line:
                continue

            low = line.lower()

            if "singles competition" in low:
                current_type = "Singles"
                continue

            if "doubles competition" in low:
                current_type = "Doubles"
                continue

            # =====================================================
            # NEW CONDITION (ADDED ONLY)
            # Handle: vs. unfinished / vs. dnf
            # =====================================================
            if current_type and "vs." in line.lower() and any(x in line.lower() for x in ["unfinished", "dnf"]):

                m = re.search(
                    r"(.+?)\s*\(([^)]+)\)\s+vs\.\s+(.+?)\s*\(([^)]+)\)\s+(.+)",
                    line,
                    re.IGNORECASE
                )
                if m:
                    p1_raw, col1, p2_raw, col2, score_raw = m.groups()

                    winner_raw, winner_col = p1_raw, col1
                    loser_raw, loser_col = p2_raw, col2

                    winner_players = [self._clean_name(x) for x in winner_raw.split("/")]
                    loser_players = [self._clean_name(x) for x in loser_raw.split("/")]

                    counter[current_type] += 1

                    results.append({
                        "draw_name": f"#{counter[current_type]} {current_type}".title(),
                        "draw_team_type": current_type.title(),

                        "winner_1_name": helper.clean_name(winner_players[0]) if winner_players else "",
                        "winner_2_name": helper.clean_name(winner_players[1]) if len(winner_players) > 1 else "",
                        "winner_college": winner_col,

                        "loser_1_name": helper.clean_name(loser_players[0]) if loser_players else "",
                        "loser_2_name": helper.clean_name(loser_players[1]) if len(loser_players) > 1 else "",
                        "loser_college": loser_col,

                        "score": self._clean_score(score_raw),
                    })

                continue

            # =====================================================
            # ORIGINAL CONDITION (UNCHANGED)
            # =====================================================
            if "def." not in line or not current_type:
                continue

            m = re.search(
                r"(.+?)\s*\(([^)]+)\)\s+def\.\s+(.+?)\s*\(([^)]+)\)\s+(.+)",
                line
            )
            if not m:
                continue

            winner_raw, winner_col, loser_raw, loser_col, score_raw = m.groups()

            winner_players = [self._clean_name(x) for x in winner_raw.split("/")]
            loser_players = [self._clean_name(x) for x in loser_raw.split("/")]

            counter[current_type] += 1

            results.append({
                "draw_name": f"#{counter[current_type]} {current_type}".title(),
                "draw_team_type": current_type.title(),

                "winner_1_name": helper.clean_name(winner_players[0]) if winner_players else "",
                "winner_2_name": helper.clean_name(winner_players[1]) if len(winner_players) > 1 else "",
                "winner_college": winner_col,

                "loser_1_name": helper.clean_name(loser_players[0]) if loser_players else "",
                "loser_2_name": helper.clean_name(loser_players[1]) if len(loser_players) > 1 else "",
                "loser_college": loser_col,

                "score": self._clean_score(score_raw),
            })

        return results


    # =====================================================
    # SECOND TYPE PARSER (UNCHANGED)
    # =====================================================
    def _parse_second_type_matches(self, text):
        results = []
        current_type = None
        counter = {"Singles": 0, "Doubles": 0}

        for raw in text.splitlines():
            line = raw.strip()
            if not line:
                continue

            low = line.lower()

            if low == "singles":
                current_type = "Singles"
                continue

            if low == "doubles":
                current_type = "Doubles"
                continue

            if not current_type:
                continue

            m = re.search(
                r"\d+\.\s+(.+?)\s*\(([^)]+)\)\s+(def\.|vs\.)\s+(.+?)\s*\(([^)]+)\)\s*(.*)",
                line,
                re.IGNORECASE,
            )
            if not m:
                continue

            p1_raw, col1, sep, p2_raw, col2, score_raw = m.groups()
            score_low = score_raw.lower()

            if sep.lower() == "vs." and not any(x in score_low for x in ["dnf", "unfinished"]):
                continue

            winner_raw, winner_col = p1_raw, col1
            loser_raw, loser_col = p2_raw, col2

            winner_players = [self._clean_name(x) for x in winner_raw.split("/")]
            loser_players = [self._clean_name(x) for x in loser_raw.split("/")]

            counter[current_type] += 1

            results.append({
                "draw_name": f"#{counter[current_type]} {current_type}".title(),
                "draw_team_type": current_type,

                "winner_1_name": helper.clean_name(winner_players[0]) if winner_players else "",
                "winner_2_name": helper.clean_name(winner_players[1]) if len(winner_players) > 1 else "",
                "winner_college": winner_col,

                "loser_1_name": helper.clean_name(loser_players[0]) if loser_players else "",
                "loser_2_name": helper.clean_name(loser_players[1]) if len(loser_players) > 1 else "",
                "loser_college": loser_col,

                "score": self._clean_score(score_raw),
            })

        return results


    def parse_team_data(self, text, job_tournament_url):
        winner_team = ""
        loser_team = ""
        team_score = ""
        tournament_date = ""

        # -------------------------------------------------
        # 0) NORMALIZE RAW PDF TEXT (CRITICAL FIX)
        # -------------------------------------------------
        text = text.replace('\xa0', ' ')
        text = text.replace('\r', '\n')
        text = re.sub(r'[ \t]+', ' ', text)
        text = re.sub(r'\n+', '\n', text)

        # -------------------------------------------------
        # 1) TOURNAMENT DATE
        # -------------------------------------------------

        date_match = re.search(
            r"\b("
            r"Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|"
            r"Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|"
            r"Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?"
            r")\s+\d{1,2},\s+\d{4}|\d{1,2}/\d{1,2}/\d{4}\b",
            text
        )

        logger.info(f'date_match: {date_match}')

        if date_match:
            try:
                tournament_date = fctcore.convert_string_to_date_format(date_match.group(0), list_in_format=['%b %d, %Y', '%B %d, %Y', '%m/%d/%Y'], out_format='%m/%d/%Y', job_tournament_url=job_tournament_url)
            except Exception:
                logger.error(f'job_tournament_url: {job_tournament_url} | {traceback.format_exc()}')

        # -------------------------------------------------
        # 2) PRIMARY TEAM SCORE
        # Example: Holy Cross 7, Plymouth State 0
        # -------------------------------------------------
        score_pattern1 = re.compile(
            r"([A-Za-z .&'-]+)\s+(\d+)\s*,\s*([A-Za-z .&'-]+)\s+(\d+)",
            re.MULTILINE
        )

        score_pattern2 = re.compile(
            r"^\s*([A-Za-z .&'-]+?)\s+(\d{1,2})\s*,\s*([A-Za-z .&'-]+?)\s+(\d{1,2})\s*$",
            re.MULTILINE
        )

        score_pattern3 = re.compile(
            r"#?\d*\s*([A-Za-z .&'-]+)\s+(\d+)\s*,\s*#?\d*\s*([A-Za-z .&'-]+)\s+(\d+)",
            re.MULTILINE
        )

        for score_pattern in [score_pattern1, score_pattern2, score_pattern3]:
            score_match = score_pattern.search(text)

            if score_match:
                team1, score1, team2, score2 = score_match.groups()

                team1 = re.sub(r"\s+", " ", team1).strip()
                team2 = re.sub(r"\s+", " ", team2).strip()

                score1 = int(score1)
                score2 = int(score2)

                if score1 > score2:
                    winner_team = team1.strip()
                    loser_team = team2.strip()
                    team_score = f"{score1}-{score2};"
                else:
                    winner_team = team2.strip()
                    loser_team = team1.strip()
                    team_score = f"{score2}-{score1};"

                winner_team = helper.get_official_college_name(winner_team, self.ai_client)
                loser_team = helper.get_official_college_name(loser_team, self.ai_client)

                if winner_team != 'Unknown' and loser_team != 'Unknown':
                    return winner_team, loser_team, team_score, tournament_date

        # -------------------------------------------------
        # 3) FALLBACK — Match Notes Records (1-0 style)
        # -------------------------------------------------
        teams = []

        for raw in text.splitlines():
            line = raw.strip()
            if not line:
                continue

            m = re.match(r"(.+?)\s+(\d+)\s*-\s*(\d+)$", line)
            if not m:
                continue

            team = m.group(1).strip()
            losses = int(m.group(2))
            wins = int(m.group(3))

            teams.append((team, wins))

        if len(teams) == 2:
            winner, loser = sorted(teams, key=lambda x: x[1], reverse=True)
            winner_team = winner[0]
            loser_team = loser[0]
            team_score = f"{winner[1]}-{loser[1]};"


        winner_team = helper.get_official_college_name(winner_team, self.ai_client)
        loser_team = helper.get_official_college_name(loser_team, self.ai_client)

        return winner_team, loser_team, team_score, tournament_date

def extract_detached_scores(text):
    scores = []
    capture = False

    for line in text.splitlines():
        line = line.strip()

        if "match notes" in line.lower():
            capture = True
            continue

        if not capture:
            continue

        # Match: 6-4
        # Match: 7-6 (7-5)
        # Match: 1-0 (10-5)
        if re.fullmatch(r"\d+-\d+(?:\s*\(\d+-\d+\))?", line):
            scores.append(line)

    return scores


def group_scores_into_matches(scores, expected_matches):
    grouped = []
    current = []

    for s in scores:
        current.append(s)

        # Most singles are 2 sets
        if len(current) == 2:
            grouped.append(" ".join(current) + ";")
            current = []

    # Safety fallback
    if current:
        grouped.append(" ".join(current) + ";")

    return grouped[:expected_matches]

if __name__ == "__main__":
    pdf_text = """
Tennis Match Results
Duke vs South Carolina
2/8/2026 at Columbia, S.C.
(Carolina Indoor Tennis)

#14 South Carolina 4, #20 Duke 1

Singles competition
1. #23 Lucas da Silva (SC) def. #47 Cooper Williams (DU) 6-2, 6-3
2. #36 Sean Daryabeigi (SC) vs. #90 Pedro Rodenas (DU) 6-7 (3-7), 3-3, unfinished
3. #87 Paul Barbier Gazeu (SC) def. #78 G Planelles Ripoll (DU) 6-4, 6-4
4. Alexander Visser (DU) def. Atakan Karahan (SC) 6-2, 6-4
5. Max Stenzer (SC) vs. Dylan Long (DU) 6-2, 3-6, 3-2, unfinished
6. Charlie Swaine (SC) def. Teddy Truwit (DU) 6-2, 6-1

Doubles competition
1. #51 Lucas da Silva/Paul Barbier Gazeu (SC) def. #36 Cooper Williams/Pedro Rodenas (DU) 6-4
2. Dylan Long/G Planelles Ripoll (DU) def. Sean Daryabeigi/Charlie Swaine (SC) 6-4
3. Atakan Karahan/Cole Henceroth (SC) def. Alexander Visser/Teddy Truwit (DU) 6-4

Match Notes:
Order of finish: Doubles (2,1,3); Singles (6,1,3,4)
    """

    parser = Parser()
    matches_data = parser.parse_matches(pdf_text)
    logger.info(f'matches_data: {matches_data}')
    logger.info(f'matches_data: {len(matches_data)}')

    job_tournament_url = ''
    winner_team, loser_team, team_score, tournament_date = parser.parse_team_data(pdf_text, job_tournament_url)
    logger.info(f'winner_team: {winner_team}')
    logger.info(f'loser_team: {loser_team}')
    logger.info(f'team_score: {team_score}')
    logger.info(f'tournament_date: {tournament_date}')