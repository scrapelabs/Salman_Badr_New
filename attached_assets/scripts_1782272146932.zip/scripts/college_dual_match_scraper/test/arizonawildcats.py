import logging, coloredlogs, re, traceback
from scrapy.selector import Selector
from datetime import datetime, timedelta

logger = logging.getLogger("scraper")
logger.setLevel(logging.INFO)
coloredlogs.install(level="INFO", logger=logger)
logger.propagate = False


class fctcore:
    @staticmethod
    def convert_string_to_date_format(date_str: str, in_format: str = '%Y-%m-%d', out_format: str = '%Y-%m-%d', job_tournament_url='', list_in_format=None) -> str:
        if date_str:
            if list_in_format:
                for in_format in list_in_format:
                    try:
                        return datetime.strptime(date_str, in_format).strftime(out_format)
                    except Exception:
                        if job_tournament_url:
                            logger.error(f'job_tournament_url: {job_tournament_url} | {traceback.format_exc()}')
                        else:
                            logger.error(traceback.format_exc())
            else:
                try:
                    return datetime.strptime(date_str, in_format).strftime(out_format)
                except Exception:
                    if job_tournament_url:
                        logger.error(f'job_tournament_url: {job_tournament_url} | {traceback.format_exc()}')
                    else:
                        logger.error(traceback.format_exc())
        return ''


class helper:
    @staticmethod
    def clean_name(s: str) -> str:
        s = s.strip()
        s = re.sub(r'^\(\s*\d+\s*,\s*', '', s)
        s = re.sub(r'[^A-Za-zÀ-ÖØ-öø-ÿ,\s-]', '', s)
        s = re.sub(r'\s+', ' ', s)
        return s.strip()

    @staticmethod
    def get_official_college_name(team, ai_client=None):
        return team.strip()


class Parser:

    def __init__(self):
        self.ai_client = 'ai_client'

    # -------------------------------------------------
    # JOIN MULTI-LINE MATCHES (CRITICAL FIX)
    # -------------------------------------------------
    def _explode_matches(self, text: str):
        blocks = []
        buf = ""

        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue

            if re.match(r"^\d+\s+", line):
                if buf:
                    blocks.append(buf.strip())
                buf = line
            else:
                buf += " " + line

        if buf:
            blocks.append(buf.strip())

        return blocks

    # -------------------------------------------------
    # PLAYER NORMALIZER
    # -------------------------------------------------
    def _normalize_player(self, name: str) -> str:
        name = helper.clean_name(name)
        if "," in name:
            return name
        parts = name.split()
        return f"{parts[-1]}, {' '.join(parts[:-1])}" if len(parts) >= 2 else name

    # -------------------------------------------------
    # SCORE PARSER
    # -------------------------------------------------
    def _extract_score(self, line: str):
        sets = re.findall(r"\d+-\d+(?:\(\d+\))?", line)
        if "vs." in line.lower():
            sets.append("UF-UF")
        return " ".join(sets) + ";" if sets else ""

    # -------------------------------------------------
    # MAIN
    # -------------------------------------------------
    def parse_matches(self, text: str):
        results = []

        for block in self._explode_matches(text):

            if not ("(" in block and ("def." in block.lower() or "vs." in block.lower())):
                continue

            # match number
            m_num = re.match(r"^(\d+)", block)
            if not m_num:
                continue
            num = int(m_num.group(1))

            # players + colleges (flexible order)
            m = re.search(
                r"""
                ^\d+\s+
                (?P<winners>.+?)\s*\((?P<wcol>[^)]+)\)
                .*?(def\.|vs\.)
                .*?
                (?P<losers>.+?)\s*\((?P<lcol>[^)]+)\)
                """,
                block,
                re.VERBOSE | re.IGNORECASE,
            )
            if not m:
                continue

            winners_raw = m.group("winners")
            losers_raw = m.group("losers")
            w_col = m.group("wcol")
            l_col = m.group("lcol")

            is_doubles = " and " in winners_raw.lower() or "/" in winners_raw
            match_type = "Doubles" if is_doubles else "Singles"

            w_players = re.split(r"/| and ", winners_raw)
            l_players = re.split(r"/| and ", losers_raw)

            w_players = [self._normalize_player(p) for p in w_players]
            l_players = [self._normalize_player(p) for p in l_players]

            score = self._extract_score(block)

            results.append({
                "draw_name": f"#{num} {match_type.lower()}",
                "draw_team_type": match_type,
                "winner_1_name": w_players[0],
                "winner_2_name": w_players[1] if is_doubles and len(w_players) > 1 else "",
                "winner_college": w_col,
                "loser_1_name": l_players[0],
                "loser_2_name": l_players[1] if is_doubles and len(l_players) > 1 else "",
                "loser_college": l_col,
                "score": score,
                "outcome": "Tie" if "UF-UF" in score else "Completed",
            })

        return results



if __name__ == "__main__":

    pdf_text = """
Official Tennis Dual Match Results (Final)
Arizona (2-1) vs New Mexico State (0-5)
01/19/2026 at Tucson, AZ --
Match Score: Arizona 7, New Mexico State 0
# DOUBLES DRAWS
1 Filip Gustafsson and Glib Sekachov (AZ) def. 6-1
Holland Snell and Roko Stipetic (NMSU)
2 Zoran Ludoski and Alexander Rozin (AZ) def. 6-2
Laurendi Fischer and Patrick Lohmann (NMSU)
3 Oskar Jansson and Cole Stelse (AZ) vs.
TEAM and TEAM (NMSU)
# SINGLES DRAWS
1 Filip Gustafsson (AZ) def. Roko Stipetic (NMSU) 6-3 6-4
2 Zoran Ludoski (AZ) def. Holland Snell (NMSU) 6-3 6-3
3 Pepijn Bastiaansen (AZ) def. Laurendi Fischer (NMSU) 6-2 6-3
4 Alejandro Arcila (AZ) def. Thomas Duforets (NMSU) 6-1 6-0
5 Matthias Uwe Kask (AZ) def. Patrick Lohmann (NMSU) 6-1 6-1
6 Oskar Jansson (AZ) def. TEAM (NMSU) 1-0
DUAL SCORING
TM D1 D2 D3 S1 S2 S3 S4 S5 S6 TOT
AZ X X uf 1 1 1 1 1 1 1 7
NMSU uf 0
MATCH NOTES
Order of finish:
Singles -- 6 4 5 1 3 2 ; Doubles -- 1 2
Start Time:3:30 PM
Duration:2:00
Attendance:
    """

    parser = Parser()

    matches = parser.parse_matches(pdf_text)
    logger.info(f'matches: {matches}')
