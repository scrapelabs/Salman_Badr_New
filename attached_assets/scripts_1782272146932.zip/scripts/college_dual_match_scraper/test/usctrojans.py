import logging, coloredlogs, re, traceback
from scrapy.selector import Selector
from datetime import datetime, timedelta

logger = logging.getLogger("scraper")
logger.setLevel(logging.INFO)
coloredlogs.install(level="INFO", logger=logger)
logger.propagate = False


class fctcore:
    @staticmethod
    def convert_string_to_date_format(date_str: str, in_format: str = '%Y-%m-%d', out_format: str = '%Y-%m-%d', job_tournament_url='', list_in_format=None) -> str:
        if date_str:
            if list_in_format:
                for in_format in list_in_format:
                    try:
                        return datetime.strptime(date_str, in_format).strftime(out_format)
                    except Exception:
                        if job_tournament_url:
                            logger.error(f'job_tournament_url: {job_tournament_url} | {traceback.format_exc()}')
                        else:
                            logger.error(traceback.format_exc())
            else:
                try:
                    return datetime.strptime(date_str, in_format).strftime(out_format)
                except Exception:
                    if job_tournament_url:
                        logger.error(f'job_tournament_url: {job_tournament_url} | {traceback.format_exc()}')
                    else:
                        logger.error(traceback.format_exc())
        return ''


class helper:
    @staticmethod
    def clean_name(s: str) -> str:
        s = s.strip()
        s = re.sub(r'^\(\s*\d+\s*,\s*', '', s)
        s = re.sub(r'[^A-Za-zÀ-ÖØ-öø-ÿ,\s-]', '', s)
        s = re.sub(r'\s+', ' ', s)
        return s.strip()

    @staticmethod
    def get_official_college_name(team, ai_client=None):
        return team.strip()


class Parser:

    def __init__(self):
        self.ai_client = 'ai_client'

    def parse_team_data(self, text, job_tournament_url):
        header = re.search(
            r"#\s*\d+\s+(.+?)\s+(\d+),\s+#\s*\d+\s+(.+?)\s+(\d+)",
            text,
        )
        if not header:
            return "", "", "", ""

        t1, s1, t2, s2 = header.groups()

        if int(s1) > int(s2):
            winner_team, loser_team = t1.strip(), t2.strip()
            team_score = f"{s1}-{s2};"
        else:
            winner_team, loser_team = t2.strip(), t1.strip()
            team_score = f"{s2}-{s1};"

        # ✅ FIX: extract tournament date
        date_match = re.search(
            r"\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\.?\s+\d{1,2}",
            text,
        )
        tournament_date = ''
        if date_match:
            date1 = date_match.group(0)
            tournament_date = fctcore.convert_string_to_date_format(f'{date1} {datetime.now().year}', in_format='%b. %d %Y', out_format='%m/%d/%Y', job_tournament_url=job_tournament_url)

        if not tournament_date:
            # extract explicit MM/DD/YYYY date (e.g. 01/24/2026)
            tournament_date = ''
            date_match = re.search(r'\b\d{2}/\d{2}/\d{4}\b', text)
            if date_match:
                tournament_date = fctcore.convert_string_to_date_format(
                    date_match.group(0),
                    in_format='%m/%d/%Y',
                    out_format='%m/%d/%Y',
                    job_tournament_url=job_tournament_url,
                )

        winner_team = helper.get_official_college_name(winner_team, self.ai_client)
        loser_team = helper.get_official_college_name(loser_team, self.ai_client)

        return winner_team, loser_team, team_score, tournament_date


if __name__ == "__main__":

    pdf_text = """
    Oklahoma vs UCF
01/24/2026 at Berkeley, CA
(Hellman Tennis Complex)

#12 UCF 4, #17 Oklahoma 3

Singles competition
1. Yassine Dlimi (UCF) def. #57 Oscar Lacides (OU) 7-5, 6-4
2. #46 Luis Alvarez (OU) def. Wissam Abderrahman (UCF) 6-4, 6-2
3. Johan Rodriguez (OU) def. Mehdi Benchakroun (UCF) 6-1, 6-4
4. Pedro Rodrigues (UCF) def. Orel Kimhi (OU) 6-4, 6-2
5. Paul Colin (UCF) def. #74 Asahi Harazaki (OU) 2-6, 6-3, 7-5
6. Clement Lemire (UCF) def. Alejandro Melero (OU) 6-4, 5-7, 6-4

Doubles competition
1. Bruno Nhavene/Oscar Lacides (OU) def. Paul Colin/Yassine Dlimi (UCF) 6-3
2. Orel Kimhi/Johan Rodriguez (OU) def. Wissam Abderrahman/Mehdi Benchakroun (UCF) 7-6 (7-4)
3. Luca Hotze/Nicolas Oliveira (UCF) def. Luis Alvarez/Alejandro Melero (OU) 6-4

Match Notes:
Order of finish: Doubles (1,3,2); Singles (3,2,1,4,5,6)
T-3:55
    """

    parser = Parser()

    winner_team, loser_team, team_score, tournament_date = parser.parse_team_data(pdf_text, 'job_tournament_url')
    logger.info(f'winner_team: {winner_team}')
    logger.info(f'loser_team: {loser_team}')
    logger.info(f'team_score: {team_score}')
    logger.info(f'tournament_date: {tournament_date}')
