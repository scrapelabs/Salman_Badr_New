html = """
    <div id="DataTables_Table_1_wrapper" class="dataTables_wrapper no-footer"><table class="sidearm-table overall-stats highlight-hover highlight-column-hover centered-caption dataTable no-footer" sortable-table="" id="DataTables_Table_1" role="grid">
									<caption>#2 Doubles</caption>
									<thead>
										<tr role="row"><th scope="col" class="text-left sorting" tabindex="0" aria-controls="DataTables_Table_1" rowspan="1" colspan="1" aria-label="FINAL: activate to sort column descending" style="width: 599px;">FINAL</th><th scope="col" class="text-center sorting" data-label="set" tabindex="0" aria-controls="DataTables_Table_1" rowspan="1" colspan="1" aria-label="1: activate to sort column descending" style="width: 28px;">1</th></tr>
									</thead>
									<tbody>
									
										
									
										
									
									<tr role="row" class="odd">
											<td>
												
													<span class="boxscore-winner"><span class="sr-only">Winner</span></span>
												Eleana Yu / Claire An (29/-) [DUKE]
											</td>
											<td class="text-center" data-label="set_1">6</td>
										</tr><tr role="row" class="even">
											<td>
												<a href="/sports/womens-tennis/roster/mckenna-schaefbauer/15245" class="boxscore_player_link">Schaefbauer, McKenna</a> / <a href="/sports/womens-tennis/roster/kimiko-cooper/15416" class="boxscore_player_link">Cooper, Kimiko</a> [ILLINI]
											</td>
											<td class="text-center" data-label="set_1">2</td>
										</tr></tbody>
								</table></div>
								<div id="DataTables_Table_4_wrapper" class="dataTables_wrapper no-footer"><table class="sidearm-table overall-stats highlight-hover highlight-column-hover centered-caption dataTable no-footer" sortable-table="" id="DataTables_Table_4" role="grid">
									<caption>#2 Singles</caption>
									<thead>
										<tr role="row"><th scope="col" class="text-left sorting" tabindex="0" aria-controls="DataTables_Table_4" rowspan="1" colspan="1" aria-label="FINAL: activate to sort column descending" style="width: 493px;">FINAL</th><th scope="col" class="text-center sorting" data-label="set" tabindex="0" aria-controls="DataTables_Table_4" rowspan="1" colspan="1" aria-label="1: activate to sort column descending" style="width: 73px;">1</th><th scope="col" class="text-center sorting" data-label="set" tabindex="0" aria-controls="DataTables_Table_4" rowspan="1" colspan="1" aria-label="2: activate to sort column descending" style="width: 45px;">2</th></tr>
									</thead>
									<tbody>
									
										
									
										
									
									<tr role="row" class="odd">
											<td>
												
													<span class="boxscore-winner"><span class="sr-only">Winner</span></span>
												Liv Hovde (120/-) [DUKE]
											</td>
											<td class="text-center" data-label="set_1">7 <sup>7</sup></td><td class="text-center" data-label="set_2">6</td>
										</tr><tr role="row" class="even">
											<td>
												<a href="/sports/womens-tennis/roster/kimiko-cooper/15416" class="boxscore_player_link">Cooper, Kimiko</a> [ILLINI]
											</td>
											<td class="text-center" data-label="set_1">6 <sup>3</sup></td><td class="text-center" data-label="set_2">3</td>
										</tr></tbody>
								</table></div>
            """

import logging, coloredlogs, re
from scrapy.selector import Selector

logger = logging.getLogger("scraper")
logger.setLevel(logging.INFO)
coloredlogs.install(level="INFO", logger=logger)
logger.propagate = False


class helper:
    @staticmethod
    def clean_name(s: str) -> str:
        s = s.strip()
        s = re.sub(r'^\(\s*\d+\s*,\s*', '', s)
        s = re.sub(r'[^A-Za-zÀ-ÖØ-öø-ÿ,\s-]', '', s)
        s = re.sub(r'\s+', ' ', s)
        return s.strip()


class Parser:
    def _fmt_name(self, name: str) -> str:
        name = name.strip()
        if "," in name:
            return name
        parts = name.split()
        if len(parts) >= 2:
            return f"{parts[-1]}, {' '.join(parts[:-1])}"
        return name

    def _extract_college(self, td):
        """
        Extract college code from [STU], [BARRY-M], etc.
        """
        text = " ".join(td.xpath(".//text()").getall())
        m = re.search(r"\[([A-Z0-9\-]+)\]", text)
        return m.group(1) if m else ""


    def _extract_players00(self, td):
        links = td.xpath(".//a/text()").getall()
        if links:
            return [self._fmt_name(x) for x in links]

        texts = td.xpath(".//text()[not(ancestor::span)]").getall()
        text = " ".join(texts).strip()
        text = re.sub(r"\[.*?\]", "", text)  # remove college
        text = text.split("[")[0].strip()

        return [self._fmt_name(x) for x in text.split("/") if x.strip()]

    def _extract_players(self, td):
        """
        Extract players correctly even when one name is plain text
        and the other is inside <a>.
        Also handles rankings like (29/-) or (120/-).
        """

        # Get full visible text inside td
        text = " ".join(td.xpath(".//text()").getall())
        text = re.sub(r"\s+", " ", text).strip()

        # Remove college code [XXX]
        text = re.sub(r"\[.*?\]", "", text).strip()

        # Remove rankings like (29/-) or (120/-)
        text = re.sub(r"\(\s*\d+\s*/\s*[-\d]+\s*\)", "", text).strip()

        # Remove 'Winner' hidden label if present
        text = re.sub(r"Winner", "", text, flags=re.IGNORECASE).strip()

        # Normalize spacing around slash
        text = re.sub(r"\s*/\s*", "/", text)

        # Split players
        players = [p.strip() for p in text.split("/") if p.strip()]

        return [self._fmt_name(p) for p in players]

    def _extract_scores(self, row):
        return [
            int(x)
            for x in row.xpath(".//td[@class='text-center']/text()").getall()
            if x.strip().isdigit()
        ]


    def parse_match(self, table_html):
        sel = Selector(text=table_html.get())
        rows = sel.xpath(".//tbody/tr")

        if len(rows) != 2:
            return {
                "winner_1_name": "",
                "winner_2_name": "",
                "winner_college": "",
                "loser_1_name": "",
                "loser_2_name": "",
                "loser_college": "",
                "score": "",
            }

        if rows[0].xpath(".//span[contains(@class,'boxscore-winner')]"):
            winner_row, loser_row = rows[0], rows[1]
        else:
            winner_row, loser_row = rows[1], rows[0]

        winner_td = winner_row.xpath("./td[1]")
        loser_td = loser_row.xpath("./td[1]")

        winner_players = self._extract_players(winner_td)
        loser_players = self._extract_players(loser_td)

        winner_scores = self._extract_scores(winner_row)
        loser_scores = self._extract_scores(loser_row)

        score = " ".join(f"{w}-{l}" for w, l in zip(winner_scores, loser_scores)) + ";"

        return {
            "winner_1_name": helper.clean_name(winner_players[0]) if winner_players else "",
            "winner_2_name": helper.clean_name(winner_players[1]) if len(winner_players) > 1 else "",
            "winner_college": self._extract_college(winner_td),

            "loser_1_name": helper.clean_name(loser_players[0]) if loser_players else "",
            "loser_2_name": helper.clean_name(loser_players[1]) if len(loser_players) > 1 else "",
            "loser_college": self._extract_college(loser_td),

            "score": score,
        }


if __name__ == "__main__":
    sel = Selector(text=html)
    parser = Parser()

    for d1 in sel.xpath('//table[contains(@class, "sidearm-table")]'):
        data = parser.parse_match(d1)
        logger.info(data)
