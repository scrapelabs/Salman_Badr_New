import time
from assets.fct.fctlog import logger
from assets.fct import fctcore
from scripts import helper
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn, TaskProgressColumn
from scripts.college_dual_match_scraper.schedule_parser import ScheduleParser
from scripts.college_dual_match_scraper.spreadsheets_parser import spreadsheetsParser
from scripts.college_dual_match_scraper.core_parser import CoreParser
from scripts.college_dual_match_scraper.parser.gobarrybucs import gobarrybucsParser
from scripts.college_dual_match_scraper.parser.auburntigers import auburntigersParser
from scripts.college_dual_match_scraper.parser.albertusfalcons import albertusfalconsParser
from scripts.college_dual_match_scraper.parser.bsubears import bsubearsParser
from scripts.college_dual_match_scraper.parser.plymouth import plymouthParser
from scripts.college_dual_match_scraper.parser.usctrojans import usctrojansParser
from scripts.college_dual_match_scraper.parser.gomarquette import gomarquetteParser
from scripts.college_dual_match_scraper.parser.gocrimson import gocrimsonParser
from scripts.college_dual_match_scraper.parser.arizonawildcats import arizonawildcatsParser
from app_spiders.models import jobsModel

start_dt = time.time()

class InfoParser:

    def __init__(self, progress):
        self.sheet_name = 'Main'
        self.progress = progress
        self.gobarrybucs_parser = gobarrybucsParser()
        self.auburntigers_parser = auburntigersParser()
        self.albertusfalcons_parser = albertusfalconsParser()
        self.bsubears_parser = bsubearsParser()
        self.plymouth_parser = plymouthParser()
        self.usctrojans_parser = usctrojansParser()
        self.gomarquette_parser = gomarquetteParser()
        self.gocrimson_parser = gocrimsonParser()
        self.arizonawildcats_parser = arizonawildcatsParser()

        self.core_parser = CoreParser(self.gobarrybucs_parser, self.auburntigers_parser, self.albertusfalcons_parser, self.bsubears_parser, self.plymouth_parser, self.usctrojans_parser, self.gomarquette_parser, self.gocrimson_parser, self.arizonawildcats_parser)
        self.schedule_parser = ScheduleParser(self.progress,  self.core_parser)
        self.spreadsheets_parser = spreadsheetsParser(self.sheet_name, self.progress, self.schedule_parser, self.core_parser)


    def parse_site(self, spider_id, job_id, job_tournament_url):
        if job_tournament_url:
            job_domain = fctcore.extract_domain(job_tournament_url)
            if 'docs.google.com' in job_domain:
                self.spreadsheets_parser.parse_site(spider_id, job_id, job_tournament_url)

            elif '/schedule' in job_tournament_url:
                job_schedule_link = job_tournament_url
                job_team = ''
                spreadsheet_key = ''
                self.schedule_parser.parse_schedule(spider_id, job_id, job_schedule_link, job_team, spreadsheet_key)

            else:
                self.core_parser.parse_site(spider_id, job_id, job_tournament_url)


def run(*args):
    # from app_spiders.models import JobsSpreadsheetsCollegeDualMatchScraperModel
    # logger.warning('Deleting old data app_jobs_college_dual_match_scraper_spreadsheets ...')
    # JobsCollegeDualMatchScraperSpreadsheetsModel.objects.all().delete()

    params = list(args)
    job_id = int(params[0])
    spider_name = params[1]
    folder_path = params[2]
    max_workers = int(params[3])

    base_file = f'{spider_name}__{job_id}__{fctcore.current_date("%Y-%m-%d_%H-%M")}.csv'

    job_obj = jobsModel.objects.get(id=job_id)
    spider_id = job_obj.spider_id
    job_settings = job_obj.job_settings
    job_tournament_urls = job_settings.get('tournament_url', '')

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(bar_width=100), TaskProgressColumn(), TextColumn("{task.completed}/{task.total}"), TimeElapsedColumn(), TimeRemainingColumn(), transient=False) as progress:
        if isinstance(job_tournament_urls, list):
            for job_tournament_url in job_tournament_urls:
                logger.info(f'spider_name: {spider_name} | job_id: {job_id} | job_tournament_url: {job_tournament_url}')
                InfoParser(progress).parse_site(spider_id, job_id, job_tournament_url)

        else:
            job_tournament_url = job_tournament_urls
            logger.info(f'spider_name: {spider_name} | job_id: {job_id} | job_tournament_url: {job_tournament_url}')

            InfoParser(progress).parse_site(spider_id, job_id, job_tournament_url)

    helper.finalize_items_from_db(job_obj, folder_path, base_file)
    helper.finalize_job(job_obj, base_file, folder_path)

    logger.info(f'script take {round(time.time()-start_dt, 2)} sec to finished')
