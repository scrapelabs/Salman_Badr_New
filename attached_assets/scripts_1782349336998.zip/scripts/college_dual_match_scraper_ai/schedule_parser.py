import traceback
from urllib.parse import urljoin
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts import helper
from scrapy.selector import Selector
from app_spiders.models import JobsSpreadsheetsCollegeDualMatchScraperAiModel

class ScheduleParser:

    def __init__(self, progress, core_parser, auburntigers_parser):
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=False, use_proxy=self.use_proxy)

        self.core_parser = core_parser
        self.auburntigers_parser = auburntigers_parser


    def parse_schedule(self, spider_id, job_id, job_schedule, job_team, spreadsheet_key, thread_num):
        try:
            logger.info(f'job_schedule: {job_schedule}')
            job_schedule = helper.normalize_url(job_schedule)

            job_domain = fctcore.extract_domain(job_schedule, remove_www=False, with_scheme=True)
            logger.info(f'job_domain: {job_domain}')

            headers = {
                "Accept": "*/*",
                "Accept-Language": "en-US,en;q=0.9",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36",
            }
            response1 = self.fctrequest.request(method='GET', link=job_schedule, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    box_score_links = []
                    for d1 in html1.xpath('//a[normalize-space(.)="Box Score"]'):
                        box_score_link_pre = fctcore.parse_field('./@href', d1)
                        if box_score_link_pre:
                            box_score_link = urljoin(job_domain, box_score_link_pre)
                            box_score_links.append(box_score_link)

                    if not box_score_links:
                        for d1 in html1.xpath('//a[normalize-space(.)="Box Score (PDF)"]'):
                            box_score_link_pre = fctcore.parse_field('./@href', d1)
                            if box_score_link_pre:
                                box_score_link = urljoin(job_domain, box_score_link_pre)
                                box_score_links.append(box_score_link)

                    if not box_score_links:
                        for d1 in html1.xpath('//a[normalize-space(.)="PDF Box"]'):
                            box_score_link_pre = fctcore.parse_field('./@href', d1)
                            if box_score_link_pre:
                                box_score_link = urljoin(job_domain, box_score_link_pre)
                                box_score_links.append(box_score_link)

                    logger.info(f'box_score_links count: {len(box_score_links)}')

                    if box_score_links:
                        for box_score_link in box_score_links:
                            if not JobsSpreadsheetsCollegeDualMatchScraperAiModel.objects.filter(box_score_link=box_score_link).exists():
                                logger.info(f'box_score_link: {box_score_link}')

                                for cls_parser in [self.core_parser, self.auburntigers_parser]:
                                    items_found = cls_parser.parse_site(spider_id, job_id, box_score_link, thread_num)
                                    logger.info(f'box_score_link: {box_score_link} | items_found: {items_found}')

                                    if items_found:
                                        JobsSpreadsheetsCollegeDualMatchScraperAiModel(
                                            spreadsheet_key=spreadsheet_key,
                                            team=job_team,
                                            job_link=job_schedule,
                                            box_score_link=box_score_link,
                                        ).save()

                                    if items_found:
                                        break

        except Exception:
            logger.error(traceback.format_exc())
