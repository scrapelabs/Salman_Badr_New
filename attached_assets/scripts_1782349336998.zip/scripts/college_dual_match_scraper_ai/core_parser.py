import random
import traceback, json, os, uuid
from openai import OpenAI
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts import helper
from scrapy.selector import Selector
from app_spiders.models import JobsItemsCollegeDualMatchScraperAiModel
from scripts.college_dual_match_scraper_ai.claude_extractor import ClaudeExtractor

class CoreParser:

    def __init__(self):
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=False, use_proxy=self.use_proxy)

        self.openai_client = OpenAI(api_key=random.choice(settings.API_KEYS))
        self.tournament_date_prompt_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "prompt", "tournament_dates_prompt.txt")

        self.save_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "files")
        os.makedirs(self.save_dir, exist_ok=True)


    def parse_site(self, spider_id, job_id, job_tournament_url, thread_num):
        items_found = False
        try:
            claude_key = settings.CLAUDE_KEYS[thread_num]
            claude_client = ClaudeExtractor(api_key=claude_key)
            dual_match_prompt_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "prompt", "dual_match_extraction_prompt.txt")

            try:
                logger.info(f'job_tournament_url: {job_tournament_url}')

                headers = {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                    'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
                }
                response1 = self.fctrequest.request(method='GET', link=job_tournament_url, headers=headers, proxies=self.proxies, tries=3)
                if response1:
                    if response1.status_code in range(200, 300):
                        content1 = response1.text
                        html1 = Selector(text=content1)

                        pdf_link = fctcore.parse_field('//li[contains(@class, "sidearm-document-header-open")]//a[@data-test-id="s-btn__root"]/@href', html1)
                        if not pdf_link: pdf_link = fctcore.parse_field('//object[@type="application/pdf"]/@data', html1)
                        if not pdf_link: pdf_link = fctcore.parse_field('//li[@id="ctl00_cplhMainContent_btnOpen"]/a/@href', html1)
                        logger.info(f'pdf_link: {pdf_link}')

                        results_ai = {}
                        if pdf_link:
                            logger.info(f'pdf_link: {pdf_link}')

                            pdf_path = self.save_pdf(pdf_link)
                            logger.info(f'pdf_path: {pdf_path}')

                            if pdf_path:
                                results_ai = claude_client.extract(
                                    prompt_path=dual_match_prompt_path,
                                    input_path=pdf_path, # .pdf / .html / .xml
                                )

                                if results_ai:
                                    tournament_date = self.tournament_date_openai(results_ai, content1)
                                    for res_ai in results_ai:
                                        items_found = self.parse_page(spider_id, job_id, job_tournament_url, res_ai, tournament_date)

                                self.remove_file(pdf_path)


                        if "application/pdf" in response1.headers.get("Content-Type", "").lower() or response1.content[:5] == b"%PDF-":
                            pdf_name = f"{uuid.uuid4()}.pdf"
                            pdf_path = os.path.join(self.save_dir, pdf_name)
                            with open(pdf_path, "wb") as f:
                                f.write(response1.content)

                            results_ai = claude_client.extract(
                                prompt_path=dual_match_prompt_path,
                                input_path=pdf_path, # .pdf / .html / .xml
                            )

                            if results_ai:
                                tournament_date = self.tournament_date_openai(results_ai, content1)
                                for res_ai in results_ai:
                                    try:
                                        items_found = self.parse_page(spider_id, job_id, job_tournament_url, res_ai, tournament_date)
                                    except Exception:
                                        logger.error(traceback.format_exc())

                            self.remove_file(pdf_path)


                        if not results_ai:
                            html_path = self.save_html(content1)

                            results_ai = claude_client.extract(
                                prompt_path=dual_match_prompt_path,
                                input_path=html_path,  # .pdf / .html / .xml
                            )

                            if results_ai:
                                tournament_date = self.tournament_date_openai(results_ai, content1)
                                for res_ai in results_ai:
                                    try:
                                        items_found = self.parse_page(spider_id, job_id, job_tournament_url, res_ai, tournament_date)
                                    except Exception:
                                        logger.error(traceback.format_exc())

                            self.remove_file(html_path)

            except Exception:
                logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())

        return items_found

    def save_pdf(self, pdf_link):
        file_path = ''
        try:
            logger.info(f'pdf_link: {pdf_link}')

            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=pdf_link, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    file_name = f"{uuid.uuid4()}.pdf"
                    file_path = os.path.join(self.save_dir, file_name)
                    with open(file_path, "wb") as f:
                        f.write(response1.content)

        except Exception:
            logger.error(traceback.format_exc())

        return file_path


    def save_html(self, html_content):
        file_path = ''
        try:
            file_name = f"{uuid.uuid4()}.html"
            file_path = os.path.join(self.save_dir, file_name)
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(html_content)
        except Exception:
            logger.error(traceback.format_exc())
        return file_path


    def remove_file(self, file_path):
        try:
            os.remove(file_path)
        except FileNotFoundError:
            pass

    def parse_page(self, spider_id, job_id, job_tournament_url, res_ai, tournament_date):
        items_found = False
        try:
            match_id = ""
            ball_type = "Yellow"
            draw_bracket_value = ""
            draw_name = ""
            draw_team_type = ""
            tournament_name = ""
            date = ""
            score = ""
            winner_1_name = ""
            winner_1_gender = ""
            winner_1_third_party_id = ""
            winner_1_city = ""
            winner_1_country = ""
            winner_1_state = ""
            winner_2_name = ""
            winner_2_gender = ""
            winner_2_third_party_id = ""
            winner_2_city = ""
            winner_2_state = ""
            loser_1_name = ""
            loser_1_gender = ""
            loser_1_third_party_id = ""
            loser_1_city = ""
            loser_1_state = ""
            loser_1_country = ""
            loser_2_name = ""
            loser_2_gender = ""
            loser_2_third_party_id = ""
            loser_2_city = ""
            loser_2_state = ""
            outcome = "Completed"
            id_type = ""
            draw_bracket_type = ""
            draw_type = ""
            tournament_city = ""
            tournament_state = ""
            tournament_country_code = "USA"
            tournament_host = ""
            tournament_location_type = ""
            tournament_surface = ""
            tournament_event_category = ""
            tournament_event_grade = ""
            tournament_import_source = "College"
            tournament_sanction_body = "College"
            winner_2_country = ""
            winner_2_college = ""
            loser_2_country = ""
            loser_2_college = ""
            tournament_event_type = "Dual Match"
            winner_1_college = ""
            loser_1_college = ""
            tournament_url = job_tournament_url
            winner_1_dob = ""
            winner_2_dob = ""
            loser_1_dob = ""
            loser_2_dob = ""
            tournament_country = "USA"
            tournament_start_date = ""
            tournament_end_date = ""
            winner_team_type = "College"
            loser_team_type = "College"

            winner_team = ''
            loser_team = ''
            team_score = ''
            tournament_gender = ''
            draw_gender = ''

            date = tournament_start_date = tournament_end_date = tournament_date
            try:
                tournament_name = res_ai['tournament_name']
            except:
                ''
            try:
                tournament_gender = res_ai['tournament_gender']
            except:
                ''
            try:
                draw_name = res_ai['draw_name']
            except:
                ''
            try:
                draw_gender = res_ai['draw_gender']
            except:
                ''
            try:
                draw_team_type = res_ai['draw_team_type']
            except:
                ''
            try:
                winner_1_name = res_ai['winner_1_name']
            except:
                ''
            try:
                winner_2_name = res_ai['winner_2_name']
            except:
                ''
            try:
                winner_1_gender = res_ai['winner_1_gender']
            except:
                ''
            try:
                winner_2_gender = res_ai['winner_2_gender']
            except:
                ''
            try:
                winner_1_college = res_ai['winner_1_college']
            except:
                ''
            try:
                winner_2_college = res_ai['winner_2_college']
            except:
                ''
            try:
                loser_1_name = res_ai['loser_1_name']
            except:
                ''
            try:
                loser_2_name = res_ai['loser_2_name']
            except:
                ''
            try:
                loser_1_gender = res_ai['loser_1_gender']
            except:
                ''
            try:
                loser_2_gender = res_ai['loser_2_gender']
            except:
                ''
            try:
                loser_1_college = res_ai['loser_1_college']
            except:
                ''
            try:
                loser_2_college = res_ai['loser_2_college']
            except:
                ''
            try:
                score = res_ai['score']
            except:
                ''
            try:
                winner_team = res_ai['winner_team']
            except:
                ''
            try:
                loser_team = res_ai['loser_team']
            except:
                ''
            try:
                team_score = res_ai['team_score']
            except:
                ''
            try:
                outcome = res_ai['outcome']
            except:
                ''

            if winner_team and loser_team and team_score and winner_1_name and loser_1_name:
                items_found = True
                JobsItemsCollegeDualMatchScraperAiModel(
                    spider_id=spider_id,
                    job_id=job_id,
                    match_id=match_id,
                    ball_type=ball_type,
                    draw_bracket_value=draw_bracket_value,
                    draw_name=draw_name,
                    draw_team_type=draw_team_type,
                    tournament_name=tournament_name,
                    date=date,
                    score=score,
                    winner_1_name=winner_1_name,
                    winner_1_gender=winner_1_gender,
                    winner_1_third_party_id=winner_1_third_party_id,
                    winner_1_city=winner_1_city,
                    winner_1_country=winner_1_country,
                    winner_1_state=winner_1_state,
                    winner_2_name=winner_2_name,
                    winner_2_gender=winner_2_gender,
                    winner_2_third_party_id=winner_2_third_party_id,
                    winner_2_city=winner_2_city,
                    winner_2_state=winner_2_state,
                    loser_1_name=loser_1_name,
                    loser_1_gender=loser_1_gender,
                    loser_1_third_party_id=loser_1_third_party_id,
                    loser_1_city=loser_1_city,
                    loser_1_state=loser_1_state,
                    loser_1_country=loser_1_country,
                    loser_2_name=loser_2_name,
                    loser_2_gender=loser_2_gender,
                    loser_2_third_party_id=loser_2_third_party_id,
                    loser_2_city=loser_2_city,
                    loser_2_state=loser_2_state,
                    outcome=outcome,
                    id_type=id_type,
                    draw_gender=draw_gender,
                    draw_bracket_type=draw_bracket_type,
                    draw_type=draw_type,
                    tournament_city=tournament_city,
                    tournament_state=tournament_state,
                    tournament_country_code=tournament_country_code,
                    tournament_host=tournament_host,
                    tournament_location_type=tournament_location_type,
                    tournament_surface=tournament_surface,
                    tournament_event_category=tournament_event_category,
                    tournament_event_grade=tournament_event_grade,
                    tournament_import_source=tournament_import_source,
                    tournament_sanction_body=tournament_sanction_body,
                    winner_2_country=winner_2_country,
                    winner_2_college=winner_2_college,
                    loser_2_country=loser_2_country,
                    loser_2_college=loser_2_college,
                    tournament_event_type=tournament_event_type,
                    winner_1_college=winner_1_college,
                    loser_1_college=loser_1_college,
                    tournament_url=tournament_url,
                    winner_1_dob=winner_1_dob,
                    winner_2_dob=winner_2_dob,
                    loser_1_dob=loser_1_dob,
                    loser_2_dob=loser_2_dob,
                    tournament_country=tournament_country,
                    tournament_start_date=tournament_start_date,
                    tournament_end_date=tournament_end_date,
                    winner_team=winner_team,
                    loser_team=loser_team,
                    team_score=team_score,
                    winner_team_type=winner_team_type,
                    loser_team_type=loser_team_type,
                ).save()

                logger.info(f'tournament_date: {tournament_date}')
                logger.info(f'tournament_name: {tournament_name}')
                logger.info(f'tournament_gender: {tournament_gender}')
                logger.info(f'draw_name: {draw_name}')
                logger.info(f'draw_gender: {draw_gender}')
                logger.info(f'draw_team_type: {draw_team_type}')
                logger.info(f'winner_1_name: {winner_1_name}')
                logger.info(f'winner_2_name: {winner_2_name}')
                logger.info(f'winner_1_gender: {winner_1_gender}')
                logger.info(f'winner_2_gender: {winner_2_gender}')
                logger.info(f'winner_1_college: {winner_1_college}')
                logger.info(f'winner_2_college: {winner_2_college}')
                logger.info(f'loser_1_name: {loser_1_name}')
                logger.info(f'loser_2_name: {loser_2_name}')
                logger.info(f'loser_1_gender: {loser_1_gender}')
                logger.info(f'loser_2_gender: {loser_2_gender}')
                logger.info(f'loser_1_college: {loser_1_college}')
                logger.info(f'loser_2_college: {loser_2_college}')
                logger.info(f'score: {score}')
                logger.info(f'winner_team: {winner_team}')
                logger.info(f'loser_team: {loser_team}')
                logger.info(f'team_score: {team_score}')
                logger.info(f'outcome: {outcome}')
                logger.info(f'items_found: {items_found}')
                logger.info(f'*' * 50)

        except Exception:
            logger.error(traceback.format_exc())

        return items_found

    def tournament_date_openai(self, results_ai, content):
        tournament_date_ai = ''
        try:
            tournament_date = ''
            try:
                tournament_date = results_ai[0]['tournament_date']
            except:
                ''

            if tournament_date:
                tournament_date_ai = tournament_date
                logger.info(f'tournament_date_ai from claude: {tournament_date_ai}')

            else:
                try:
                    system_prompt = open(self.tournament_date_prompt_path).read()

                    """Extract tournament dates from text/HTML content."""
                    response = self.openai_client.chat.completions.create(
                        model="gpt-4o-mini",
                        temperature=0,
                        response_format={"type": "json_object"},  # forces valid JSON
                        messages=[
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": helper.clean_html_string(content)},
                        ],
                    )

                    result = json.loads(response.choices[0].message.content)

                    # Safety net: guarantee both keys exist
                    tournament_date_ai = result.get("tournament_date", "")
                    logger.info(f'tournament_date_ai from openai: {tournament_date_ai}')

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())

        logger.info(f'tournament_date_ai: {tournament_date_ai}')

        return tournament_date_ai