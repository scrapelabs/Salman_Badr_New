﻿from assets.fct.fctlog import logger
import os, json, re, base64, requests
from scripts import helper

class ClaudeExtractor:
    API_URL = "https://api.anthropic.com/v1/messages"
    INPUT_PRICE_PER_M  = 0.80
    OUTPUT_PRICE_PER_M = 4.00

    def __init__(self, api_key: str, model: str = "claude-sonnet-4-5-20250929", max_tokens: int = 4096, max_workers: int = 1):
        self.api_key     = api_key
        self.model       = model
        self.max_tokens  = max_tokens
        self.max_workers = max_workers
        self.stats       = {"requests": 0, "input_tokens": 0, "output_tokens": 0, "total_cost": 0.0}
        self._stats_lock = __import__("threading").Lock()

    # ── Public ────────────────────────────────────────────────────────────

    def extract(self, prompt_path: str, input_path: str, output_path: str = "output.json"):
        prompt = helper._read(prompt_path)
        ext    = os.path.splitext(input_path)[1].lower()
        logger.info(f"📄 File type: {ext}")

        if ext == ".pdf":
            results = self._extract_pdf(prompt, input_path)
        elif ext in (".html", ".htm"):
            results = self._extract_text(prompt, helper.clean_html(input_path))
        elif ext == ".xml":
            results = self._extract_text(prompt, helper.clean_xml(input_path))
        else:
            raise ValueError(f"Unsupported type: {ext}. Use .pdf / .html / .xml")

        # Flatten: single chunk list -> unwrap; multi-chunk list of lists -> merge into one array
        if isinstance(results, list) and len(results) == 1:
            output = results[0]
        elif isinstance(results, list) and all(isinstance(r, list) for r in results):
            output = [item for chunk in results for item in chunk]
        else:
            output = results

        # logger.info(f'results_ai: {output}')

        self._save(output, output_path)
        self._print_stats()
        return output

    # ── Extraction helpers ────────────────────────────────────────────────

    def _extract_pdf(self, prompt: str, path: str):
        pdf_b64 = base64.standard_b64encode(open(path, "rb").read()).decode()
        logger.info(f"⏳ Sending PDF to Claude...")
        return self._parse_json(self._request(prompt, content=[
            {"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": pdf_b64}},
            {"type": "text",     "text": "Extract as instructed. Return ONLY valid JSON."}
        ]))

    def _extract_text(self, prompt: str, content: str):
        CHUNK = 160_000
        chunks = [content[i:i+CHUNK] for i in range(0, len(content), CHUNK)]
        logger.info(f"{'✅ One API call' if len(chunks) == 1 else f'🔀 {len(chunks)} chunks'}\n")
        results = []
        for i, chunk in enumerate(chunks):
            logger.info(f"⏳ Chunk {i+1}/{len(chunks)}...")
            text = f"Part {i+1}/{len(chunks)}:\n\n{chunk}" if len(chunks) > 1 else chunk
            results.append(self._parse_json(self._request(prompt, text=text)))
            logger.info(f"  ✅ Done\n")
        return results

    # ── Claude API ────────────────────────────────────────────────────────

    def _request(self, system: str, text: str = None, content: list = None) -> str:
        payload = {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "system": system,
            "messages": [{"role": "user", "content": content if content else text}]
        }
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json"
        }
        res  = requests.post(self.API_URL, headers=headers, json=payload)
        data = res.json()
        if res.status_code != 200:
            raise RuntimeError(f"API Error: {data}")

        usage = data.get("usage", {})
        inp, out = usage.get("input_tokens", 0), usage.get("output_tokens", 0)
        cost = (inp / 1e6) * self.INPUT_PRICE_PER_M + (out / 1e6) * self.OUTPUT_PRICE_PER_M
        with self._stats_lock:
            self.stats["requests"]     += 1
            self.stats["input_tokens"] += inp
            self.stats["output_tokens"]+= out
            self.stats["total_cost"]   += cost
        logger.info(f"  📊 {inp} in + {out} out = ${cost:.6f}")

        return data["content"][0]["text"] if data.get("content") else ""

    # ── Utils ─────────────────────────────────────────────────────────────

    def _save(self, data, path: str):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        logger.info(f"\n✅ Saved to: {path}")

    def _parse_json(self, text: str):
        for pattern in [r'```(?:json)?\s*([\s\S]*?)\s*```', r'(\{[\s\S]*\}|\[[\s\S]*\])']:
            m = re.search(pattern, text)
            if m:
                try:    return json.loads(m.group(1))
                except: pass
        try:    return json.loads(text)
        except: pass
        logger.info("  ⚠️ Could not parse JSON, saving raw text")
        return text

    def _print_stats(self):
        s   = self.stats
        avg = s["total_cost"] / s["requests"] if s["requests"] else 0
        logger.info(f"""
{'='*50}
💰 COST SUMMARY
{'='*50}
  Requests      : {s['requests']}
  Input Tokens  : {s['input_tokens']:,}
  Output Tokens : {s['output_tokens']:,}
  Total Cost    : ${s['total_cost']:.6f}
  Avg Cost/Req  : ${avg:.6f}
{'='*50}""")


# if __name__ == "__main__":
#     claude_client = ClaudeExtractor(api_key="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")
#
#     results_ai = claude_client.extract(
#         prompt_path = r"D:\_work_khemiri\Salman_Bader\spiders_app\scripts\college_dual_match_scraper_ai\dual_match_extraction_prompt.txt",
#         input_path  = r"D:\_work_khemiri\Salman_Bader\spiders_app\scripts\college_dual_match_scraper_ai\article.pdf",   # .pdf / .html / .xml
#     )
#
#     logger.info(f'results_ai: {results_ai}')
#     fctcore.exit()
#
#     for res_ai in results_ai:
#         tournament_date = date = tournament_start_date = tournament_end_date = res_ai['tournament_date']
#         tournament_name = res_ai['tournament_name']
#         tournament_gender = res_ai['tournament_gender']
#         draw_name = res_ai['draw_name']
#         draw_gender = res_ai['draw_gender']
#         draw_team_type = res_ai['draw_team_type']
#         winner_1_name = res_ai['winner_1_name']
#         winner_2_name = res_ai['winner_2_name']
#         winner_1_gender = res_ai['winner_1_gender']
#         winner_2_gender = res_ai['winner_2_gender']
#         winner_1_college = res_ai['winner_1_college']
#         winner_2_college = res_ai['winner_2_college']
#         loser_1_name = res_ai['loser_1_name']
#         loser_2_name = res_ai['loser_2_name']
#         loser_1_gender = res_ai['loser_1_gender']
#         loser_2_gender = res_ai['loser_2_gender']
#         loser_1_college = res_ai['loser_1_college']
#         loser_2_college = res_ai['loser_2_college']
#         score = res_ai['score']
#         winner_team = res_ai['winner_team']
#         loser_team = res_ai['loser_team']
#         team_score = res_ai['team_score']
#         outcome = res_ai['outcome']
#
#         logger.info(f'tournament_date: {tournament_date}')
#         logger.info(f'tournament_name: {tournament_name}')
#         logger.info(f'tournament_gender: {tournament_gender}')
#         logger.info(f'draw_name: {draw_name}')
#         logger.info(f'draw_gender: {draw_gender}')
#         logger.info(f'draw_team_type: {draw_team_type}')
#         logger.info(f'winner_1_name: {winner_1_name}')
#         logger.info(f'winner_2_name: {winner_2_name}')
#         logger.info(f'winner_1_gender: {winner_1_gender}')
#         logger.info(f'winner_2_gender: {winner_2_gender}')
#         logger.info(f'winner_1_college: {winner_1_college}')
#         logger.info(f'winner_2_college: {winner_2_college}')
#         logger.info(f'loser_1_name: {loser_1_name}')
#         logger.info(f'loser_2_name: {loser_2_name}')
#         logger.info(f'loser_1_gender: {loser_1_gender}')
#         logger.info(f'loser_2_gender: {loser_2_gender}')
#         logger.info(f'loser_1_college: {loser_1_college}')
#         logger.info(f'loser_2_college: {loser_2_college}')
#         logger.info(f'score: {score}')
#         logger.info(f'winner_team: {winner_team}')
#         logger.info(f'loser_team: {loser_team}')
#         logger.info(f'team_score: {team_score}')
#         logger.info(f'outcome: {outcome}')
#         logger.info(f'*' * 50)
#
