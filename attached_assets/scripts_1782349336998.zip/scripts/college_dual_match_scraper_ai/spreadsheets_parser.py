import traceback
import concurrent.futures
from django.db import connection, close_old_connections
from assets.fct import fctcore
from assets.fct.fctlog import logger
from assets.fct.fctsheet import fctsheet
from scripts import helper
from scripts.college_dual_match_scraper_ai.schedule_parser import ScheduleParser


class spreadsheetsParser:
    def __init__(self, sheet_name, progress, core_parser, auburntigers_parser):
        self.max_workers = 5

        self.sheet_name = sheet_name
        self.progress = progress
        self.core_parser = core_parser
        self.auburntigers_parser = auburntigers_parser
        self.schedule_parser = ScheduleParser(self.progress, self.core_parser, self.auburntigers_parser)


    def parse_site(self, spider_id, job_id, job_tournament_url):
        try:
            close_old_connections()

            logger.info(f'job_tournament_url: {job_tournament_url}')

            spreadsheet_key = helper.extract_google_sheet_id(job_tournament_url)
            logger.info(f'spreadsheet_key: {spreadsheet_key}')

            if spreadsheet_key:
                fsheet = fctsheet(sheet_key=spreadsheet_key)
                sheet_results_list = fsheet.get_all_values(sheet_name=self.sheet_name)
                logger.info(f'sheet_results_list: {len(sheet_results_list)}')

                sheet_results_chunks = list(fctcore.split_list_into_chunks(lst=sheet_results_list, max_workers=self.max_workers))
                logger.info(f'sheet_results_chunks: {len(sheet_results_chunks)}')

                with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                    main_task = self.progress.add_task(description=f'job_id: {job_id} | spreadsheet', total=len(sheet_results_list))
                    for thread_num, sheet_results_chunk in enumerate(sheet_results_chunks):
                        thread_task = self.progress.add_task(f"job_id: {job_id} | spreadsheet | Thread: {thread_num + 1}", total=len(sheet_results_chunk))
                        executor.submit(self._process_row, spider_id, job_id, spreadsheet_key, sheet_results_chunk, thread_num, main_task, thread_task)

        except Exception:
            logger.error(traceback.format_exc())


    def _process_row(self, spider_id, job_id, spreadsheet_key, results_chunk, thread_num, main_task, thread_task):
        try:
            for result in results_chunk:
                self.progress.update(main_task, advance=1)
                self.progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    job_team = result.get('Team', '').strip()
                    job_schedule_link = result.get('Link', '').strip()

                    logger.info(f'job_schedule_link: {job_schedule_link}')

                    if not job_schedule_link:
                        return

                    if '/schedule' in job_schedule_link:
                        self.schedule_parser.parse_schedule(spider_id, job_id, job_schedule_link, job_team, spreadsheet_key, thread_num)

                    else:
                        for cls_parser in [self.core_parser, self.auburntigers_parser]:
                            items_found = cls_parser.parse_site(spider_id, job_id, job_schedule_link, thread_num)
                            if items_found:
                                break

                except Exception:
                    logger.error(traceback.format_exc())
                finally:
                    connection.close()

        except Exception:
            logger.error(traceback.format_exc())
        finally:
            connection.close()