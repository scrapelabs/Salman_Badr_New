import traceback, time, csv, os
import concurrent.futures
from os.path import basename, dirname, abspath
from django.conf import settings
from django.db import close_old_connections
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn, TaskProgressColumn
from assets.fct.fctlog import logger
from assets.fct import fctcore
from scripts import helper
from app_spiders.models import PlayersUstaTeamCaptainsModel

start_dt = time.time()

class CoreParser:

    def __init__(self):
        self.spider_name = basename(dirname(abspath(__file__)))


    def parse_site(self, thread_id, items_chunk, main_task, thread_task, progress):
        try:
            for third_party_id, captain_name in items_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    if not PlayersUstaTeamCaptainsModel.objects.filter(third_party_id=third_party_id).exists():
                        logger.info(f'new: captain_name: {captain_name} | third_party_id: {third_party_id}')

                        self.claude_key = settings.CLAUDE_KEYS[thread_id]
                        captain_name, player_gender = helper.format_name_gender_claude(captain_name, self.claude_key)

                        PlayersUstaTeamCaptainsModel(
                            spider_name=self.spider_name,
                            third_party_id=third_party_id,
                            player_name=captain_name,
                            gender=player_gender,
                        ).save()

                except:
                    logger.error(traceback.format_exc())
        except:
            logger.error(traceback.format_exc())


def run():
    max_workers = len(settings.CLAUDE_KEYS)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    csv_path = os.path.join(script_dir, 'items__Usta Team Captains__2833__2026-04-24_23-41.csv')

    with open(csv_path, encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        csv_map = {helper.sha256_id(row['Captain Name']): row['Captain Name'] for row in reader}
    logger.info(f'csv_map: {len(csv_map)}')

    existing_ids = set(PlayersUstaTeamCaptainsModel.objects.all().values_list('third_party_id', flat=True))
    logger.info(f'existing_ids: {len(existing_ids)}')

    new_ids = list(set(csv_map.keys()) - existing_ids)
    logger.info(f'new_ids: {len(new_ids)}')

    if new_ids:
        new_items = [(id_, csv_map[id_]) for id_ in new_ids]
        logger.info(f'new_items: {len(new_items)}')

        items_chunks = list(fctcore.split_list_into_chunks(lst=new_items, max_workers=max_workers))
        logger.info(f'ids_chunks: {len(items_chunks)}')

        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(bar_width=100), TaskProgressColumn(), TextColumn("{task.completed}/{task.total}"), TimeElapsedColumn(), TimeRemainingColumn(), transient=False) as progress:
                futures = []
                main_task = progress.add_task(description=settings.DATABASES['default']['NAME'], total=len(new_items))
                for thread_id, items_chunk in enumerate(items_chunks):
                    thread_task = progress.add_task(f"Thread {thread_id+1}", total=len(items_chunk))
                    future = executor.submit(CoreParser().parse_site, thread_id, items_chunk, main_task, thread_task, progress)
                    futures.append(future)

                for future in concurrent.futures.as_completed(futures):
                    future.result()

    logger.info(f'script take {round(time.time()-start_dt, 2)} sec to finished')