import time
import concurrent.futures
from django.conf import settings
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts.usta_team_captains.parser.login import Login
from scripts.usta_team_captains.parser.ntrp import NtrpParser
from scripts.usta_team_captains.parser.details import DetailsParser
from scripts import helper
from app_spiders.models import jobsModel

start_dt = time.time()

def run(*args):
    params = list(args)
    job_id = int(params[0])
    spider_name = params[1]
    folder_path = params[2]
    max_workers = int(params[3])

    username = 'sbadertennis@gmail.com'
    password = 'Un1v3rsal'
    domain = 'tennislink.usta.com'

    use_proxy = settings.USE_PROXY
    fctrequest = Request(use_session=True, use_cffi=False, use_proxy=use_proxy)

    base_file = f'{spider_name}__{job_id}__{fctcore.current_date("%Y-%m-%d_%H-%M")}.csv'

    job_obj = jobsModel.objects.get(id=job_id)
    spider_id = job_obj.spider_id
    job_settings = job_obj.job_settings
    job_rank_year = job_settings.get('rank_year', '')
    logger.info(f'job_spider: {spider_name} | job_id: {job_id} | job_rank_year: {job_rank_year}')

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(), TextColumn("{task.completed}/{task.total}"), TimeElapsedColumn(), TimeRemainingColumn(), transient=False) as progress:
        is_logged_in = Login(spider_id, username, password, domain, fctrequest).login()

        if is_logged_in:
            df_ntrp, payload_params = NtrpParser(spider_id, username, domain, fctrequest).parse_ntrp()
            logger.info(f'df_ntrp: {len(df_ntrp)}')

            if not df_ntrp.empty:
                ntrp_list = df_ntrp.to_dict("records")
                ntrp_chunks = list(fctcore.split_list_into_chunks(lst=ntrp_list, max_workers=max_workers))
                if max_workers > len(ntrp_chunks): max_workers=len(ntrp_chunks)

                with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                    main_task = progress.add_task(description=f'{spider_name}_results', total=len(ntrp_list))
                    for thread_id, ntrp_chunk in enumerate(ntrp_chunks):
                        thread_task = progress.add_task(f"Thread {thread_id + 1}", total=len(ntrp_chunk))
                        executor.submit(DetailsParser(spider_id, job_id, username, domain, fctrequest, progress).parse_site, job_rank_year, payload_params, ntrp_chunk, main_task, thread_task, progress)

        helper.finalize_items_from_db(job_obj, folder_path, base_file)
        helper.finalize_job(job_obj, base_file, folder_path)

    logger.info(f'script take {round(time.time()-start_dt, 2)} sec to finished')
