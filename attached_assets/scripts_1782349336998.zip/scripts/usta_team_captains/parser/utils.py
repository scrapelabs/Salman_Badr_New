import traceback, re
from scrapy.selector import Selector
from assets.fct.fctlog import logger
from assets.fct import fctcore
from app_spiders.models import JobsCookiesModel

class Utils:

    def __init__(self, spider_id, domain, username):
        self.spider_id = spider_id
        self.domain = domain
        self.username = username


    def get_cookies_db(self):
        cookies = {}
        try:
            objs = JobsCookiesModel.objects.filter(
                spider_id=self.spider_id,
                domain=self.domain,
                username=self.username,
            )
            if objs:
                cookies = objs.first().cookies
        except Exception:
            logger.error(traceback.format_exc())
        return cookies


    def get_payload_params(self, str1):
        __VIEWSTATE = ''
        __VIEWSTATEGENERATOR = ''
        CSRFToken = ''
        HistoryPointParam = ''
        CurrentYear = ''
        try:
            html1 = Selector(text=str1)

            __VIEWSTATE = fctcore.parse_field('//input[@id="__VIEWSTATE"]/@value', html1)
            __VIEWSTATEGENERATOR = fctcore.parse_field('//input[@id="__VIEWSTATEGENERATOR"]/@value', html1)
            CSRFToken = fctcore.parse_field('//input[@id="hdnCSRFToken"]/@value', html1)
            HistoryPointParam = fctcore.parse_field('//input[@id="ctl00_mainContent_hfHistoryPointParam"]/@value', html1)
            ddlCYear = fctcore.parse_field('//select[@name="ctl00$mainContent$ddlCYear"]/option[@selected="selected"]/@value', html1)
            hdnCyear = fctcore.parse_field('//input[@id="ctl00_mainContent_hdnCyear"]/@value', html1)

            if not __VIEWSTATE:
                __VIEWSTATE = re.search(r'__VIEWSTATE\|([^|]+)', str1).group(1)
                __VIEWSTATEGENERATOR = re.search(r'__VIEWSTATEGENERATOR\|([^|]+)', str1).group(1)

        except Exception:
            logger.error(traceback.format_exc())
        return {'__VIEWSTATE': __VIEWSTATE, '__VIEWSTATEGENERATOR': __VIEWSTATEGENERATOR, 'CSRFToken': CSRFToken, 'HistoryPointParam': HistoryPointParam, 'ddlCYear': ddlCYear, 'hdnCyear': hdnCyear}