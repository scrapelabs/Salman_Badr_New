import traceback
from urllib.parse import urlparse, parse_qs
from django.conf import settings
from assets.fct.fctlog import logger
from scripts.usta_team_captains.parser.utils import Utils
from app_spiders.models import JobsCookiesModel

class Login:

    def __init__(self, spider_id, username, password, domain, fctrequest):
        self.spider_id = spider_id
        self.username = username
        self.password = password
        self.domain = domain
        self.fctrequest = fctrequest

        self.proxies = settings.PROXIES
        self.Utils = Utils(self.spider_id, self.domain, self.username)
        self.cookies = self.Utils.get_cookies_db()


    def login(self):
        is_logged_in = False
        try:
            is_logged_in = self.check_is_logged_in()
            logger.info(f'is_logged_in: {is_logged_in}')

            if not is_logged_in:
                state = self.parse_state_login()
                logger.info(f'state: {state}')

                if state:
                    headers = {
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                        'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                        'content-type': 'application/x-www-form-urlencoded',
                        'upgrade-insecure-requests': '1',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0',
                    }

                    params = {
                        'state': state,
                    }

                    data = {
                        'state': state,
                        'ulp-login': 'email',
                        'username': self.username,
                        'password': self.password,
                    }

                    index_link = 'https://account.usta.com/u/login'
                    response1 = self.fctrequest.request(method='POST', link=index_link, params=params, data=data, headers=headers, proxies=self.proxies, tries=3)
                    if response1:
                        if response1.status_code in range(200, 300):
                            redirect_link = response1.url
                            logger.info(f'redirect_link: {redirect_link}')

                            if 'Home.aspx' in redirect_link:
                                cookies = dict(self.fctrequest.session.cookies)
                                is_logged_in = True

                                JobsCookiesModel.objects.update_or_create(
                                    # lookup fields (WHERE clause)
                                    spider_id=self.spider_id,
                                    domain=self.domain,
                                    username=self.username,
                                    # fields to set on create or update
                                    defaults={'cookies': cookies}
                                )

        except Exception:
            logger.error(traceback.format_exc())

        return is_logged_in


    def parse_state_login(self):
        state = ''
        try:
            index_link = f'https://tennislink.usta.com/Dashboard/Main/Login.aspx?returnURL=https://tennislink.usta.com/Leagues'
            logger.info(f'index_link: {index_link}')

            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=index_link, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    redirect_link = response1.url
                    logger.info(f'redirect_link: {redirect_link}')

                    if redirect_link:
                        params = parse_qs(urlparse(redirect_link).query)
                        state = params["state"][0]

        except Exception:
            logger.error(traceback.format_exc())

        return state


    def check_is_logged_in(self):
        is_logged_in = False
        try:
            if self.cookies:
                headers = {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                    'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                    'Upgrade-Insecure-Requests': '1',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0',
                }

                index_link = 'https://tennislink.usta.com/Leagues/Common/Home.aspx'
                response1 = self.fctrequest.request(method='GET', link=index_link, cookies=self.cookies, headers=headers, proxies=self.proxies, tries=3)
                if response1:
                    if response1.status_code in range(200, 300):
                        redirect_link = response1.url
                        logger.info(f'redirect_link: {redirect_link}')

                        if 'Home.aspx' in redirect_link:
                            is_logged_in = True

        except Exception:
            logger.error(traceback.format_exc())

        return is_logged_in

