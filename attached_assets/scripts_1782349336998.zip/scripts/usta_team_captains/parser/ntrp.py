import traceback
from scrapy.selector import Selector
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from scripts.log_items import ItemsLogger
from scripts.usta_team_captains.parser.utils import Utils

class NtrpParser:

    def __init__(self, spider_id, username, domain, fctrequest):
        self.spider_id = spider_id
        self.username = username
        self.domain = domain
        self.fctrequest = fctrequest
        self.proxies = settings.PROXIES

        self.df_ntrp = ItemsLogger()

        self.Utils = Utils(self.spider_id, self.domain, self.username)
        self.cookies = self.Utils.get_cookies_db()
        self.base_link = f'https://tennislink.usta.com/Leagues/Main/StatsAndStandings.aspx?SearchType=3'

    def parse_ntrp(self):
        payload_params = {}
        try:
            logger.info(f'base_link: {self.base_link}')

            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=self.base_link, headers=headers, cookies=self.cookies, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    str1 = response1.text
                    html1 = Selector(text=str1)
                    payload_params = self.Utils.get_payload_params(str1)

                    for d1 in html1.xpath('//select[@id="ctl00_mainContent_ddlNTRPLevel"]/option[not(contains(text(), "-- select --"))]'):
                        ntrp_text = fctcore.parse_field('./text()', d1)
                        ntrp_value = fctcore.parse_field('./@value', d1)

                        for d1 in html1.xpath('//select[@id="ctl00_mainContent_ddlGender"]/option[not(contains(text(), "-- select --"))]'):
                            gender_text = fctcore.parse_field('./text()', d1)
                            gender_value = fctcore.parse_field('./@value', d1)

                            self.df_ntrp.log({
                                "ntrp_text": ntrp_text,
                                "ntrp_value": ntrp_value,
                                "gender_text": gender_text,
                                "gender_value": gender_value,
                            })

        except Exception:
            logger.error(traceback.format_exc())

        return self.df_ntrp.get_df(), payload_params

