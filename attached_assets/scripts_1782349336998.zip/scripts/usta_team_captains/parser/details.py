import traceback, random, re
from os.path import basename, dirname, abspath
from scrapy.selector import Selector
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from scripts import helper
from scripts.usta_team_captains.parser.utils import Utils
from app_spiders.models import ItemsUstaTeamCaptainsModel, PlayersUstaTeamCaptainsModel

class DetailsParser:

    def __init__(self, spider_id, job_id, username, domain, fctrequest, progress):
        self.spider_id = spider_id
        self.job_id = job_id
        self.username = username
        self.domain = domain
        self.fctrequest = fctrequest
        self.progress = progress
        self.proxies = settings.PROXIES
        self.spider_name = basename(dirname(dirname(abspath(__file__))))
        self.claude_key = random.choice(settings.CLAUDE_KEYS)
        self.Utils = Utils(self.spider_id, self.domain, self.username)
        self.cookies = self.Utils.get_cookies_db()
        self.base_link = f'https://tennislink.usta.com/Leagues/Main/StatsAndStandings.aspx?SearchType=3'


    def parse_site(self, job_rank_year, payload_params, ntrp_chunk, main_task, thread_task, progress):
        try:
            __VIEWSTATE = payload_params.get('__VIEWSTATE', '')
            __VIEWSTATEGENERATOR = payload_params.get('__VIEWSTATEGENERATOR', '')
            CSRFToken = payload_params.get('CSRFToken', '')
            HistoryPointParam = payload_params.get('HistoryPointParam', '')
            ddlCYear = payload_params.get('ddlCYear', '')

            for ntrp_data in ntrp_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    ntrp_text = ntrp_data.get("ntrp_text", "")
                    ntrp_value = ntrp_data.get("ntrp_value", "")
                    gender_text = ntrp_data.get("gender_text", "")
                    gender_value = ntrp_data.get("gender_value", "")

                    logger.info(f'ntrp_text: {ntrp_text} | gender_text: {gender_text}')

                    headers = {
                        'Accept': '*/*',
                        'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0',
                        'X-MicrosoftAjax': 'Delta=true',
                        'X-Requested-With': 'XMLHttpRequest',
                    }

                    data = {
                        'ctl00$ScriptManager1': 'ctl00$mainContent$UpdatePanel1|ctl00$mainContent$btnSearchTeamByName',
                        'hdnCSRFToken': CSRFToken,
                        'hdnCSRFLogId': '',
                        'hdnCSRFCookieRefreshed': 'false',
                        'q_player_record': 'on',
                        'ctl00$SocialMediaPanel$isExistSocialMedia': 'False',
                        'ctl00$mainContent$ddlCYear': ddlCYear,
                        'ctl00$mainContent$ddlDivision': '0',
                        'ctl00$mainContent$ddlNTRPlevelChampionlevel': '0',
                        'ctl00$mainContent$ddlGenderChampion': '0',
                        'ctl00$mainContent$ddlClevel': '',
                        'ctl00$mainContent$txtMatchNum': '',
                        'ctl00$mainContent$ddlChampYear': job_rank_year,
                        'ctl00$mainContent$ddlDivisionForTeams': '0',
                        'ctl00$mainContent$ddlSection': '',
                        'ctl00$mainContent$ddlNTRPLevel': ntrp_value,
                        'ctl00$mainContent$ddlGender': gender_value,
                        'ctl00$mainContent$txtTeamName': '',
                        'ctl00$mainContent$txtTeamNum': '',
                        'ctl00$mainContent$txtUSTANum': '',
                        'ctl00$mainContent$txtFirstName': '',
                        'ctl00$mainContent$txtLastName': '',
                        'ctl00$mainContent$hdnSearchType': '',
                        'ctl00$mainContent$hfScoreEntryPopupShowHide': '',
                        'ctl00$mainContent$hfHistoryPointParam': HistoryPointParam,
                        '__EVENTTARGET': '',
                        '__EVENTARGUMENT': '',
                        '__LASTFOCUS': '',
                        '__VIEWSTATE': __VIEWSTATE,
                        '__VIEWSTATEGENERATOR': __VIEWSTATEGENERATOR,
                        '__ASYNCPOST': 'true',
                        'ctl00$mainContent$btnSearchTeamByName': 'Find Teams',
                    }

                    response1 = self.fctrequest.request(method='POST', link=self.base_link, data=data, headers=headers, cookies=self.cookies, proxies=self.proxies, tries=3)
                    if response1:
                        if response1.status_code in range(200, 300):
                            str1 = response1.text
                            html1 = Selector(text=str1)
                            self.parse_teams(ntrp_text, gender_text, CSRFToken, str1, html1)

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())


    def parse_teams(self, ntrp_text, gender_text, CSRFToken, str1, html1):
        try:
            payload_params = self.Utils.get_payload_params(str1)
            __VIEWSTATE = payload_params.get('__VIEWSTATE', '')
            __VIEWSTATEGENERATOR = payload_params.get('__VIEWSTATEGENERATOR', '')
            HistoryPointParam = payload_params.get('HistoryPointParam', '')

            for d1 in html1.xpath('//a[contains(@id, "mainContent_rptYearForTeamResults")]'):
                team_name = fctcore.parse_field('./text()', d1)
                team_link = fctcore.parse_field('./@href', d1)
                team_target = self.parse_target(team_link)

                if team_target:
                    logger.info(f'team_name: {team_name}')
                    headers = {
                        'Accept': '*/*',
                        'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0',
                        'X-MicrosoftAjax': 'Delta=true',
                        'X-Requested-With': 'XMLHttpRequest',
                    }

                    data = {
                        "ctl00$ScriptManager1": "ctl00$mainContent$UpdatePanel1|"+team_target,
                        "__LASTFOCUS": "",
                        "hdnCSRFToken": CSRFToken,
                        "hdnCSRFLogId": "",
                        "hdnCSRFCookieRefreshed": "false",
                        "q_player_record": "on",
                        "ctl00$SocialMediaPanel$isExistSocialMedia": "False",
                        "ss_search_member_name_criteria_year": "",
                        "ctl00$mainContent$ss_jsonSearForMemberFilterCriteria": "",
                        "ctl00$mainContent$ss_jsonSearForMemberResultCriteria": "",
                        "ctl00$mainContent$ss_jsonSearForMemberFirstLoadYear": "",
                        "ss_search_member_name": "",
                        "ctl00$mainContent$hdnSearchType": "",
                        "ctl00$mainContent$hfScoreEntryPopupShowHide": "",
                        "ctl00$mainContent$hfHistoryPointParam": HistoryPointParam,
                        "__EVENTTARGET": team_target,
                        "__EVENTARGUMENT": "",
                        "__VIEWSTATE": __VIEWSTATE,
                        "__VIEWSTATEGENERATOR": __VIEWSTATEGENERATOR,
                        "__ASYNCPOST": "true",
                    }
                    response1 = self.fctrequest.request(method='POST', link=self.base_link, data=data, headers=headers, cookies=self.cookies, proxies=self.proxies, tries=3)
                    if response1:
                        if response1.status_code in range(200, 300):
                            str1 = response1.text
                            html1 = Selector(text=str1)
                            self.parse_player_roster(ntrp_text, gender_text, team_name, CSRFToken, str1, html1)

                else:
                    logger.warning(f'team_name: {team_name} | team_target not found')

        except Exception:
            logger.error(traceback.format_exc())


    def parse_player_roster(self, ntrp_text, gender_text, team_name, CSRFToken, str1, html1):
        try:
            payload_params = self.Utils.get_payload_params(str1)
            __VIEWSTATE = payload_params.get('__VIEWSTATE', '')
            __VIEWSTATEGENERATOR = payload_params.get('__VIEWSTATEGENERATOR', '')
            HistoryPointParam = payload_params.get('HistoryPointParam', '')
            hdnCyear = payload_params.get('hdnCyear', '')

            player_roster_link = fctcore.parse_field('//a[contains(@id, "ctl00_mainContent_lnkPlayerRosterForTeams")]/@href', html1)
            player_roster_target = self.parse_target(player_roster_link)

            if player_roster_target:
                headers = {
                    'Accept': '*/*',
                    'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0',
                    'X-MicrosoftAjax': 'Delta=true',
                    'X-Requested-With': 'XMLHttpRequest',
                }

                data = {
                    "ctl00$ScriptManager1": "ctl00$mainContent$UpdatePanel1|"+player_roster_target,
                    "__LASTFOCUS": "",
                    "hdnCSRFToken": CSRFToken,
                    "hdnCSRFLogId": "",
                    "hdnCSRFCookieRefreshed": "false",
                    "q_player_record": "on",
                    "ctl00$SocialMediaPanel$isExistSocialMedia": "True",
                    "ctl00$mainContent$hdnMatchWinCriteria": "1",
                    "ctl00$mainContent$hdnCyear": hdnCyear,
                    "ctl00$mainContent$hdnIsGamesLostFirst": "False",
                    "ctl00$mainContent$hdnTeamWinsSwapIndivWinsIndex": "0",
                    "ctl00$mainContent$hdnTeamSummaryHTMLContent": "",
                    "ctl00$mainContent$hdnTeamSummaryTeamMatchesHTMContent": "",
                    "ctl00$mainContent$hdnSearchType": "DefaultType",
                    "ctl00$mainContent$hfScoreEntryPopupShowHide": "",
                    "ctl00$mainContent$hfHistoryPointParam": HistoryPointParam,
                    "__EVENTTARGET": player_roster_target,
                    "__EVENTARGUMENT": "",
                    "__VIEWSTATE": __VIEWSTATE,
                    "__VIEWSTATEGENERATOR": __VIEWSTATEGENERATOR,
                    "__ASYNCPOST": "true",
                }

                response1 = self.fctrequest.request(method='POST', link=self.base_link, data=data, headers=headers, cookies=self.cookies, proxies=self.proxies, tries=3)
                if response1:
                    if response1.status_code in range(200, 300):
                        str1 = response1.text
                        html1 = Selector(text=str1)
                        self.parse_roster_info(ntrp_text, gender_text, team_name, CSRFToken, str1, html1)

            else:
                logger.warning(f'team_name: {team_name} | player_roster_target not found')

        except Exception:
            logger.error(traceback.format_exc())

    def parse_roster_info(self, ntrp_text, gender_text, team_name, CSRFToken, str1, html1):
        try:
            # team_name = fctcore.parse_field('//td[contains(@class, "subhead") and contains(text(), "Team Name")]//ancestor::table//tr[2]/td[1]', html1)
            season_start = fctcore.parse_field('//td[contains(@class, "subhead") and contains(text(), "Season Start")]//ancestor::table//tr[2]/td[3]', html1)
            no_players = fctcore.parse_field('//td[contains(@class, "subhead") and contains(text(), "No. Players")]//ancestor::table//tr[2]/td[4]', html1)
            usta_section = fctcore.parse_field('//td[contains(@class, "subhead") and contains(text(), "USTA Section")]//ancestor::table//tr[2]/td[1]', html1)
            usta_district = fctcore.parse_field('//td[contains(@class, "subhead") and contains(text(), "USTA District")]//ancestor::table//tr[2]/td[2]', html1)
            local_league_league_type = fctcore.parse_field('//td[contains(@class, "subhead") and contains(text(), "Local League / League Type")]//ancestor::table//tr[2]/td[3]', html1)
            team_ntrp_gender = fctcore.parse_field('//td[contains(@class, "subhead") and contains(text(), "Team NTRP/Gender")]//ancestor::table//tr[2]/td[4]', html1)
            flight_sub_flight_name = fctcore.parse_field('//td[contains(@class, "subhead") and contains(text(), "Flight/Sub-Flight Name")]//ancestor::table//tr[2]/td[5]', html1)
            facility_name = fctcore.parse_field('//td[contains(@class, "subhead") and contains(text(), "Facility Name")]//ancestor::table//tr[2]/td[1]', html1)
            facility_address = fctcore.parse_field('//td[contains(@class, "subhead") and contains(text(), "Facility Address")]//ancestor::table//tr[2]/td[2]', html1)

            if season_start:
                logger.info(f'team_name: {team_name}')
                logger.info(f'season_start: {season_start}')
                logger.info(f'no_players: {no_players}')
                logger.info(f'usta_section: {usta_section}')
                logger.info(f'usta_district: {usta_district}')
                logger.info(f'local_league_league_type: {local_league_league_type}')
                logger.info(f'team_ntrp_gender: {team_ntrp_gender}')
                logger.info(f'flight_sub_flight_name: {flight_sub_flight_name}')
                logger.info(f'facility_name: {facility_name}')
                logger.info(f'facility_address: {facility_address}')
                logger.info(f'*'*50)

                captain_found = False
                captain_name = ''
                captain_city_state = ''
                captain_ntrp = ''
                for d1 in html1.xpath('//td[contains(@class, "subhead") and contains(text(), "Captain Name")]//ancestor::table//tr[not(td[contains(@class, "subhead")])]//td//a[contains(@id, "CaptainForPlayerRosterForPublic")]'):
                    captain_found = True
                    captain_name = fctcore.parse_field('./text()', d1)
                    captain_link = fctcore.parse_field('./@href', d1)
                    captain_target = self.parse_target(captain_link)
                    third_party_id = helper.sha256_id(captain_name)

                    objs = PlayersUstaTeamCaptainsModel.objects.filter(spider_name=self.spider_name, third_party_id=third_party_id)
                    if not objs.exists():
                        captain_name, player_gender = helper.format_name_gender_claude(captain_name, self.claude_key)

                        PlayersUstaTeamCaptainsModel(
                            spider_name=self.spider_name,
                            third_party_id=third_party_id,
                            player_name=captain_name,
                            gender=player_gender,
                        ).save()

                    else:
                        obj = objs.first()
                        captain_name = obj.player_name

                    if captain_target:
                        _, captain_city_state, captain_ntrp = self.parse_captain_page(captain_target, CSRFToken, str1)

                        logger.info(f'captain_name: {captain_name}')
                        # logger.info(f'captain_link: {captain_link}')
                        # logger.info(f'captain_target: {captain_target}')
                        logger.info(f'captain_city_state: {captain_city_state}')
                        logger.info(f'captain_ntrp: {captain_ntrp}')
                        logger.info(f'*'*50)

                    else:
                        logger.warning(f'team_name: {team_name} | captain_target not found')

                    self.insert(ntrp_text, gender_text, team_name, season_start, no_players, usta_section, usta_district, local_league_league_type,
                                team_ntrp_gender, flight_sub_flight_name, facility_name, facility_address, captain_name,
                                captain_city_state, captain_ntrp)

                if not captain_found:
                    self.insert(ntrp_text, gender_text, team_name, season_start, no_players, usta_section, usta_district, local_league_league_type,
                               team_ntrp_gender, flight_sub_flight_name, facility_name, facility_address, captain_name,
                               captain_city_state, captain_ntrp)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_captain_page(self, captain_target, CSRFToken, str1):
        captain_name = ''
        captain_city_state = ''
        captain_ntrp = ''
        try:
            payload_params = self.Utils.get_payload_params(str1)
            __VIEWSTATE = payload_params.get('__VIEWSTATE', '')
            __VIEWSTATEGENERATOR = payload_params.get('__VIEWSTATEGENERATOR', '')
            HistoryPointParam = payload_params.get('HistoryPointParam', '')

            headers = {
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0',
                'X-MicrosoftAjax': 'Delta=true',
                'X-Requested-With': 'XMLHttpRequest',
            }

            data = {
                "ctl00$ScriptManager1": "ctl00$mainContent$UpdatePanel1|"+captain_target,
                "__LASTFOCUS": "",
                "hdnCSRFToken": CSRFToken,
                "hdnCSRFLogId": "",
                "hdnCSRFCookieRefreshed": "false",
                "q_player_record": "on",
                "ctl00$SocialMediaPanel$isExistSocialMedia": "True",
                "ctl00$mainContent$hdnSearchType": "PlayerRoster",
                "ctl00$mainContent$hfScoreEntryPopupShowHide": "",
                "ctl00$mainContent$hfHistoryPointParam": HistoryPointParam,
                "__EVENTTARGET": captain_target,
                "__EVENTARGUMENT": "",
                "__VIEWSTATE": __VIEWSTATE,
                "__VIEWSTATEGENERATOR": __VIEWSTATEGENERATOR,
                "__ASYNCPOST": "true",
            }

            response1 = self.fctrequest.request(method='POST', link=self.base_link, data=data, headers=headers, cookies=self.cookies, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    str1 = response1.text
                    html1 = Selector(text=str1)

                    captain_name = fctcore.parse_field('//table[@id="ctl00_mainContent_tblIndividualAnchor"]//tr[2]/td[1]', html1)
                    captain_city_state = fctcore.parse_field('//table[@id="ctl00_mainContent_tblIndividualAnchor"]//tr[2]/td[2]', html1)
                    captain_ntrp = fctcore.parse_field('//table[@id="ctl00_mainContent_tblIndividualAnchor"]//tr[2]/td[3]', html1)

        except Exception:
            logger.error(traceback.format_exc())

        return captain_name, captain_city_state, captain_ntrp


    def insert(self, ntrp_text='', gender_text='', team_name='', season_start='', no_players='', usta_section='', usta_district='', local_league_league_type='', team_ntrp_gender='', flight_sub_flight_name='', facility_name='', facility_address='', captain_name='', captain_city_state='', captain_ntrp=''):
        ItemsUstaTeamCaptainsModel(
            spider_id=self.spider_id,
            job_id=self.job_id,
            ntrp_text=ntrp_text,
            gender_text=gender_text,
            team_name=team_name,
            season_start=season_start,
            no_players=no_players,
            usta_section=usta_section,
            usta_district=usta_district,
            local_league_league_type=local_league_league_type,
            team_ntrp_gender=team_ntrp_gender,
            flight_sub_flight_name=flight_sub_flight_name,
            facility_name=facility_name,
            facility_address=facility_address,
            captain_name=captain_name,
            captain_city_state=captain_city_state,
            captain_ntrp=captain_ntrp,
        ).save()

    def parse_target(self, link):
        target = ''
        try:
            target = re.search(r"__doPostBack\('([^']+)'", link).group(1)
        except Exception:
            logger.error(f'link: {link} | traceback: {traceback.format_exc()}')
        return target