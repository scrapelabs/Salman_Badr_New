import traceback, calendar
from datetime import datetime
from urllib.parse import quote
from scrapy.selector import Selector
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts.log_items import ItemsLogger
from scripts.usta_team_captains.parser.utils import Utils
from app_spiders.models import JobsItemsUstaTeamCaptainsModel

class NtrpParser:

    def __init__(self, spider_id, username, domain, fctrequest):
        self.spider_id = spider_id
        self.username = username
        self.domain = domain
        self.fctrequest = fctrequest
        self.proxies = settings.PROXIES

        self.df_ntrp = ItemsLogger()
        self.df_gender = ItemsLogger()

        self.Utils = Utils(self.spider_id, self.domain, self.username)
        self.cookies = self.Utils.get_cookies_db()
        self.base_link = f'https://tennislink.usta.com/Leagues/Main/StatsAndStandings.aspx?SearchType=3'

    def parse_ntrp(self, job_rank_year):
        try:
            logger.info(f'base_link: {self.base_link}')

            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=self.base_link, headers=headers, cookies=self.cookies, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    for d1 in html1.xpath('//select[@id="ctl00_mainContent_ddlNTRPLevel"]/option[not(contains(text(), "-- select --"))]'):
                        ntrp_text = fctcore.parse_field('./text()', d1)
                        ntrp_value = fctcore.parse_field('./@value', d1)

                        self.df_ntrp.log({
                            "ntrp_text": ntrp_text,
                            "ntrp_value": ntrp_value,
                        })

                    for d1 in html1.xpath('//select[@id="ctl00_mainContent_ddlNTRPLevel"]/option[not(contains(text(), "-- select --"))]'):
                        gender_text = fctcore.parse_field('./text()', d1)
                        gender_value = fctcore.parse_field('./@value', d1)

                        self.df_gender.log({
                            "gender_text": gender_text,
                            "gender_value": gender_value,
                        })



                    if job_rank_year != fctcore.current_date('%Y'):
                        self.change_year(job_rank_year, html1)

                    fctcore.exit()

                    results1 = response1.json()

                    for data in results1.get('data', []):
                        for event in data.get('events', []):
                            for draw in event.get('draws', []):
                                contents = draw.get('content', None)
                                if isinstance(contents, list):
                                    for content in contents:
                                        for tie in content.get('ntrp', []):
                                            tie_id = tie.get('id', '')
                                            tie_date = self.parse_dates(tie.get('formattedDate', ''))

                                            self.df_ntrp.log({
                                                "tie_id": tie_id,
                                                "tie_date": tie_date,
                                            })


                                elif isinstance(contents, dict):
                                    for tie in contents.get('recent', []):

                                        tie_id = tie.get('id', '')
                                        tie_date = self.parse_dates(tie.get('formattedDate', ''))

                                        self.df_ntrp.log({
                                            "tie_id": tie_id,
                                            "tie_date": tie_date,
                                        })

        except Exception:
            logger.error(traceback.format_exc())

        return self.df_ntrp.get_df()


    def change_year(self, job_rank_year, html1):
        try:
            dict__viewstate = self.Utils.get__viewstate(html1)
            __VIEWSTATE = quote(dict__viewstate.get('viewstate', ''))
            __VIEWSTATEGENERATOR = quote(dict__viewstate.get('__VIEWSTATEGENERATOR', ''))
            CSRFToken = quote(dict__viewstate.get('CSRFToken', ''))
            HistoryPointParam = quote(dict__viewstate.get('HistoryPointParam', ''))
            ddlCYear = quote(dict__viewstate.get('ddlCYear', ''))

            headers = {
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0',
                'X-MicrosoftAjax': 'Delta=true',
                'X-Requested-With': 'XMLHttpRequest',
            }

            data = 'ctl00%24ScriptManager1=ctl00%24mainContent%24UpdatePanel1%7Cctl00%24mainContent%24ddlChampYear&__EVENTTARGET=ctl00%24mainContent%24ddlChampYear&__EVENTARGUMENT=&__LASTFOCUS=&__VIEWSTATE='+str(__VIEWSTATE)+'&__VIEWSTATEGENERATOR='+str(__VIEWSTATEGENERATOR)+'&hdnCSRFToken='+str(CSRFToken)+'&hdnCSRFLogId=&hdnCSRFCookieRefreshed=false&q_player_record=on&ctl00%24SocialMediaPanel%24isExistSocialMedia=False&ctl00%24mainContent%24ddlCYear='+str(ddlCYear)+'&ctl00%24mainContent%24ddlDivision=0&ctl00%24mainContent%24ddlNTRPlevelChampionlevel=0&ctl00%24mainContent%24ddlGenderChampion=0&ctl00%24mainContent%24ddlClevel=&ctl00%24mainContent%24txtMatchNum=&ctl00%24mainContent%24ddlChampYear='+str(job_rank_year)+'&ctl00%24mainContent%24ddlDivisionForTeams=0&ctl00%24mainContent%24ddlSection=&ctl00%24mainContent%24ddlNTRPLevel=0&ctl00%24mainContent%24ddlGender=0&ctl00%24mainContent%24txtTeamName=&ctl00%24mainContent%24txtTeamNum=&ctl00%24mainContent%24txtUSTANum=&ctl00%24mainContent%24txtFirstName=&ctl00%24mainContent%24txtLastName=&ctl00%24mainContent%24hdnSearchType=&ctl00%24mainContent%24hfScoreEntryPopupShowHide=&ctl00%24mainContent%24hfHistoryPointParam='+str(HistoryPointParam)+'&__ASYNCPOST=true&'

            response1 = self.fctrequest.request(method='POST', link=self.base_link, data=data, headers=headers, cookies=self.cookies, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    for d1 in html1.xpath('//select[@id="ctl00_mainContent_ddlNTRPLevel"]/option[not(contains(text(), "-- select --"))]'):
                        ntrp_text = fctcore.parse_field('./text()', d1)
                        ntrp_value = fctcore.parse_field('./@value', d1)

                        self.df_ntrp.log({
                            "ntrp_text": ntrp_text,
                            "ntrp_value": ntrp_value,
                        })

                    for d1 in html1.xpath('//select[@id="ctl00_mainContent_ddlNTRPLevel"]/option[not(contains(text(), "-- select --"))]'):
                        gender_text = fctcore.parse_field('./text()', d1)
                        gender_value = fctcore.parse_field('./@value', d1)

                        self.df_gender.log({
                            "gender_text": gender_text,
                            "gender_value": gender_value,
                        })

        except Exception:
            logger.error(traceback.format_exc())

        return self.df_ntrp.get_df(), self.df_gender.get_df()

