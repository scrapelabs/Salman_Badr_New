cd /d %~dp0../../
call python manage.py runscript scripts.usta_team_captains.captain_name_claude
pause