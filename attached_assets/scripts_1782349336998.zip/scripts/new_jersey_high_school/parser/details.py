import traceback
from datetime import datetime
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from app_spiders.models import JobsItemsNewJerseyHighSchoolModel

class DetailsParser:

    def __init__(self, main_task, thread_task, progress):
        self.main_task = main_task
        self.thread_task = thread_task
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = False
        self.fctrequest = Request(use_session=False, use_cffi=True, use_proxy=self.use_proxy)
        self.headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,fr;q=0.8',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
        }
        # self.base_link = 'https://www.njschoolsports.com/Feeds/UTRResults/?key=4f59cee1-3db0-4128-84ba-bd7995dadd95&gender=boys&gamedate=03/24/2026'
        self.base_link = 'https://www.njschoolsports.com/Feeds/UTRResults/?key={job_api_key}&gender={job_gender}&gamedate={job_date}'
        self.job_api_key = '4f59cee1-3db0-4128-84ba-bd7995dadd95'


    def parse_site(self, spider_id, job_id, job_date_chunk, job_gender):
        try:
            for job_date in job_date_chunk:
                self.progress.update(self.main_task, advance=1)
                self.progress.update(self.thread_task, advance=1)
                close_old_connections()

                job_date = fctcore.convert_string_to_date_format(job_date, in_format='%Y-%m-%d', out_format='%m/%d/%Y')

                index_link = self.base_link.format(job_api_key=self.job_api_key, job_gender=job_gender, job_date=job_date)
                logger.info(f'job_gender: {job_gender} | job_date: {job_date} | {index_link}')

                results1 = {}
                try:
                    response1 = self.fctrequest.request(method='GET', link=index_link, headers=self.headers, proxies=self.proxies, tries=3, timeout=60*4)
                    if response1:
                        if response1.status_code in range(200, 300):
                            try:
                                results1 = response1.json()
                            except Exception:
                                ''
                except Exception:
                    logger.error(traceback.format_exc())

                if results1:
                    self.parse_page(spider_id, job_id, results1)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_page(self, spider_id, job_id, results1):
        try:
            games = results1.get('games', {}).get('games', [])
            for game in games:
                for match in game.get('matches', []):
                    match_id = ""  # JSON field names: gameReportId '-'eventResultId' #Sample: 1127878-2584577
                    ball_type = ""  # JSON field names: Always Yellow #Sample:
                    id_type = ""  # JSON field names: Always NNJHS #Sample:
                    draw_bracket_value = ""  # JSON field names: Always Blank #Sample:
                    draw_name = ""  # JSON field names: eventName #Sample: 1st Singles
                    draw_team_type = ""  # JSON field names: If winner2 and loser2 objects are there then 'Doubles' otherwise 'Singles' #Sample: Singles
                    tournament_name = ""  # JSON field names: Dual Match: 'winner1 {schoolName}' vs 'loser1 {schoolName}' #Sample: Dual Match: West Windsor-Plainsboro South vs Princeton
                    date = ""  # JSON field names: gameDate #Sample: 03/23/2026
                    score = ""  # JSON field names: score #Sample: 6-3, 6-2
                    winner_1_name = ""  # JSON field names: winner1 {lastName, firstName } #Sample: Doles, John
                    winner_1_gender = ""  # JSON field names: sportGender If value is 'Boys' then M If value is 'Girls' then F #Sample: M
                    winner_1_dob = ""  # JSON field names: Always Blank #Sample:
                    winner_1_third_party_id = ""  # JSON field names: winner1 {playerId} #Sample:
                    winner_1_city = ""  # JSON field names: winner1 {schoolCity} #Sample:
                    winner_1_state = ""  # JSON field names: winner1 {schoolState} #Sample:
                    winner_1_country = ""  # JSON field names: Always USA #Sample:
                    winner_2_name = ""  # JSON field names: winner2 {lastName, firstName } #Sample:
                    winner_2_gender = ""  # JSON field names: sportGender If value is 'Boys' then M If value is 'Girls' then F #Sample:
                    winner_2_dob = ""  # JSON field names: Always Blank #Sample:
                    winner_2_third_party_id = ""  # JSON field names: winner2 {playerId} #Sample:
                    winner_2_city = ""  # JSON field names: winner2 {schoolCity} #Sample:
                    winner_2_state = ""  # JSON field names: winner2 {schoolState} #Sample:
                    winner_2_country = ""  # JSON field names: Always USA #Sample:
                    loser_1_name = ""  # JSON field names: loser1 {lastName, firstName } #Sample:
                    loser_1_gender = ""  # JSON field names: sportGender If value is 'Boys' then M If value is 'Girls' then F #Sample:
                    loser_1_dob = ""  # JSON field names: Always Blank #Sample:
                    loser_1_third_party_id = ""  # JSON field names: loser1 {playerId} #Sample:
                    loser_1_city = ""  # JSON field names: loser1 {schoolCity} #Sample:
                    loser_1_state = ""  # JSON field names: loser1 {schoolState} #Sample:
                    loser_1_country = ""  # JSON field names: Always USA #Sample:
                    loser_2_name = ""  # JSON field names: loser2 {lastName, firstName } #Sample:
                    loser_2_gender = ""  # JSON field names: sportGender If value is 'Boys' then M If value is 'Girls' then F #Sample:
                    loser_2_dob = ""  # JSON field names: Always Blank #Sample:
                    loser_2_third_party_id = ""  # JSON field names: loser2 {playerId} #Sample:
                    loser_2_city = ""  # JSON field names: loser2 {schoolCity} #Sample:
                    loser_2_state = ""  # JSON field names: loser2 {schoolState} #Sample:
                    loser_2_country = ""  # JSON field names: Always USA #Sample:
                    outcome = ""  # JSON field names: Always Completed #Sample:
                    draw_gender = ""  # JSON field names: sportGender If value is 'Boys' then Male If value is 'Girls' then Female #Sample:
                    draw_bracket_type = ""  # JSON field names: Always Blank #Sample:
                    draw_type = ""  # JSON field names: Always Blank #Sample:
                    tournament_city = ""  # JSON field names: Always Blank #Sample:
                    tournament_state = ""  # JSON field names: Always Blank #Sample:
                    tournament_country_code = ""  # JSON field names: Always USA #Sample:
                    tournament_host = ""  # JSON field names: Always Blank #Sample:
                    tournament_location_type = ""  # JSON field names: Always Blank #Sample:
                    tournament_surface = ""  # JSON field names: Always Blank #Sample:
                    tournament_event_category = ""  # JSON field names: Always Blank #Sample:
                    tournament_event_grade = ""  # JSON field names: Always Blank #Sample:
                    tournament_import_source = ""  # JSON field names: Always NJ School Sports #Sample:
                    tournament_sanction_body = ""  # JSON field names: Always NJ School Sports #Sample:
                    winner_2_college = ""  # JSON field names: Always Blank #Sample:
                    loser_2_college = ""  # JSON field names: Always Blank #Sample:
                    tournament_event_type = ""  # JSON field names: Always Dual Match #Sample:
                    winner_1_college = ""  # JSON field names: Always Blank #Sample:
                    loser_1_college = ""  # JSON field names: Always Blank #Sample:
                    tournament_url = ""  # JSON field names: Always Blank #Sample:
                    tournament_country = ""  # JSON field names: Always USA #Sample:
                    tournament_start_date = ""  # JSON field names: gameDate #Sample:
                    tournament_end_date = ""  # JSON field names: gameDate #Sample:

                    game_report_id = game.get('gameReportId', '')
                    event_result_id = match.get('eventResultId', '')
                    sport_gender = game.get('sportGender', '')
                    game_date = self.parse_date(game.get('gameDate', ''))

                    winner1 = match.get('winner1') or {}
                    winner2 = match.get('winner2') or {}
                    loser1 = match.get('loser1') or {}
                    loser2 = match.get('loser2') or {}

                    is_doubles = bool(match.get('winner2') or match.get('loser2'))

                    # Tournament name: "Dual Match: {winner1 schoolName} vs {loser1 schoolName}"
                    w1_school = winner1.get('schoolName', '')
                    l1_school = loser1.get('schoolName', '')
                    tournament_name = f"Dual Match: {w1_school} vs {l1_school}"

                    # Identifiers
                    match_id = f"{game_report_id}-{event_result_id}"
                    ball_type = 'Yellow'
                    id_type = 'NNJHS'
                    draw_bracket_value = ''

                    # Draw info
                    draw_name = match.get('eventName', '')
                    draw_team_type = 'Doubles' if is_doubles else 'Singles'
                    draw_gender = self.get_gender_long(sport_gender)
                    draw_bracket_type = ''
                    draw_type = ''

                    # Tournament info
                    tournament_name = tournament_name
                    tournament_city = ''
                    tournament_state = ''
                    tournament_country_code = 'USA'
                    tournament_host = ''
                    tournament_location_type = ''
                    tournament_surface = ''
                    tournament_event_category = ''
                    tournament_event_grade = ''
                    tournament_import_source = 'NJ School Sports'
                    tournament_sanction_body = 'NJ School Sports'
                    tournament_event_type = 'Dual Match'
                    tournament_url = ''
                    tournament_country = 'USA'
                    tournament_start_date = game_date
                    tournament_end_date = game_date

                    # Match info
                    date = game_date
                    score = match.get('score', '')
                    outcome = 'Completed'

                    # Winner 1
                    winner_1_name = self.format_name(winner1)
                    winner_1_gender = self.get_gender_short(sport_gender)
                    winner_1_dob = ''
                    winner_1_third_party_id = str(winner1.get('playerId', ''))
                    winner_1_city = winner1.get('schoolCity', '')
                    winner_1_state = winner1.get('schoolState', '')
                    winner_1_country = 'USA'
                    winner_1_college = ''

                    # Winner 2 (Doubles only)
                    winner_2_name = self.format_name(winner2) if is_doubles else ''
                    winner_2_gender = self.get_gender_short(sport_gender) if is_doubles else ''
                    winner_2_dob = ''
                    winner_2_third_party_id = str(winner2.get('playerId', '')) if is_doubles else ''
                    winner_2_city = winner2.get('schoolCity', '') if is_doubles else ''
                    winner_2_state = winner2.get('schoolState', '') if is_doubles else ''
                    winner_2_country = 'USA' if is_doubles else ''
                    winner_2_college = ''

                    # Loser 1
                    loser_1_name = self.format_name(loser1)
                    loser_1_gender = self.get_gender_short(sport_gender)
                    loser_1_dob = ''
                    loser_1_third_party_id = str(loser1.get('playerId', ''))
                    loser_1_city = loser1.get('schoolCity', '')
                    loser_1_state = loser1.get('schoolState', '')
                    loser_1_country = 'USA'
                    loser_1_college = ''

                    # Loser 2 (Doubles only)
                    loser_2_name = self.format_name(loser2) if is_doubles else ''
                    loser_2_gender = self.get_gender_short(sport_gender) if is_doubles else ''
                    loser_2_dob = ''
                    loser_2_third_party_id = str(loser2.get('playerId', '')) if is_doubles else ''
                    loser_2_city = loser2.get('schoolCity', '') if is_doubles else ''
                    loser_2_state = loser2.get('schoolState', '') if is_doubles else ''
                    loser_2_country = 'USA' if is_doubles else ''
                    loser_2_college = ''

                    if not JobsItemsNewJerseyHighSchoolModel.objects.filter(spider_id=spider_id, job_id=job_id, winner_1_name=winner_1_name, loser_1_name=loser_1_name, winner_2_name=winner_2_name, loser_2_name=loser_2_name, score=score, match_id=match_id).exists():
                        logger.info(f'match_id: {match_id}')
                        logger.info(f'draw_name: {draw_name}')
                        logger.info(f'draw_team_type: {draw_team_type}')
                        logger.info(f'tournament_name: {tournament_name}')
                        logger.info(f'date: {date}')
                        logger.info(f'score: {score}')
                        logger.info(f'winner_1_name: {winner_1_name}')
                        logger.info(f'winner_1_gender: {winner_1_gender}')
                        logger.info(f'winner_1_third_party_id: {winner_1_third_party_id}')
                        logger.info(f'winner_1_dob: {winner_1_dob}')
                        logger.info(f'winner_2_name: {winner_2_name}')
                        logger.info(f'winner_2_gender: {winner_2_gender}')
                        logger.info(f'winner_2_third_party_id: {winner_2_third_party_id}')
                        logger.info(f'winner_2_dob: {winner_2_dob}')
                        logger.info(f'loser_1_name: {loser_1_name}')
                        logger.info(f'loser_1_gender: {loser_1_gender}')
                        logger.info(f'loser_1_third_party_id: {loser_1_third_party_id}')
                        logger.info(f'loser_1_dob: {loser_1_dob}')
                        logger.info(f'loser_2_name: {loser_2_name}')
                        logger.info(f'loser_2_gender: {loser_2_gender}')
                        logger.info(f'loser_2_third_party_id: {loser_2_third_party_id}')
                        logger.info(f'loser_2_dob: {loser_2_dob}')
                        logger.info(f'outcome: {outcome}')
                        logger.info(f'draw_gender: {draw_gender}')
                        logger.info(f'tournament_city: {tournament_city}')
                        logger.info(f'tournament_country_code: {tournament_country_code}')
                        logger.info(f'tournament_url: {tournament_url}')
                        logger.info(f'tournament_country: {tournament_country}')
                        logger.info(f'tournament_start_date: {tournament_start_date}')
                        logger.info(f'tournament_end_date: {tournament_end_date}')
                        logger.info('*' * 50)

                        JobsItemsNewJerseyHighSchoolModel(
                            spider_id=spider_id,
                            job_id=job_id,
                            match_id=match_id,
                            ball_type=ball_type,
                            id_type=id_type,
                            draw_bracket_value=draw_bracket_value,
                            draw_name=draw_name,
                            draw_team_type=draw_team_type,
                            tournament_name=tournament_name,
                            date=date,
                            score=score,
                            winner_1_name=winner_1_name,
                            winner_1_gender=winner_1_gender,
                            winner_1_dob=winner_1_dob,
                            winner_1_third_party_id=winner_1_third_party_id,
                            winner_1_city=winner_1_city,
                            winner_1_state=winner_1_state,
                            winner_1_country=winner_1_country,
                            winner_2_name=winner_2_name,
                            winner_2_gender=winner_2_gender,
                            winner_2_dob=winner_2_dob,
                            winner_2_third_party_id=winner_2_third_party_id,
                            winner_2_city=winner_2_city,
                            winner_2_state=winner_2_state,
                            winner_2_country=winner_2_country,
                            loser_1_name=loser_1_name,
                            loser_1_gender=loser_1_gender,
                            loser_1_dob=loser_1_dob,
                            loser_1_third_party_id=loser_1_third_party_id,
                            loser_1_city=loser_1_city,
                            loser_1_state=loser_1_state,
                            loser_1_country=loser_1_country,
                            loser_2_name=loser_2_name,
                            loser_2_gender=loser_2_gender,
                            loser_2_dob=loser_2_dob,
                            loser_2_third_party_id=loser_2_third_party_id,
                            loser_2_city=loser_2_city,
                            loser_2_state=loser_2_state,
                            loser_2_country=loser_2_country,
                            outcome=outcome,
                            draw_gender=draw_gender,
                            draw_bracket_type=draw_bracket_type,
                            draw_type=draw_type,
                            tournament_city=tournament_city,
                            tournament_state=tournament_state,
                            tournament_country_code=tournament_country_code,
                            tournament_host=tournament_host,
                            tournament_location_type=tournament_location_type,
                            tournament_surface=tournament_surface,
                            tournament_event_category=tournament_event_category,
                            tournament_event_grade=tournament_event_grade,
                            tournament_import_source=tournament_import_source,
                            tournament_sanction_body=tournament_sanction_body,
                            winner_2_college=winner_2_college,
                            loser_2_college=loser_2_college,
                            tournament_event_type=tournament_event_type,
                            winner_1_college=winner_1_college,
                            loser_1_college=loser_1_college,
                            tournament_url=tournament_url,
                            tournament_country=tournament_country,
                            tournament_start_date=tournament_start_date,
                            tournament_end_date=tournament_end_date,
                        ).save()

        except Exception:
            logger.error(traceback.format_exc())

    def get_gender_short(self, sport_gender):
        """Boys -> M, Girls -> F"""
        return 'M' if sport_gender == 'Boys' else 'F' if sport_gender == 'Girls' else ''

    def get_gender_long(self, sport_gender):
        """Boys -> Male, Girls -> Female"""
        return 'Male' if sport_gender == 'Boys' else 'Female' if sport_gender == 'Girls' else ''

    def format_name(self, player):
        """Returns 'lastName, firstName' or blank if player is None."""
        if not player:
            return ''
        last = player.get('lastName', '')
        first = player.get('firstName', '')
        return f"{last}, {first}" if last or first else ''

    def parse_date(self, date_str):
        """Parse gameDate and return date-only string."""
        if not date_str:
            return ''
        try:
            return datetime.fromisoformat(date_str).strftime('%Y-%m-%d')
        except Exception:
            return date_str