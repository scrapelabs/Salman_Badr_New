import traceback, re
from django.db import close_old_connections
from datetime import datetime
from assets.fct.fctlog import logger
from app_spiders.models import JobsItemsAustraliaTennisModel, jobsAustraliaTennisFilesNamesModel, jobsAustraliaTennisFilesDataModel

class DetailsParser:

    def __init__(self):
        pass


    def parse_site(self, spider_id, job_id, ids_chunk, main_task, thread_task, progress):
        try:
            for id in ids_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    jobsAustraliaTennisFilesNames_obj = jobsAustraliaTennisFilesNamesModel.objects.get(id=id)
                    file_name = jobsAustraliaTennisFilesNames_obj.file_name
                    total_scores = jobsAustraliaTennisFilesNames_obj.total_scores

                    jobsAustraliaTennisFilesData_obj = jobsAustraliaTennisFilesDataModel.objects.get(file_name=file_name)
                    file_data = jobsAustraliaTennisFilesData_obj.file_data

                    logger.info(f'file_name: {file_name} | total_scores: {total_scores}')

                    matches = self.extract_matches(file_data)
                    for match in matches:
                        self.match_to_row(spider_id, job_id, match, file_name)

                except Exception:
                    logger.error(traceback.format_exc())
        except Exception:
            logger.error(traceback.format_exc())

    # ---------- Helpers ----------

    def parse_date_to_mmddyyyy(self, value):
        """
        Robust date parser -> 'MM/DD/YYYY'

        Supports:
          - 'YYYY-MM-DD'
          - 'YYYY-MM-DDTHH:MM:SSZ' (and fractional seconds)
          - 'YYYY-MM-DD HH:MM:SS'  (common DOB format)
          - ISO with timezone offsets

        Returns '' if empty/invalid or placeholder year <= 1.
        """
        if value is None:
            return ""
        s = str(value).strip()
        if not s or s.lower() == "null":
            return ""

        # Fast path: if starts with YYYY-MM-DD, parse only that portion
        m = re.match(r"^(\d{4}-\d{2}-\d{2})", s)
        if m:
            try:
                dt = datetime.strptime(m.group(1), "%Y-%m-%d").date()
                if dt.year <= 1:
                    return ""
                return dt.strftime("%m/%d/%Y")
            except Exception:
                pass

        # Fallbacks
        fmts = [
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M:%S.%fZ",
            "%Y-%m-%dT%H:%M:%S.%f",
        ]
        for fmt in fmts:
            try:
                dt = datetime.strptime(s, fmt).date()
                if dt.year <= 1:
                    return ""
                return dt.strftime("%m/%d/%Y")
            except Exception:
                continue

        # Last resort: fromisoformat (handles offsets)
        try:
            iso = s.replace("Z", "+00:00")
            dt = datetime.fromisoformat(iso).date()
            if dt.year <= 1:
                return ""
            return dt.strftime("%m/%d/%Y")
        except Exception:
            return ""

    def normalize_gender(self, g):
        """
        NEW RULE:
          - If value is 'Male' -> 'M'
          - If value is 'Female' -> 'F'
          - If value is a number (int/float or numeric string) -> keep the number as-is
          - Otherwise -> blank
        """
        if g is None:
            return ""

        # numeric types -> keep as-is
        if isinstance(g, (int, float)) and not isinstance(g, bool):
            try:
                if float(g).is_integer():
                    return str(int(g))
                return str(g)
            except Exception:
                return str(g)

        s = str(g).strip()
        if not s or s.lower() == "null":
            return ""

        # numeric string -> keep
        if s.isdigit():
            return s

        sl = s.lower()
        if sl == "male":
            return "M"
        if sl == "female":
            return "F"
        # if already 'M'/'F'
        if sl in {"m", "f"}:
            return sl.upper()

        return ""

    def _lookup_case_insensitive(self, d, key):
        key_lower = key.lower()
        for k, v in d.items():
            if k.lower() == key_lower:
                return True, v
        return False, None

    def safe_get(self, match, key):
        """
        Resilient get:
          - Exact key
          - Fallback to case-insensitive match
          - None -> empty string
        """
        if key in match:
            val = match[key]
        else:
            found, val = self._lookup_case_insensitive(match, key)
            if not found:
                return ""
        return "" if val is None else val

    def safe_int(self, match, key):
        raw = self.safe_get(match, key)
        if raw == "":
            return 0
        try:
            return int(raw)
        except (TypeError, ValueError):
            try:
                return int(float(str(raw)))
            except Exception:
                return 0

    def safe_bool(self, match, key):
        raw = self.safe_get(match, key)
        if isinstance(raw, bool):
            return raw
        s = str(raw).strip().lower()
        if s in {"1", "true", "t", "yes", "y"}:
            return True
        if s in {"0", "false", "f", "no", "n"}:
            return False
        return False

    def choose_third_party_id(self, match, prefix):
        """
        - If TennisConnectID present => (id, 'Tennis Connect')
        - Else if UniqueID present => (id, 'Tennis Australia')
        - Else => ('', '')
        """
        tc = self.safe_get(match, prefix + "TennisConnectID")
        unique = self.safe_get(match, prefix + "UniqueID")

        tc_str = str(tc).strip()
        unique_str = str(unique).strip()

        if tc_str.lower() == "null":
            tc_str = ""
        if unique_str.lower() == "null":
            unique_str = ""

        if tc_str:
            return tc_str, "Tennis Connect"
        if unique_str:
            return unique_str, "Tennis Australia"
        return "", ""

    def get_result_sides(self, match):
        """
        Returns (winner_side, loser_side, outcome_text).

        winner_side/loser_side are "1" or "2" (Team1/Team2).
        """
        res = str(self.safe_get(match, "Match_Result") or "").upper()
        if res == "TEAM1WIN":
            return "1", "2", "Completed"
        elif res == "TEAM2WIN":
            return "2", "1", "Completed"
        else:
            return "1", "2", "Tie"

    def get_player_prefix(self, result, role, person):
        """
        Prefix like 'Player1Team1_' / 'Player2Team2_' based on winner/loser and person index.
        """
        res = (result or "").upper()

        if role == "winner":
            if person == 1:
                if res == "TEAM1WIN":
                    return "Player1Team1_"
                elif res == "TEAM2WIN":
                    return "Player1Team2_"
                else:
                    return "Player1Team1_"
            else:  # person == 2
                if res == "TEAM1WIN":
                    return "Player2Team1_"
                elif res == "TEAM2WIN":
                    return "Player2Team2_"
                else:
                    return "Player2Team1_"
        else:  # loser
            if person == 1:
                if res == "TEAM1WIN":
                    return "Player1Team2_"
                elif res == "TEAM2WIN":
                    return "Player1Team1_"
                else:
                    return "Player1Team2_"
            else:  # person == 2
                if res == "TEAM1WIN":
                    return "Player2Team2_"
                elif res == "TEAM2WIN":
                    return "Player2Team1_"
                else:
                    return "Player2Team2_"

    def build_name(self, last_name, first_name):
        last_name = (last_name or "").strip()
        first_name = (first_name or "").strip()
        if not last_name and not first_name:
            return ""
        if not last_name:
            return first_name
        if not first_name:
            return last_name
        return f"{last_name}, {first_name}"

    def build_score(self, match):
        """
        UPDATED SCORE LOGIC:
          - Always check Match_Set{i}IsTieBreak
          - Include set if:
              * games are non-zero OR
              * is tiebreak is True OR
              * tiebreak points exist (non-zero)
          - If tie-break: format "G1-G2 (TB1-TB2)" (both sides)
          - Winner side first.
        """
        winner_side, _, _ = self.get_result_sides(match)

        first_side = winner_side
        second_side = "1" if winner_side == "2" else "2"

        parts = []
        for i in range(1, 8):
            g1 = self.safe_int(match, f"Match_Team{first_side}Set{i}GamesWon")
            g2 = self.safe_int(match, f"Match_Team{second_side}Set{i}GamesWon")

            is_tb = self.safe_bool(match, f"Match_Set{i}IsTieBreak")
            tb1 = self.safe_int(match, f"Match_Team{first_side}Set{i}TieBreakPoints")
            tb2 = self.safe_int(match, f"Match_Team{second_side}Set{i}TieBreakPoints")

            include = (g1 != 0 or g2 != 0 or is_tb or tb1 != 0 or tb2 != 0)
            if not include:
                continue

            set_str = f"{g1}-{g2}"
            if is_tb or tb1 != 0 or tb2 != 0:
                set_str = f"{set_str} ({tb1}-{tb2})"

            parts.append(set_str)

        return ", ".join(parts)

    def build_tournament_url(self, match):
        data_type = str(self.safe_get(match, "Match_DataType") or "").lower()
        league_id = str(self.safe_get(match, "Match_LeagueID") or "").strip()
        if not league_id:
            return ""

        if data_type == "league":
            return f"https://matchcentre.tennis.com.au/divisions/{league_id}"
        elif data_type == "tournament":
            return f"https://tournaments.tennis.com.au/tournament/{league_id}"
        return ""

    def is_doubles_match(self, match):
        """
        Auto-detect singles vs doubles.
        - If Match_Type == 'DOUBLES' => True
        - Else, if any Player2Team1 or Player2Team2 first name exists => True
        - Else => False (singles)
        """
        match_type = str(self.safe_get(match, "Match_Type") or "").upper()
        if match_type == "DOUBLES":
            return True

        p2t1 = str(self.safe_get(match, "Player2Team1_FirstName") or "").strip()
        p2t2 = str(self.safe_get(match, "Player2Team2_FirstName") or "").strip()
        return bool(p2t1 or p2t2)

    # ---------- Row builder ----------

    def match_to_row(self, spider_id, job_id, match, file_name):
        result_raw = self.safe_get(match, "Match_Result") or ""
        result_upper = str(result_raw).upper()
        winner_side, loser_side, outcome = self.get_result_sides(match)
        doubles = self.is_doubles_match(match)

        match_id = str(self.safe_get(match, "Match_ID"))
        ball_type = str(self.safe_get(match, "Match_BallType"))
        draw_bracket_value = ""
        draw_name = str(self.safe_get(match, "Match_DivisionName"))
        draw_team_type = str(self.safe_get(match, "Match_Type"))
        tournament_name = str(self.safe_get(match, "Match_LeagueName"))
        date_str = self.parse_date_to_mmddyyyy(self.safe_get(match, "Match_Date"))

        # Score (Excel-safe: add ';' only here)
        score_raw = self.build_score(match)
        if score_raw and not score_raw.endswith(";"):
            score = score_raw + ";"
        else:
            score = score_raw

        # Winner 1
        w1_prefix = self.get_player_prefix(result_upper, "winner", 1)
        w1_first = str(self.safe_get(match, w1_prefix + "FirstName"))
        w1_last = str(self.safe_get(match, w1_prefix + "LastName"))
        winner_1_name = self.build_name(w1_last, w1_first)
        winner_1_gender = self.normalize_gender(self.safe_get(match, w1_prefix + "Gender"))
        winner_1_dob = self.parse_date_to_mmddyyyy(self.safe_get(match, w1_prefix + "DateOfBirth"))
        winner_1_third_party_id, winner_1_id_type = self.choose_third_party_id(match, w1_prefix)
        winner_1_city = str(self.safe_get(match, w1_prefix + "Suburb"))
        winner_1_state = str(self.safe_get(match, w1_prefix + "AddressState"))
        winner_1_country = str(self.safe_get(match, w1_prefix + "Country"))

        # Winner 2
        if doubles:
            w2_prefix = self.get_player_prefix(result_upper, "winner", 2)
            w2_first = str(self.safe_get(match, w2_prefix + "FirstName")).strip()
            w2_last = str(self.safe_get(match, w2_prefix + "LastName")).strip()

            if not w2_first and not w2_last:
                winner_2_name = ""
                winner_2_gender = ""
                winner_2_dob = ""
                winner_2_third_party_id = ""
                winner_2_id_type = ""
                winner_2_city = ""
                winner_2_state = ""
                winner_2_country = ""
            else:
                winner_2_name = self.build_name(w2_last, w2_first)
                winner_2_gender = self.normalize_gender(self.safe_get(match, w2_prefix + "Gender"))
                winner_2_dob = self.parse_date_to_mmddyyyy(self.safe_get(match, w2_prefix + "DateOfBirth"))
                winner_2_third_party_id, winner_2_id_type = self.choose_third_party_id(match, w2_prefix)
                winner_2_city = str(self.safe_get(match, w2_prefix + "Suburb"))
                winner_2_state = str(self.safe_get(match, w2_prefix + "AddressState"))
                winner_2_country = str(self.safe_get(match, w2_prefix + "Country"))
        else:
            # Singles: Winner 2 must be blank
            winner_2_name = ""
            winner_2_gender = ""
            winner_2_dob = ""
            winner_2_third_party_id = ""
            winner_2_id_type = ""
            winner_2_city = ""
            winner_2_state = ""
            winner_2_country = ""

        # Loser 1
        l1_prefix = self.get_player_prefix(result_upper, "loser", 1)
        l1_first = str(self.safe_get(match, l1_prefix + "FirstName"))
        l1_last = str(self.safe_get(match, l1_prefix + "LastName"))
        loser_1_name = self.build_name(l1_last, l1_first)
        loser_1_gender = self.normalize_gender(self.safe_get(match, l1_prefix + "Gender"))
        loser_1_dob = self.parse_date_to_mmddyyyy(self.safe_get(match, l1_prefix + "DateOfBirth"))
        loser_1_third_party_id, loser_1_id_type = self.choose_third_party_id(match, l1_prefix)
        loser_1_city = str(self.safe_get(match, l1_prefix + "Suburb"))
        loser_1_state = str(self.safe_get(match, l1_prefix + "AddressState"))
        loser_1_country = str(self.safe_get(match, l1_prefix + "Country"))

        # Loser 2
        if doubles:
            l2_prefix = self.get_player_prefix(result_upper, "loser", 2)
            l2_first = str(self.safe_get(match, l2_prefix + "FirstName")).strip()
            l2_last = str(self.safe_get(match, l2_prefix + "LastName")).strip()

            if not l2_first and not l2_last:
                loser_2_name = ""
                loser_2_gender = ""
                loser_2_dob = ""
                loser_2_third_party_id = ""
                loser_2_id_type = ""
                loser_2_city = ""
                loser_2_state = ""
                loser_2_country = ""
            else:
                loser_2_name = self.build_name(l2_last, l2_first)
                loser_2_gender = self.normalize_gender(self.safe_get(match, l2_prefix + "Gender"))
                loser_2_dob = self.parse_date_to_mmddyyyy(self.safe_get(match, l2_prefix + "DateOfBirth"))
                loser_2_third_party_id, loser_2_id_type = self.choose_third_party_id(match, l2_prefix)
                loser_2_city = str(self.safe_get(match, l2_prefix + "Suburb"))
                loser_2_state = str(self.safe_get(match, l2_prefix + "AddressState"))
                loser_2_country = str(self.safe_get(match, l2_prefix + "Country"))
        else:
            # Singles: Loser 2 must be blank
            loser_2_name = ""
            loser_2_gender = ""
            loser_2_dob = ""
            loser_2_third_party_id = ""
            loser_2_id_type = ""
            loser_2_city = ""
            loser_2_state = ""
            loser_2_country = ""

        # Draw / Tournament static fields
        draw_gender = ""
        draw_bracket_type = ""
        draw_type = ""
        tournament_city = ""
        tournament_state = ""
        tournament_country_code = "AUS"
        tournament_host = ""
        tournament_location_type = ""
        tournament_surface = ""
        tournament_event_category = ""
        tournament_event_grade = ""
        tournament_import_source = file_name
        tournament_sanction_body = "Tennis Australia"
        winner_2_college = ""
        loser_2_college = ""

        event_type_raw = str(self.safe_get(match, "Match_DataType"))
        tournament_event_type = event_type_raw.capitalize() if event_type_raw else ""

        winner_1_college = ""
        loser_1_college = ""

        tournament_url = self.build_tournament_url(match)
        tournament_country = "AUS"
        tournament_start_date = ""
        tournament_end_date = ""

        JobsItemsAustraliaTennisModel(
            spider_id=spider_id,
            job_id=job_id,
            match_id=match_id,
            ball_type=ball_type,
            draw_bracket_value=draw_bracket_value,
            draw_name=draw_name,
            draw_team_type=draw_team_type,
            tournament_name=tournament_name,
            date=date_str,
            score=score,
            winner_1_name=winner_1_name,
            winner_1_gender=winner_1_gender,
            winner_1_dob=winner_1_dob,
            winner_1_third_party_id=winner_1_third_party_id,
            winner_1_id_type=winner_1_id_type,
            winner_1_city=winner_1_city,
            winner_1_state=winner_1_state,
            winner_1_country=winner_1_country,
            winner_2_name=winner_2_name,
            winner_2_gender=winner_2_gender,
            winner_2_dob=winner_2_dob,
            winner_2_third_party_id=winner_2_third_party_id,
            winner_2_id_type=winner_2_id_type,
            winner_2_city=winner_2_city,
            winner_2_state=winner_2_state,
            winner_2_country=winner_2_country,
            loser_1_name=loser_1_name,
            loser_1_gender=loser_1_gender,
            loser_1_dob=loser_1_dob,
            loser_1_third_party_id=loser_1_third_party_id,
            loser_1_id_type=loser_1_id_type,
            loser_1_city=loser_1_city,
            loser_1_state=loser_1_state,
            loser_1_country=loser_1_country,
            loser_2_name=loser_2_name,
            loser_2_gender=loser_2_gender,
            loser_2_dob=loser_2_dob,
            loser_2_third_party_id=loser_2_third_party_id,
            loser_2_id_type=loser_2_id_type,
            loser_2_city=loser_2_city,
            loser_2_state=loser_2_state,
            loser_2_country=loser_2_country,
            outcome=outcome,
            draw_gender=draw_gender,
            draw_bracket_type=draw_bracket_type,
            draw_type=draw_type,
            tournament_city=tournament_city,
            tournament_state=tournament_state,
            tournament_country_code=tournament_country_code,
            tournament_host=tournament_host,
            tournament_location_type=tournament_location_type,
            tournament_surface=tournament_surface,
            tournament_event_category=tournament_event_category,
            tournament_event_grade=tournament_event_grade,
            tournament_import_source=tournament_import_source,
            tournament_sanction_body=tournament_sanction_body,
            winner_2_college=winner_2_college,
            loser_2_college=loser_2_college,
            tournament_event_type=tournament_event_type,
            winner_1_college=winner_1_college,
            loser_1_college=loser_1_college,
            tournament_url=tournament_url,
            tournament_country=tournament_country,
            tournament_start_date=tournament_start_date,
            tournament_end_date=tournament_end_date,
        ).save()

    # ---------- Main script ----------

    def extract_matches(self, data):
        matches_obj = data.get("Matches") or data.get("matches") or {}
        if not isinstance(matches_obj, dict):
            return []

        matches = matches_obj.get("Match") or matches_obj.get("match") or []
        if isinstance(matches, dict):
            return [matches]
        if isinstance(matches, list):
            return matches
        return []
