import json, os, shutil, traceback
import pandas as pd
import concurrent.futures
from pathlib import Path
from datetime import datetime, timezone, timedelta, date

from azure.storage.blob import ContainerClient
from assets.fct.fctlog import logger
from assets.fct import fctcore
from scripts import helper
from app_spiders.models import jobsModel, jobsAustraliaTennisFilesNamesModel


class BlobParser:

    def __init__(self, max_workers, progress, df_requests, df_errors):
        self.max_workers = max_workers
        self.progress = progress
        self.df_requests = df_requests
        self.df_errors = df_errors

        # ================= CONFIG =================
        self.CONTAINER_SAS_URL = (
            "https://utprod.blob.core.windows.net/result-submissions"
            "?sp=rl&st=2025-12-10T00:16:08Z&se=2028-06-26T08:31:08Z"
            "&sv=2024-11-04&sr=c"
            "&sig=9W0cSlen6CFiJLhJ6HOKoOKsnP5Mx4izhMwWPSNX38g%3D"
        )

        self.FOLDER_PREFIX = "tennis_australia/"  # Azure "folder"
        self.DOWNLOAD_DIR = Path(__file__).resolve().parent / "blob_files"
        # =========================================

        # if self.DOWNLOAD_DIR.exists():
        #     shutil.rmtree(self.DOWNLOAD_DIR)
        #     self.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

        self.DOWNLOAD_DIR.mkdir(exist_ok=True)
        self.data_data = []

        # Date-only range (YYYY-MM-DD)
        self.start_date = None
        self.end_date = None


    # ================= DATE HELPERS =================
    def _parse_date_yyyy_mm_dd(self, s: str):
        if not s:
            return None
        return datetime.strptime(s, "%Y-%m-%d").date()

    def _parse_date_range(self, start_date, end_date):
        """
        start_date/end_date: 'YYYY-MM-DD'
        Returns python date objects (no time).
        """
        if not start_date or not end_date:
            return None, None

        start_d = self._parse_date_yyyy_mm_dd(start_date)
        end_d = self._parse_date_yyyy_mm_dd(end_date)
        return start_d, end_d

    def _date_range_iter(self, start_d: date, end_d: date):
        """
        Yield each day in [start_d, end_d]
        """
        cur = start_d
        while cur <= end_d:
            yield cur
            cur += timedelta(days=1)

    def _date_to_blob_prefix(self, d: date) -> str:
        """
        Your blob names look like:
          tennis_australia/20190926_055512588.json
        So for a given date, we list only:
          tennis_australia/YYYYMMDD_
        """
        return f"{self.FOLDER_PREFIX}{d.strftime('%Y%m%d')}_"

    # ===============================================


    def parse_site(self, job_id, job_start_date, job_end_date):
        # date-only range
        self.start_date, self.end_date = self._parse_date_range(job_start_date, job_end_date)

        logger.info(f"Blob filename-date filter | start={self.start_date} | end={self.end_date}")

        self.download_new_json_blobs(job_id, n='all')
        return pd.DataFrame(self.data_data), self.df_requests, self.df_errors


    def download_new_json_blobs(self, job_id, n=3):
        """
        ✅ FAST: no full folder scan.
        We list blobs by day-prefix:
            tennis_australia/YYYYMMDD_
        which matches your filename convention (upload date embedded in name).
        """
        container = ContainerClient.from_container_url(self.CONTAINER_SAS_URL)

        if not self.start_date or not self.end_date:
            logger.warning("start_date or end_date is missing - cannot do prefix-by-date listing")
            return

        # 1) Discover and schedule new blobs inside threading section
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {}
            submitted = 0

            # iterate days and list ONLY that day's prefix
            for d in self._date_range_iter(self.start_date, self.end_date):
                day_prefix = self._date_to_blob_prefix(d)
                logger.info(f"listing prefix: {day_prefix}")

                for blob in container.list_blobs(name_starts_with=day_prefix):

                    job_obj = jobsModel.objects.get(id=job_id)
                    if job_obj.job_status == 'completed':
                        helper.kill_proccess(job_obj.job_pid)

                    file_name = blob.name

                    # skip non-json
                    if not file_name.lower().endswith(".json"):
                        continue

                    if not jobsAustraliaTennisFilesNamesModel.objects.filter(file_name=file_name).exists():
                        logger.info(f'new: file_name: {file_name}')

                        blob_path = self.DOWNLOAD_DIR / Path(file_name).name

                        # skip if exists locally
                        if os.path.isfile(blob_path):
                            continue

                        # respect limit n (unless "all")
                        if n != "all" and submitted >= int(n):
                            break

                        future = executor.submit(self._download_one_blob, container, file_name, blob_path)
                        futures[future] = file_name
                        submitted += 1

                    else:
                        logger.warning(f'exist: file_name: {file_name}')

                # if limited and reached, stop scanning further days
                if n != "all" and submitted >= int(n):
                    break

            # Optional: surface any download exceptions in logs
            for fut, fname in list(futures.items()):
                try:
                    fut.result()
                except Exception as e:
                    logger.exception(f"download failed | file_name={fname} | err={e}")


    def _download_one_blob(self, container: ContainerClient, file_name, blob_path):
        """Download one blob and save as local JSON file. Returns file_name."""
        blob_client = container.get_blob_client(file_name)
        data = json.loads(blob_client.download_blob().readall())

        with open(blob_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

        logger.info(f"downloaded: {blob_path.name}")

        self.data_data.append({
            "blob_path": self.DOWNLOAD_DIR / blob_path.name,
        })
