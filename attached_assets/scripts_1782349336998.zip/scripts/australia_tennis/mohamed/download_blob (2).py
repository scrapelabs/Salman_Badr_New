import json, os, traceback
import pandas as pd
import concurrent.futures
from pathlib import Path
from datetime import datetime, time, timezone
from azure.storage.blob import ContainerClient
from assets.fct.fctlog import logger
from assets.fct import fctcore
from scripts import helper
from app_spiders.models import jobsModel


class BlobParser:

    def __init__(self, max_workers, progress, df_requests, df_errors):
        self.max_workers = max_workers
        self.progress = progress
        self.df_requests = df_requests
        self.df_errors = df_errors

        # ================= CONFIG =================
        self.CONTAINER_SAS_URL = (
            "https://utprod.blob.core.windows.net/result-submissions"
            "?sp=rl&st=2025-12-10T00:16:08Z&se=2028-06-26T08:31:08Z"
            "&sv=2024-11-04&sr=c"
            "&sig=9W0cSlen6CFiJLhJ6HOKoOKsnP5Mx4izhMwWPSNX38g%3D"
        )

        self.FOLDER_PREFIX = "tennis_australia/"
        self.DOWNLOAD_DIR = Path(__file__).resolve().parent / "blob_files"
        self.STATE_FILE = Path("downloaded_blobs.json")
        # =========================================

        self.DOWNLOAD_DIR.mkdir(exist_ok=True)
        self.data_data = []

        self.start_dt = None
        self.end_dt = None


    # ================= DATE HELPERS =================
    def _parse_date_range(self, start_date, end_date):
        """
        start_date, end_date: YYYY-MM-DD
        Creates inclusive UTC datetime range
        """
        if not start_date or not end_date:
            return None, None

        start_d = datetime.strptime(start_date, "%Y-%m-%d").date()
        end_d = datetime.strptime(end_date, "%Y-%m-%d").date()

        start_dt = datetime.combine(start_d, time.min).replace(tzinfo=timezone.utc)
        end_dt = datetime.combine(end_d, time.max).replace(tzinfo=timezone.utc)
        return start_dt, end_dt


    def _blob_in_date_range(self, blob):
        if not self.start_dt or not self.end_dt:
            return True

        lm = getattr(blob, "last_modified", None)
        if not lm:
            return False

        if lm.tzinfo is None:
            lm = lm.replace(tzinfo=timezone.utc)
        else:
            lm = lm.astimezone(timezone.utc)

        return self.start_dt <= lm <= self.end_dt
    # ===============================================


    def parse_site(self, job_id, job_start_date, job_end_date):
        # init date range
        self.start_dt, self.end_dt = self._parse_date_range(job_start_date, job_end_date)

        logger.info(
            f"Blob date filter | start={self.start_dt} | end={self.end_dt}"
        )

        self.download_new_json_blobs(job_id, n="all")
        return pd.DataFrame(self.data_data), self.df_requests, self.df_errors


    def download_new_json_blobs(self, job_id, n=3):
        container = ContainerClient.from_container_url(self.CONTAINER_SAS_URL)

        already_downloaded = self.load_downloaded_state()
        newly_downloaded = set()

        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {}
            submitted = 0

            for blob in container.list_blobs(name_starts_with=self.FOLDER_PREFIX):

                job_obj = jobsModel.objects.get(id=job_id)
                if job_obj.job_status == 'completed':
                    helper.kill_proccess(job_obj.job_pid)

                # 🔹 DATE FILTER HERE
                if not self._blob_in_date_range(blob):
                    continue

                blob_name = blob.name
                blob_path = self.DOWNLOAD_DIR / Path(blob_name).name

                if os.path.isfile(blob_path):
                    continue

                # skip non-json
                if not blob_name.lower().endswith(".json"):
                    continue

                # skip already downloaded
                if blob_name in already_downloaded:
                    continue

                # respect limit n (unless "all")
                if n != "all" and submitted >= int(n):
                    break

                future = executor.submit(
                    self._download_one_blob,
                    container,
                    blob_name,
                    blob_path
                )
                futures[future] = blob_name
                submitted += 1

            for future in concurrent.futures.as_completed(futures):
                blob_name = futures[future]
                try:
                    newly_downloaded.add(future.result())
                except Exception:
                    logger.error(f"error downloading {blob_name}: {traceback.format_exc()}")

        already_downloaded.update(newly_downloaded)
        self.save_downloaded_state(already_downloaded)

        logger.info(f"New files downloaded: {len(newly_downloaded)}")
        return list(newly_downloaded)


    def load_downloaded_state(self) -> set:
        if self.STATE_FILE.exists():
            try:
                return set(json.loads(self.STATE_FILE.read_text()))
            except Exception:
                return set()
        return set()


    def save_downloaded_state(self, downloaded: set) -> None:
        self.STATE_FILE.write_text(json.dumps(sorted(downloaded), indent=2))


    def _download_one_blob(self, container: ContainerClient, blob_name, blob_path) -> str:
        blob_client = container.get_blob_client(blob_name)
        data = json.loads(blob_client.download_blob().readall())

        with open(blob_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

        logger.info(f"downloaded: {blob_path.name}")

        self.data_data.append({
            "blob_path": self.DOWNLOAD_DIR / blob_path.name,
        })

        return blob_name
