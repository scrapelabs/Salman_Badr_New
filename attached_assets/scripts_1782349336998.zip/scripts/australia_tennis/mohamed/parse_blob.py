import json
import csv
import os
import sys
from datetime import datetime
from typing import Any, Dict, List, Tuple, Optional


# ---------- Helpers ----------

def parse_iso_to_mmddyyyy(value: Optional[str]) -> str:
    """Convert 'YYYY-MM-DDTHH:MM:SS' (or 'YYYY-MM-DD') to 'MM/DD/YYYY'."""
    if not value:
        return ""
    try:
        value = str(value)
        if "T" in value:
            value = value.split("T", 1)[0]
        dt = datetime.strptime(value, "%Y-%m-%d").date()
        return dt.strftime("%m/%d/%Y")
    except Exception:
        return ""


def normalize_gender(g: Optional[str]) -> str:
    """
    Convert gender to 'M' / 'F'.

    Handles:
      - 'Male' / 'Female' (any case)
      - 'M' / 'F'
      - '1' (male) / '2' (female)
    """
    if g is None:
        return ""
    g = str(g).strip().lower()
    if g in {"male", "m", "1"}:
        return "M"
    if g in {"female", "f", "2"}:
        return "F"
    return ""


def _lookup_case_insensitive(d: Dict[str, Any], key: str) -> Tuple[bool, Any]:
    key_lower = key.lower()
    for k, v in d.items():
        if k.lower() == key_lower:
            return True, v
    return False, None


def safe_get(match: Dict[str, Any], key: str) -> Any:
    """
    Resilient get:
      - Exact key
      - Fallback to case-insensitive match
      - None -> empty string
    """
    if key in match:
        val = match[key]
    else:
        found, val = _lookup_case_insensitive(match, key)
        if not found:
            return ""
    return "" if val is None else val


def safe_int(match: Dict[str, Any], key: str) -> int:
    raw = safe_get(match, key)
    if raw == "":
        return 0
    try:
        return int(raw)
    except (TypeError, ValueError):
        try:
            return int(float(str(raw)))
        except Exception:
            return 0


def safe_bool(match: Dict[str, Any], key: str) -> bool:
    raw = safe_get(match, key)
    if isinstance(raw, bool):
        return raw
    s = str(raw).strip().lower()
    if s in {"1", "true", "t", "yes", "y"}:
        return True
    if s in {"0", "false", "f", "no", "n"}:
        return False
    return False


def choose_third_party_id(match: Dict[str, Any], prefix: str) -> Tuple[str, str]:
    """
    - If TennisConnectID present => (id, 'Tennis Connect')
    - Else if UniqueID present => (id, 'Tennis Australia')
    - Else => ('', '')
    """
    tc = safe_get(match, prefix + "TennisConnectID")
    unique = safe_get(match, prefix + "UniqueID")

    tc_str = str(tc).strip()
    unique_str = str(unique).strip()

    if tc_str:
        return tc_str, "Tennis Connect"
    if unique_str:
        return unique_str, "Tennis Australia"
    return "", ""


def get_result_sides(match: Dict[str, Any]) -> Tuple[str, str, str]:
    """
    Returns (winner_side, loser_side, outcome_text).

    winner_side/loser_side are "1" or "2" (Team1/Team2).
    """
    res = str(safe_get(match, "Match_Result") or "").upper()
    if res == "TEAM1WIN":
        return "1", "2", "Completed"
    elif res == "TEAM2WIN":
        return "2", "1", "Completed"
    else:
        return "1", "2", "Tie"


def get_player_prefix(result: str, role: str, person: int) -> str:
    """
    Prefix like 'Player1Team1_' / 'Player2Team2_' based on winner/loser and person index.
    """
    res = (result or "").upper()

    if role == "winner":
        if person == 1:
            if res == "TEAM1WIN":
                return "Player1Team1_"
            elif res == "TEAM2WIN":
                return "Player1Team2_"
            else:
                return "Player1Team1_"
        else:  # person == 2
            if res == "TEAM1WIN":
                return "Player2Team1_"
            elif res == "TEAM2WIN":
                return "Player2Team2_"
            else:
                return "Player2Team1_"
    else:  # loser
        if person == 1:
            if res == "TEAM1WIN":
                return "Player1Team2_"
            elif res == "TEAM2WIN":
                return "Player1Team1_"
            else:
                return "Player1Team2_"
        else:  # person == 2
            if res == "TEAM1WIN":
                return "Player2Team2_"
            elif res == "TEAM2WIN":
                return "Player2Team1_"
            else:
                return "Player2Team2_"


def build_name(last_name: str, first_name: str) -> str:
    last_name = (last_name or "").strip()
    first_name = (first_name or "").strip()
    if not last_name and not first_name:
        return ""
    if not last_name:
        return first_name
    if not first_name:
        return last_name
    return f"{last_name}, {first_name}"


def build_score(match: Dict[str, Any]) -> str:
    """
    Build Score (raw; Excel-safety is applied later only for this column).

    Winner side is first in the score (Team{winner} vs Team{loser} orientation).
    """
    result = str(safe_get(match, "Match_Result") or "").upper()
    winner_side, loser_side, _ = get_result_sides(match)

    first_side = winner_side
    second_side = "1" if winner_side == "2" else "2"

    parts: List[str] = []

    for i in range(1, 8):
        team_first_games = safe_int(match, f"Match_Team{first_side}Set{i}GamesWon")
        team_second_games = safe_int(match, f"Match_Team{second_side}Set{i}GamesWon")

        if not (team_first_games or team_second_games):
            continue

        set_str = f"{team_first_games}-{team_second_games}"

        is_tiebreak = safe_bool(match, f"Match_Set{i}IsTieBreak")
        if is_tiebreak:
            tb_first = safe_int(match, f"Match_Team{first_side}Set{i}TieBreakPoints")
            if tb_first:
                set_str = f"{set_str}({tb_first})"

        parts.append(set_str)

    return ", ".join(parts)


def build_tournament_url(match: Dict[str, Any]) -> str:
    data_type = str(safe_get(match, "Match_DataType") or "").lower()
    league_id = str(safe_get(match, "Match_LeagueID") or "").strip()
    if not league_id:
        return ""

    if data_type == "league":
        return f"https://matchcentre.tennis.com.au/divisions/{league_id}"
    elif data_type == "tournament":
        return f"https://tournaments.tennis.com.au/tournament/{league_id}"
    return ""


def is_doubles_match(match: Dict[str, Any]) -> bool:
    """
    Auto-detect singles vs doubles.
    - If Match_Type == 'DOUBLES' => True
    - Else, if any Player2Team1 or Player2Team2 first name exists => True
    - Else => False (singles)
    """
    match_type = str(safe_get(match, "Match_Type") or "").upper()
    if match_type == "DOUBLES":
        return True

    p2t1 = str(safe_get(match, "Player2Team1_FirstName") or "").strip()
    p2t2 = str(safe_get(match, "Player2Team2_FirstName") or "").strip()
    return bool(p2t1 or p2t2)


# ---------- Row builder ----------

def match_to_row(match: Dict[str, Any], import_source_name: str) -> List[str]:
    result_raw = safe_get(match, "Match_Result") or ""
    result_upper = str(result_raw).upper()
    winner_side, loser_side, outcome = get_result_sides(match)
    doubles = is_doubles_match(match)

    match_id = str(safe_get(match, "Match_ID"))
    ball_type = str(safe_get(match, "Match_BallType"))
    draw_bracket_value = ""
    draw_name = str(safe_get(match, "Match_DivisionName"))
    draw_team_type = str(safe_get(match, "Match_Type"))
    tournament_name = str(safe_get(match, "Match_LeagueName"))
    date_str = parse_iso_to_mmddyyyy(safe_get(match, "Match_Date"))

    # Score (Excel-safe: add ';' only here)
    score_raw = build_score(match)
    if score_raw and not score_raw.endswith(";"):
        score = score_raw + ";"
    else:
        score = score_raw

    # Winner 1
    w1_prefix = get_player_prefix(result_upper, "winner", 1)
    w1_first = str(safe_get(match, w1_prefix + "FirstName"))
    w1_last = str(safe_get(match, w1_prefix + "LastName"))
    w1_name = build_name(w1_last, w1_first)
    w1_gender = normalize_gender(safe_get(match, w1_prefix + "Gender"))
    w1_dob = parse_iso_to_mmddyyyy(safe_get(match, w1_prefix + "DateOfBirth"))
    w1_third_id, w1_id_type = choose_third_party_id(match, w1_prefix)
    w1_city = str(safe_get(match, w1_prefix + "Suburb"))
    w1_state = str(safe_get(match, w1_prefix + "AddressState"))
    w1_country = str(safe_get(match, w1_prefix + "Country"))

    # Winner 2
    if doubles:
        w2_prefix = get_player_prefix(result_upper, "winner", 2)
        w2_first = str(safe_get(match, w2_prefix + "FirstName")).strip()
        w2_last = str(safe_get(match, w2_prefix + "LastName")).strip()

        if not w2_first and not w2_last:
            w2_name = ""
            w2_gender = ""
            w2_dob = ""
            w2_third_id = ""
            w2_id_type = ""
            w2_city = ""
            w2_state = ""
            w2_country = ""
        else:
            w2_name = build_name(w2_last, w2_first)
            w2_gender = normalize_gender(safe_get(match, w2_prefix + "Gender"))
            w2_dob = parse_iso_to_mmddyyyy(safe_get(match, w2_prefix + "DateOfBirth"))
            w2_third_id, w2_id_type = choose_third_party_id(match, w2_prefix)
            w2_city = str(safe_get(match, w2_prefix + "Suburb"))
            w2_state = str(safe_get(match, w2_prefix + "AddressState"))
            w2_country = str(safe_get(match, w2_prefix + "Country"))
    else:
        # Singles: Winner 2 must be blank
        w2_name = ""
        w2_gender = ""
        w2_dob = ""
        w2_third_id = ""
        w2_id_type = ""
        w2_city = ""
        w2_state = ""
        w2_country = ""

    # Loser 1
    l1_prefix = get_player_prefix(result_upper, "loser", 1)
    l1_first = str(safe_get(match, l1_prefix + "FirstName"))
    l1_last = str(safe_get(match, l1_prefix + "LastName"))
    l1_name = build_name(l1_last, l1_first)
    l1_gender = normalize_gender(safe_get(match, l1_prefix + "Gender"))
    l1_dob = parse_iso_to_mmddyyyy(safe_get(match, l1_prefix + "DateOfBirth"))
    l1_third_id, l1_id_type = choose_third_party_id(match, l1_prefix)
    l1_city = str(safe_get(match, l1_prefix + "Suburb"))
    l1_state = str(safe_get(match, l1_prefix + "AddressState"))
    l1_country = str(safe_get(match, l1_prefix + "Country"))

    # Loser 2
    if doubles:
        l2_prefix = get_player_prefix(result_upper, "loser", 2)
        l2_first = str(safe_get(match, l2_prefix + "FirstName")).strip()
        l2_last = str(safe_get(match, l2_prefix + "LastName")).strip()

        if not l2_first and not l2_last:
            l2_name = ""
            l2_gender = ""
            l2_dob = ""
            l2_third_id = ""
            l2_id_type = ""
            l2_city = ""
            l2_state = ""
            l2_country = ""
        else:
            l2_name = build_name(l2_last, l2_first)
            l2_gender = normalize_gender(safe_get(match, l2_prefix + "Gender"))
            l2_dob = parse_iso_to_mmddyyyy(safe_get(match, l2_prefix + "DateOfBirth"))
            l2_third_id, l2_id_type = choose_third_party_id(match, l2_prefix)
            l2_city = str(safe_get(match, l2_prefix + "Suburb"))
            l2_state = str(safe_get(match, l2_prefix + "AddressState"))
            l2_country = str(safe_get(match, l2_prefix + "Country"))
    else:
        # Singles: Loser 2 must be blank
        l2_name = ""
        l2_gender = ""
        l2_dob = ""
        l2_third_id = ""
        l2_id_type = ""
        l2_city = ""
        l2_state = ""
        l2_country = ""

    # Draw / Tournament static fields
    draw_gender = ""
    draw_bracket_type = ""
    draw_type = ""
    tournament_city = ""
    tournament_state = ""
    tournament_country_code = "AUS"
    tournament_host = ""
    tournament_location_type = ""
    tournament_surface = ""
    tournament_event_category = ""
    tournament_event_grade = ""
    tournament_import_source = import_source_name
    tournament_sanction_body = "Tennis Australia"
    winner2_college = ""
    loser2_college = ""

    event_type_raw = str(safe_get(match, "Match_DataType"))
    tournament_event_type = event_type_raw.capitalize() if event_type_raw else ""

    winner1_college = ""
    loser1_college = ""

    tournament_url = build_tournament_url(match)
    tournament_country = "AUS"
    tournament_start_date = ""
    tournament_end_date = ""

    row = [
        match_id,
        ball_type,
        draw_bracket_value,
        draw_name,
        draw_team_type,
        tournament_name,
        date_str,
        score,  # already Excel-safe with trailing ';'
        # Winner 1
        w1_name,
        w1_gender,
        w1_dob,
        w1_third_id,
        w1_id_type,
        w1_city,
        w1_state,
        w1_country,
        # Winner 2
        w2_name,
        w2_gender,
        w2_dob,
        w2_third_id,
        w2_id_type,
        w2_city,
        w2_state,
        w2_country,
        # Loser 1
        l1_name,
        l1_gender,
        l1_dob,
        l1_third_id,
        l1_id_type,
        l1_city,
        l1_state,
        l1_country,
        # Loser 2
        l2_name,
        l2_gender,
        l2_dob,
        l2_third_id,
        l2_id_type,
        l2_city,
        l2_state,
        l2_country,
        # Outcome / Tournament
        outcome,
        draw_gender,
        draw_bracket_type,
        draw_type,
        tournament_city,
        tournament_state,
        tournament_country_code,
        tournament_host,
        tournament_location_type,
        tournament_surface,
        tournament_event_category,
        tournament_event_grade,
        tournament_import_source,
        tournament_sanction_body,
        winner2_college,
        loser2_college,
        tournament_event_type,
        winner1_college,
        loser1_college,
        tournament_url,
        tournament_country,
        tournament_start_date,
        tournament_end_date,
    ]

    # All other fields are left as-is (no Excel-safe transformation)
    return [v if isinstance(v, str) else str(v) for v in row]


# ---------- Main script ----------

def extract_matches(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    matches_obj = data.get("Matches") or data.get("matches") or {}
    if not isinstance(matches_obj, dict):
        return []

    matches = matches_obj.get("Match") or matches_obj.get("match") or []
    if isinstance(matches, dict):
        return [matches]
    if isinstance(matches, list):
        return matches
    return []


def json_to_csv(json_path: str, csv_path: Optional[str] = None) -> None:
    if csv_path is None:
        base, _ = os.path.splitext(json_path)
        csv_path = base + ".csv"

    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    matches = extract_matches(data)
    import_source_name = os.path.basename(json_path)

    headers = [
        "Match ID",
        "Ball Type",
        "Draw Bracket Value",
        "Draw Name",
        "Draw Team Type",
        "Tournament Name",
        "Date",
        "Score",
        "Winner 1 Name",
        "Winner 1 Gender",
        "Winner 1 DOB",
        "Winner 1 Third Party ID",
        "Winner 1 ID Type",
        "Winner 1 City",
        "Winner 1 State",
        "Winner 1 Country",
        "Winner 2 Name",
        "Winner 2 Gender",
        "Winner 2 DOB",
        "Winner 2 Third Party ID",
        "Winner 2 ID Type",
        "Winner 2 City",
        "Winner 2 State",
        "Winner 2 Country",
        "Loser 1 Name",
        "Loser 1 Gender",
        "Loser 1 DOB",
        "Loser 1 Third Party ID",
        "Loser 1 ID Type",
        "Loser 1 City",
        "Loser 1 State",
        "Loser 1 Country",
        "Loser 2 Name",
        "Loser 2 Gender",
        "Loser 2 DOB",
        "Loser 2 Third Party ID",
        "Loser 2 ID Type",
        "Loser 2 City",
        "Loser 2 State",
        "Loser 2 Country",
        "Outcome",
        "Draw Gender",
        "Draw Bracket Type",
        "Draw Type",
        "Tournament City",
        "Tournament State",
        "Tournament Country Code",
        "Tournament Host",
        "Tournament Location Type",
        "Tournament Surface",
        "Tournament Event Category",
        "Tournament Event Grade",
        "Tournament Import Source",
        "Tournament Sanction Body",
        "Winner 2 College",
        "Loser 2 College",
        "Tournament Event Type",
        "Winner 1 College",
        "Loser 1 College",
        "Tournament URL",
        "Tournament Country",
        "Tournament Start Date",
        "Tournament End Date",
    ]

    with open(csv_path, "w", encoding="utf-8", newline="") as f_out:
        writer = csv.writer(f_out)
        writer.writerow(headers)
        for match in matches:
            row = match_to_row(match, import_source_name)
            writer.writerow(row)

    print(f"Wrote {len(matches)} rows to {csv_path}")


if __name__ == "__main__":
    # Example usage: adjust path to your JSON file
    json_to_csv(r"D:\_work_khemiri\Salman_Bader\spiders_app\scripts\australia_tennis\mohamed\20251205_073909385.json")
