# pip install azure-storage-blob

import json, os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

from azure.storage.blob import ContainerClient

# ================= CONFIG =================
CONTAINER_SAS_URL = (
    "https://utprod.blob.core.windows.net/result-submissions"
    "?sp=rl&st=2025-12-10T00:16:08Z&se=2028-06-26T08:31:08Z"
    "&sv=2024-11-04&sr=c"
    "&sig=9W0cSlen6CFiJLhJ6HOKoOKsnP5Mx4izhMwWPSNX38g%3D"
)

FOLDER_PREFIX = "tennis_australia/"   # Azure "folder"
DOWNLOAD_DIR = Path("downloaded_jsons")
STATE_FILE = Path("downloaded_blobs.json")

MAX_WORKERS = 5  # concurrent threads
# =========================================

DOWNLOAD_DIR.mkdir(exist_ok=True)

def load_downloaded_state() -> set:
    if STATE_FILE.exists():
        try:
            return set(json.loads(STATE_FILE.read_text()))
        except Exception:
            return set()
    return set()


def save_downloaded_state(downloaded: set) -> None:
    STATE_FILE.write_text(json.dumps(sorted(downloaded), indent=2))


def _download_one_blob(container: ContainerClient, blob_name, blob_path) -> str:
    """Download one blob and save as local JSON file. Returns blob_name."""
    blob_client = container.get_blob_client(blob_name)
    data = json.loads(blob_client.download_blob().readall())

    with open(blob_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    print(f"✅ downloaded: {blob_path.name}")

    return blob_name


def download_new_json_blobs(n=3):
    """
    Download new JSON blobs under FOLDER_PREFIX using up to MAX_WORKERS threads.

    n = int    -> download first N new files
    n = 'all'  -> download all new files
    """
    container = ContainerClient.from_container_url(CONTAINER_SAS_URL)

    already_downloaded = load_downloaded_state()
    newly_downloaded = set()

    # 1) Discover and schedule new blobs inside threading section
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {}
        submitted = 0

        # Discover blobs and submit download tasks on the fly
        for blob in container.list_blobs(name_starts_with=FOLDER_PREFIX):

            blob_name = blob.name
            blob_path = DOWNLOAD_DIR / Path(blob_name).name
            if os.path.isfile(blob_path):
                print(f"❌ exist: {blob_path.name}")
                continue

            # skip non-json
            if not blob_name.lower().endswith(".json"):
                continue

            # skip already downloaded
            if blob_name in already_downloaded:
                continue

            # respect limit n (unless "all")
            if n != "all" and submitted >= int(n):
                break

            future = executor.submit(_download_one_blob, container, blob_name, blob_path)
            futures[future] = blob_name
            submitted += 1

        # Collect results as they complete
        for future in as_completed(futures):
            blob_name = futures[future]
            try:
                result_name = future.result()
                newly_downloaded.add(result_name)
            except Exception as e:
                print(f"❌ error downloading {blob_name}: {e}")

    already_downloaded.update(newly_downloaded)
    save_downloaded_state(already_downloaded)

    print(f"\n✅ New files successfully downloaded this run: {len(newly_downloaded)}")
    return list(newly_downloaded)


# ================= USAGE =================
if __name__ == "__main__":
    # PROD: when ready, download all new files
    newly_downloaded = download_new_json_blobs(n="all")
