import json, traceback, time
import concurrent.futures
from pathlib import Path
from datetime import timedelta
from zoneinfo import ZoneInfo
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn
from django.db import close_old_connections
from django.utils import timezone
from azure.storage.blob import ContainerClient
from assets.fct.fctlog import logger
from assets.fct import fctcore
from app_spiders.models import jobsAustraliaTennisFilesNamesModel, jobsAustraliaTennisFilesDataModel

start_dt = time.time()

class BlobParser:
    def __init__(self, max_workers, progress):
        self.max_workers = max_workers
        self.progress = progress

        # ================= CONFIG =================
        self.CONTAINER_SAS_URL = (
            "https://utprod.blob.core.windows.net/result-submissions"
            "?sp=rl&st=2025-12-10T00:16:08Z&se=2028-06-26T08:31:08Z"
            "&sv=2024-11-04&sr=c"
            "&sig=9W0cSlen6CFiJLhJ6HOKoOKsnP5Mx4izhMwWPSNX38g%3D"
        )

        self.FOLDER_PREFIX = "tennis_australia/"  # Azure "folder"
        self.FILENAME_DATE_TZ = "Australia/Sydney"  # used only to compute "yesterday"
        # =========================================

    def _yesterday_prefix(self, day):
        """
        Filenames look like: 20190926_055512588.json
        and are stored under: tennis_australia/20190926_055512588.json

        So yesterday's prefix is: tennis_australia/YYYYMMDD_
        """
        tz = ZoneInfo(self.FILENAME_DATE_TZ)
        now_in_tz = timezone.now().astimezone(tz)
        yday = now_in_tz.date() - timedelta(days=day)
        return f"{self.FOLDER_PREFIX}{yday.strftime('%Y%m%d')}_"

    def parse_site(self):
        for day in [1, 2]:
            try:
                container = ContainerClient.from_container_url(self.CONTAINER_SAS_URL)

                # ✅ ONLY yesterday by filename-date prefix (no full folder scan)
                prefix = self._yesterday_prefix(day)
                logger.info(f"Listing ONLY yesterday files by prefix: {prefix}")

                with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                    for blob in container.list_blobs(name_starts_with=prefix):
                        blob_name = blob.name
                        file_name = Path(blob_name).name
                        file_date = fctcore.convert_string_to_date_format(file_name.split('_')[0], in_format='%Y%m%d', out_format='%Y-%m-%d')

                        # (optional) ensure json only
                        if not file_name.lower().endswith(".json"):
                            continue

                        if not jobsAustraliaTennisFilesNamesModel.objects.filter(file_name=file_name).exists():
                            logger.info(f"new: file_name: {file_name} | file_date: {file_date}")
                            executor.submit(self.download_one_blob, container, blob_name, file_name, file_date)

                        else:
                            logger.warning(f"exist: file_name: {file_name} | file_date: {file_date}")

            except Exception:
                logger.error(traceback.format_exc())


    def download_one_blob(self, container: ContainerClient, blob_name, file_name, file_date):
        try:
            close_old_connections()

            blob_client = container.get_blob_client(blob_name)
            file_data = json.loads(blob_client.download_blob().readall())
            matches = self.extract_matches(file_data)

            jobsAustraliaTennisFilesNamesModel(
                file_name=file_name,
                file_date=file_date,
                date_scraped=timezone.now(),
                total_scores=len(matches)
            ).save()

            jobsAustraliaTennisFilesDataModel(
                file_name=file_name,
                file_date=file_date,
                file_data=file_data,
            ).save()

        except Exception:
            logger.error(traceback.format_exc())


    def extract_matches(self, data):
        try:
            matches_obj = data.get("Matches") or data.get("matches") or {}
            if not isinstance(matches_obj, dict):
                return []

            matches = matches_obj.get("Match") or matches_obj.get("match") or []
            if isinstance(matches, dict):
                return [matches]
            if isinstance(matches, list):
                return matches
        except Exception:
            logger.error(traceback.format_exc())
        return []


def run():
    max_workers = 5
    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(), TextColumn("{task.completed}/{task.total}"), TimeElapsedColumn(), TimeRemainingColumn(), transient=False) as progress:
        BlobParser(max_workers, progress).parse_site()
    logger.info(f'script take {round(time.time()-start_dt, 2)} sec to finished')
