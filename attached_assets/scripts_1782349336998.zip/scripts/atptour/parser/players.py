import traceback, re
import concurrent.futures
from datetime import datetime, timedelta
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctbrowser import Browser
from scripts.log_items import ItemsLogger
from scrapy.selector import Selector
from urllib.parse import urljoin

class PlayersParser:

    def __init__(self, progress=None):
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctbrowser = Browser(
            library='D',
            use_proxy=True,
            proxies=self.proxies,
            cloudflare=True,
            cloudflare_title='just a moment',
        )

        self.headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,fr;q=0.8',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
        }
        self.df_players = ItemsLogger()
        self.seen_rows = getattr(self, "seen_rows", set())

    def parse_site(self, max_workers, job_id, single_date, rank_type):
        try:
            if self.is_current_week(single_date):
                job_date = 'Current+Week'
            else:
                job_date = single_date

            ranges = [(0, 100), (101, 200), (201, 300), (301, 400), (401, 500), (501, 600), (601, 700), (701, 800), (801, 900), (901, 1000), (1001, 1100), (1101, 1200), (1201, 1300), (1301, 1400), (1401, 1500), (1501, 5000)]
            for r in ranges:
                rankRange = f"{r[0]}-{r[1]}"

                index_link = f'https://www.atptour.com/en/rankings/{rank_type.lower()}?dateWeek={job_date}&rankRange={rankRange}'
                logger.info(f'index_link: {index_link}')

                selectors = []
                max_retries = 5
                for attempt in range(1, max_retries + 1):
                    self.fctbrowser.open()
                    str1 = self.fctbrowser.request(method='GET', link=index_link, timeout=5)
                    self.fctbrowser.close()
                    html1 = Selector(text=str1)
                    title = fctcore.parse_field('//title', html1)

                    if 'just a moment' not in title.lower():
                        selectors = html1.xpath('//table[contains(@class, "mega-table") and contains(@class, "desktop-table")]//tr[@class="lower-row"]')
                        if selectors:
                            break
                        logger.warning(f'No selectors found, attempt {attempt}/{max_retries}')
                    else:
                        logger.warning(f'Bad response on attempt {attempt}/{max_retries}')

                if selectors:
                    selectors_chunks = list(fctcore.split_list_into_chunks(lst=selectors, max_workers=max_workers))
                    if max_workers > len(selectors_chunks): max_workers = len(selectors_chunks)

                    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                        main_task = self.progress.add_task(description='atptour_players', total=len(selectors))
                        for thread_id, selectors_chunk in enumerate(selectors_chunks):
                            thread_task = self.progress.add_task(f"Thread {thread_id + 1}", total=len(selectors_chunk))
                            executor.submit(self.parse_page, selectors_chunk, job_id, single_date, rank_type, main_task, thread_task)
                else:
                    logger.error(f'No selectors found after {max_retries} attempts for {index_link}')

        except Exception:
            logger.error(traceback.format_exc())

        return self.df_players.get_df()


    def parse_page(self, selectors_chunk, job_id, single_date, rank_type, main_task, thread_task):
        try:
            for d1 in selectors_chunk:
                self.progress.update(main_task, advance=1)
                self.progress.update(thread_task, advance=1)
                close_old_connections()

                player_link = urljoin('https://www.atptour.com/', fctcore.parse_field('.//td[contains(@class, "player")]//ul[@class="player-stats"]//li[contains(@class, "name")]//a[contains(@href, "/players/")]/@href', d1))
                player_id = ''
                try:
                    match = re.search(r"/players/[^/]+/([^/]+)/", player_link)
                    if match:
                        player_id = match.group(1)
                except Exception:
                    logger.error(traceback.format_exc())

                rank = fctcore.parse_field('.//td[contains(@class, "rank")]', d1)
                rank = fctcore.preg_repace(patt="[^\d+]", repl="", subj=rank)
                points = fctcore.parse_field('.//td[contains(@class, "points")]', d1)

                if player_id:
                    row_key = f"{player_id}"
                    if row_key not in self.seen_rows:
                        # logger.info(f'player_id: {player_id}')
                        self.df_players.log({
                            "player_id": player_id,
                            "player_link": player_link,
                            "rank_type": rank_type,
                            "range_date": single_date,
                            "points": points,
                            "rank": rank,
                        })
                        self.seen_rows.add(row_key)

        except Exception:
            logger.error(traceback.format_exc())

    def is_current_week(self, date_str):
        """Check if a date string (YYYY-MM-DD) falls in the current week (Mon–Sun)."""
        date = datetime.strptime(date_str, "%Y-%m-%d").date()
        today = datetime.today().date()

        # Get start (Monday) and end (Sunday) of the current week
        start_of_week = today - timedelta(days=today.weekday())  # Monday
        end_of_week = start_of_week + timedelta(days=6)  # Sunday

        return start_of_week <= date <= end_of_week