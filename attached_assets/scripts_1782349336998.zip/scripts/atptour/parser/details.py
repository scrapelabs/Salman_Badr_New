import traceback
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from app_spiders.models import ItemsAtptourModel

class DetailsParser:

    def __init__(self):
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=True, use_proxy=self.use_proxy)

        self.headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,fr;q=0.8',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
        }
        self.seen_rows = getattr(self, "seen_rows", set())

    def parse_site(self, spider_id, job_id, players_chunk, main_task, thread_task, progress):
        try:
            for players_data in players_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    player_id = players_data.get("player_id", "")
                    if player_id:
                        player_link = f'https://www.atptour.com/en/-/www/players/hero/{player_id}'
                        rank_type = players_data.get("rank_type", "")
                        range_date = players_data.get("range_date", "")
                        points = players_data.get("points", "")
                        rank = players_data.get("rank", "")

                        row_key = f"{player_id}"
                        if row_key not in self.seen_rows:
                            logger.info(f'player_id: {player_id} | {player_link}')

                            results1 = None
                            max_retries = 5
                            for attempt in range(1, max_retries + 1):
                                response1 = self.fctrequest.request(method='GET', link=player_link, headers=self.headers, proxies=self.proxies, tries=1, timeout=120)
                                if response1 and response1.status_code in range(200, 300):
                                    results1 = response1.json()
                                    if results1:
                                        break
                                    logger.warning(f'Empty JSON for player_id={player_id}, attempt {attempt}/{max_retries}')
                                else:
                                    logger.warning(f'Bad response for player_id={player_id}, attempt {attempt}/{max_retries}')

                            if results1:
                                self.parse_page(spider_id, job_id, player_id, rank_type, range_date, points, rank, results1)
                            else:
                                logger.error(f'No result after {max_retries} attempts for player_id={player_id}')

                            self.seen_rows.add(row_key)

                except Exception:
                    logger.error(traceback.format_exc())
        except Exception:
            logger.error(traceback.format_exc())


    def parse_page(self, spider_id, job_id, player_id, rank_type, range_date, points, rank, results1):
        try:
            birthdate = ''
            gender = 'M'
            name = ''
            nationality = ''

            try:
                name = f"{results1.get('LastName', '')}, {results1.get('FirstName', '')}"
            except Exception:
                ''
            try:
                nationality = results1.get('NatlId', '')
            except Exception:
                ''
            try:
                birthdate = fctcore.convert_string_to_date_format(date_str=results1.get('BirthDate', ''), in_format='%Y-%m-%dT%H:%M:%S', out_format='%m/%d/%Y')
            except Exception:
                ''

            logger.info(f'player_id: {player_id}')
            logger.info(f'birthdate: {birthdate}')
            logger.info(f'gender: {gender}')
            logger.info(f'name: {name}')
            logger.info(f'nationality: {nationality}')
            logger.info(f'points: {points}')
            logger.info(f'rank: {rank}')
            logger.info(f'range_date: {range_date}')
            logger.info(f'rank_type: {rank_type}')
            logger.info('*' * 50)

            ItemsAtptourModel(
                spider_id=spider_id,
                job_id=job_id,
                birthdate=birthdate,
                gender=gender,
                player_id=player_id,
                name=name,
                nationality=nationality,
                points=points,
                rank=rank,
                rankdate=range_date,
                ranktype=rank_type,
            ).save()

        except Exception:
            logger.error(traceback.format_exc())
