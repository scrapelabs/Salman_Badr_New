from scripts.atptour.fctlog import logger
import time, traceback, random, requests, hashlib, uuid
import pandas as pd
from io import BytesIO
from PIL import Image
from curl_cffi import requests as cffi_requests
from datetime import datetime
from threading import Lock
from collections import deque
import warnings
warnings.filterwarnings('ignore')

# =========================
# SHARED BUFFERS
# =========================
_req_lock   = Lock()
_req_buffer = deque()

# =========================
# COLUMNS
# =========================
_REQ_COLS = [
    "request_id",
    "duration",
    "fingerprint",
    "http_method",
    "response_size",
    "http_status",
    "last_seen",
    "url",
]

# =========================
# BROWSER PROFILES (anti-bot)
# Each profile keeps the TLS/JA3 fingerprint (impersonate) CONSISTENT with the
# User-Agent string and the Client Hints headers. Mixing a Chrome JA3 with an
# Edge User-Agent (the old bug) is an instant tell for Cloudflare / anti-bot WAFs.
# =========================
_BROWSER_PROFILES = [
    {
        "impersonate": "chrome131",
        "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "sec_ch_ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
        "platform": '"Windows"',
        "accept_language": "en-US,en;q=0.9",
    },
    {
        "impersonate": "chrome124",
        "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "sec_ch_ua": '"Google Chrome";v="124", "Chromium";v="124", "Not-A.Brand";v="99"',
        "platform": '"Windows"',
        "accept_language": "en-US,en;q=0.9",
    },
    {
        "impersonate": "chrome120",
        "ua": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "sec_ch_ua": '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
        "platform": '"macOS"',
        "accept_language": "en-US,en;q=0.9",
    },
    {
        "impersonate": "edge101",
        "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36 Edg/101.0.1210.53",
        "sec_ch_ua": '"Microsoft Edge";v="101", "Chromium";v="101", "Not;A=Brand";v="99"',
        "platform": '"Windows"',
        "accept_language": "en-US,en;q=0.9",
    },
    {
        "impersonate": "safari17_0",
        "ua": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
        "sec_ch_ua": None,  # Safari does not send Client Hints
        "platform": '"macOS"',
        "accept_language": "en-US,en;q=0.9",
    },
]

# Anti-bot challenge markers found in block / interstitial pages.
_CHALLENGE_MARKERS = (
    "just a moment",
    "attention required",
    "cf-chl",
    "cf_chl",
    "challenge-platform",
    "enable javascript and cookies",
    "access denied",
    "请稍候",
    "verifying you are human",
    "ddos protection by",
    "captcha-delivery",
    "px-captcha",
    "/_incapsula_",
    "请开启 javascript",
)
_BLOCK_STATUS = {401, 403, 406, 409, 429, 503}


# =========================
# REQUEST LOGGER
# =========================
class RequestLogger:
    """
    Log any HTTP request/response with timing and metadata.

    Usage:
        rl = RequestLogger()
        with rl.start() as timer:
            response = requests.get(url)
        rl.log(response, url, timer.elapsed_ms, fingerprint="optional")
    """

    def log(self, response, url: str, duration_ms: float, fingerprint: str = ""):
        entry = (
            str(uuid.uuid4()),
            f"{duration_ms:.0f} ms",
            fingerprint,
            response.request.method if response.request else "",
            f"{len(response.content)} bytes",
            response.status_code,
            datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
            url,
        )
        with _req_lock:
            _req_buffer.append(entry)

    def log_failed(self, url: str, duration_ms: float, error: str, fingerprint: str = ""):
        """Log a request that raised an exception (no response object)."""
        entry = (
            str(uuid.uuid4()),
            f"{duration_ms:.0f} ms",
            fingerprint,
            "",
            "0 bytes",
            0,
            datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
            url,
        )
        with _req_lock:
            _req_buffer.append(entry)


# =========================
# HELPERS
# =========================
def get_requests_df() -> pd.DataFrame:
    """All requests from in-memory buffer."""
    with _req_lock:
        return pd.DataFrame(list(_req_buffer), columns=_REQ_COLS)


# Singleton
request_logger = RequestLogger()


class Request:
    def __init__(self, use_session=False, use_cffi=False, use_proxy=False,
                 profile=None, rotate_profile_on_block=True, human_delay=(0.8, 2.6),
                 proxy_mode='random'):
        self.truncate_nbre = 40
        self.use_proxy = use_proxy
        self.use_session = use_session
        self.use_cffi = use_cffi
        # rotate_profile_on_block: pick a fresh browser identity after a block
        self.rotate_profile_on_block = rotate_profile_on_block
        # human_delay: (min, max) seconds of jitter applied between retries / page hops
        self.human_delay = human_delay
        # ---- per-request proxy rotation state ----
        # proxy_mode: 'random'  -> pick a random proxy each request (never repeat
        #                          the same one twice in a row when possible)
        #             'roundrobin' -> cycle through the list in order
        self.proxy_mode = proxy_mode
        self._proxy_lock = Lock()
        self._proxy_index = 0          # round-robin cursor
        self._last_proxy_raw = None    # last raw proxy string used
        self._force_new_proxy = False  # set after a block to skip the bad IP
        # A session should keep ONE consistent browser identity for its lifetime,
        # exactly like a real browser. We lock a profile per Request instance.
        self.profile = profile or random.choice(_BROWSER_PROFILES)

        if self.use_cffi:
            if self.use_session:
                self.session = cffi_requests.Session()
            else:
                self.session = cffi_requests
        else:
            if self.use_session:
                self.session = requests.session()
            else:
                self.session = requests

    # ---------------------------------------------------------------
    # Fingerprint / header construction
    # ---------------------------------------------------------------
    def _new_identity(self):
        """Rotate to a brand-new browser identity (used after a block)."""
        self.profile = random.choice(_BROWSER_PROFILES)
        # Also burn the current proxy so the next request leaves from a fresh IP.
        self._force_new_proxy = True
        if self.use_cffi and self.use_session:
            # A fresh session drops the old TLS session tickets / cookies that
            # may already be flagged.
            try:
                self.session = cffi_requests.Session()
            except Exception:
                logger.error(traceback.format_exc())
        logger.info(f"Rotated browser identity -> {self.profile['impersonate']} (+ new proxy)")

    def build_headers(self, extra=None, referer=None, is_navigation=True, host=None):
        """
        Build a realistic, ORDER-correct header set that matches the locked
        browser profile. Real browsers send headers in a stable order and a
        coherent set of Client Hints; anti-bot systems fingerprint both.
        """
        p = self.profile
        headers = {}

        # Client Hints first (Chromium-based browsers only)
        if p.get("sec_ch_ua"):
            headers["sec-ch-ua"] = p["sec_ch_ua"]
            headers["sec-ch-ua-mobile"] = "?0"
            headers["sec-ch-ua-platform"] = p["platform"]

        if is_navigation:
            headers["upgrade-insecure-requests"] = "1"

        headers["user-agent"] = p["ua"]

        if is_navigation:
            headers["accept"] = (
                "text/html,application/xhtml+xml,application/xml;q=0.9,"
                "image/avif,image/webp,image/apng,*/*;q=0.8,"
                "application/signed-exchange;v=b3;q=0.7"
            )
        else:
            headers["accept"] = "*/*"

        # Sec-Fetch metadata (Chromium only). Distinguishes a top-level
        # navigation from an XHR/asset fetch — getting this wrong is a tell.
        if p.get("sec_ch_ua"):
            if is_navigation:
                headers["sec-fetch-site"] = "same-origin" if referer else "none"
                headers["sec-fetch-mode"] = "navigate"
                headers["sec-fetch-user"] = "?1"
                headers["sec-fetch-dest"] = "document"
            else:
                headers["sec-fetch-site"] = "same-origin"
                headers["sec-fetch-mode"] = "cors"
                headers["sec-fetch-dest"] = "empty"

        if referer:
            headers["referer"] = referer

        headers["accept-encoding"] = "gzip, deflate, br, zstd"
        headers["accept-language"] = p.get("accept_language", "en-US,en;q=0.9")

        # Caller overrides win, but we never let them break UA<->JA3 coherence:
        # the user-agent is always forced back to the profile's UA.
        if extra:
            for k, v in extra.items():
                if k.lower() == "user-agent":
                    continue
                headers[k] = v

        return headers

    @staticmethod
    def _looks_blocked(response):
        """Detect anti-bot interstitials even when status is 200."""
        if response is None:
            return True
        if response.status_code in _BLOCK_STATUS:
            return True
        try:
            server = (response.headers.get("server", "") or "").lower()
            # Cloudflare/anti-bot pages are tiny; a real ranking table is large.
            small_body = len(response.content) < 1500
            text = response.text[:4000].lower()
            if any(m in text for m in _CHALLENGE_MARKERS):
                return True
            if small_body and ("cloudflare" in server or "challenge" in text):
                return True
        except Exception:
            return False
        return False

    def _human_pause(self, factor=1.0):
        lo, hi = self.human_delay
        delay = random.uniform(lo, hi) * factor
        time.sleep(delay)
        return delay

    def generate_requests_log(self, link, response, start_dt, type, error=None):
        fingerprint_str = f"{link}{response.status_code if response else 'timeout'}{len(response.content) if response else 0}"
        fingerprint = hashlib.sha1(fingerprint_str.encode()).hexdigest()
        duration_ms = (time.time() - start_dt) * 1000
        if type == 'success':
            request_logger.log(response, link, duration_ms, fingerprint=fingerprint)
        else:
            request_logger.log_failed(link, duration_ms, str(error), fingerprint="fingerprint")

    def _select_proxy_raw(self, proxies):
        """
        Pick the raw proxy string for THIS request.

        - 'random'     : random pick, avoiding the same proxy twice in a row.
        - 'roundrobin' : cycle through the list in order.
        After a block, `_force_new_proxy` guarantees we move off the bad IP.
        """
        with self._proxy_lock:
            if not proxies:
                return None
            if len(proxies) == 1:
                chosen = proxies[0]
            elif self.proxy_mode == 'roundrobin':
                chosen = proxies[self._proxy_index % len(proxies)]
                self._proxy_index += 1
                # If the cursor landed on the burned proxy, advance once more.
                if self._force_new_proxy and chosen == self._last_proxy_raw:
                    chosen = proxies[self._proxy_index % len(proxies)]
                    self._proxy_index += 1
            else:  # random, never repeat the previous proxy back-to-back
                candidates = [p for p in proxies if p != self._last_proxy_raw] or proxies
                chosen = random.choice(candidates)

            self._last_proxy_raw = chosen
            self._force_new_proxy = False
            return chosen

    def generate_proxy(self, proxies=None):
        dict_proxy = {}
        if proxies and self.use_proxy:
            try:
                raw = self._select_proxy_raw(proxies)
                if raw is None:
                    return dict_proxy
                if self.use_cffi:
                    raw = raw.replace('http://', '').strip()
                    dict_proxy = {"http": raw, "https": raw}
                else:
                    raw = f'http://{raw.strip()}'
                    dict_proxy = {"http": raw, "https": raw}
                # Log which egress IP this request will use (masking credentials).
                logger.info(f"Proxy [{self.proxy_mode}] -> {self._mask_proxy(raw)}")
            except Exception:
                logger.error(traceback.format_exc())
        return dict_proxy

    @staticmethod
    def _mask_proxy(raw):
        """Hide credentials when logging a proxy string."""
        try:
            tail = raw.split('@')[-1]
            return f"***@{tail}"
        except Exception:
            return "***"

    # ---------------------------------------------------------------
    # Session warming
    # ---------------------------------------------------------------
    def warm_up(self, home_url, proxies=None, timeout=30):
        """
        Visit the site's homepage first to obtain cookies (incl. Cloudflare
        clearance) before hitting deep pages — exactly what a human browser
        does. Requires use_session=True to retain the cookie jar.
        """
        if not self.use_session:
            logger.warning("warm_up() is most effective with use_session=True")
        headers = self.build_headers(is_navigation=True)
        logger.info(f"Warming up session via {home_url}")
        resp = self.get_simple(home_url, headers=headers, proxies=proxies,
                               timeout=timeout, sleep=0, is_navigation=True)
        # Brief human-like dwell on the landing page before navigating onward.
        self._human_pause()
        return resp

    # ---------------------------------------------------------------
    # Public dispatch
    # ---------------------------------------------------------------
    def request(self, method='', link='', params=None, data=None, json=None, headers=None, cookies={}, proxies=[], verify=False, allow_redirects=True, timeout=30, sleep=0, tries=3, path_file='', is_image=False, referer=None, is_navigation=True):
        response = None
        if method == 'GET':
            response = self.get(link, params=params, headers=headers, cookies=cookies, proxies=proxies, verify=verify, allow_redirects=allow_redirects, timeout=timeout, sleep=sleep, tries=tries, referer=referer, is_navigation=is_navigation)

        elif method == 'POST':
            response = self.post(link, params=params, data=data, json=json, headers=headers, cookies=cookies, proxies=proxies, verify=verify, allow_redirects=allow_redirects, timeout=timeout, sleep=sleep, tries=tries, referer=referer)

        elif method == 'PUT':
            response = self.put(link, params=params, data=data, json=json, headers=headers, cookies=cookies, proxies=proxies, verify=verify, allow_redirects=allow_redirects, timeout=timeout, sleep=sleep, tries=tries, referer=referer)

        elif method == 'DGET':
            response = self.download(method=method, link=link, params=params, data=data, json=json, headers=headers, cookies=cookies, proxies=proxies, verify=verify, allow_redirects=allow_redirects, timeout=timeout, sleep=sleep, tries=tries, path_file=path_file, is_image=is_image, referer=referer)

        elif method == 'DPOST':
            response = self.download(method=method, link=link, params=params, data=data, json=json, headers=headers, cookies=cookies, proxies=proxies, verify=verify, allow_redirects=allow_redirects, timeout=timeout, sleep=sleep, tries=tries, path_file=path_file, is_image=is_image, referer=referer)

        else:
            logger.warning(f'Method {method} Not Supported in request function')

        return response

    def get(self, link, params=None, headers=None, cookies={}, proxies=[], verify=False, allow_redirects=True, timeout=30, sleep=0, tries=3, referer=None, is_navigation=True):
        response = None
        try:
            i = 0
            blocked = True
            while blocked and i < tries:
                i += 1
                try:
                    response = self.get_simple(link, params=params, headers=headers, cookies=cookies, proxies=proxies, verify=verify, allow_redirects=allow_redirects, timeout=timeout, sleep=sleep, referer=referer, is_navigation=is_navigation)
                    blocked = self._looks_blocked(response)
                except Exception:
                    logger.error(traceback.format_exc())

                status_code = response.status_code if response is not None else 0
                logger.info(f'Request Get: {i}/{tries} | status_code: {status_code} | blocked: {blocked} | {link}')

                if blocked and i < tries:
                    if self.rotate_profile_on_block:
                        self._new_identity()
                    # Exponential backoff with jitter so retries don't look robotic.
                    backoff = self._human_pause(factor=2 ** (i - 1))
                    logger.info(f'Backing off {backoff:.1f}s before retry')

        except Exception:
            logger.error(traceback.format_exc())

        return response

    def get_simple(self, link, params=None, headers=None, cookies={}, proxies=[], verify=False, allow_redirects=True, timeout=30, sleep=0, referer=None, is_navigation=True):
        response = None
        start_dt = time.time()
        try:
            proxies = self.generate_proxy(proxies)
            req_headers = self.build_headers(extra=headers, referer=referer, is_navigation=is_navigation)
            if self.use_cffi:
                try:
                    response = self.session.request(method='GET', url=link, params=params, impersonate=self.profile["impersonate"], proxies=proxies, verify=verify, headers=req_headers, cookies=cookies, allow_redirects=allow_redirects, timeout=timeout)
                except Exception as req_error:
                    logger.error(f"Request failed for {link}: {req_error}\n{traceback.format_exc()}")
                    self.generate_requests_log(link, None, start_dt, 'failed', req_error)
                    return None
            else:
                try:
                    response = self.session.request(method='GET', url=link, params=params, proxies=proxies, verify=verify, headers=req_headers, cookies=cookies, allow_redirects=allow_redirects, timeout=timeout)
                except Exception as req_error:
                    logger.error(f"Request failed for {link}: {req_error}\n{traceback.format_exc()}")
                    self.generate_requests_log(link, None, start_dt, 'failed', req_error)
                    return None

            self.log_request(method='GET', link=link, params=params, sleep=sleep)

            if response is not None and response.status_code in range(200, 300):
                self.generate_requests_log(link, response, start_dt, 'success')
            else:
                status = response.status_code if response is not None else "no response"
                logger.warning(f"Non-2xx status {status} for {link}")
                self.generate_requests_log(link, response, start_dt, 'failed', f"HTTP {status}")

        except Exception as error:
            logger.error(f"Unexpected error for {link}: {error}\n{traceback.format_exc()}")
            self.generate_requests_log(link, response, start_dt, 'failed', error)

        return response

    def post(self, link, params=None, data=None, json=None, headers=None, cookies={}, proxies=[], verify=False, allow_redirects=True, timeout=30, sleep=0, tries=3, referer=None):
        response = None
        try:
            i = 0
            blocked = True
            while blocked and i < tries:
                i += 1
                try:
                    response = self.post_simple(link, params=params, data=data, json=json, headers=headers, cookies=cookies, proxies=proxies, verify=verify, allow_redirects=allow_redirects, timeout=timeout, sleep=sleep, referer=referer)
                    blocked = self._looks_blocked(response)
                except Exception:
                    logger.error(traceback.format_exc())

                status_code = response.status_code if response is not None else 0
                logger.info(f'Request Post: {i}/{tries} | status_code: {status_code} | blocked: {blocked} | {link}')

                if blocked and i < tries:
                    if self.rotate_profile_on_block:
                        self._new_identity()
                    self._human_pause(factor=2 ** (i - 1))

        except Exception:
            logger.error(traceback.format_exc())

        return response

    def post_simple(self, link, params=None, data=None, json=None, headers=None, cookies={}, proxies=[], verify=False, allow_redirects=True, timeout=30, sleep=0, referer=None):
        response = None
        start_dt = time.time()
        try:
            proxies = self.generate_proxy(proxies)
            req_headers = self.build_headers(extra=headers, referer=referer, is_navigation=False)
            if self.use_cffi:
                try:
                    response = self.session.request(method='POST', url=link, params=params, data=data, json=json, impersonate=self.profile["impersonate"], proxies=proxies, verify=verify, headers=req_headers, cookies=cookies, allow_redirects=allow_redirects, timeout=timeout)
                except Exception as req_error:
                    logger.error(f"Request failed for {link}: {req_error}\n{traceback.format_exc()}")
                    self.generate_requests_log(link, None, start_dt, 'failed', req_error)
                    return None
            else:
                try:
                    response = self.session.request(method='POST', url=link, params=params, data=data, json=json, proxies=proxies, verify=verify, headers=req_headers, cookies=cookies, allow_redirects=allow_redirects, timeout=timeout)
                except Exception as req_error:
                    logger.error(f"Request failed for {link}: {req_error}\n{traceback.format_exc()}")
                    self.generate_requests_log(link, None, start_dt, 'failed', req_error)
                    return None

            self.log_request(method='POST', link=link, params=params, data=data, json=json, sleep=sleep)

            if response is not None and response.status_code in range(200, 300):
                self.generate_requests_log(link, response, start_dt, 'success')
            else:
                status = response.status_code if response is not None else "no response"
                logger.warning(f"Non-2xx status {status} for {link}")
                self.generate_requests_log(link, response, start_dt, 'failed', f"HTTP {status}")

        except Exception as error:
            logger.error(f"Unexpected error for {link}: {error}\n{traceback.format_exc()}")
            self.generate_requests_log(link, response, start_dt, 'failed', error)

        return response

    def put(self, link, params=None, data=None, json=None, headers=None, cookies={}, proxies=[], verify=False, allow_redirects=True, timeout=30, sleep=0, tries=3, referer=None):
        response = None
        try:
            i = 0
            blocked = True
            while blocked and i < tries:
                i += 1
                try:
                    response = self.put_simple(link, params=params, data=data, json=json, headers=headers, cookies=cookies, proxies=proxies, verify=verify, allow_redirects=allow_redirects, timeout=timeout, sleep=sleep, referer=referer)
                    blocked = self._looks_blocked(response)
                except Exception:
                    logger.error(traceback.format_exc())

                status_code = response.status_code if response is not None else 0
                logger.info(f'Request Put: {i}/{tries} | status_code: {status_code} | blocked: {blocked} | {link}')

                if blocked and i < tries:
                    if self.rotate_profile_on_block:
                        self._new_identity()
                    self._human_pause(factor=2 ** (i - 1))

        except Exception:
            logger.error(traceback.format_exc())

        return response

    def put_simple(self, link, params=None, data=None, json=None, headers=None, cookies={}, proxies=[], verify=False, allow_redirects=True, timeout=30, sleep=0, referer=None):
        response = None
        start_dt = time.time()
        try:
            proxies = self.generate_proxy(proxies)
            req_headers = self.build_headers(extra=headers, referer=referer, is_navigation=False)
            if self.use_cffi:
                try:
                    response = self.session.request(method='PUT', url=link, params=params, data=data, json=json, impersonate=self.profile["impersonate"], proxies=proxies, verify=verify, headers=req_headers, cookies=cookies, allow_redirects=allow_redirects, timeout=timeout)
                except Exception as req_error:
                    logger.error(f"Request failed for {link}: {req_error}\n{traceback.format_exc()}")
                    self.generate_requests_log(link, None, start_dt, 'failed', req_error)
                    return None
            else:
                try:
                    response = self.session.request(method='PUT', url=link, params=params, data=data, json=json, proxies=proxies, verify=verify, headers=req_headers, cookies=cookies, allow_redirects=allow_redirects, timeout=timeout)
                except Exception as req_error:
                    logger.error(f"Request failed for {link}: {req_error}\n{traceback.format_exc()}")
                    self.generate_requests_log(link, None, start_dt, 'failed', req_error)
                    return None

            self.log_request(method='PUT', link=link, params=params, data=data, json=json, sleep=sleep)

            if response is not None and response.status_code in range(200, 300):
                self.generate_requests_log(link, response, start_dt, 'success')
            else:
                status = response.status_code if response is not None else "no response"
                logger.warning(f"Non-2xx status {status} for {link}")
                self.generate_requests_log(link, response, start_dt, 'failed', f"HTTP {status}")

        except Exception as error:
            logger.error(f"Unexpected error for {link}: {error}\n{traceback.format_exc()}")
            self.generate_requests_log(link, response, start_dt, 'failed', error)

        return response

    def download(self, method='', link='', params=None, data=None, json=None, headers=None, cookies={}, proxies=[], verify=False, allow_redirects=True, timeout=30, sleep=0, tries=3, path_file='', is_image=False, referer=None):
        file_size = 0
        try:
            i = 0
            status_code = 0
            while status_code not in range(200, 300) and i < tries:
                i += 1
                try:
                    if method == 'DGET':
                        response = self.get_simple(link, params=params, headers=headers, cookies=cookies, proxies=proxies, verify=verify, allow_redirects=allow_redirects, timeout=timeout, sleep=sleep, referer=referer, is_navigation=False)

                    elif method == 'DPOST':
                        response = self.post_simple(link, data=data, json=json, headers=headers, cookies=cookies, proxies=proxies, verify=verify, allow_redirects=allow_redirects, timeout=timeout, sleep=sleep, referer=referer)

                    else:
                        logger.warning(f'Method {method} Not Supported in download function')
                        return file_size

                    if response:
                        body = response.content
                        file_size = len(body)
                        status_code = response.status_code
                        if status_code:
                            if is_image:
                                im = Image.open(BytesIO(body))
                                im.save(path_file)  # Save the image as a JPEG file
                            else:
                                with open(path_file, 'wb') as file:
                                    file.write(body)
                except Exception:
                    logger.error(traceback.format_exc())

                logger.info(f'Request Download: {i}/{tries} | status_code: {status_code} | file_size = {file_size} | {link}')

                if status_code not in range(200, 300) and i < tries:
                    if self.rotate_profile_on_block:
                        self._new_identity()
                    self._human_pause(factor=2 ** (i - 1))

        except Exception:
            logger.error(traceback.format_exc())

        return file_size

    def log_request(self, method=None, link=None, params=None, data=None, json=None, sleep=0):
        if sleep:
            library = ''
            if self.use_cffi:
                library = 'Cffi '

            link_display = f"| link: {link[:self.truncate_nbre]}..." if link else ""
            params_display = f"| params: {str(params)[:self.truncate_nbre]}..." if params else ""
            data_display = f"| data: {str(data)[:self.truncate_nbre]}..." if data else ""
            json_display = f"| json: {str(json)[:self.truncate_nbre]}..." if json else ""
            if isinstance(sleep, list):
                if len(sleep) >= 2:
                    # float + jitter reads as human; int truncation was robotic.
                    _sleep = random.uniform(sleep[0], sleep[1])
                    logger.info(f'{library}Request {method} | sleep: {_sleep:.1f}s {link_display} {params_display} {data_display} {json_display}')
                    time.sleep(_sleep)
            elif isinstance(sleep, (int, float)):
                _sleep = sleep + random.uniform(0, 0.7)
                logger.info(f'{library}Request {method} | sleep: {_sleep:.1f}s {link_display} {params_display} {data_display} {json_display}')
                time.sleep(_sleep)


# if __name__ == '__main__':
#     proxies = ["EDoqoyPZeB9Mmw00-country-US:dmkJoq6JAxe5uMw@res-v2.pr.plainproxies.com:8080"]
#     use_proxy = True
#     fctrequest = fctrequest(use_session=False, use_cffi=False, use_proxy=use_proxy)
#
#     headers = {
#         'accept': '*',
#         'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
#     }
#
#     response = fctrequest.request(method='GET', link='https://www.searchpeoplefree.com/address/ca/trabuco-canyon/brassie-ln/36', headers=headers, proxies=proxies, tries=5)
#     print(response.text)
#     # response = fctrequest.request(method='POST', link=link, data=param, headers=headers, proxies=proxies, tries=5)
#     # image_size = fctrequest.request(method='DGET', link=image_link, path=image_path, is_image=True, proxies=proxies, tries=5)
#     # image_size = fctrequest.request(method='DPOST', link=image_link, path=image_path, is_image=True, proxies=proxies, tries=5)
