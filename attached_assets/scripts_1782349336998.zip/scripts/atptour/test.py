from scripts.atptour.fctrequest import Request
from scrapy.selector import Selector

USE_PROXY = True
use_proxy = True
proxies = ["RV6v2jY8MvCkq-ttl-0:DpSYOpTeYvEw6mE@dc.us-pr.plainproxies.com:1338"]
headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,fr;q=0.8',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
        }

fctrequest = Request(use_session=False, use_cffi=True, use_proxy=use_proxy)

response1 = fctrequest.request(method='GET', link='https://icanhazip.com/', headers=headers, proxies=proxies, tries=1, timeout=120)
print(f'icanhazip: {response1.text}')

index_link = f'https://www.atptour.com/en/rankings/doubles?rankRange=0-5000&dateWeek=2026-05-25'
print(f'index_link: {index_link}')

response1 = fctrequest.request(method='GET', link=index_link, headers=headers, proxies=proxies, tries=1, timeout=120)
print(f'status_code: {response1.status_code}')

if response1 and response1.status_code in range(200, 300):
    html1 = Selector(text=response1.text)
    selectors = html1.xpath('//table[contains(@class, "mega-table") and contains(@class, "desktop-table")]//tr[@class="lower-row"]')
    print(f'selectors: {len(selectors)}')