import time
import concurrent.futures
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn
from assets.fct.fctlog import logger
from assets.fct import fctcore
from scripts.atptour.parser.players import PlayersParser
from scripts.atptour.parser.details import DetailsParser
from scripts import helper
from app_spiders.models import jobsModel

start_dt = time.time()

def run(*args):
    params = list(args)
    job_id = int(params[0])
    spider_name = params[1]
    folder_path = params[2]
    max_workers = int(params[3])

    base_file = f'{spider_name}__{job_id}__{fctcore.current_date("%Y-%m-%d_%H-%M")}.csv'

    job_obj = jobsModel.objects.get(id=job_id)
    spider_id = job_obj.spider_id
    job_settings = job_obj.job_settings
    job_rank_type = job_settings.get('rank_type', '')
    job_single_date = fctcore.convert_string_to_date_format(date_str=job_settings.get('single_date', ''), in_format='%m/%d/%Y', out_format='%Y-%m-%d')
    logger.info(f'spider_name: {spider_name} | job_id: {job_id} | job_single_date: {job_single_date}')

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(), TextColumn("{task.completed}/{task.total}"), TimeElapsedColumn(), TimeRemainingColumn(), transient=False) as progress:
        df_players = PlayersParser(progress).parse_site(max_workers, job_id, job_single_date, job_rank_type)
        logger.info(f'df_players: {len(df_players)}')

        if not df_players.empty:
            players_list = df_players.to_dict("records")
            players_chunks = list(fctcore.split_list_into_chunks(lst=players_list, max_workers=max_workers))
            if max_workers > len(players_chunks): max_workers=len(players_chunks)

            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                main_task = progress.add_task(description=f'{spider_name}_results', total=len(players_list))
                for thread_id, players_chunk in enumerate(players_chunks):
                    thread_task = progress.add_task(f"Thread {thread_id + 1}", total=len(players_chunk))
                    executor.submit(DetailsParser().parse_site, spider_id, job_id, players_chunk, main_task, thread_task, progress)

        helper.finalize_items_from_db(job_obj, folder_path, base_file)
        helper.finalize_job(job_obj, base_file, folder_path)

    logger.info(f'script take {round(time.time()-start_dt, 2)} sec to finished')
