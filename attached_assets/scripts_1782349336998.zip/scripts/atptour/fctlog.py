import logging, coloredlogs
import pandas as pd
from datetime import datetime
from threading import Lock
from collections import deque

# =========================
# SHARED BUFFERS
# =========================
_log_lock      = Lock()
_log_buffer    = deque()
_error_buffer  = deque()

# =========================
# COLUMNS
# =========================
_LOG_COLS   = ["timestamp", "level", "message"]
_ERROR_COLS = ["timestamp", "level", "message", "exception"]

# =========================
# HANDLERS
# =========================
class DataFrameHandler(logging.Handler):
    """Append all logs to in-memory buffer."""
    def emit(self, record):
        with _log_lock:
            _log_buffer.append((
                datetime.now(),
                record.levelname,
                record.getMessage(),
            ))


class ErrorDataFrameHandler(logging.Handler):
    """Catch ERROR+ logs and append to error buffer."""
    def emit(self, record):
        if record.levelno >= logging.ERROR:
            with _log_lock:
                _error_buffer.append((
                    datetime.now(),
                    record.levelname,
                    record.getMessage(),
                    self.formatException(record.exc_info) if record.exc_info else "",
                ))

# =========================
# LOGGER SETUP
# =========================
logger = logging.getLogger("scraper")
logger.setLevel(logging.INFO)

if not any(isinstance(h, DataFrameHandler) for h in logger.handlers):
    coloredlogs.install(level="INFO", logger=logger)
    logger.addHandler(DataFrameHandler())
    logger.addHandler(ErrorDataFrameHandler())
    logger.propagate = False

# =========================
# HELPERS
# =========================
def get_logs_df() -> pd.DataFrame:
    """All logs from in-memory buffer."""
    with _log_lock:
        return pd.DataFrame(list(_log_buffer), columns=_LOG_COLS)


def get_errors_df() -> pd.DataFrame:
    """All errors from in-memory buffer."""
    with _log_lock:
        return pd.DataFrame(list(_error_buffer), columns=_ERROR_COLS)