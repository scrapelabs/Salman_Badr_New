import traceback
from scrapy.selector import Selector
from urllib.parse import urljoin
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts.log_items import ItemsLogger
from scripts.finland_league.parser.utils import Utils

class TournamentParser:

    def __init__(self):
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=True, use_cffi=False, use_proxy=self.use_proxy)
        self.df_tournaments = ItemsLogger()
        self.Utils = Utils(self.proxies, self.fctrequest)
        self.Utils.change_language_to_english()
        self.Utils.accept_cookies()


    def parse_tournaments(self, job_start_date, job_end_date, job_tournament_url):
        try:
            if job_tournament_url:
                try:
                    headers = {
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                        'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                        'upgrade-insecure-requests': '1',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
                    }
                    response1 = self.fctrequest.request(method='GET', link=job_tournament_url, headers=headers, proxies=self.proxies, tries=3)
                    if response1:
                        if response1.status_code in range(200, 300):
                            html1 = Selector(text=response1.text)

                            tournament_url = ''
                            tournament_name = fctcore.parse_field('//header[contains(@class, "page-head")]//div[@class="media__content"]//h2[contains(@class, "media__title")]/a/span[@class="nav-link__value"]', html1)
                            tournament_url_pre = fctcore.parse_field('//header[contains(@class, "page-head")]//div[@class="media__content"]//h2[contains(@class, "media__title")]/a/@href', html1)
                            if tournament_url_pre:
                                tournament_url = urljoin(f'https://www.tennisassa.fi/', tournament_url_pre)

                            if tournament_name and tournament_url:
                                self.df_tournaments.log({
                                    "tournament_name": tournament_name,
                                    "tournament_url": tournament_url,
                                })

                except Exception:
                    logger.error(traceback.format_exc())

            else:
                try:
                    headers = {
                        'accept': '*/*',
                        'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
                        'x-requested-with': 'XMLHttpRequest',
                    }

                    data = {
                        'LoadMoreResults': 'LoadMoreResults',
                        'Page': '1',
                        'LeagueFilter.Q': '',
                        'LeagueFilter.StartDate': '2000-01-01',
                        'LeagueFilter.EndDate': '2026-07-11',
                        'LeagueFilter.StatusFilterID': 'false',
                        'X-Requested-With': 'XMLHttpRequest',
                    }

                    index_link = 'https://www.tennisassa.fi/find/league/DoSearch'

                    # job_start_date = fctcore.get_offset_date(days=14, direction='-', format='%Y-%m-%d')
                    # job_end_date = fctcore.current_date(format='%Y-%m-%d')

                    logger.info(f'job_start_date: {job_start_date}')
                    logger.info(f'job_end_date: {job_end_date}')

                    page = 0
                    while True:
                        results_found = False
                        page += 1
                        data['Page'] = page
                        data['LeagueFilter.StartDate'] = job_start_date
                        data['LeagueFilter.EndDate'] = job_end_date

                        logger.info(f'page: {page}')

                        response1 = self.fctrequest.request(method='POST', link=index_link, data=data, headers=headers, proxies=self.proxies, tries=3)
                        if response1:
                            if response1.status_code in range(200, 300):
                                html1 = Selector(text=response1.text)

                                for d1 in html1.xpath('//li[@class="list__item"]//div[@class="media__content"]'):
                                    results_found = True
                                    tournament_name = fctcore.parse_field('.//h4[@class="media__title"]/a/@title', d1)
                                    tournament_url = urljoin(f'https://www.tennisassa.fi/', fctcore.parse_field('.//h4[@class="media__title"]/a/@href', d1))

                                    if tournament_name and tournament_url:
                                        self.df_tournaments.log({
                                            "tournament_name": tournament_name,
                                            "tournament_url": tournament_url,
                                        })

                        if not results_found:
                            break

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())

        return self.df_tournaments.get_df()
