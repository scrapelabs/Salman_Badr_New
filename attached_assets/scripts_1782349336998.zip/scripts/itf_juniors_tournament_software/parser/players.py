import traceback, random
from os.path import basename, dirname, abspath
from urllib.parse import urljoin
from scrapy.selector import Selector
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts import helper
from scripts.itf_juniors_tournament_software.parser.utils import Utils
from app_spiders.models import PlayersItfJuniorsTournamentSoftwareModel


class PlayersParser:

    def __init__(self, progress):
        self.progress = progress
        self.spider_name = basename(dirname(dirname(abspath(__file__))))

        self.DetailsTournamentParser = DetailsTournamentParser(self.spider_name)
        self.DetailsSportParser = DetailsSportParser(self.spider_name)


    def parse_site(self, tournaments_chunk, main_task, thread_task, progress):
        try:
            for tournaments_data in tournaments_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    tournament_id = tournaments_data.get("tournament_id", "")
                    tournament_name = tournaments_data.get("tournament_name", "")
                    tournament_url = tournaments_data.get("tournament_url", "")
                    logger.info(f'tournament_id: {tournament_id} | tournament_name: {tournament_name} | {tournament_url}')

                    data_found = self.DetailsTournamentParser.parse_players(tournament_id)

                    if not data_found:
                        self.DetailsSportParser.parse_players(tournament_id)


                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())


class DetailsSportParser:

    def __init__(self, spider_name):
        self.spider_name = spider_name
        self.claude_key = random.choice(settings.CLAUDE_KEYS)

        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=True, use_cffi=False, use_proxy=self.use_proxy)
        self.Utils = Utils(self.proxies, self.fctrequest)
        self.Utils.accept_cookies()


    def parse_players(self, tournament_id):
        data_found = False
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0',
            }
            index_link = f'https://itfjuniors.tournamentsoftware.com/sport/players.aspx?id={tournament_id}'
            response1 = self.fctrequest.request(method='GET', link=index_link, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    for d1 in html1.xpath('//table[@class="players"]//tr//td//a[contains(@href, "/sport/player.aspx")]'):
                        data_found = True
                        player_name = fctcore.parse_field('./text()', d1)
                        player_url = urljoin(f'https://itfjuniors.tournamentsoftware.com/', fctcore.parse_field('./@href', d1))

                        logger.info(f'player_name: {player_name} | player_url: {player_url}')
                        self.parse_matches(player_name, player_url)

        except Exception:
            logger.error(traceback.format_exc())

        return data_found


    def parse_matches(self, player_name, player_url):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=player_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    player_profile_pre = fctcore.parse_field('//div[@id="content"]//div[@class="subtitle"]//h2/a[@class="button"]/@href', html1)
                    logger.info(f'player_profile_pre: {player_profile_pre}')

                    if player_profile_pre:
                        player_profile = urljoin(f'https://itfjuniors.tournamentsoftware.com/', player_profile_pre)
                        logger.info(f'player_profile: {player_profile}')

                        third_party_id = ''
                        try:
                            third_party_id = player_profile.split('/')[-1].strip()
                        except Exception:
                            ''
                        logger.info(f'third_party_id: {third_party_id}')

                        is_has_third_party_id = True
                        if not third_party_id:
                            is_has_third_party_id = False
                            player_name_profile = fctcore.parse_field('//div[contains(@class, "page-subhead")]//div[@class="media__content"]//h4[contains(@class, "media__title")]//span[@class="nav-link__value"]', html1)
                            third_party_id = helper.sha256_id(player_name_profile)

                        if third_party_id:
                            objs = PlayersItfJuniorsTournamentSoftwareModel.objects.filter(third_party_id=third_party_id)
                            if not objs.exists():
                                player_country = self.parse_page_profile(player_profile)
                                player_name_claude, player_gender = helper.format_name_gender_claude(player_name, self.claude_key)

                                if not is_has_third_party_id:
                                    player_name = player_name_claude

                                PlayersItfJuniorsTournamentSoftwareModel(
                                    spider_name=self.spider_name,
                                    third_party_id=third_party_id,
                                    player_name=player_name,
                                    gender=player_gender,
                                    country=player_country,
                                ).save()

                            else:
                                objs.update(player_name=player_name)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_page_profile(self, player_profile):
        player_country = ''
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=player_profile, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    player_country = fctcore.parse_field('//header[contains(@class, "page-head")]//div[@class="media__img"]//span[contains(@class, "profile-icon")]/img[@class="profile-head__nat"]/@title', html1)
                    logger.info(f'player_country: {player_country}')

        except Exception:
            logger.error(traceback.format_exc())

        return player_country



class DetailsTournamentParser:

    def __init__(self, spider_name):
        self.spider_name = spider_name
        self.claude_key = random.choice(settings.CLAUDE_KEYS)

        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=True, use_cffi=False, use_proxy=self.use_proxy)
        self.Utils = Utils(self.proxies, self.fctrequest)
        self.Utils.accept_cookies()


    def parse_players(self, tournament_id):
        data_found = False
        try:
            headers = {
                'accept': '*/*',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
                'x-requested-with': 'XMLHttpRequest',
            }

            data = {
                'X-Requested-With': 'XMLHttpRequest',
            }

            index_link = f'https://itfjuniors.tournamentsoftware.com/tournament/{tournament_id.lower()}/Players/GetPlayersContent'
            response1 = self.fctrequest.request(method='POST', link=index_link, data=data, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    for d1 in html1.xpath('//div[@id="PlayersView"]//ol//li[contains(@class, "list__item")]//h5/a'):
                        data_found = True
                        player_name = fctcore.parse_field('./span[@class="nav-link__value"]', d1)
                        player_url = urljoin(f'https://itfjuniors.tournamentsoftware.com/', fctcore.parse_field('./@href', d1))

                        logger.info(f'player_name: {player_name}')
                        self.parse_matches(player_name, player_url)

        except Exception:
            logger.error(traceback.format_exc())

        return data_found

    def parse_matches(self, player_name, player_url):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=player_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    player_profile_pre = fctcore.parse_field('//div[contains(@class, "page-subhead")]//div[@class="media__content"]//h4[contains(@class, "media__title")]/a/@href', html1)
                    logger.info(f'player_profile_pre: {player_profile_pre}')

                    player_country = fctcore.parse_field('//div[contains(@class, "page-subhead")]//div[@class="media__img"]//div[contains(@class, "profile-icon")]/img[@class="profile-head__nat"]/@title', html1)
                    logger.info(f'player_country: {player_country}')

                    if player_profile_pre:
                        player_profile = urljoin(f'https://itfjuniors.tournamentsoftware.com/', player_profile_pre)
                        logger.info(f'player_profile: {player_profile}')

                        third_party_id = player_profile_pre.split('/')[-1].strip()
                        logger.info(f'third_party_id: {third_party_id}')

                        is_has_third_party_id = True
                        if not third_party_id:
                            is_has_third_party_id = False
                            third_party_id = helper.sha256_id(player_name)

                        if third_party_id:
                            objs = PlayersItfJuniorsTournamentSoftwareModel.objects.filter(third_party_id=third_party_id)
                            if not objs.exists():
                                player_name_claude, player_gender = helper.format_name_gender_claude(player_name, self.claude_key)

                                if not is_has_third_party_id:
                                    player_name = player_name_claude

                                PlayersItfJuniorsTournamentSoftwareModel(
                                    spider_name=self.spider_name,
                                    third_party_id=third_party_id,
                                    player_name=player_name,
                                    gender=player_gender,
                                    country=player_country
                                ).save()

                            else:
                                objs.update(player_name=player_name)

        except Exception:
            logger.error(traceback.format_exc())


