html_text1 = '''
<tr style="background-color: transparent;">
			<td align="right">Mon 09/03/2026</td><td>MS1</td><td><a href="./draw.aspx?id=DF475E4A-BFAC-4C0C-B2FC-BB7709D8B62A&amp;draw=5">ITF World Junior Tennis – Boys – Group D</a></td><td class="nowrap" align="right"><a class="teamname" href="teammatch.aspx?id=DF475E4A-BFAC-4C0C-B2FC-BB7709D8B62A&amp;match=60">Philippines</a><a href="matches.aspx?id=DF475E4A-BFAC-4C0C-B2FC-BB7709D8B62A&amp;c=PHI"><img src="//static.tournamentsoftware.com/content/images/flags/PHI.svg" class="intext flag" width="16" height="14" alt="Philippines" title="Philippines"><span class="printonly flag">[PHI] </span></a><br><strong><a class="highlighted" href="player.aspx?id=DF475E4A-BFAC-4C0C-B2FC-BB7709D8B62A&amp;player=6">Alexi Luca Rafael ALDEMITA</a></strong><img src="//static.tournamentsoftware.com/content/images/flags/PHI.svg" class="intext flag" width="16" height="14" alt="PHI" title="PHI"><span class="printonly flag">[PHI] </span></td><td align="center">-</td><td class="nowrap"><a href="matches.aspx?id=DF475E4A-BFAC-4C0C-B2FC-BB7709D8B62A&amp;c=MGL"><img src="//static.tournamentsoftware.com/content/images/flags/MGL.svg" class="intext flag" width="16" height="14" alt="Mongolia" title="Mongolia"><span class="printonly flag">[MGL] </span></a><a class="teamname" href="teammatch.aspx?id=DF475E4A-BFAC-4C0C-B2FC-BB7709D8B62A&amp;match=60">Mongolia</a><br><img src="//static.tournamentsoftware.com/content/images/flags/MGL.svg" class="intext flag" width="16" height="14" alt="MGL" title="MGL"><span class="printonly flag">[MGL] </span><a href="player.aspx?id=DF475E4A-BFAC-4C0C-B2FC-BB7709D8B62A&amp;player=34">Tushig ALTANGEREL</a></td><td><span class="score"><span>6-1</span> <span>6-0</span></span></td><td><a href="matchcalendarhandler.ashx?code=DF475E4A-BFAC-4C0C-B2FC-BB7709D8B62A&amp;id=62&amp;LCID=2057&amp;typeID=11" class="icon-calendar inline-icalendar" title="Export Calendar">Export Calendar</a></td><td>1-0</td><td></td><td></td><td align="right">47m</td><td><a href="./court.aspx?id=DF475E4A-BFAC-4C0C-B2FC-BB7709D8B62A&amp;crtid=10">Main Location - Court 06</a></td>
		</tr>
'''


import re, logging, coloredlogs
from scrapy.selector import Selector

logger = logging.getLogger("scraper")
logger.setLevel(logging.INFO)
coloredlogs.install(level="INFO", logger=logger)

class ParseSport:
    def __init__(self):
        pass

    def parse_match(self, row):
        # ── Extract players from a side <td> ──────────────────────────────────────
        def extract_players(td: Selector) -> list[dict]:
            players = []
            for a in td.xpath(".//a[contains(@href, 'player.aspx')]"):
                country = td.xpath(".//a[contains(@href, 'matches.aspx')]/img/@title").get("")
                # Check if the <a> tag is directly inside a <strong> tag
                is_winner = bool(a.xpath("parent::strong").get())
                players.append({
                    "name": a.xpath("normalize-space(.)").get(""),
                    "profile_url": a.xpath("@href").get(""),
                    "highlighted": is_winner,
                    "country": country,
                })
            return players

        # FIX: use .//td[N] so it works when row is a full document selector
        left_players = extract_players(row.xpath(".//td[4]"))
        right_players = extract_players(row.xpath(".//td[6]"))

        # ── Determine winner by <strong> tag ──────────────────────────────────────
        left_wins = any(p["highlighted"] for p in left_players)

        winners = left_players if left_wins else right_players
        losers = right_players if left_wins else left_players

        # ── draw_team_type ────────────────────────────────────────────────────────
        draw_team_type = "Doubles" if len(winners) == 2 else "Singles"

        # ── Score ─────────────────────────────────────────────────────────────────
        raw_scores = row.xpath(".//span[@class='score']/span/text()").getall()

        # ── Outcome ───────────────────────────────────────────────────────────────
        outcome = "Completed"
        if row.xpath('.//*[contains(normalize-space(.), "Retired")]'):
            outcome = "Retired"
            raw_scores = [s for s in raw_scores if "retired" not in s.lower()]

        # FIX: flip each set score so it reflects the winner's perspective
        def flip_set(s: str) -> str:
            tb_match = re.search(r'(\(\d+\))$', s)
            tiebreak = tb_match.group(1) if tb_match else ""
            clean = s[:tb_match.start()] if tb_match else s
            parts = clean.split("-")
            if len(parts) == 2:
                return f"{parts[1]}-{parts[0]}{tiebreak}"
            return s

        if not left_wins:
            raw_scores = [flip_set(s) for s in raw_scores]

        score = ", ".join(raw_scores) + ";" if raw_scores else ""

        # ── Helper ────────────────────────────────────────────────────────────────
        def _player(lst: list[dict], idx: int) -> dict:
            if idx < len(lst):
                profile_url_pre = lst[idx]["profile_url"]
                if profile_url_pre:
                    profile_url = f'https://te.tournamentsoftware.com/sport/{profile_url_pre}'
                    return {
                        "name": self.clean_name(lst[idx]["name"]),
                        "profile_url": profile_url,
                        "player_country": lst[idx]["country"],
                    }
            return {}

        match_data = {
            "draw_team_type": draw_team_type,
            "outcome": outcome,
            "score": score,
            "winner_1": _player(winners, 0),
            "winner_2": _player(winners, 1),
            "loser_1": _player(losers, 0),
            "loser_2": _player(losers, 1),
        }
        return match_data

    def clean_name(self, name: str) -> str:
        return re.sub(r"\s*\[[^\]]+\]\s*$", "", name).strip()


if __name__ == "__main__":
    html1 = Selector(text=html_text1)
    for d1 in html1.xpath('//tr'):
        match_data = ParseSport().parse_match(d1)
        logger.info(f'match_data: {match_data}')
