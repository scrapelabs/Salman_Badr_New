import requests, tempfile, webbrowser, os

class DetailsSportParser:

    def __init__(self):
        self.session = requests.Session()


    def parse(self):
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
        }

        data = {
            'ReturnUrl': '',
            'SettingsOpen': 'false',
            'CookiePurposes': [
                '2',
                '4',
                '16',
            ],
        }

        index_link = 'https://itfjuniors.tournamentsoftware.com/cookiewall/Save'
        response1 = self.session.post(index_link, headers=headers, data=data)

        index_link = 'https://te.tournamentsoftware.com/cookiewall/Save'
        response1 = self.session.post(index_link, headers=headers, data=data)

        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0',
        }
        index_link = f'https://itfjuniors.tournamentsoftware.com/sport/players.aspx?id=AFAC92B6-F7A1-48B7-9AD7-E9A62A0A0A96'
        response1 = self.session.get(index_link, headers=headers, data=data)

        player_url = 'https://te.tournamentsoftware.com/sport/player.aspx?id=AFAC92B6-F7A1-48B7-9AD7-E9A62A0A0A96&player=15'
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
        }

        response1 = self.session.get(player_url, headers=headers, data=data)
        self.open_html_in_browser(response1.text)

    def open_html_in_browser(self, html_content: str) -> bool:
        fd, fname = tempfile.mkstemp('.html')
        with open(fname, 'w', encoding="utf-8") as f:
            f.write(str(html_content))
        os.close(fd)
        return webbrowser.open(f"file://{fname}")


if __name__ == '__main__':
    DetailsSportParser().parse()