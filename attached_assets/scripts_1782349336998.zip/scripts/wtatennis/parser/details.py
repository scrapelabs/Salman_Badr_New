import traceback
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from app_spiders.models import JobsItemsWtatennisModel

class DetailsParser:

    def __init__(self):
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=True, use_proxy=self.use_proxy)
        self.headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,fr;q=0.8',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
        }
        self.base_link = 'https://api.wtatennis.com/tennis/players/ranked?page={page}&pageSize=100&type=rank{rank}&sort=asc&metric={rank_type}&name=&at={current_date}'


    def parse_site(self, spider_id, job_id, start_date, rank_type):
        try:
            page = 0
            found = True
            while found:
                close_old_connections()

                index_link = self.base_link.format(page=page, rank=rank_type.title(), rank_type=rank_type.upper(), current_date=start_date)
                logger.info(f'rank_type: {rank_type} | {index_link}')

                results1 = []
                for attempt in range(3):
                    try:
                        response1 = self.fctrequest.request(method='GET', link=index_link, headers=self.headers, proxies=self.proxies, tries=1)
                        if response1 and response1.status_code in range(200, 300):
                            try:
                                results1 = response1.json()
                            except Exception:
                                logger.error(traceback.format_exc())
                        if results1:
                            break
                    except Exception:
                        logger.error(traceback.format_exc())

                if results1:
                    found = True
                    self.parse_page(spider_id, job_id, start_date, rank_type, results1)

                else:
                    found = False

                page += 1

        except Exception:
            logger.error(traceback.format_exc())


    def parse_page(self, spider_id, job_id, start_date, rank_type, results1):
        try:
            for result in results1:
                player_id = ''
                try:
                    player_id = result.get('player', {}).get('id', '')
                except:
                    ''
                if player_id:
                    birthdate = ''
                    rankdate = ''
                    try:
                        birthdate = fctcore.convert_string_to_date_format(
                            date_str=result.get('player', {}).get('dateOfBirth', ''),
                            in_format='%Y-%m-%d',
                            out_format='%m/%d/%Y'
                        )
                    except Exception:
                        ''
                    last_name = result.get('player', {}).get('lastName', '')
                    first_name = result.get('player', {}).get('firstName', '')
                    name = f'{last_name}, {first_name}'
                    nationality = result.get('player', {}).get('countryCode', '')
                    points = result.get('points', '')
                    rank = result.get('ranking', '')
                    try:
                        rankdate = fctcore.convert_string_to_date_format(
                            date_str=result.get('rankedAt', ''),
                            in_format='%Y-%m-%dT%H:%M:%SZ',
                            out_format='%m/%d/%Y'
                        )
                    except Exception:
                        ''
                    ranktype = rank_type
                    gender = 'F'

                    # current_date = fctcore.convert_string_to_date_format(start_date, in_format="%Y-%m-%d", out_format="%m/%d/%Y")
                    # if current_date == rankdate:
                    logger.info(f'birthdate: {birthdate}')
                    logger.info(f'gender: {gender}')
                    logger.info(f'player_id: {player_id}')
                    logger.info(f'name: {name}')
                    logger.info(f'nationality: {nationality}')
                    logger.info(f'points: {points}')
                    logger.info(f'rank: {rank}')
                    logger.info(f'rankdate: {rankdate}')
                    logger.info(f'ranktype: {ranktype}')
                    logger.info('*' * 50)

                    JobsItemsWtatennisModel(
                        spider_id=spider_id,
                        job_id=job_id,
                        birthdate=birthdate,
                        gender=gender,
                        player_id=player_id,
                        name=name,
                        nationality=nationality,
                        points=points,
                        rank=rank,
                        rankdate=rankdate,
                        ranktype=ranktype,
                        processed=True,
                    ).save()

                    # else:
                    #     logger.warning(f'❌ Rank date ({rankdate}) is different from today ({current_date})')

        except Exception:
            logger.error(traceback.format_exc())

