import traceback, random
from scrapy.selector import Selector
from urllib.parse import urljoin
from os.path import basename, dirname, abspath
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts import helper
from scripts.hong_kong_tournament.parser.utils import Utils
from app_spiders.models import PlayersHongKongTournamentModel

class PlayersParser:

    def __init__(self, progress):
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=True, use_cffi=False, use_proxy=self.use_proxy)
        self.spider_name = basename(dirname(dirname(abspath(__file__))))
        self.claude_key = random.choice(settings.CLAUDE_KEYS)
        self.Utils = Utils(self.proxies, self.fctrequest)
        self.Utils.change_language_to_english()
        self.Utils.accept_cookies()


    def parse_site(self, tournaments_chunk, main_task, thread_task, progress):
        try:
            for tournaments_data in tournaments_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    tournament_id = tournaments_data.get("tournament_id", "")
                    tournament_name = tournaments_data.get("tournament_name", "")
                    tournament_url = tournaments_data.get("tournament_url", "")
                    logger.info(f'tournament_id: {tournament_id} | tournament_name: {tournament_name} | {tournament_url}')

                    self.parse_players(tournament_id)

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())


    def parse_players(self, tournament_id):
        try:
            headers = {
                'accept': '*/*',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
                'x-requested-with': 'XMLHttpRequest',
            }

            data = {
                'X-Requested-With': 'XMLHttpRequest',
            }

            index_link = f'https://hkta.tournamentsoftware.com/tournament/{tournament_id.lower()}/Players/GetPlayersContent'
            response1 = self.fctrequest.request(method='POST', link=index_link, data=data, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    for d1 in html1.xpath('//div[@id="PlayersView"]//ol//li[contains(@class, "list__item")]//h5/a'):
                        player_name = fctcore.parse_field('./span[@class="nav-link__value"]', d1)
                        player_url = urljoin(f'https://hkta.tournamentsoftware.com/', fctcore.parse_field('./@href', d1))

                        logger.info(f'player_name: {player_name}')
                        self.parse_matches(player_url, player_name)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_matches(self, player_url, player_name):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=player_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    third_party_id = fctcore.parse_field('//div[contains(@class, "page-subhead")]//div[@class="media__content"]//h4[contains(@class, "media__title")]/span[@class="media__title-aside"]', html1)
                    third_party_id = fctcore.preg_repace(patt="\(|\)", repl="", subj=third_party_id)
                    third_party_id = fctcore.preg_repace(patt="[^\d+]", repl="", subj=third_party_id)
                    logger.info(f'third_party_id: {third_party_id}')

                    is_has_third_party_id = True
                    if not third_party_id:
                        is_has_third_party_id = False
                        player_name_profile = fctcore.parse_field('//div[contains(@class, "page-subhead")]//div[@class="media__content"]//h4[contains(@class, "media__title")]//span[@class="nav-link__value"]', html1)
                        third_party_id = helper.sha256_id(player_name_profile)

                    if third_party_id:
                        objs = PlayersHongKongTournamentModel.objects.filter(spider_name=self.spider_name, third_party_id=third_party_id)
                        if not objs.exists():
                            player_name_claude, player_gender = helper.format_name_gender_claude(player_name, self.claude_key)

                            if not is_has_third_party_id:
                                player_name = player_name_claude

                            PlayersHongKongTournamentModel(
                                spider_name=self.spider_name,
                                third_party_id=third_party_id,
                                player_name=player_name,
                                gender=player_gender,
                            ).save()

                        else:
                            objs.update(player_name=player_name)

        except Exception:
            logger.error(traceback.format_exc())
