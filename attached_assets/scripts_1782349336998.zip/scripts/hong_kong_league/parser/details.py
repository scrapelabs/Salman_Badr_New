import traceback, json, re
from scrapy.selector import Selector
from urllib.parse import urljoin
from datetime import datetime
from os.path import basename, dirname, abspath
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts import helper
from scripts.log_items import ItemsLogger
from scripts.hong_kong_league.parser.utils import Utils
from app_spiders.models import ItemsHongKongLeagueModel, PlayersHongKongLeagueModel

class DetailsParser:

    def __init__(self, progress):
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=True, use_cffi=False, use_proxy=self.use_proxy)

        self.df_tournaments = ItemsLogger()

        self.full_country_code = "Hong Kong"
        self.short_country_code = "HKG"

        self.spider_name = basename(dirname(dirname(abspath(__file__))))
        self.Utils = Utils(self.proxies, self.fctrequest)
        self.Utils.change_language_to_english()
        self.Utils.accept_cookies()


    def parse_site(self, spider_id, job_id, tournaments_chunk, main_task, thread_task, progress):
        try:
            for tournaments_data in tournaments_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    tournament_name = tournaments_data.get("tournament_name", "")
                    tournament_url = tournaments_data.get("tournament_url", "")

                    logger.info(f'tournament_name: {tournament_name} | {tournament_url}')

                    self.parse_groups(spider_id, job_id, tournament_url)

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())

    def parse_groups(self, spider_id, job_id, tournament_url):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }
            response1 = self.fctrequest.request(method='GET', link=tournament_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    draw_list = []
                    try:
                        draw_list = json.loads(fctcore.preg_repace(patt=";$", repl="", subj=fctcore.preg_repace(patt="^var DrawList =", repl="", subj=[n for n in html1.xpath('//script[contains(., "var DrawList =")]').get().split('\n') if 'var DrawList' in n][0].strip())))
                    except Exception:
                        ''

                    for draw_res in draw_list:
                        group_id = draw_res['XTPID']
                        logger.info(f'group_id: {group_id}')

                        if group_id:
                            group_url = f"{tournament_url}/draw/{group_id}"
                            logger.info(f'group_url: {group_url}')

                            self.parse_group(spider_id, job_id, group_url)

        except Exception:
            logger.error(traceback.format_exc())

    def parse_group(self, spider_id, job_id, group_url):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }
            response1 = self.fctrequest.request(method='GET', link=group_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    tournament_url = ''
                    tournament_name = fctcore.parse_field('//header[contains(@class, "page-head")]//div[@class="media__content"]//h2[contains(@class, "media__title")]/a/span[@class="nav-link__value"]', html1)
                    tournament_url_pre = fctcore.parse_field('//header[contains(@class, "page-head")]//div[@class="media__content"]//h2[contains(@class, "media__title")]/a/@href', html1)
                    if tournament_url_pre:
                        tournament_url = urljoin(f'https://hkta.tournamentsoftware.com/', tournament_url_pre)

                    tournament_range_date = ''
                    tournament_start_date = ''
                    tournament_end_date = ''
                    try:
                        tournament_range_date = fctcore.parse_field('//header[contains(@class, "page-head")]//div[@class="media__content"]//ul[contains(@class, "list")]/li[@class="list__item"][1]/span[contains(@class, "tag--mono")]', html1)
                        tournament_start_date, tournament_end_date = helper.parse_tournament_range_date(tournament_range_date, format='%m/%d/%Y')
                    except Exception:
                        ''

                    logger.info(f'tournament_range_date: {tournament_range_date}')
                    logger.info(f'tournament_start_date: {tournament_start_date}')
                    logger.info(f'tournament_end_date: {tournament_end_date}')

                    for d1 in html1.xpath('//div[@class="module-container"]/h4[@class="module-divider"]'):
                        for d2 in d1.xpath('./following-sibling::ul[@class="match-group"][1]/li[@class="match-group__item"]//a[@class="team-match__wrapper"]'):
                            match_url_pre = fctcore.parse_field('./@href', d2)
                            logger.info(f'match_url_pre: {match_url_pre}')

                            if match_url_pre:
                                match_url = urljoin(f'https://hkta.tournamentsoftware.com/', match_url_pre)
                                logger.info(f'match_url: {match_url}')

                                self.parse_matches(spider_id, job_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, match_url)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_matches(self, spider_id, job_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, match_url):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=match_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    match_round = fctcore.parse_field('(//div[@id="js-league-team-match-index"]//div[contains(@class, "team-match-header")]//div[@class="module-container"]//div[contains(@class, "text--center")]//time)[1]/parent::node()/text()[1]', html1).replace("•", "").strip()
                    logger.info(f'match_round: {match_round}')

                    tournament_city = ''
                    # tournament_city = fctcore.parse_field('//div[@class="h-card"]//span[@class="p-locality"]', html1)
                    # logger.info(f'tournament_city: {tournament_city}')

                    match_date = ''
                    try:
                        match_date_pre = fctcore.parse_field('(//div[@id="js-league-team-match-index"]//div[contains(@class, "team-match-header")]//div[@class="module-container"]//div[contains(@class, "text--center")]//time)[1]/@datetime', html1)
                        match_date = datetime.strptime(match_date_pre, "%Y-%m-%d %H:%M").strftime('%m/%d/%Y')
                    except Exception:
                        ''
                    logger.info(f'match_date: {match_date}')

                    draw_name = fctcore.parse_field('//div[@id="js-league-team-match-index"]//div[contains(@class, "team-match-header")]//div[@class="module-container"]//div[contains(@class, "text--center")]/a[@class="nav-link"]/span[@class="nav-link__value"]', html1)

                    for d1 in html1.xpath('//div[@class="module-container"]/ul/li[@class="match-group__item"]/div[@class="match"]'):
                        match_data = self.parse_match(Selector(text=d1.xpath('.//div[@class="match__body"]').get()))
                        logger.info(f'match_data: {match_data}')

                        draw_team_type = match_data.get("draw_team_type", "")
                        outcome = match_data.get("outcome", "")
                        score = match_data.get("score", "")

                        winner_1_name = match_data.get("winner_1", {}).get('name', '')
                        winner_1_url = match_data.get("winner_1", {}).get('profile_url', '')

                        winner_2_name = match_data.get("winner_2", {}).get('name', '')
                        winner_2_url = match_data.get("winner_2", {}).get('profile_url', '')

                        loser_1_name = match_data.get("loser_1", {}).get('name', '')
                        loser_1_url = match_data.get("loser_1", {}).get('profile_url', '')

                        loser_2_name = match_data.get("loser_2", {}).get('name', '')
                        loser_2_url = match_data.get("loser_2", {}).get('profile_url', '')

                        logger.info(f'tournament_name: {tournament_name}')
                        logger.info(f'tournament_url: {tournament_url}')
                        logger.info(f'draw_name: {draw_name}')
                        logger.info(f'draw_team_type: {draw_team_type}')
                        logger.info(f'outcome: {outcome}')
                        logger.info(f'score: {score}')
                        logger.info(f'winner_1_name: {winner_1_name} | winner_2_name: {winner_2_name}')
                        logger.info(f'loser_1_name: {loser_1_name} | loser_2_name: {loser_2_name}')

                        self.parse_page(spider_id, job_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_city, draw_name,draw_team_type, score, outcome, winner_1_name, winner_2_name, loser_1_name, loser_2_name, winner_1_url, winner_2_url, loser_1_url, loser_2_url, match_round, match_date)

        except Exception:
            logger.error(traceback.format_exc())

    def parse_page(self, spider_id, job_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_city, draw_name,draw_team_type, score, outcome, winner_1_name, winner_2_name, loser_1_name, loser_2_name, winner_1_url, winner_2_url, loser_1_url, loser_2_url, match_round, match_date):
        try:
            match_id = ""
            ball_type = "Yellow"
            draw_bracket_value = ""
            date = match_date
            winner_1_city = ""
            winner_1_country = self.full_country_code
            winner_1_state = ""
            winner_2_city = ""
            winner_2_state = ""
            loser_1_city = ""
            loser_1_state = ""
            loser_1_country =self.full_country_code
            loser_2_city = ""
            loser_2_state = ""
            id_type = self.full_country_code
            draw_gender = ""
            draw_bracket_type = ""
            draw_type = ""
            tournament_state = ""
            tournament_country_code = self.short_country_code
            tournament_host = ""
            tournament_location_type = ""
            tournament_surface = ""
            tournament_event_category = ""
            tournament_event_grade = ""
            tournament_import_source = self.full_country_code
            tournament_sanction_body = self.full_country_code
            winner_2_country = self.full_country_code
            winner_2_college = ""
            loser_2_country = self.full_country_code
            loser_2_college = ""
            tournament_event_type = "League"
            winner_1_college = ""
            loser_1_college = ""
            tournament_country = self.full_country_code

            winner_1_name, winner_1_third_party_id, winner_1_dob, winner_1_gender = self.parse_page_player(winner_1_name, winner_1_url)
            winner_2_name, winner_2_third_party_id, winner_2_dob, winner_2_gender = self.parse_page_player(winner_2_name, winner_2_url)
            loser_1_name, loser_1_third_party_id, loser_1_dob, loser_1_gender = self.parse_page_player(loser_1_name, loser_1_url)
            loser_2_name, loser_2_third_party_id, loser_2_dob, loser_2_gender = self.parse_page_player(loser_2_name, loser_2_url)

            if winner_1_gender == 'M':
                draw_gender = "Male"
            elif winner_1_gender == 'F':
                draw_gender = "Female"

            if not ItemsHongKongLeagueModel.objects.filter(spider_id=spider_id, job_id=job_id, winner_1_name=winner_1_name, loser_1_name=loser_1_name, winner_2_name=winner_2_name, loser_2_name=loser_2_name, score=score).exists():
                logger.info(f'match_id: {match_id}')
                logger.info(f'draw_name: {draw_name}')
                logger.info(f'draw_team_type: {draw_team_type}')
                logger.info(f'tournament_name: {tournament_name}')
                logger.info(f'date: {date}')
                logger.info(f'score: {score}')
                logger.info(f'winner_1_name: {winner_1_name}')
                logger.info(f'winner_1_gender: {winner_1_gender}')
                logger.info(f'winner_1_third_party_id: {winner_1_third_party_id}')
                logger.info(f'winner_1_dob: {winner_1_dob}')
                logger.info(f'winner_2_name: {winner_2_name}')
                logger.info(f'winner_2_gender: {winner_2_gender}')
                logger.info(f'winner_2_third_party_id: {winner_2_third_party_id}')
                logger.info(f'winner_2_dob: {winner_2_dob}')
                logger.info(f'loser_1_name: {loser_1_name}')
                logger.info(f'loser_1_gender: {loser_1_gender}')
                logger.info(f'loser_1_third_party_id: {loser_1_third_party_id}')
                logger.info(f'loser_1_dob: {loser_1_dob}')
                logger.info(f'loser_2_name: {loser_2_name}')
                logger.info(f'loser_2_gender: {loser_2_gender}')
                logger.info(f'loser_2_third_party_id: {loser_2_third_party_id}')
                logger.info(f'loser_2_dob: {loser_2_dob}')
                logger.info(f'outcome: {outcome}')
                logger.info(f'draw_gender: {draw_gender}')
                logger.info(f'tournament_city: {tournament_city}')
                logger.info(f'tournament_country_code: {tournament_country_code}')
                logger.info(f'tournament_url: {tournament_url}')
                logger.info(f'tournament_country: {tournament_country}')
                logger.info(f'tournament_start_date: {tournament_start_date}')
                logger.info(f'tournament_end_date: {tournament_end_date}')
                logger.info(f'match_round: {match_round}')
                logger.info('*' * 50)

                ItemsHongKongLeagueModel(
                    spider_id=spider_id,
                    job_id=job_id,
                    match_id=match_id,
                    ball_type=ball_type,
                    draw_bracket_value=draw_bracket_value,
                    draw_name=draw_name,
                    draw_team_type=draw_team_type,
                    tournament_name=tournament_name,
                    date=date,
                    round=match_round,
                    score=score,
                    winner_1_name=winner_1_name,
                    winner_1_gender=winner_1_gender,
                    winner_1_third_party_id=winner_1_third_party_id,
                    winner_1_city=winner_1_city,
                    winner_1_country=winner_1_country,
                    winner_1_state=winner_1_state,
                    winner_2_name=winner_2_name,
                    winner_2_gender=winner_2_gender,
                    winner_2_third_party_id=winner_2_third_party_id,
                    winner_2_city=winner_2_city,
                    winner_2_state=winner_2_state,
                    loser_1_name=loser_1_name,
                    loser_1_gender=loser_1_gender,
                    loser_1_third_party_id=loser_1_third_party_id,
                    loser_1_city=loser_1_city,
                    loser_1_state=loser_1_state,
                    loser_1_country=loser_1_country,
                    loser_2_name=loser_2_name,
                    loser_2_gender=loser_2_gender,
                    loser_2_third_party_id=loser_2_third_party_id,
                    loser_2_city=loser_2_city,
                    loser_2_state=loser_2_state,
                    outcome=outcome,
                    id_type=id_type,
                    draw_gender=draw_gender,
                    draw_bracket_type=draw_bracket_type,
                    draw_type=draw_type,
                    tournament_city=tournament_city,
                    tournament_state=tournament_state,
                    tournament_country_code=tournament_country_code,
                    tournament_host=tournament_host,
                    tournament_location_type=tournament_location_type,
                    tournament_surface=tournament_surface,
                    tournament_event_category=tournament_event_category,
                    tournament_event_grade=tournament_event_grade,
                    tournament_import_source=tournament_import_source,
                    tournament_sanction_body=tournament_sanction_body,
                    winner_2_country=winner_2_country,
                    winner_2_college=winner_2_college,
                    loser_2_country=loser_2_country,
                    loser_2_college=loser_2_college,
                    tournament_event_type=tournament_event_type,
                    winner_1_college=winner_1_college,
                    loser_1_college=loser_1_college,
                    tournament_url=tournament_url,
                    winner_1_dob=winner_1_dob,
                    winner_2_dob=winner_2_dob,
                    loser_1_dob=loser_1_dob,
                    loser_2_dob=loser_2_dob,
                    tournament_country=tournament_country,
                    tournament_start_date=tournament_start_date,
                    tournament_end_date=tournament_end_date,
                ).save()

        except Exception:
            logger.error(traceback.format_exc())


    def parse_page_player(self, player_name, player_url):
        third_party_id = ''
        player_dob = ''
        player_gender = ''
        if player_name and player_url:
            try:
                headers = {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                    'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
                }

                response1 = self.fctrequest.request(method='GET', link=player_url, headers=headers, proxies=self.proxies, tries=3)
                if response1:
                    if response1.status_code in range(200, 300):
                        html1 = Selector(text=response1.text)

                        third_party_id = fctcore.parse_field('//div[contains(@class, "page-subhead")]//div[@class="media__content"]//h4[contains(@class, "media__title")]/span[@class="media__title-aside"]', html1)
                        third_party_id = fctcore.preg_repace(patt="\(|\)", repl="", subj=third_party_id)
                        logger.info(f'third_party_id: {third_party_id}')

                        objs = PlayersHongKongLeagueModel.objects.filter(spider_name=self.spider_name, third_party_id=third_party_id)
                        if objs.exists():
                            obj = objs.first()
                            player_name = obj.player_name
                            player_dob = obj.dob
                            player_gender = obj.gender

            except Exception:
                logger.error(traceback.format_exc())

        return player_name, third_party_id, player_dob, player_gender


    def parse_match(self, sel):
        # -------- OUTCOME --------
        outcome = "Completed"
        if sel.xpath('.//*[contains(normalize-space(.),"Retired")]'):
            outcome = "Retired"

        # -------- PLAYERS (KEEP ROW ORDER) --------
        rows = sel.xpath(
            './/div[contains(@class,"match__row-wrapper")]/div[contains(@class,"match__row")]'
        )

        row_players = []  # index 0 = top row, index 1 = bottom row
        winner_row_index = None

        for idx, row in enumerate(rows):
            players = []
            for a in row.xpath('.//a[contains(@class,"nav-link")]'):
                name = a.xpath('.//span[@class="nav-link__value"]/text()').get()
                href = a.xpath('./@href').get()
                if name and href:
                    players.append({
                        "name": self.clean_name(name),
                        "profile_url": urljoin(
                            "https://hkta.tournamentsoftware.com/",
                            href.strip()
                        )
                    })

            row_players.append(players)

            if 'has-won' in row.attrib.get('class', ''):
                winner_row_index = idx

        loser_row_index = 1 - winner_row_index

        winners = row_players[winner_row_index]
        losers = row_players[loser_row_index]

        # -------- SCORE (ROW ORDER BASED) --------
        scores = []

        for ul in sel.xpath('//div[contains(@class,"match__result")]//ul[@class="points"]'):
            cells = [c.xpath('normalize-space(text())').get() for c in ul.xpath('./li')]
            if len(cells) != 2:
                continue

            winner_games = cells[winner_row_index]
            loser_games = cells[loser_row_index]

            scores.append(f"{winner_games}-{loser_games}")

        draw_team_type = "Doubles" if len(winners) == 2 else "Singles"

        match_data = {
            "draw_team_type": draw_team_type,
            "outcome": outcome,
            "score": ", ".join(scores) + ";" if scores else "",

            "winner_1": winners[0] if len(winners) > 0 else {},
            "winner_2": winners[1] if len(winners) > 1 else {},

            "loser_1": losers[0] if len(losers) > 0 else {},
            "loser_2": losers[1] if len(losers) > 1 else {},
        }

        logger.info(f'match_data: {match_data}')

        return match_data

    def clean_name(self, name: str) -> str:
        return re.sub(r"\s*\[[^\]]+\]\s*$", "", name).strip()
