import requests
import traceback
import logging
from scrapy.selector import Selector

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def parse_field(selector: str, node) -> str:
    try:
        v = node.xpath(f"normalize-space({selector})").get()
        return v or ""
    except Exception:
        logger.error(traceback.format_exc())
        return ""


def filter_valid_sets(sets1, sets2):
    out = []
    for s1, s2 in zip(sets1, sets2):
        if int(s1) > 0 or int(s2) > 0:
            out.append((int(s1), int(s2)))
    return out


def reverse_number_with_larger_first(input_string: str) -> str:
    try:
        a, b = map(int, input_string.split("-"))
        return f"{max(a, b)}-{min(a, b)}"
    except Exception:
        logger.error(traceback.format_exc())
        return ""


def build_teams_and_players(html1):
    # teams: {"V": {"name": "...", "total_won": 3}, "H": {...}}
    teams = {}
    for team_el in html1.xpath("//team"):
        vh = parse_field("./@vh", team_el)
        if not vh:
            continue
        name = parse_field("./@name", team_el)
        singles_won = int(parse_field("./totals/singles/@won", team_el) or 0)
        doubles_won = int(parse_field("./totals/doubles/@won", team_el) or 0)
        teams[vh] = {"name": name, "total_won": singles_won + doubles_won}

    # player_map: (vh, uni) -> {playerId, name, college}
    player_map = {}
    # player_by_name: (vh, lower(name)) -> same dict (fallback when uni missing)
    player_by_name = {}

    for team_el in html1.xpath("//team"):
        vh = parse_field("./@vh", team_el)
        college_name = parse_field("./@name", team_el)
        for p in team_el.xpath("./player"):
            uni = parse_field("./@uni", p)
            pid = parse_field("./@playerId", p)  # <-- third_party_id source
            name = parse_field("./@name", p)

            if uni:
                player_map[(vh, uni)] = {"playerId": pid, "name": name, "college": college_name}
            if name:
                player_by_name[(vh, name.strip().lower())] = {"playerId": pid, "name": name, "college": college_name}

    return teams, player_map, player_by_name


def resolve_player(vh, uni, name, player_map, player_by_name):
    uni = (uni or "").strip()
    name_key = (name or "").strip().lower()

    if uni and (vh, uni) in player_map:
        return player_map[(vh, uni)]
    if name_key and (vh, name_key) in player_by_name:
        return player_by_name[(vh, name_key)]
    return {"playerId": "", "name": (name or "").strip(), "college": ""}


def insert(*args, **kwargs):
    # keep your existing insert() if you want; this is just a placeholder
    # NOTE: ids are at positions in your signature; you already print them in your version.
    pass


def parse_data(season_type, season_id, event_id, event_url, event_gender_long, event_gender_short, event_score, html1):
    try:
        key = ""
        ball_type = "Yellow"
        date = tournament_end_date = tournament_start_date = parse_field("//tngame/@generated", html1)
        draw_bracket_type = ""
        draw_bracket_value = ""
        draw_gender = event_gender_long
        loser_1_gender = event_gender_short
        winner_1_gender = event_gender_short
        loser_2_gender = ""
        winner_2_gender = ""
        tournament_url = event_url
        draw_size = ""
        id_type = "Presto Sports"
        loser_1_city = ""
        loser_1_country = ""
        loser_1_dob = ""
        loser_1_state = ""
        loser_1_third_party_id = ""
        loser_2_city = ""
        loser_2_country = ""
        loser_2_dob = ""
        loser_2_state = ""
        loser_2_third_party_id = ""
        loser_team_type = "College"
        round = ""
        tournament_city = ""
        tournament_country = "USA"
        tournament_country_code = "USA"
        tournament_event_category = ""
        tournament_event_grade = ""
        tournament_event_type = "Dual Match"
        tournament_host = ""
        tournament_import_source = "College"
        tournament_location_type = ""
        tournament_sanction_body = "College"
        tournament_state = ""
        tournament_surface = ""
        winner_1_city = ""
        winner_1_country = ""
        winner_1_dob = ""
        winner_1_state = ""
        winner_1_third_party_id = ""
        winner_2_city = ""
        winner_2_country = ""
        winner_2_dob = ""
        winner_2_state = ""
        winner_2_third_party_id = ""
        winner_team_type = "College"
        draw_type = ""

        loser_2_name = ""
        loser_2_college = ""
        winner_2_name = ""
        winner_2_college = ""
        score = ""

        teams, player_map, player_by_name = build_teams_and_players(html1)
        if not teams:
            logger.error("No <team> nodes found. Make sure Selector(type='xml') is used and xml is valid.")
            return

        winner_vh = max(teams, key=lambda vh: teams[vh]["total_won"])
        loser_vh = min(teams, key=lambda vh: teams[vh]["total_won"])
        winner_team = teams[winner_vh]["name"]
        loser_team = teams[loser_vh]["name"]
        team_score = event_score

        tied_singles = {
            int(parse_field("./@pair", p) or 0): int(parse_field("./@tied", p) or 0)
            for p in html1.xpath('//team[@vh="V"]/totals/singles/singles_pair')
        }
        tied_doubles = {
            int(parse_field("./@pair", p) or 0): int(parse_field("./@tied", p) or 0)
            for p in html1.xpath('//team[@vh="V"]/totals/doubles/doubles_pair')
        }

        # =========================
        # SINGLES
        # =========================
        for m in html1.xpath("//singles_matches/singles_match"):
            winner_2_name = loser_2_name = ""
            winner_2_college = loser_2_college = ""
            winner_2_third_party_id = loser_2_third_party_id = ""

            match_no = int(parse_field("./@match", m) or 0)
            draw_name = f"#{match_no} Singles"
            draw_team_type = "Singles"

            score_data = {}
            for sc in m.xpath("./singles_score"):
                vh = parse_field("./@vh", sc)
                uni = parse_field("./@uni", sc)
                name = parse_field("./@name", sc)
                pdata = resolve_player(vh, uni, name, player_map, player_by_name)
                sets = [int(parse_field(f"./@set_{i}", sc) or 0) for i in range(1, 4)]
                score_data[vh] = {
                    "name": pdata.get("name", name),
                    "playerId": pdata.get("playerId", ""),  # <-- third_party_id
                    "college": pdata.get("college", teams.get(vh, {}).get("name", "")),
                    "sets": sets,
                }

            v_sets = score_data.get("V", {}).get("sets", [0, 0, 0])
            h_sets = score_data.get("H", {}).get("sets", [0, 0, 0])
            valid_sets = filter_valid_sets(v_sets, h_sets)

            status = "tie" if tied_singles.get(match_no, 0) == 1 else "completed"
            if status == "completed":
                v_wins = sum(v > h for v, h in valid_sets)
                h_wins = sum(h > v for v, h in valid_sets)
                winner_side, loser_side = ("V", "H") if v_wins > h_wins else ("H", "V")
                outcome = "Completed"
            else:
                winner_side, loser_side = "V", "H"
                outcome = "Tie"

            winner_info = score_data.get(winner_side, {})
            loser_info = score_data.get(loser_side, {})

            winner_1_third_party_id = winner_info.get("playerId", "")
            winner_1_name = winner_info.get("name", "")
            winner_1_college = winner_info.get("college", teams.get(winner_side, {}).get("name", ""))

            loser_1_third_party_id = loser_info.get("playerId", "")
            loser_1_name = loser_info.get("name", "")
            loser_1_college = loser_info.get("college", teams.get(loser_side, {}).get("name", ""))

            if status == "completed":
                score = ", ".join(reverse_number_with_larger_first(f"{v}-{h}") for v, h in valid_sets)
            else:
                score = ", ".join(f"{v}-{h}" for v, h in valid_sets)
            if score:
                score += ";"

            tournament_name = f"{tournament_event_type}: {winner_team} vs {loser_team}"

            insert(season_type, season_id, event_id, key, ball_type, date, draw_bracket_type,
                        draw_bracket_value, draw_gender, draw_name, draw_size, draw_team_type, draw_type, id_type,
                        loser_1_city, loser_1_college, loser_1_country, loser_1_dob, loser_1_gender, loser_1_name,
                        loser_1_state, loser_1_third_party_id, loser_2_city, loser_2_college, loser_2_country,
                        loser_2_dob, loser_2_gender, loser_2_name, loser_2_state, loser_2_third_party_id, loser_team,
                        loser_team_type, outcome, round, score, team_score, tournament_city, tournament_country,
                        tournament_country_code, tournament_end_date, tournament_event_category, tournament_event_grade,
                        tournament_event_type, tournament_host, tournament_import_source, tournament_location_type,
                        tournament_name, tournament_sanction_body, tournament_start_date, tournament_state,
                        tournament_surface, tournament_url, winner_1_city, winner_1_college, winner_1_country,
                        winner_1_dob, winner_1_gender, winner_1_name, winner_1_state, winner_1_third_party_id,
                        winner_2_city, winner_2_college, winner_2_country, winner_2_dob, winner_2_gender, winner_2_name,
                        winner_2_state, winner_2_third_party_id, winner_team, winner_team_type)

        # =========================
        # DOUBLES
        # =========================
        for m in html1.xpath("//doubles_matches/doubles_match"):
            match_no = int(parse_field("./@match", m) or 0)
            draw_name = f"#{match_no} Doubles"
            draw_team_type = "Doubles"

            v_list = m.xpath('./doubles_score[@vh="V"]')
            h_list = m.xpath('./doubles_score[@vh="H"]')
            if not v_list or not h_list:
                continue
            v_sc = v_list[0]
            h_sc = h_list[0]

            # uni + names from doubles_score
            v_uni_1 = parse_field("./@uni_1", v_sc)
            v_uni_2 = parse_field("./@uni_2", v_sc)
            h_uni_1 = parse_field("./@uni_1", h_sc)
            h_uni_2 = parse_field("./@uni_2", h_sc)

            v_name_1 = parse_field("./@name_1", v_sc)
            v_name_2 = parse_field("./@name_2", v_sc)
            h_name_1 = parse_field("./@name_1", h_sc)
            h_name_2 = parse_field("./@name_2", h_sc)

            v_p1 = resolve_player("V", v_uni_1, v_name_1, player_map, player_by_name)
            v_p2 = resolve_player("V", v_uni_2, v_name_2, player_map, player_by_name)
            h_p1 = resolve_player("H", h_uni_1, h_name_1, player_map, player_by_name)
            h_p2 = resolve_player("H", h_uni_2, h_name_2, player_map, player_by_name)

            v_sets = [int(parse_field(f"./@set_{i}", v_sc) or 0) for i in range(1, 4)]
            h_sets = [int(parse_field(f"./@set_{i}", h_sc) or 0) for i in range(1, 4)]
            valid_sets = filter_valid_sets(v_sets, h_sets)

            status = "tie" if tied_doubles.get(match_no, 0) == 1 else "completed"

            if status == "completed":
                v_wins = sum(v > h for v, h in valid_sets)
                h_wins = sum(h > v for v, h in valid_sets)
                if v_wins > h_wins:
                    winner_side = "V"
                    loser_side = "H"
                    w1, w2, l1, l2 = v_p1, v_p2, h_p1, h_p2
                else:
                    winner_side = "H"
                    loser_side = "V"
                    w1, w2, l1, l2 = h_p1, h_p2, v_p1, v_p2
                outcome = "Completed"
                score = ", ".join(reverse_number_with_larger_first(f"{v}-{h}") for v, h in valid_sets)
            else:
                # tie: keep V as "winner" slot (your old behavior), but ids still parsed
                winner_side = "V"
                loser_side = "H"
                w1, w2, l1, l2 = v_p1, v_p2, h_p1, h_p2
                outcome = "Tie"
                score = ", ".join(f"{v}-{h}" for v, h in valid_sets)

            winner_1_third_party_id = w1.get("playerId", "")
            winner_2_third_party_id = w2.get("playerId", "")
            loser_1_third_party_id = l1.get("playerId", "")
            loser_2_third_party_id = l2.get("playerId", "")

            winner_1_name = w1.get("name", "")
            winner_2_name = w2.get("name", "")
            loser_1_name = l1.get("name", "")
            loser_2_name = l2.get("name", "")

            winner_1_college = w1.get("college", teams.get(winner_side, {}).get("name", ""))
            winner_2_college = w2.get("college", teams.get(winner_side, {}).get("name", ""))
            loser_1_college = l1.get("college", teams.get(loser_side, {}).get("name", ""))
            loser_2_college = l2.get("college", teams.get(loser_side, {}).get("name", ""))

            if score:
                score += ";"

            loser_2_gender = event_gender_short
            winner_2_gender = event_gender_short

            tournament_name = f"{tournament_event_type}: {winner_team} vs {loser_team}"

            insert(season_type, season_id, event_id, key, ball_type, date, draw_bracket_type,
                        draw_bracket_value, draw_gender, draw_name, draw_size, draw_team_type, draw_type, id_type,
                        loser_1_city, loser_1_college, loser_1_country, loser_1_dob, loser_1_gender, loser_1_name,
                        loser_1_state, loser_1_third_party_id, loser_2_city, loser_2_college, loser_2_country,
                        loser_2_dob, loser_2_gender, loser_2_name, loser_2_state, loser_2_third_party_id, loser_team,
                        loser_team_type, outcome, round, score, team_score, tournament_city, tournament_country,
                        tournament_country_code, tournament_end_date, tournament_event_category, tournament_event_grade,
                        tournament_event_type, tournament_host, tournament_import_source, tournament_location_type,
                        tournament_name, tournament_sanction_body, tournament_start_date, tournament_state,
                        tournament_surface, tournament_url, winner_1_city, winner_1_college, winner_1_country,
                        winner_1_dob, winner_1_gender, winner_1_name, winner_1_state, winner_1_third_party_id,
                        winner_2_city, winner_2_college, winner_2_country, winner_2_dob, winner_2_gender, winner_2_name,
                        winner_2_state, winner_2_third_party_id, winner_team, winner_team_type)

    except Exception:
        logger.error(traceback.format_exc())

def insert(season_type, season_id, event_id, key, ball_type, date, draw_bracket_type, draw_bracket_value,
           draw_gender, draw_name, draw_size, draw_team_type, draw_type, id_type, loser_1_city, loser_1_college,
           loser_1_country, loser_1_dob, loser_1_gender, loser_1_name, loser_1_state, loser_1_third_party_id,
           loser_2_city, loser_2_college, loser_2_country, loser_2_dob, loser_2_gender, loser_2_name, loser_2_state,
           loser_2_third_party_id, loser_team, loser_team_type, outcome, round, score, team_score, tournament_city,
           tournament_country, tournament_country_code, tournament_end_date, tournament_event_category,
           tournament_event_grade, tournament_event_type, tournament_host, tournament_import_source,
           tournament_location_type, tournament_name, tournament_sanction_body, tournament_start_date,
           tournament_state, tournament_surface, tournament_url, winner_1_city, winner_1_college, winner_1_country,
           winner_1_dob, winner_1_gender, winner_1_name, winner_1_state, winner_1_third_party_id, winner_2_city,
           winner_2_college, winner_2_country, winner_2_dob, winner_2_gender, winner_2_name, winner_2_state,
           winner_2_third_party_id, winner_team, winner_team_type):

    print(f'season_type: {season_type}')
    print(f'season_id: {season_id}')
    print(f'event_id: {event_id}')
    print(f'key: {key}')
    print(f'ball_type: {ball_type}')
    print(f'date: {date}')
    print(f'draw_bracket_type: {draw_bracket_type}')
    print(f'draw_bracket_value: {draw_bracket_value}')
    print(f'draw_gender: {draw_gender}')
    print(f'draw_name: {draw_name}')
    print(f'draw_size: {draw_size}')
    print(f'draw_team_type: {draw_team_type}')
    print(f'draw_type: {draw_type}')
    print(f'id_type: {id_type}')
    print(f'loser_1_city: {loser_1_city}')
    print(f'loser_1_college: {loser_1_college}')
    print(f'loser_1_country: {loser_1_country}')
    print(f'loser_1_dob: {loser_1_dob}')
    print(f'loser_1_gender: {loser_1_gender}')
    print(f'loser_1_name: {loser_1_name}')
    print(f'loser_1_state: {loser_1_state}')
    print(f'loser_1_third_party_id: {loser_1_third_party_id}')
    print(f'loser_2_city: {loser_2_city}')
    print(f'loser_2_college: {loser_2_college}')
    print(f'loser_2_country: {loser_2_country}')
    print(f'loser_2_dob: {loser_2_dob}')
    print(f'loser_2_gender: {loser_2_gender}')
    print(f'loser_2_name: {loser_2_name}')
    print(f'loser_2_state: {loser_2_state}')
    print(f'loser_2_third_party_id: {loser_2_third_party_id}')
    print(f'loser_team: {loser_team}')
    print(f'loser_team_type: {loser_team_type}')
    print(f'outcome: {outcome}')
    print(f'round: {round}')
    print(f'score: {score}')
    print(f'team_score: {team_score}')
    print(f'tournament_city: {tournament_city}')
    print(f'tournament_country: {tournament_country}')
    print(f'tournament_country_code: {tournament_country_code}')
    print(f'tournament_end_date: {tournament_end_date}')
    print(f'tournament_event_category: {tournament_event_category}')
    print(f'tournament_event_grade: {tournament_event_grade}')
    print(f'tournament_event_type: {tournament_event_type}')
    print(f'tournament_host: {tournament_host}')
    print(f'tournament_import_source: {tournament_import_source}')
    print(f'tournament_location_type: {tournament_location_type}')
    print(f'tournament_name: {tournament_name}')
    print(f'tournament_sanction_body: {tournament_sanction_body}')
    print(f'tournament_start_date: {tournament_start_date}')
    print(f'tournament_state: {tournament_state}')
    print(f'tournament_surface: {tournament_surface}')
    print(f'tournament_url: {tournament_url}')
    print(f'winner_1_city: {winner_1_city}')
    print(f'winner_1_college: {winner_1_college}')
    print(f'winner_1_country: {winner_1_country}')
    print(f'winner_1_dob: {winner_1_dob}')
    print(f'winner_1_gender: {winner_1_gender}')
    print(f'winner_1_name: {winner_1_name}')
    print(f'winner_1_state: {winner_1_state}')
    print(f'winner_1_third_party_id: {winner_1_third_party_id}')
    print(f'winner_2_city: {winner_2_city}')
    print(f'winner_2_college: {winner_2_college}')
    print(f'winner_2_country: {winner_2_country}')
    print(f'winner_2_dob: {winner_2_dob}')
    print(f'winner_2_gender: {winner_2_gender}')
    print(f'winner_2_name: {winner_2_name}')
    print(f'winner_2_state: {winner_2_state}')
    print(f'winner_2_third_party_id: {winner_2_third_party_id}')
    print(f'winner_team: {winner_team}')
    print(f'winner_team_type: {winner_team_type}')
    print("-" * 60)

if __name__ == "__main__":
    login_username = 'salman.bader@utrsports.com'
    login_password = 'ulussigh'

    headers = {
        'accept': '*/*',
        'Content-Type': 'application/json',
    }
    json_data = {
        'username': login_username,
        'password': login_password,
    }
    index_link = 'https://gameday-api.prestosports.com/api/auth/token'
    response1 = requests.post(index_link, headers=headers, json=json_data)
    results1 = response1.json()
    token = results1.get('idToken', '')

    headers = {
        'accept': 'application/json',
        'Authorization': f'Bearer {token}',
    }

    event_id = "855ph0gihug2mnzy"
    event_url = f"https://gameday-api.prestosports.com/api/events/{event_id}/stats/"
    # response1 = {"data":{"eventId":"2umif7b9iwqv05a0","status":"Final","xml":"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<tngame source=\"PrestoSports\" version=\"7.6.0\" generated=\"09/21/2025\"> \n  <venue gameid=\"2umif7b9iwqv05a0\" visid=\"405huohj3xf1gwpx\" visname=\"Judson (IL)\" homeid=\"i766p0ccjjj6drqk\" homename=\"Indiana Wesleyan (IN)\" date=\"09/20/2025\" location=\"\" arena=\"\" time=\"01:00 PM EDT\" duration=\"02:00:00\" schednote=\"\" attend=\"\" leaguegame=\"N\" regiongame=\"N\" neutralgame=\"N\" nitegame=\"N\" postseason=\"N\" forcehome=\"N/A\" tournament=\"N/A\" tournamentname=\"N/A\"> \n    <officials/>  \n    <rules doublesone=\"1\" doublestwo=\"0\" indivonly=\"0\" suspended=\"0\" format=\"1\" squash=\"0\" forfeit=\"\"/>  \n    <notes>Indiana Wesleyan University</notes> \n  </venue>  \n  <team vh=\"V\" id=\"405huohj3xf1gwpx\" name=\"Judson (IL)\" code=\"NAIA1006\"> \n    <totals score=\"0\"> \n      <singles won=\"0\" lost=\"6\" tied=\"0\"> \n        <singles_pair pair=\"1\" won=\"0\" lost=\"1\" tied=\"0\"/>  \n        <singles_pair pair=\"2\" won=\"0\" lost=\"1\" tied=\"0\"/>  \n        <singles_pair pair=\"3\" won=\"0\" lost=\"1\" tied=\"0\"/>  \n        <singles_pair pair=\"4\" won=\"0\" lost=\"1\" tied=\"0\"/>  \n        <singles_pair pair=\"5\" won=\"0\" lost=\"1\" tied=\"0\"/>  \n        <singles_pair pair=\"6\" won=\"0\" lost=\"1\" tied=\"0\"/> \n      </singles>  \n      <doubles won=\"0\" lost=\"3\" tied=\"0\"> \n        <doubles_pair pair=\"1\" won=\"0\" lost=\"1\" tied=\"0\"/>  \n        <doubles_pair pair=\"2\" won=\"0\" lost=\"1\" tied=\"0\"/>  \n        <doubles_pair pair=\"3\" won=\"0\" lost=\"1\" tied=\"0\"/> \n      </doubles> \n    </totals>  \n    <player uni=\"07\" playerId=\"j3kibedqr9ffphij\" code=\"\" name=\"Nicol Valeria Torres Villamil\" checkname=\"VALERIA TORRES VILLAMIL,NICOL\" gp=\"1\"> \n      <singles won=\"0\" lost=\"1\" tied=\"0\"> \n        <singles_pair pair=\"4\" won=\"0\" lost=\"1\" tied=\"0\"/> \n      </singles>  \n      <doubles won=\"0\" lost=\"1\" tied=\"0\"> \n        <doubles_pair pair=\"2\" won=\"0\" lost=\"1\" tied=\"0\"/> \n      </doubles> \n    </player>  \n    <player uni=\"03\" playerId=\"7cc0fl0l1n0nafxb\" code=\"\" name=\"Ruth Hernandez\" checkname=\"HERNANDEZ,RUTH\" gp=\"1\"> \n      <singles won=\"0\" lost=\"1\" tied=\"0\"> \n        <singles_pair pair=\"3\" won=\"0\" lost=\"1\" tied=\"0\"/> \n      </singles>  \n      <doubles won=\"0\" lost=\"1\" tied=\"0\"> \n        <doubles_pair pair=\"2\" won=\"0\" lost=\"1\" tied=\"0\"/> \n      </doubles> \n    </player>  \n    <player uni=\"08\" playerId=\"cl81kbsg0c72ymne\" code=\"\" name=\"Mackenzie Meland\" checkname=\"MELAND,MACKENZIE\" gp=\"1\"> \n      <singles won=\"0\" lost=\"1\" tied=\"0\"> \n        <singles_pair pair=\"5\" won=\"0\" lost=\"1\" tied=\"0\"/> \n      </singles>  \n      <doubles won=\"0\" lost=\"0\" tied=\"0\"/> \n    </player>  \n    <player uni=\"01\" playerId=\"w9jtcdqdyh8ll7b2\" code=\"\" name=\"Erin Jacobs\" checkname=\"JACOBS,ERIN\" gp=\"1\"> \n      <singles won=\"0\" lost=\"1\" tied=\"0\"> \n        <singles_pair pair=\"2\" won=\"0\" lost=\"1\" tied=\"0\"/> \n      </singles>  \n      <doubles won=\"0\" lost=\"1\" tied=\"0\"> \n        <doubles_pair pair=\"1\" won=\"0\" lost=\"1\" tied=\"0\"/> \n      </doubles> \n    </player>  \n    <player uni=\"NA\" playerId=\"85zwm7xc7m0dnacp\" code=\"\" name=\"No Player undefined\" checkname=\"UNDEFINED,NO PLAYER\" gp=\"0\"/>  \n    <player uni=\"TM\" playerId=\"TM-13a46e71-3e73-4769-aee0-34d66eeea3ac\" code=\"\" name=\"Team undefined\" checkname=\"UNDEFINED,TEAM\" gp=\"0\"/>  \n    <player uni=\"04\" playerId=\"4kk6hp3hnilxzx3a\" code=\"\" name=\"Anna Illes\" checkname=\"ILLES,ANNA\" gp=\"1\"> \n      <singles won=\"0\" lost=\"1\" tied=\"0\"> \n        <singles_pair pair=\"6\" won=\"0\" lost=\"1\" tied=\"0\"/> \n      </singles>  \n      <doubles won=\"0\" lost=\"0\" tied=\"0\"/> \n    </player>  \n    <player uni=\"05\" playerId=\"f4qij9vwz8t1wrsp\" code=\"\" name=\"Carla Guerrero\" checkname=\"GUERRERO,CARLA\" gp=\"0\"/>  \n    <player uni=\"06\" playerId=\"85zwm7xc7m0dnacp\" code=\"\" name=\"Ava Vardaros\" checkname=\"VARDAROS,AVA\" gp=\"0\"/>  \n    <player uni=\"TM\" playerId=\"TM-dfd6afcd-bb9f-4e1c-8055-fe4d15d40804\" code=\"\" name=\"Team undefined\" checkname=\"UNDEFINED,TEAM\" gp=\"0\"/>  \n    <player uni=\"NA\" playerId=\"NA-dfd6afcd-bb9f-4e1c-8055-fe4d15d40804\" code=\"\" name=\"No Player undefined\" checkname=\"UNDEFINED,NO PLAYER\" gp=\"1\"> \n      <singles won=\"0\" lost=\"0\" tied=\"0\"/>  \n      <doubles won=\"0\" lost=\"1\" tied=\"0\"> \n        <doubles_pair pair=\"3\" won=\"0\" lost=\"1\" tied=\"0\"/> \n      </doubles> \n    </player>  \n    <player uni=\"02\" playerId=\"83bton559ntah9ku\" code=\"\" name=\"Charlie Stirling\" checkname=\"STIRLING,CHARLIE\" gp=\"1\"> \n      <singles won=\"0\" lost=\"1\" tied=\"0\"> \n        <singles_pair pair=\"1\" won=\"0\" lost=\"1\" tied=\"0\"/> \n      </singles>  \n      <doubles won=\"0\" lost=\"1\" tied=\"0\"> \n        <doubles_pair pair=\"1\" won=\"0\" lost=\"1\" tied=\"0\"/> \n      </doubles> \n    </player> \n  </team>  \n  <team vh=\"H\" id=\"i766p0ccjjj6drqk\" name=\"Indiana Wesleyan (IN)\" code=\"NAIA906\"> \n    <totals score=\"7\"> \n      <singles won=\"6\" lost=\"0\" tied=\"0\"> \n        <singles_pair pair=\"1\" won=\"1\" lost=\"0\" tied=\"0\"/>  \n        <singles_pair pair=\"2\" won=\"1\" lost=\"0\" tied=\"0\"/>  \n        <singles_pair pair=\"3\" won=\"1\" lost=\"0\" tied=\"0\"/>  \n        <singles_pair pair=\"4\" won=\"1\" lost=\"0\" tied=\"0\"/>  \n        <singles_pair pair=\"5\" won=\"1\" lost=\"0\" tied=\"0\"/>  \n        <singles_pair pair=\"6\" won=\"1\" lost=\"0\" tied=\"0\"/> \n      </singles>  \n      <doubles won=\"3\" lost=\"0\" tied=\"0\"> \n        <doubles_pair pair=\"1\" won=\"1\" lost=\"0\" tied=\"0\"/>  \n        <doubles_pair pair=\"2\" won=\"1\" lost=\"0\" tied=\"0\"/>  \n        <doubles_pair pair=\"3\" won=\"1\" lost=\"0\" tied=\"0\"/> \n      </doubles> \n    </totals>  \n    <player uni=\"auto_61p31z6936yf4ywc\" playerId=\"61p31z6936yf4ywc\" code=\"\" name=\"Madison Peacock\" checkname=\"PEACOCK,MADISON\" gp=\"0\"/>  \n    <player uni=\"auto_ghtcb2c7xs6l7csw\" playerId=\"ghtcb2c7xs6l7csw\" code=\"\" name=\"Paige Riegsecker\" checkname=\"RIEGSECKER,PAIGE\" gp=\"0\"/>  \n    <player uni=\"auto_bxdxber7hk358zbb\" playerId=\"bxdxber7hk358zbb\" code=\"\" name=\"Michaela Cook\" checkname=\"COOK,MICHAELA\" gp=\"0\"/>  \n    <player uni=\"auto_5edkmre4x0kwlv6z\" playerId=\"5edkmre4x0kwlv6z\" code=\"\" name=\"Maria Downs\" checkname=\"DOWNS,MARIA\" gp=\"0\"/>  \n    <player uni=\"auto_a2hp5zw0cwo3wnkg\" playerId=\"a2hp5zw0cwo3wnkg\" code=\"\" name=\"Danica Kuntz\" checkname=\"KUNTZ,DANICA\" gp=\"0\"/>  \n    <player uni=\"NA\" playerId=\"NA-307c2901-94a1-4f3c-9c83-15c5c715651d\" code=\"\" name=\"No Player undefined\" checkname=\"UNDEFINED,NO PLAYER\" gp=\"0\"/>  \n    <player uni=\"auto_0b1jb7mw7tha1t65\" playerId=\"0b1jb7mw7tha1t65\" code=\"\" name=\"Sarah Harmelink\" checkname=\"HARMELINK,SARAH\" gp=\"0\"/>  \n    <player uni=\"auto_j4j7cspmobm1eym0\" playerId=\"j4j7cspmobm1eym0\" code=\"\" name=\"Meribel Jarna\" checkname=\"JARNA,MERIBEL\" gp=\"1\"> \n      <singles won=\"1\" lost=\"0\" tied=\"0\"> \n        <singles_pair pair=\"3\" won=\"1\" lost=\"0\" tied=\"0\"/> \n      </singles>  \n      <doubles won=\"1\" lost=\"0\" tied=\"0\"> \n        <doubles_pair pair=\"2\" won=\"1\" lost=\"0\" tied=\"0\"/> \n      </doubles> \n    </player>  \n    <player uni=\"auto_r1ncgy5jf4s622ci\" playerId=\"r1ncgy5jf4s622ci\" code=\"\" name=\"Emily Cox\" checkname=\"COX,EMILY\" gp=\"0\"/>  \n    <player uni=\"auto_c5np2lvcbp4pfsuq\" playerId=\"c5np2lvcbp4pfsuq\" code=\"\" name=\"Katie Parr\" checkname=\"PARR,KATIE\" gp=\"1\"> \n      <singles won=\"1\" lost=\"0\" tied=\"0\"> \n        <singles_pair pair=\"4\" won=\"1\" lost=\"0\" tied=\"0\"/> \n      </singles>  \n      <doubles won=\"1\" lost=\"0\" tied=\"0\"> \n        <doubles_pair pair=\"2\" won=\"1\" lost=\"0\" tied=\"0\"/> \n      </doubles> \n    </player>  \n    <player uni=\"auto_1w22yhaxgbvx701w\" playerId=\"1w22yhaxgbvx701w\" code=\"\" name=\"Emma Vanpuffelen\" checkname=\"VANPUFFELEN,EMMA\" gp=\"0\"/>  \n    <player uni=\"auto_oplpzl54glv8thzj\" playerId=\"oplpzl54glv8thzj\" code=\"\" name=\"Sofia Munoz\" checkname=\"MUNOZ,SOFIA\" gp=\"1\"> \n      <singles won=\"1\" lost=\"0\" tied=\"0\"> \n        <singles_pair pair=\"1\" won=\"1\" lost=\"0\" tied=\"0\"/> \n      </singles>  \n      <doubles won=\"1\" lost=\"0\" tied=\"0\"> \n        <doubles_pair pair=\"1\" won=\"1\" lost=\"0\" tied=\"0\"/> \n      </doubles> \n    </player>  \n    <player uni=\"auto_seqrvus2h91mksv0\" playerId=\"seqrvus2h91mksv0\" code=\"\" name=\"Audrey Gregg\" checkname=\"GREGG,AUDREY\" gp=\"1\"> \n      <singles won=\"1\" lost=\"0\" tied=\"0\"> \n        <singles_pair pair=\"6\" won=\"1\" lost=\"0\" tied=\"0\"/> \n      </singles>  \n      <doubles won=\"0\" lost=\"0\" tied=\"0\"/> \n    </player>  \n    <player uni=\"auto_5wva23b6uwmkjlxs\" playerId=\"5wva23b6uwmkjlxs\" code=\"\" name=\"Maria Oliveira\" checkname=\"OLIVEIRA,MARIA\" gp=\"1\"> \n      <singles won=\"0\" lost=\"0\" tied=\"0\"/>  \n      <doubles won=\"1\" lost=\"0\" tied=\"0\"> \n        <doubles_pair pair=\"3\" won=\"1\" lost=\"0\" tied=\"0\"/> \n      </doubles> \n    </player>  \n    <player uni=\"TM\" playerId=\"TM-307c2901-94a1-4f3c-9c83-15c5c715651d\" code=\"\" name=\"Team undefined\" checkname=\"UNDEFINED,TEAM\" gp=\"0\"/>  \n    <player uni=\"auto_6q5m9yhvb05g2aut\" playerId=\"6q5m9yhvb05g2aut\" code=\"\" name=\"Lauren Dick\" checkname=\"DICK,LAUREN\" gp=\"1\"> \n      <singles won=\"1\" lost=\"0\" tied=\"0\"> \n        <singles_pair pair=\"5\" won=\"1\" lost=\"0\" tied=\"0\"/> \n      </singles>  \n      <doubles won=\"1\" lost=\"0\" tied=\"0\"> \n        <doubles_pair pair=\"3\" won=\"1\" lost=\"0\" tied=\"0\"/> \n      </doubles> \n    </player>  \n    <player uni=\"auto_f131cw5rlyzhinl6\" playerId=\"f131cw5rlyzhinl6\" code=\"\" name=\"Nicole Puga\" checkname=\"PUGA,NICOLE\" gp=\"1\"> \n      <singles won=\"1\" lost=\"0\" tied=\"0\"> \n        <singles_pair pair=\"2\" won=\"1\" lost=\"0\" tied=\"0\"/> \n      </singles>  \n      <doubles won=\"1\" lost=\"0\" tied=\"0\"> \n        <doubles_pair pair=\"1\" won=\"1\" lost=\"0\" tied=\"0\"/> \n      </doubles> \n    </player>  \n    <player uni=\"auto_lzm2agsw1hkx64kf\" playerId=\"lzm2agsw1hkx64kf\" code=\"\" name=\"Mary Grenda\" checkname=\"GRENDA,MARY\" gp=\"0\"/>  \n    <player uni=\"auto_upux8tpr59sv7og9\" playerId=\"upux8tpr59sv7og9\" code=\"\" name=\"Britton Jesse\" checkname=\"JESSE,BRITTON\" gp=\"0\"/> \n  </team>  \n  <singles_matches> \n    <singles_match match=\"1\" order=\"0\" asflight=\"\" touropp=\"\"> \n      <singles_score vh=\"V\" uni=\"02\" name=\"Charlie Stirling\" set_1=\"0\" set_2=\"1\" set_3=\"0\" game_set_1=\"0\" game_set_2=\"1\"/>  \n      <singles_score vh=\"H\" uni=\"auto_oplpzl54glv8thzj\" name=\"Sofia Munoz\" set_1=\"6\" set_2=\"6\" set_3=\"0\" game_set_1=\"6\" game_set_2=\"6\"/> \n    </singles_match>  \n    <singles_match match=\"2\" order=\"1\" asflight=\"\" touropp=\"\" tiebreak=\"pts\"> \n      <singles_score vh=\"V\" uni=\"01\" name=\"Erin Jacobs\" set_1=\"6\" set_2=\"3\" set_3=\"0\" tiebreakScore=\"4\" game_set_1=\"6\" game_set_2=\"3\"/>  \n      <singles_score vh=\"H\" uni=\"auto_f131cw5rlyzhinl6\" name=\"Nicole Puga\" set_1=\"2\" set_2=\"6\" set_3=\"0\" tiebreakScore=\"10\" game_set_1=\"2\" game_set_2=\"6\"/> \n    </singles_match>  \n    <singles_match match=\"3\" order=\"2\" asflight=\"\" touropp=\"\"> \n      <singles_score vh=\"V\" uni=\"03\" name=\"Ruth Hernandez\" set_1=\"0\" set_2=\"4\" set_3=\"0\" game_set_1=\"0\" game_set_2=\"4\"/>  \n      <singles_score vh=\"H\" uni=\"auto_j4j7cspmobm1eym0\" name=\"Meribel Jarna\" set_1=\"6\" set_2=\"6\" set_3=\"0\" game_set_1=\"6\" game_set_2=\"6\"/> \n    </singles_match>  \n    <singles_match match=\"4\" order=\"3\" asflight=\"\" touropp=\"\"> \n      <singles_score vh=\"V\" uni=\"07\" name=\"Nicol Valeria Torres Villamil\" set_1=\"1\" set_2=\"1\" set_3=\"0\" game_set_1=\"1\" game_set_2=\"1\"/>  \n      <singles_score vh=\"H\" uni=\"auto_c5np2lvcbp4pfsuq\" name=\"Katie Parr\" set_1=\"6\" set_2=\"6\" set_3=\"0\" game_set_1=\"6\" game_set_2=\"6\"/> \n    </singles_match>  \n    <singles_match match=\"5\" order=\"4\" asflight=\"\" touropp=\"\"> \n      <singles_score vh=\"V\" uni=\"08\" name=\"Mackenzie Meland\" set_1=\"0\" set_2=\"0\" set_3=\"0\" game_set_1=\"0\" game_set_2=\"0\"/>  \n      <singles_score vh=\"H\" uni=\"auto_6q5m9yhvb05g2aut\" name=\"Lauren Dick\" set_1=\"6\" set_2=\"6\" set_3=\"0\" game_set_1=\"6\" game_set_2=\"6\"/> \n    </singles_match>  \n    <singles_match match=\"6\" order=\"5\" asflight=\"\" touropp=\"\"> \n      <singles_score vh=\"V\" uni=\"04\" name=\"Anna Illes\" set_1=\"0\" set_2=\"0\" set_3=\"0\" game_set_1=\"0\" game_set_2=\"0\"/>  \n      <singles_score vh=\"H\" uni=\"auto_seqrvus2h91mksv0\" name=\"Audrey Gregg\" set_1=\"6\" set_2=\"6\" set_3=\"0\" game_set_1=\"6\" game_set_2=\"6\"/> \n    </singles_match> \n  </singles_matches>  \n  <doubles_matches> \n    <doubles_match match=\"1\" order=\"0\" asflight=\"\" touropp=\"\"> \n      <doubles_score vh=\"V\" uni_1=\"01\" uni_2=\"02\" name_1=\"Erin Jacobs\" name_2=\"Charlie Stirling\" set_1=\"1\" game_set_1=\"1\"/>  \n      <doubles_score vh=\"H\" uni_1=\"auto_oplpzl54glv8thzj\" uni_2=\"auto_f131cw5rlyzhinl6\" name_1=\"Sofia Munoz\" name_2=\"Nicole Puga\" set_1=\"6\" game_set_1=\"6\"/> \n    </doubles_match>  \n    <doubles_match match=\"2\" order=\"1\" asflight=\"\" touropp=\"\"> \n      <doubles_score vh=\"V\" uni_1=\"03\" uni_2=\"07\" name_1=\"Ruth Hernandez\" name_2=\"Nicol Valeria Torres Villamil\" set_1=\"1\" game_set_1=\"1\"/>  \n      <doubles_score vh=\"H\" uni_1=\"auto_j4j7cspmobm1eym0\" uni_2=\"auto_c5np2lvcbp4pfsuq\" name_1=\"Meribel Jarna\" name_2=\"Katie Parr\" set_1=\"6\" game_set_1=\"6\"/> \n    </doubles_match>  \n    <doubles_match match=\"3\" order=\"2\" asflight=\"\" touropp=\"\"> \n      <doubles_score vh=\"V\" uni_1=\"NA\" uni_2=\"\" name_1=\"No Player\" name_2=\"\" set_1=\"0\"/>  \n      <doubles_score vh=\"H\" uni_1=\"auto_5wva23b6uwmkjlxs\" uni_2=\"auto_6q5m9yhvb05g2aut\" name_1=\"Maria Oliveira\" name_2=\"Lauren Dick\" set_1=\"0\"/> \n    </doubles_match> \n  </doubles_matches>  \n  <status desc=\"Final\" code=\"0\"/> \n</tngame>"}}
    response1 = requests.get(event_url, headers=headers)
    print(response1.json())
    response1 = response1.json()

    xml_str = response1["data"]["xml"]

    # IMPORTANT: use type="xml" so //team, @playerId, etc works
    html1 = Selector(text=xml_str, type="xml")

    parse_data(
        season_type="men",
        season_id="kxetzl72d99ilqa9",
        event_id=event_id,
        event_url=event_url,
        event_gender_long="Male",
        event_gender_short="M",
        event_score="0-0;",
        html1=html1,
    )
