import traceback
from openai import OpenAI
from django.db import close_old_connections
from django.conf import settings
from scrapy.selector import Selector
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts import helper
from app_spiders.models import JobsItemsPrestosportsModel, tournamentsModel


class DetailsParser:

    def __init__(self, token, thread_id):
        self.thread_id = thread_id
        self.token = token
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=True, use_proxy=self.use_proxy)

        self.ai_client = OpenAI(api_key=settings.API_KEYS[self.thread_id])

        self.seen_rows = getattr(self, "seen_rows", set())


    def parse_site(self, spider_id, job_id, events_chunk, main_task, thread_task, progress):
        try:
            for event_data in events_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    headers = {
                        'accept': 'application/json',
                        'Authorization': f'Bearer {self.token}',
                    }

                    season_type = event_data.get("season_type", "")
                    season_id = event_data.get("season_id", "")
                    event_id = event_data.get("event_id", "")
                    event_gender_long = event_data.get("event_gender_long", "")
                    event_gender_short = event_data.get("event_gender_short", "")
                    event_score = event_data.get("event_score", "")

                    # event_id = '2umif7b9iwqv05a0'
                    if event_id:
                        event_url = f'https://gameday-api.prestosports.com/api/events/{event_id}/stats/'
                        if not tournamentsModel.objects.filter(tournament_url=event_url).exists():
                            logger.info(f'new: event_id: {event_id} | tournament_url: {event_url}')
                            response1 = self.fctrequest.request(method='GET', link=event_url, headers=headers, proxies=self.proxies, tries=3)
                            if response1:
                                if response1.status_code in range(200, 300):
                                    html1 = None
                                    try:
                                        xml_str = response1.json()["data"]["xml"]
                                        html1 = Selector(text=xml_str, type="xml")
                                    except Exception:
                                        ''

                                    if html1:
                                        row_key = f"{event_id}"
                                        if row_key not in self.seen_rows:
                                            self.parse_data(spider_id, job_id, season_type, season_id, event_id, event_url, event_gender_long, event_gender_short, event_score, html1)
                                            self.seen_rows.add(row_key)
                                            tournamentsModel(tournament_url=event_url).save()

                        else:
                            logger.warning(f'exist: event_id: {event_id} | tournament_url: {event_url}')

                except Exception:
                    logger.error(traceback.format_exc())
        except Exception:
            logger.error(traceback.format_exc())


    def parse_data(self, spider_id, job_id, season_type, season_id, event_id, event_url, event_gender_long, event_gender_short, event_score, html1):
        try:
            key = ''
            ball_type = 'Yellow'
            date = tournament_end_date = tournament_start_date = fctcore.parse_field('//tngame/@generated', html1)
            draw_bracket_type = ''
            draw_bracket_value = ''
            draw_gender = tournament_gender = event_gender_long
            loser_1_gender = event_gender_short
            winner_1_gender = event_gender_short
            loser_2_gender = ''
            winner_2_gender = ''
            tournament_url = event_url
            draw_size = ''
            id_type = 'Presto Sports'
            loser_1_city = ''
            loser_1_country = ''
            loser_1_dob = ''
            loser_1_state = ''
            loser_1_third_party_id = ''
            loser_2_city = ''
            loser_2_country = ''
            loser_2_dob = ''
            loser_2_state = ''
            loser_2_third_party_id = ''
            loser_team_type = 'College'
            round = ''
            tournament_city = ''
            tournament_country = 'USA'
            tournament_country_code = 'USA'
            tournament_event_category = ''
            tournament_event_grade = ''
            tournament_event_type = 'Dual Match'
            tournament_host = ''
            tournament_import_source = 'College'
            tournament_location_type = ''
            tournament_name = ''
            tournament_sanction_body = 'College'
            tournament_state = ''
            tournament_surface = ''
            winner_1_city = ''
            winner_1_country = ''
            winner_1_dob = ''
            winner_1_state = ''
            winner_1_third_party_id = ''
            winner_2_city = ''
            winner_2_country = ''
            winner_2_dob = ''
            winner_2_state = ''
            winner_2_third_party_id = ''
            winner_team_type = 'College'
            draw_type = ''

            loser_2_name = ''
            loser_2_college = ''
            winner_2_name = ''
            winner_2_college = ''
            score = ''

            teams, player_map, player_by_name = self.build_teams_and_players(html1)
            if not teams:
                logger.error("No <team> nodes found. Make sure Selector(type='xml') is used and xml is valid.")
                return

            winner_vh = max(teams, key=lambda vh: teams[vh]["total_won"])
            loser_vh = min(teams, key=lambda vh: teams[vh]["total_won"])
            winner_team = helper.get_official_college_name(teams[winner_vh]["name"], self.ai_client)
            loser_team = helper.get_official_college_name(teams[loser_vh]["name"], self.ai_client)
            team_score = event_score

            try:
                tournament_name = f'{tournament_event_type}: {winner_team} vs {loser_team} - {tournament_gender}'
            except Exception:
                ''

            tied_singles = {
                int(fctcore.parse_field("./@pair", p) or 0): int(fctcore.parse_field("./@tied", p) or 0)
                for p in html1.xpath('//team[@vh="V"]/totals/singles/singles_pair')
            }
            tied_doubles = {
                int(fctcore.parse_field("./@pair", p) or 0): int(fctcore.parse_field("./@tied", p) or 0)
                for p in html1.xpath('//team[@vh="V"]/totals/doubles/doubles_pair')
            }

            # =========================
            # SINGLES
            # =========================
            for m in html1.xpath("//singles_matches/singles_match"):
                winner_2_name = loser_2_name = ""
                winner_2_college = loser_2_college = ""
                winner_2_third_party_id = loser_2_third_party_id = ""

                match_no = int(fctcore.parse_field("./@match", m) or 0)
                draw_name = f"#{match_no} Singles"
                draw_team_type = "Singles"

                score_data = {}
                for sc in m.xpath("./singles_score"):
                    vh = fctcore.parse_field("./@vh", sc)
                    uni = fctcore.parse_field("./@uni", sc)
                    name = fctcore.parse_field("./@name", sc)
                    pdata = self.resolve_player(vh, uni, name, player_map, player_by_name)
                    sets = [int(fctcore.parse_field(f"./@set_{i}", sc) or 0) for i in range(1, 4)]
                    score_data[vh] = {
                        "name": pdata.get("name", name),
                        "playerId": pdata.get("playerId", ""),  # <-- third_party_id
                        "college": pdata.get("college", teams.get(vh, {}).get("name", "")),
                        "sets": sets,
                    }

                v_sets = score_data.get("V", {}).get("sets", [0, 0, 0])
                h_sets = score_data.get("H", {}).get("sets", [0, 0, 0])
                valid_sets = self.filter_valid_sets(v_sets, h_sets)

                status = "tie" if tied_singles.get(match_no, 0) == 1 else "completed"
                if status == "completed":
                    v_wins = sum(v > h for v, h in valid_sets)
                    h_wins = sum(h > v for v, h in valid_sets)
                    winner_side, loser_side = ("V", "H") if v_wins > h_wins else ("H", "V")
                    outcome = "Completed"
                else:
                    winner_side, loser_side = "V", "H"
                    outcome = "Tie"

                winner_info = score_data.get(winner_side, {})
                loser_info = score_data.get(loser_side, {})

                winner_1_third_party_id = winner_info.get("playerId", "")
                winner_1_name = winner_info.get("name", "")
                winner_1_college = helper.get_official_college_name(winner_info.get("college", teams.get(winner_side, {}).get("name", "")), self.ai_client)

                loser_1_third_party_id = loser_info.get("playerId", "")
                loser_1_name = loser_info.get("name", "")
                loser_1_college = helper.get_official_college_name(loser_info.get("college", teams.get(loser_side, {}).get("name", "")), self.ai_client)

                if status == "completed":
                    score = ", ".join(self.reverse_number_with_larger_first(f"{v}-{h}") for v, h in valid_sets)
                else:
                    score = ", ".join(f"{v}-{h}" for v, h in valid_sets)
                if score:
                    score += ";"

                self.insert(spider_id, job_id, season_type, season_id, event_id, key, ball_type, date, draw_bracket_type,
                       draw_bracket_value, draw_gender, draw_name, draw_size, draw_team_type, draw_type, id_type,
                       loser_1_city, loser_1_college, loser_1_country, loser_1_dob, loser_1_gender, loser_1_name,
                       loser_1_state, loser_1_third_party_id, loser_2_city, loser_2_college, loser_2_country,
                       loser_2_dob, loser_2_gender, loser_2_name, loser_2_state, loser_2_third_party_id, loser_team,
                       loser_team_type, outcome, round, score, team_score, tournament_city, tournament_country,
                       tournament_country_code, tournament_end_date, tournament_event_category, tournament_event_grade,
                       tournament_event_type, tournament_host, tournament_import_source, tournament_location_type,
                       tournament_name, tournament_sanction_body, tournament_start_date, tournament_state,
                       tournament_surface, tournament_url, winner_1_city, winner_1_college, winner_1_country,
                       winner_1_dob, winner_1_gender, winner_1_name, winner_1_state, winner_1_third_party_id,
                       winner_2_city, winner_2_college, winner_2_country, winner_2_dob, winner_2_gender, winner_2_name,
                       winner_2_state, winner_2_third_party_id, winner_team, winner_team_type)

            # =========================
            # DOUBLES
            # =========================
            for m in html1.xpath("//doubles_matches/doubles_match"):
                match_no = int(fctcore.parse_field("./@match", m) or 0)
                draw_name = f"#{match_no} Doubles"
                draw_team_type = "Doubles"

                v_list = m.xpath('./doubles_score[@vh="V"]')
                h_list = m.xpath('./doubles_score[@vh="H"]')
                if not v_list or not h_list:
                    continue
                v_sc = v_list[0]
                h_sc = h_list[0]

                # uni + names from doubles_score
                v_uni_1 = fctcore.parse_field("./@uni_1", v_sc)
                v_uni_2 = fctcore.parse_field("./@uni_2", v_sc)
                h_uni_1 = fctcore.parse_field("./@uni_1", h_sc)
                h_uni_2 = fctcore.parse_field("./@uni_2", h_sc)

                v_name_1 = fctcore.parse_field("./@name_1", v_sc)
                v_name_2 = fctcore.parse_field("./@name_2", v_sc)
                h_name_1 = fctcore.parse_field("./@name_1", h_sc)
                h_name_2 = fctcore.parse_field("./@name_2", h_sc)

                v_p1 = self.resolve_player("V", v_uni_1, v_name_1, player_map, player_by_name)
                v_p2 = self.resolve_player("V", v_uni_2, v_name_2, player_map, player_by_name)
                h_p1 = self.resolve_player("H", h_uni_1, h_name_1, player_map, player_by_name)
                h_p2 = self.resolve_player("H", h_uni_2, h_name_2, player_map, player_by_name)

                v_sets = [int(fctcore.parse_field(f"./@set_{i}", v_sc) or 0) for i in range(1, 4)]
                h_sets = [int(fctcore.parse_field(f"./@set_{i}", h_sc) or 0) for i in range(1, 4)]
                valid_sets = self.filter_valid_sets(v_sets, h_sets)

                status = "tie" if tied_doubles.get(match_no, 0) == 1 else "completed"

                if status == "completed":
                    v_wins = sum(v > h for v, h in valid_sets)
                    h_wins = sum(h > v for v, h in valid_sets)
                    if v_wins > h_wins:
                        winner_side = "V"
                        loser_side = "H"
                        w1, w2, l1, l2 = v_p1, v_p2, h_p1, h_p2
                    else:
                        winner_side = "H"
                        loser_side = "V"
                        w1, w2, l1, l2 = h_p1, h_p2, v_p1, v_p2
                    outcome = "Completed"
                    score = ", ".join(self.reverse_number_with_larger_first(f"{v}-{h}") for v, h in valid_sets)
                else:
                    # tie: keep V as "winner" slot (your old behavior), but ids still parsed
                    winner_side = "V"
                    loser_side = "H"
                    w1, w2, l1, l2 = v_p1, v_p2, h_p1, h_p2
                    outcome = "Tie"
                    score = ", ".join(f"{v}-{h}" for v, h in valid_sets)

                winner_1_third_party_id = w1.get("playerId", "")
                winner_2_third_party_id = w2.get("playerId", "")
                loser_1_third_party_id = l1.get("playerId", "")
                loser_2_third_party_id = l2.get("playerId", "")

                winner_1_name = w1.get("name", "")
                winner_2_name = w2.get("name", "")
                loser_1_name = l1.get("name", "")
                loser_2_name = l2.get("name", "")

                winner_1_college = helper.get_official_college_name(w1.get("college", teams.get(winner_side, {}).get("name", "")), self.ai_client)
                winner_2_college = helper.get_official_college_name(w2.get("college", teams.get(winner_side, {}).get("name", "")), self.ai_client)
                loser_1_college = helper.get_official_college_name(l1.get("college", teams.get(loser_side, {}).get("name", "")), self.ai_client)
                loser_2_college = helper.get_official_college_name(l2.get("college", teams.get(loser_side, {}).get("name", "")), self.ai_client)

                if score:
                    score += ";"

                loser_2_gender = event_gender_short
                winner_2_gender = event_gender_short

                self.insert(spider_id, job_id, season_type, season_id, event_id, key, ball_type, date, draw_bracket_type,
                       draw_bracket_value, draw_gender, draw_name, draw_size, draw_team_type, draw_type, id_type,
                       loser_1_city, loser_1_college, loser_1_country, loser_1_dob, loser_1_gender, loser_1_name,
                       loser_1_state, loser_1_third_party_id, loser_2_city, loser_2_college, loser_2_country,
                       loser_2_dob, loser_2_gender, loser_2_name, loser_2_state, loser_2_third_party_id, loser_team,
                       loser_team_type, outcome, round, score, team_score, tournament_city, tournament_country,
                       tournament_country_code, tournament_end_date, tournament_event_category, tournament_event_grade,
                       tournament_event_type, tournament_host, tournament_import_source, tournament_location_type,
                       tournament_name, tournament_sanction_body, tournament_start_date, tournament_state,
                       tournament_surface, tournament_url, winner_1_city, winner_1_college, winner_1_country,
                       winner_1_dob, winner_1_gender, winner_1_name, winner_1_state, winner_1_third_party_id,
                       winner_2_city, winner_2_college, winner_2_country, winner_2_dob, winner_2_gender, winner_2_name,
                       winner_2_state, winner_2_third_party_id, winner_team, winner_team_type)

        except Exception:
            logger.error(traceback.format_exc())

    def filter_valid_sets(self, sets1, sets2):
        out = []
        for s1, s2 in zip(sets1, sets2):
            if int(s1) > 0 or int(s2) > 0:
                out.append((int(s1), int(s2)))
        return out

    def reverse_number_with_larger_first(self, input_string: str) -> str:
        try:
            a, b = map(int, input_string.split("-"))
            return f"{max(a, b)}-{min(a, b)}"
        except Exception:
            logger.error(traceback.format_exc())
            return ""

    def build_teams_and_players(self, html1):
        # teams: {"V": {"name": "...", "total_won": 3}, "H": {...}}
        teams = {}
        for team_el in html1.xpath("//team"):
            vh = fctcore.parse_field("./@vh", team_el)
            if not vh:
                continue
            name = fctcore.parse_field("./@name", team_el)
            singles_won = int(fctcore.parse_field("./totals/singles/@won", team_el) or 0)
            doubles_won = int(fctcore.parse_field("./totals/doubles/@won", team_el) or 0)
            teams[vh] = {"name": name, "total_won": singles_won + doubles_won}

        # player_map: (vh, uni) -> {playerId, name, college}
        player_map = {}
        # player_by_name: (vh, lower(name)) -> same dict (fallback when uni missing)
        player_by_name = {}

        for team_el in html1.xpath("//team"):
            vh = fctcore.parse_field("./@vh", team_el)
            college_name = fctcore.parse_field("./@name", team_el)
            for p in team_el.xpath("./player"):
                uni = fctcore.parse_field("./@uni", p)
                pid = fctcore.parse_field("./@playerId", p)  # <-- third_party_id source
                name = fctcore.parse_field("./@name", p)

                if uni:
                    player_map[(vh, uni)] = {"playerId": pid, "name": name, "college": college_name}
                if name:
                    player_by_name[(vh, name.strip().lower())] = {"playerId": pid, "name": name,
                                                                  "college": college_name}

        return teams, player_map, player_by_name

    def resolve_player(self, vh, uni, name, player_map, player_by_name):
        uni = (uni or "").strip()
        name_key = (name or "").strip().lower()

        if uni and (vh, uni) in player_map:
            return player_map[(vh, uni)]
        if name_key and (vh, name_key) in player_by_name:
            return player_by_name[(vh, name_key)]
        return {"playerId": "", "name": (name or "").strip(), "college": ""}

    def insert(self, spider_id, job_id, season_type, season_id, event_id, key, ball_type, date, draw_bracket_type, draw_bracket_value, draw_gender, draw_name, draw_size, draw_team_type, draw_type, id_type, loser_1_city, loser_1_college, loser_1_country, loser_1_dob, loser_1_gender, loser_1_name, loser_1_state, loser_1_third_party_id, loser_2_city, loser_2_college, loser_2_country, loser_2_dob, loser_2_gender, loser_2_name, loser_2_state, loser_2_third_party_id, loser_team, loser_team_type, outcome, round, score, team_score, tournament_city, tournament_country, tournament_country_code, tournament_end_date, tournament_event_category, tournament_event_grade, tournament_event_type, tournament_host, tournament_import_source, tournament_location_type, tournament_name, tournament_sanction_body, tournament_start_date, tournament_state, tournament_surface, tournament_url, winner_1_city, winner_1_college, winner_1_country, winner_1_dob, winner_1_gender, winner_1_name, winner_1_state, winner_1_third_party_id, winner_2_city, winner_2_college, winner_2_country, winner_2_dob, winner_2_gender, winner_2_name, winner_2_state, winner_2_third_party_id, winner_team, winner_team_type):
        try:
            logger.info(f'season_type: {season_type}')
            logger.info(f'season_id: {season_id}')
            logger.info(f'event_id: {event_id}')
            logger.info(f'key: {key}')
            logger.info(f'ball_type: {ball_type}')
            logger.info(f'date: {date}')
            logger.info(f'draw_bracket_type: {draw_bracket_type}')
            logger.info(f'draw_bracket_value: {draw_bracket_value}')
            logger.info(f'draw_gender: {draw_gender}')
            logger.info(f'draw_name: {draw_name}')
            logger.info(f'draw_size: {draw_size}')
            logger.info(f'draw_team_type: {draw_team_type}')
            logger.info(f'draw_type: {draw_type}')
            logger.info(f'id_type: {id_type}')
            logger.info(f'loser_1_city: {loser_1_city}')
            logger.info(f'loser_1_college: {loser_1_college}')
            logger.info(f'loser_1_country: {loser_1_country}')
            logger.info(f'loser_1_dob: {loser_1_dob}')
            logger.info(f'loser_1_gender: {loser_1_gender}')
            logger.info(f'loser_1_name: {loser_1_name}')
            logger.info(f'loser_1_state: {loser_1_state}')
            logger.info(f'loser_1_third_party_id: {loser_1_third_party_id}')
            logger.info(f'loser_2_city: {loser_2_city}')
            logger.info(f'loser_2_college: {loser_2_college}')
            logger.info(f'loser_2_country: {loser_2_country}')
            logger.info(f'loser_2_dob: {loser_2_dob}')
            logger.info(f'loser_2_gender: {loser_2_gender}')
            logger.info(f'loser_2_name: {loser_2_name}')
            logger.info(f'loser_2_state: {loser_2_state}')
            logger.info(f'loser_2_third_party_id: {loser_2_third_party_id}')
            logger.info(f'loser_team: {loser_team}')
            logger.info(f'loser_team_type: {loser_team_type}')
            logger.info(f'outcome: {outcome}')
            logger.info(f'round: {round}')
            logger.info(f'score: {score}')
            logger.info(f'team_score: {team_score}')
            logger.info(f'tournament_city: {tournament_city}')
            logger.info(f'tournament_country: {tournament_country}')
            logger.info(f'tournament_country_code: {tournament_country_code}')
            logger.info(f'tournament_end_date: {tournament_end_date}')
            logger.info(f'tournament_event_category: {tournament_event_category}')
            logger.info(f'tournament_event_grade: {tournament_event_grade}')
            logger.info(f'tournament_event_type: {tournament_event_type}')
            logger.info(f'tournament_host: {tournament_host}')
            logger.info(f'tournament_import_source: {tournament_import_source}')
            logger.info(f'tournament_location_type: {tournament_location_type}')
            logger.info(f'tournament_name: {tournament_name}')
            logger.info(f'tournament_sanction_body: {tournament_sanction_body}')
            logger.info(f'tournament_start_date: {tournament_start_date}')
            logger.info(f'tournament_state: {tournament_state}')
            logger.info(f'tournament_surface: {tournament_surface}')
            logger.info(f'tournament_url: {tournament_url}')
            logger.info(f'winner_1_city: {winner_1_city}')
            logger.info(f'winner_1_college: {winner_1_college}')
            logger.info(f'winner_1_country: {winner_1_country}')
            logger.info(f'winner_1_dob: {winner_1_dob}')
            logger.info(f'winner_1_gender: {winner_1_gender}')
            logger.info(f'winner_1_name: {winner_1_name}')
            logger.info(f'winner_1_state: {winner_1_state}')
            logger.info(f'winner_1_third_party_id: {winner_1_third_party_id}')
            logger.info(f'winner_2_city: {winner_2_city}')
            logger.info(f'winner_2_college: {winner_2_college}')
            logger.info(f'winner_2_country: {winner_2_country}')
            logger.info(f'winner_2_dob: {winner_2_dob}')
            logger.info(f'winner_2_gender: {winner_2_gender}')
            logger.info(f'winner_2_name: {winner_2_name}')
            logger.info(f'winner_2_state: {winner_2_state}')
            logger.info(f'winner_2_third_party_id: {winner_2_third_party_id}')
            logger.info(f'winner_team: {winner_team}')
            logger.info(f'winner_team_type: {winner_team_type}')
            logger.info("-" * 60)

            JobsItemsPrestosportsModel(
                spider_id=spider_id,
                job_id=job_id,
                season_type=season_type,
                season_id=season_id,
                event_id=event_id,
                key=key,
                ball_type=ball_type,
                date=date,
                draw_bracket_type=draw_bracket_type,
                draw_bracket_value=draw_bracket_value,
                draw_gender=draw_gender,
                draw_name=draw_name,
                draw_size=draw_size,
                draw_team_type=draw_team_type,
                draw_type=draw_type,
                id_type=id_type,
                loser_1_city=loser_1_city,
                loser_1_college=loser_1_college,
                loser_1_country=loser_1_country,
                loser_1_dob=loser_1_dob,
                loser_1_gender=loser_1_gender,
                loser_1_name=loser_1_name,
                loser_1_state=loser_1_state,
                loser_1_third_party_id=loser_1_third_party_id,
                loser_2_city=loser_2_city,
                loser_2_college=loser_2_college,
                loser_2_country=loser_2_country,
                loser_2_dob=loser_2_dob,
                loser_2_gender=loser_2_gender,
                loser_2_name=loser_2_name,
                loser_2_state=loser_2_state,
                loser_2_third_party_id=loser_2_third_party_id,
                loser_team=loser_team,
                loser_team_type=loser_team_type,
                outcome=outcome,
                round=round,
                score=score,
                team_score=team_score,
                tournament_city=tournament_city,
                tournament_country=tournament_country,
                tournament_country_code=tournament_country_code,
                tournament_end_date=tournament_end_date,
                tournament_event_category=tournament_event_category,
                tournament_event_grade=tournament_event_grade,
                tournament_event_type=tournament_event_type,
                tournament_host=tournament_host,
                tournament_import_source=tournament_import_source,
                tournament_location_type=tournament_location_type,
                tournament_name=tournament_name,
                tournament_sanction_body=tournament_sanction_body,
                tournament_start_date=tournament_start_date,
                tournament_state=tournament_state,
                tournament_surface=tournament_surface,
                tournament_url=tournament_url,
                winner_1_city=winner_1_city,
                winner_1_college=winner_1_college,
                winner_1_country=winner_1_country,
                winner_1_dob=winner_1_dob,
                winner_1_gender=winner_1_gender,
                winner_1_name=winner_1_name,
                winner_1_state=winner_1_state,
                winner_1_third_party_id=winner_1_third_party_id,
                winner_2_city=winner_2_city,
                winner_2_college=winner_2_college,
                winner_2_country=winner_2_country,
                winner_2_dob=winner_2_dob,
                winner_2_gender=winner_2_gender,
                winner_2_name=winner_2_name,
                winner_2_state=winner_2_state,
                winner_2_third_party_id=winner_2_third_party_id,
                winner_team=winner_team,
                winner_team_type=winner_team_type,
            ).save()

        except Exception:
            logger.error(traceback.format_exc())
