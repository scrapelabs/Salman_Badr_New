import traceback, math
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.requests.fctrequest import Request
from scripts.log_items import ItemsLogger

class eventsParser:

    def __init__(self, start_date, end_date, progress):
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=True, use_proxy=self.use_proxy)

        self.start_date = start_date
        self.end_date = end_date

        self.login_username = 'salman.bader@utrsports.com'
        self.login_password = 'ulussigh'

        self.events_link = 'https://gameday-api.prestosports.com/api/seasons/{season_id}/events?from={start_date}&to={end_date}&pageSize={per_page}&pageNumber={page}'

        self.df_events = ItemsLogger()
        self.seen_rows = getattr(self, "seen_rows", set())


    def login(self):
        token = ''
        refresh_token = ''
        try:
            headers = {
                'accept': '*/*',
                'Content-Type': 'application/json',
            }
            json_data = {
                'username': self.login_username,
                'password': self.login_password,
            }
            index_link = 'https://gameday-api.prestosports.com/api/auth/token'
            response1 = self.fctrequest.request(method='POST', link=index_link, headers=headers, json=json_data, proxies=self.proxies, tries=1)
            if response1:
                if response1.status_code in range(200, 300):
                    results1 = response1.json()
                    token = results1.get('idToken', '')
                    refresh_token = results1.get('refreshToken', '')

        except Exception:
            logger.error(traceback.format_exc())

        return token, refresh_token

    def parse_count_page(self, season_id, token):
        count_page = 0
        try:
            headers = {
                'accept': 'application/json',
                'Authorization': f'Bearer {token}',
            }
            index_link = self.events_link.format(
                season_id=season_id,
                start_date=self.start_date,
                end_date=self.end_date,
                per_page=1,
                page=0,
            )
            logger.info(f'index_link: {index_link}')
            response1 = self.fctrequest.request(method='GET', link=index_link, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    results1 = response1.json()
                    count_result = results1.get('totalElements', 0)
                    count_page = math.ceil(count_result/100)
                    logger.info(f'count_result: {count_result} | count_page: {count_page}')

        except Exception:
            logger.error(traceback.format_exc())
        return count_page


    def parse_site(self, job_id, token, season_type, season_id, pages_chunk, main_task, thread_task, progress):
        try:
            for page in pages_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    headers = {
                        'accept': 'application/json',
                        'Authorization': f'Bearer {token}',
                    }
                    index_link = self.events_link.format(
                        season_id=season_id,
                        start_date=self.start_date,
                        end_date=self.end_date,
                        per_page=100,
                        page=page,
                    )
                    logger.info(f'page: {page} | {index_link}')
                    response1 = self.fctrequest.request(method='GET', link=index_link, headers=headers, proxies=self.proxies, tries=3)
                    if response1:
                        if response1.status_code in range(200, 300):
                            results1 = {}
                            try:
                                results1 = response1.json()
                            except Exception:
                                ''

                            if results1:
                                self.parse_page(job_id, season_type, season_id, results1)

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())

        return self.df_events.get_df()


    def parse_page(self, job_id, season_type, season_id, results1):
        try:
            for result in results1.get('data', []):
                event_id = result.get('eventId', '')
                # if event_id == "wd8ayc0v9gwkiye9":
                # if event_id == "018rxwh1thd34tid":
                # if event_id == "1ye0o68vy92ppn0l":
                event_status = result.get('status', '')
                event_score = self.reverse_number_with_larger_first(result.get('score', {}).get('home', 0), result.get('score', {}).get('away', 0))
                if event_score:
                    event_gender_long = ''
                    event_gender_short = ''
                    if result.get('sportId', '') == 'mten':
                        event_gender_long = 'Male'
                        event_gender_short = 'M'

                    if result.get('sportId', '') == 'wten':
                        event_gender_long = 'Female'
                        event_gender_short = 'F'

                    if event_status.lower() == 'final':

                        row_key = f"{event_id}"
                        if row_key not in self.seen_rows:
                            logger.info(f'new: event_id: {event_id}')
                            self.df_events.log({
                                "season_type": season_type,
                                "season_id": season_id,
                                "event_id": event_id,
                                "event_gender_long": event_gender_long,
                                "event_gender_short": event_gender_short,
                                "event_score": event_score,
                            })
                            self.seen_rows.add(row_key)

        except Exception:
            logger.error(traceback.format_exc())

    def reverse_number_with_larger_first(self, a, b):
        value = ""
        try:
            if not a or not b:
                return value

            a_int, b_int = int(a), int(b)  # convert strings to int
            value = f"{max(a_int, b_int)}-{min(a_int, b_int)};"
        except Exception:
            logger.error(traceback.format_exc())
        return value
