import time
import concurrent.futures
import pandas as pd
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from scripts.prestosports.parser.events import eventsParser
from scripts.prestosports.parser.details import DetailsParser
from scripts import helper
from app_spiders.models import jobsModel

start_dt = time.time()

def run(*args):
    params = list(args)
    job_id = int(params[0])
    spider_name = params[1]
    folder_path = params[2]
    max_workers = int(params[3])

    max_workers = len(settings.API_KEYS)

    base_file = f'{spider_name}__{job_id}__{fctcore.current_date("%Y-%m-%d_%H-%M")}.csv'

    job_obj = jobsModel.objects.get(id=job_id)
    spider_id = job_obj.spider_id
    job_settings = job_obj.job_settings
    job_range_date = job_settings.get('range_date', '')
    job_start_date = job_end_date = ''
    if job_range_date and ' to ' in job_range_date:
        job_tab_date = job_range_date.split(' to ')
        job_start_date = fctcore.convert_string_to_date_format(date_str=job_tab_date[0], in_format='%m/%d/%Y', out_format='%Y-%m-%d')
        job_end_date = fctcore.convert_string_to_date_format(date_str=job_tab_date[1], in_format='%m/%d/%Y', out_format='%Y-%m-%d')
    logger.info(f'spider_name: {spider_name} | job_id: {job_id} | job_range_date: {job_range_date} | job_start_date: {job_start_date} | job_end_date: {job_end_date}')

    events_data = []
    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(), TextColumn("{task.completed}/{task.total}"), TimeElapsedColumn(), TimeRemainingColumn(), transient=False) as progress:
        events_parser = eventsParser(job_start_date, job_end_date, progress)

        token, refresh_token = events_parser.login()
        if token:
            season_id_men = "kxetzl72d99ilqa9"
            season_id_women = "5ubesra0lj72h4jd"
            season_ids = [
                {'season_type': 'men', 'season_id': season_id_men},
                {'season_type': 'women', 'season_id': season_id_women},
            ]

            for season_tab in season_ids:
                season_type = season_tab['season_type']
                season_id = season_tab['season_id']
                count_page = events_parser.parse_count_page(season_id, token)

                pages_chunks = list(fctcore.split_list_into_chunks(lst=[p for p in range(count_page)], max_workers=max_workers))
                logger.info(f'pages_chunks: {pages_chunks}')

                with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futures = []
                    main_task = progress.add_task(description=f'prestosports_events_{season_type}', total=count_page)
                    for thread_id, pages_chunk in enumerate(pages_chunks):
                        thread_task = progress.add_task(f"Thread {thread_id + 1}", total=len(pages_chunk))
                        future = executor.submit(events_parser.parse_site, job_id, token, season_type, season_id, pages_chunk, main_task, thread_task, progress)
                        futures.append(future)

                    for future in concurrent.futures.as_completed(futures):
                        df_events = future.result()
                        events_data.append(df_events)

        logger.info(f'events_data: {len(events_data)}')

        if events_data:
            df_events = pd.concat(events_data, ignore_index=True)
            df_events = df_events.drop_duplicates()
            events_list = df_events.to_dict("records")
            events_chunks = list(fctcore.split_list_into_chunks(lst=events_list, max_workers=max_workers))
            if max_workers > len(events_chunks): max_workers=len(events_chunks)

            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                main_task = progress.add_task(description=f'{spider_name}_results', total=len(events_list))
                for thread_id, events_chunk in enumerate(events_chunks):
                    thread_task = progress.add_task(f"Thread {thread_id + 1}", total=len(events_chunk))
                    executor.submit(DetailsParser(token, thread_id).parse_site, spider_id, job_id, events_chunk, main_task, thread_task, progress)

        helper.finalize_items_from_db(job_obj, folder_path, base_file)
        helper.finalize_job(job_obj, base_file, folder_path)

    logger.info(f'script take {round(time.time()-start_dt, 2)} sec to finished')
