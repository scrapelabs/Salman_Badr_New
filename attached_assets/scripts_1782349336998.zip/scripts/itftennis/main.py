import traceback, math, requests, random, json, re
from os.path import basename, dirname, abspath
from datetime import date
from urllib.parse import urljoin
from django.db import close_old_connections
from django.conf import settings
from lxml import etree
from scrapy.selector import Selector
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts.log_items import ItemsLogger

class InfoParser:

    def __init__(self, JobsItemsItftennisModel, NamesItftennisModel, progress, circuit_title, circuit_code, tournament_event_category, tournament_sanction_body):
        self.JobsItemsItftennisModel = JobsItemsItftennisModel
        self.NamesItftennisModel = NamesItftennisModel
        self.tournament_event_category = tournament_event_category
        self.tournament_sanction_body = tournament_sanction_body
        self.circuit_title = circuit_title
        self.circuit_code = circuit_code
        self.progress = progress

        # self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.proxies = [
            'q9L2xU4P:55s63Q7u7oS@hub-us-10.litport.net:31337',
            'yqj8Zi:7GF9p0swJ7Cv@hub-us-10.litport.net:31337',
            '71V6O2:i7q6dUJKbW@hub-us-8.litport.net:31337',
            'q98g8W0:6nXQ2cAE5T63@hub-us-10.litport.net:31337',
            'N8zl0JwK:Fek2an1qgxx5@hub-us-10.litport.net:31337',
            'y9hZ0G:5RVuqc1rYpvy@hub-us-8.litport.net:31337',
            '54anbpov:xwEqAir4iP5@hub-us-10.litport.net:31337',
            'N80ysY59:leGfr14PL8F2@hub-us-8.litport.net:31337',
            'uKPRQVl:ukA67Yk9Jp@hub-us-8.litport.net:31337',
            'c8wNEW:Ry7aE31wg9b@hub-us-8.litport.net:31337',
        ]

        self.fctrequest = Request(use_session=False, use_cffi=False, use_proxy=self.use_proxy)

        self.headers = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',
        }

        self.per_page = 100
        self.params = {
            'circuitCode': '',
            'searchString': '',
            'skip': '0',
            'take': self.per_page,
            'nationCodes': '',
            'zoneCodes': '',
            'dateFrom': '2025-11-15',
            'dateTo': '2025-11-25',
            'indoorOutdoor': '',
            'categories': '',
            'isOrderAscending': 'true',
            'orderField': 'startDate',
            'surfaceCodes': '',
        }

        self.df_tournaments = ItemsLogger()


    def parse_tournaments(self, job_start_date, job_end_date, job_tournament_url):
        try:
            if job_tournament_url:
                response1 = self.fctrequest.request(method='GET', link=job_tournament_url, params=self.params, headers=self.headers, proxies=self.proxies, tries=3)
                if response1:
                    if response1.status_code in range(200, 300):
                        html1 = Selector(text=response1.text)

                        try:
                            tournament_json = json.loads( fctcore.parse_field("//script[contains(., 'startDate')]", html1))
                            tournament_url = urljoin(f'https://www.itftennis.com/', tournament_json.get("url", ""))

                            match = re.search(r'([A-Za-z0-9\-]+)$', tournament_url.strip('/'))
                            tournament_id = match.group(1) if match else None

                            self.df_tournaments.log({
                                "tournament_id": tournament_id,
                                "tournament_url": tournament_url,
                            })
                        except Exception:
                            logger.error(traceback.format_exc())

            else:
                try:
                    index_link = f'https://www.itftennis.com/tennis/api/TournamentApi/GetCalendar'
                    logger.info(f'index_link: {index_link}')

                    self.params['circuitCode'] = self.circuit_code
                    self.params['dateFrom'] = job_start_date
                    self.params['dateTo'] = job_end_date

                    count_result = 0
                    count_page = 0
                    page = 0
                    response1 = self.fctrequest.request(method='GET', link=index_link, params=self.params, headers=self.headers, proxies=self.proxies, tries=3)
                    if response1:
                        if response1.status_code in range(200, 300):
                            results1 = response1.json()

                            try:
                                count_result = results1.get('totalItems', 0)
                                count_page = math.ceil(count_result/self.per_page)
                            except Exception:
                                logger.error(traceback.format_exc())

                            logger.info(f'circuit_code: {self.circuit_code} | count_result: {count_result} | count_page: {count_page}')
                            logger.info(f'circuit_code: {self.circuit_code} | page: {page+1}')

                            for data in results1.get('items', []):
                                tournament_id = data.get('tournamentKey', '')
                                tournament_url = urljoin(f'https://www.itftennis.com/', data.get('tournamentLink', ''))

                                self.df_tournaments.log({
                                    "tournament_id": tournament_id,
                                    "tournament_url": tournament_url,
                                })

                    if count_page > 1:
                        for page in range(1, count_page):
                            logger.info(f'circuit_code: {self.circuit_code} | page: {page+1}')

                            self.params['skip'] = f'{page * self.per_page}'

                            response1 = self.fctrequest.request(method='GET', link=index_link, params=self.params, headers=self.headers, proxies=self.proxies, tries=3)
                            if response1:
                                if response1.status_code in range(200, 300):
                                    results1 = response1.json()

                                    for data in results1.get('items', []):
                                        tournament_id = data.get('tournamentKey', '')
                                        tournament_url = urljoin(f'https://www.itftennis.com/', data.get('tournamentLink', ''))

                                        self.df_tournaments.log({
                                            "tournament_id": tournament_id,
                                            "tournament_url": tournament_url,
                                        })

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())

        return self.df_tournaments.get_df()


    def parse_site(self, spider_id, job_id, tournaments_chunk, main_task, thread_task, progress):
        try:
            for tournaments_data in tournaments_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    tournament_url = tournaments_data.get("tournament_url", "")
                    tournament_id = tournaments_data.get("tournament_id", "")

                    headers = {
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                        'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                        'upgrade-insecure-requests': '1',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',
                    }

                    logger.info(f'tournament_url: {tournament_url}')
                    response1 = self.fctrequest.request(method='GET', link=tournament_url, headers=headers, proxies=self.proxies, tries=3)

                    tournament_name = ''
                    tournament_start_date = ''
                    tournament_end_date = ''
                    tournament_surface = ''
                    tournament_city = ''
                    tournament_country = ''
                    if response1:
                        if response1.status_code in range(200, 300):
                            try:
                                html1 = Selector(text=response1.text)
                                tournament_surface = fctcore.parse_field('//span[@id="ga__tournament-surface"]', html1).split('-')[0].strip()
                                tournament_name = fctcore.parse_field('//h1[@id="ga__tournament-name"]', html1)

                                tournament_data = json.loads(fctcore.parse_field("//script[contains(., 'startDate')]", html1))
                                tournament_start_date = fctcore.convert_string_to_date_format(tournament_data.get("startDate", ""), in_format='%m/%d/%Y %I:%M:%S %p', out_format="%m/%d/%Y")
                                tournament_end_date = fctcore.convert_string_to_date_format(tournament_data.get("endDate", ""), in_format='%m/%d/%Y %I:%M:%S %p', out_format="%m/%d/%Y")
                                tournament_city = tournament_data.get("location", {}).get("name", "")
                                tournament_country = tournament_data.get("location", {}).get("address", {}).get("addressCountry", "")
                            except Exception:
                                logger.error(traceback.format_exc())

                    logger.info(f'tournament_name: {tournament_name}')
                    logger.info(f'tournament_start_date: {tournament_start_date}')
                    logger.info(f'tournament_end_date: {tournament_end_date}')
                    logger.info(f'tournament_surface: {tournament_surface}')
                    logger.info(f'tournament_city: {tournament_city}')
                    logger.info(f'tournament_country: {tournament_country}')

                    if tournament_name and tournament_start_date and tournament_end_date:
                        headers = {
                            'accept': '*/*',
                            'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                            'content-type': 'application/json',
                            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',
                        }
                        index_link = f'https://www.itftennis.com/tennis/api/TournamentApi/GetEventFilters?tournamentKey={tournament_id.lower()}'

                        logger.info(f'tournament_id: {tournament_id} | {index_link}')
                        response1 = self.fctrequest.request(method='GET', link=index_link, headers=headers, proxies=self.proxies, tries=3)

                        if response1:
                            if response1.status_code in range(200, 300):
                                results1 = response1.json()
                                self.parse_tournament_details(spider_id, job_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_surface, tournament_city, tournament_country, results1)

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())

    def parse_tournament_details(self, spider_id, job_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_surface, tournament_city, tournament_country, results1):
        try:
            code_list, desc_map = self.parse_filters_tournament(results1)
            for json_data in code_list:
                draw_team_type = desc_map.get('matchTypeCode', {}).get(json_data.get('matchTypeCode'), '')
                player_type_code = json_data.get('playerTypeCode', '')
                draw_name = ' '.join([d for d in [
                    desc_map.get('ageCategoryCode', {}).get(json_data.get('ageCategoryCode'), ''),
                    desc_map.get('playerTypeCode', {}).get(json_data.get('playerTypeCode'), ''),
                    desc_map.get('matchTypeCode', {}).get(json_data.get('matchTypeCode'), ''),
                    desc_map.get('eventClassificationCode', {}).get(json_data.get('eventClassificationCode'), ''),
                ] if d])
                draw_gender, player_gender = self.get_gender(player_type_code)

                if draw_gender and player_gender:
                    logger.info(f'draw_name: {draw_name}')
                    logger.info(f'draw_team_type: {draw_team_type}')
                    logger.info(f'draw_gender: {draw_gender}')
                    logger.info(f'player_gender: {player_gender}')

                    self.parse_matchs(spider_id, job_id, draw_name, draw_team_type, draw_gender, player_gender, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_surface, tournament_city, tournament_country, json_data)

        except Exception:
            logger.error(traceback.format_exc())

    def parse_matchs(self, spider_id, job_id, draw_name, draw_team_type, draw_gender, player_gender, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_surface, tournament_city, tournament_country, json_data):
        try:
            headers = {
                'accept': '*/*',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'content-type': 'application/json',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',
            }

            index_link = 'https://www.itftennis.com/tennis/api/TournamentApi/GetDrawsheet'
            json_data = {k: str(v) for k, v in json_data.items()}

            response1 = self.fctrequest.request(method='GET', link=index_link, params=json_data, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    results1 = response1.json()
                    self.parse_matchs_details(spider_id, job_id, draw_name, draw_team_type, draw_gender, player_gender, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_surface, tournament_city, tournament_country, results1)

        except Exception:
            logger.error(traceback.format_exc())

    def parse_matchs_details(self, spider_id, job_id, draw_name, draw_team_type, draw_gender, player_gender, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_surface, tournament_city, tournament_country, results1):
        try:
            records = self.extract_all_records(results1)
            logger.info(f"Total matches parsed: {len(records)}")

            ball_type = 'Yellow'
            draw_bracket_value = ''
            date = tournament_start_date
            winner_1_city = ''
            winner_1_state = ''
            winner_2_city = ''
            winner_2_state = ''
            loser_1_city = ''
            loser_1_state = ''
            loser_2_city = ''
            loser_2_state = ''
            draw_bracket_type = ''
            draw_type = ''
            tournament_state = ''
            tournament_host = ''
            tournament_location_type = ''
            tournament_event_grade = ''
            id_type = 'ITF'
            winner_2_college = ''
            loser_2_college = ''
            winner_1_college = ''
            loser_1_college = ''
            winner_1_gender = ''
            winner_2_gender = ''
            loser_1_gender = ''
            loser_2_gender = ''
            tournament_import_source = 'ITF'
            tournament_country_code = tournament_country[:3].upper()
            tournament_event_type = 'Tournament'

            for rec in records:
                outcome = rec.get('outcome', '')
                if outcome.lower() in ['completed', 'retired']:
                    match_round = rec.get('round', '')
                    match_id = rec.get('matchId', '')
                    score = rec.get('score', '')
                    winner_1_name = rec.get('winner_1_name', '')
                    winner_1_third_party_id = rec.get('winner_1_third_party_id', '')
                    winner_1_country = rec.get('winner_1_country', '')
                    winner_2_name = rec.get('winner_2_name', '')
                    winner_2_third_party_id = rec.get('winner_2_third_party_id', '')
                    loser_1_name = rec.get('loser_1_name', '')
                    loser_1_third_party_id = rec.get('loser_1_third_party_id', '')
                    loser_1_country = rec.get('loser_1_country', '')
                    loser_2_name = rec.get('loser_2_name', '')
                    loser_2_third_party_id = rec.get('loser_2_third_party_id', '')
                    winner_2_country = rec.get('winner_2_country', '')
                    loser_2_country = rec.get('loser_2_country', '')
                    winner_1_dob = self.parse_dob(winner_1_name, rec.get('winner_1_third_party_id', ''))
                    winner_2_dob = self.parse_dob(winner_2_name, rec.get('winner_2_third_party_id', ''))
                    loser_1_dob = self.parse_dob(loser_1_name, rec.get('loser_1_third_party_id', ''))
                    loser_2_dob = self.parse_dob(loser_2_name, rec.get('loser_2_third_party_id', ''))

                    if winner_1_name:
                        winner_1_gender = player_gender

                    if winner_2_name:
                        winner_2_gender = player_gender

                    if loser_1_name:
                        loser_1_gender = player_gender

                    if loser_2_name:
                        loser_2_gender = player_gender

                    logger.info(f'match_id: {match_id}')
                    logger.info(f'ball_type: {ball_type}')
                    logger.info(f'draw_bracket_value: {draw_bracket_value}')
                    logger.info(f'draw_name: {draw_name}')
                    logger.info(f'draw_team_type: {draw_team_type}')
                    logger.info(f'tournament_name: {tournament_name}')
                    logger.info(f'date: {date}')
                    logger.info(f'score: {score}')
                    logger.info(f'winner_1_name: {winner_1_name}')
                    logger.info(f'winner_1_gender: {winner_1_gender}')
                    logger.info(f'winner_1_third_party_id: {winner_1_third_party_id}')
                    logger.info(f'winner_1_city: {winner_1_city}')
                    logger.info(f'winner_1_country: {winner_1_country}')
                    logger.info(f'winner_1_state: {winner_1_state}')
                    logger.info(f'winner_2_name: {winner_2_name}')
                    logger.info(f'winner_2_gender: {winner_2_gender}')
                    logger.info(f'winner_2_third_party_id: {winner_2_third_party_id}')
                    logger.info(f'winner_2_city: {winner_2_city}')
                    logger.info(f'winner_2_state: {winner_2_state}')
                    logger.info(f'loser_1_name: {loser_1_name}')
                    logger.info(f'loser_1_gender: {loser_1_gender}')
                    logger.info(f'loser_1_third_party_id: {loser_1_third_party_id}')
                    logger.info(f'loser_1_city: {loser_1_city}')
                    logger.info(f'loser_1_state: {loser_1_state}')
                    logger.info(f'loser_1_country: {loser_1_country}')
                    logger.info(f'loser_2_name: {loser_2_name}')
                    logger.info(f'loser_2_gender: {loser_2_gender}')
                    logger.info(f'loser_2_third_party_id: {loser_2_third_party_id}')
                    logger.info(f'loser_2_city: {loser_2_city}')
                    logger.info(f'loser_2_state: {loser_2_state}')
                    logger.info(f'outcome: {outcome}')
                    logger.info(f'id_type: {id_type}')
                    logger.info(f'draw_gender: {draw_gender}')
                    logger.info(f'draw_bracket_type: {draw_bracket_type}')
                    logger.info(f'draw_type: {draw_type}')
                    logger.info(f'tournament_city: {tournament_city}')
                    logger.info(f'tournament_state: {tournament_state}')
                    logger.info(f'tournament_country_code: {tournament_country_code}')
                    logger.info(f'tournament_host: {tournament_host}')
                    logger.info(f'tournament_location_type: {tournament_location_type}')
                    logger.info(f'tournament_surface: {tournament_surface}')
                    logger.info(f'tournament_event_category: {self.tournament_event_category}')
                    logger.info(f'tournament_event_grade: {tournament_event_grade}')
                    logger.info(f'tournament_import_source: {tournament_import_source}')
                    logger.info(f'tournament_sanction_body: {self.tournament_sanction_body}')
                    logger.info(f'winner_2_country: {winner_2_country}')
                    logger.info(f'winner_2_college: {winner_2_college}')
                    logger.info(f'loser_2_country: {loser_2_country}')
                    logger.info(f'loser_2_college: {loser_2_college}')
                    logger.info(f'tournament_event_type: {tournament_event_type}')
                    logger.info(f'winner_1_college: {winner_1_college}')
                    logger.info(f'loser_1_college: {loser_1_college}')
                    logger.info(f'tournament_url: {tournament_url}')
                    logger.info(f'winner_1_dob: {winner_1_dob}')
                    logger.info(f'winner_2_dob: {winner_2_dob}')
                    logger.info(f'loser_1_dob: {loser_1_dob}')
                    logger.info(f'loser_2_dob: {loser_2_dob}')
                    logger.info(f'tournament_country: {tournament_country}')
                    logger.info(f'tournament_start_date: {tournament_start_date}')
                    logger.info(f'tournament_end_date: {tournament_end_date}')
                    logger.info(f'match_round: {match_round}')
                    logger.info(f'*' * 50)

                    self.JobsItemsItftennisModel(
                        spider_id=spider_id,
                        job_id=job_id,
                        match_id=match_id,
                        ball_type=ball_type,
                        draw_bracket_value=draw_bracket_value,
                        draw_name=draw_name,
                        draw_team_type=draw_team_type,
                        tournament_name=tournament_name,
                        date=date,
                        score=score,
                        winner_1_name=winner_1_name,
                        winner_1_gender=winner_1_gender,
                        winner_1_third_party_id=winner_1_third_party_id,
                        winner_1_city=winner_1_city,
                        winner_1_country=winner_1_country,
                        winner_1_state=winner_1_state,
                        winner_2_name=winner_2_name,
                        winner_2_gender=winner_2_gender,
                        winner_2_third_party_id=winner_2_third_party_id,
                        winner_2_city=winner_2_city,
                        winner_2_state=winner_2_state,
                        loser_1_name=loser_1_name,
                        loser_1_gender=loser_1_gender,
                        loser_1_third_party_id=loser_1_third_party_id,
                        loser_1_city=loser_1_city,
                        loser_1_state=loser_1_state,
                        loser_1_country=loser_1_country,
                        loser_2_name=loser_2_name,
                        loser_2_gender=loser_2_gender,
                        loser_2_third_party_id=loser_2_third_party_id,
                        loser_2_city=loser_2_city,
                        loser_2_state=loser_2_state,
                        outcome=outcome,
                        id_type=id_type,
                        draw_gender=draw_gender,
                        draw_bracket_type=draw_bracket_type,
                        draw_type=draw_type,
                        tournament_city=tournament_city,
                        tournament_state=tournament_state,
                        tournament_country_code=tournament_country_code,
                        tournament_host=tournament_host,
                        tournament_location_type=tournament_location_type,
                        tournament_surface=tournament_surface,
                        tournament_event_category=self.tournament_event_category,
                        tournament_event_grade=tournament_event_grade,
                        tournament_import_source=tournament_import_source,
                        tournament_sanction_body=self.tournament_sanction_body,
                        winner_2_country=winner_2_country,
                        winner_2_college=winner_2_college,
                        loser_2_country=loser_2_country,
                        loser_2_college=loser_2_college,
                        tournament_event_type=tournament_event_type,
                        winner_1_college=winner_1_college,
                        loser_1_college=loser_1_college,
                        tournament_url=tournament_url,
                        winner_1_dob=winner_1_dob,
                        winner_2_dob=winner_2_dob,
                        loser_1_dob=loser_1_dob,
                        loser_2_dob=loser_2_dob,
                        tournament_country=tournament_country,
                        tournament_start_date=tournament_start_date,
                        tournament_end_date=tournament_end_date,
                        round=match_round,
                    ).save()

        except Exception:
            logger.error(traceback.format_exc())


    def parse_profile(self, input_name, index_link):
        player_dob = ''
        try:
            if index_link:
                namesObj = self.NamesItftennisModel.objects.filter(full_name__iexact=input_name)
                if not namesObj.exists():
                    response1 = self.fctrequest.request(method='GET', link=index_link, headers=self.headers, proxies=self.proxies, tries=3)
                    if response1:
                        if response1.status_code in range(200, 300):
                            html1 = Selector(text=response1.text)
                            player_age = fctcore.parse_field('//div[contains(@class, "player-hero__details-item") and span[@class="player-hero__label" and contains(text(), "Age:")]]/span[@class="player-hero__value"]', html1)
                            if player_age:
                                player_dob = self.age_to_dob(int(player_age))
                                spider_name = basename(dirname(dirname(abspath(__file__))))
                                self.NamesItftennisModel(spider_name=spider_name, input_name=input_name, dob=player_dob).save()

                else:
                    player_dob = namesObj.first().dob
                    logger.warning(f'exist from db | input_name: {input_name} | player_dob: {player_dob}')

        except Exception:
            logger.error(traceback.format_exc())

        return player_dob


    def parse_dob(self, input_name, player_id):
        player_dob = ''
        try:
            if input_name and player_id:
                namesObj = self.NamesItftennisModel.objects.filter(full_name__iexact=input_name)
                if not namesObj.exists():
                    headers = {
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                        'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                        'upgrade-insecure-requests': '1',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',
                    }

                    index_link = f'https://www.itftennis.com/tennis/Api/PlayerApi/GetHeadToHeadPlayerDetails?playerId={player_id}'
                    random_proxy = f'http://{random.choice(self.proxies)}'
                    dict_proxy = {"http": random_proxy, "https": random_proxy}
                    response1 = requests.get(index_link, headers=headers, proxies=dict_proxy)
                    if response1:
                        if response1.status_code in range(200, 300):
                            tree = etree.fromstring(response1.text)
                            ns = {"ns": "http://schemas.datacontract.org/2004/07/Itf.Tennis.Core.Models.Api"}
                            player_dob_text = tree.xpath("string(./ns:DateOfBirth)", namespaces=ns)
                            if player_dob_text:
                                player_dob = fctcore.convert_string_to_date_format(player_dob_text, in_format='%Y-%m-%dT%H:%M:%S', out_format='%m/%d/%Y')
                                logger.info(f'player_dob: {player_dob}')
                                self.NamesItftennisModel(input_name=input_name, dob=player_dob).save()

                else:
                    player_dob = namesObj.first().dob
                    logger.warning(f'exist from db | input_name: {input_name} | player_dob: {player_dob}')

        except Exception:
            logger.error(traceback.format_exc())

        return player_dob


    def age_to_dob(self, age):
        year = date.today().year - age
        dob = date(year, 1, 1)
        return dob.strftime("%m/%d/%Y")

    def parse_filters_tournament(self, results, parent=None, desc_map=None):
        """
        Returns:
          code_list: list of json objects
          desc_map: dict mapping dataName -> {valueCode: valueDesc}
                    e.g. {
                      'ageCategoryCode': {'V55': '55+'},
                      'playerTypeCode': {'M': "Men's", 'W': "Women's"},
                      'eventClassificationCode': {'M': 'Main Draw'}
                    }
        """
        if parent is None:
            parent = {}
        if desc_map is None:
            desc_map = {}

        tournament_id = results.get('tournamentId')
        tour_type = results.get('tourType')
        filters = results.get('filters') or []
        week_number = 0

        code_list = []

        for f in filters:
            current = parent.copy()

            data_name = f.get('dataName')
            value_code = f.get('valueCode')
            value_desc = f.get('valueDesc')

            # accumulate dataName -> valueCode
            if data_name and value_code:
                current[data_name] = value_code

                # scoped desc_map
                desc_map.setdefault(data_name, {})
                if value_code and value_desc:
                    desc_map[data_name][value_code] = value_desc

            sub = f.get('subFilter')
            if sub:
                sub_code_list, desc_map = self.parse_filters_tournament(
                    {
                        'filters': sub,
                        'tournamentId': tournament_id,
                        'tourType': tour_type
                    },
                    current,
                    desc_map
                )
                code_list.extend(sub_code_list)
            else:
                json_code = {
                    'tournamentId': tournament_id,
                    'tourType': tour_type,
                    'weekNumber': week_number,
                    **current
                }
                code_list.append(json_code)

        return code_list, desc_map

    def get_gender(self, player_type_code):
        if self.circuit_title.lower() == 'mens':
            return "Male", "M"

        if self.circuit_title.lower() == 'womens':
            return "Female", "F"

        if player_type_code.lower() in ['m', 'b']:
            return "Male", "M"

        if player_type_code.lower() in ['w', 'g']:
            return "Female", "F"

        if player_type_code.lower() in ['u']:
            return "Mixed", ""

        return "", ""

    def format_name(self, player):
        """Return 'Last, First' (familyName, givenName). For doubles players you'll call per player."""
        fn = player.get("familyName") or ""
        gn = player.get("givenName") or ""
        return f"{fn}, {gn}".strip(", ")

    def infer_country(self, player):
        # Use nationality code if present
        return player.get("nationality")

    def get_player_id(self, player):
        # prefer explicit playerId, else try to parse from profileLink
        if player.get("playerId"):
            return player["playerId"]
        link = player.get("profileLink") or ""
        m = re.search(r"/(\d{6,})/", link)
        if m:
            return int(m.group(1))
        return ''

    def get_player_link(self, player):
        return urljoin(f'https://www.itftennis.com/', player.get("profileLink")) or ""

    def build_score_string(self, winner_scores, loser_scores):
        """
        Build a score string from arrays of score objects. Ensure winner's score first in each set.
        Append semicolon at the end.
        """
        parts = []
        # both arrays expected same length; iterate up to length of shorter
        n = min(len(winner_scores), len(loser_scores))
        for i in range(n):
            ws = winner_scores[i]
            ls = loser_scores[i]
            if ws is None and ls is None:
                continue
            # When values missing, try to use available numeric 'score' fields
            try:
                wv = ws.get("score") if ws else None
            except Exception:
                wv = None
            try:
                lv = ls.get("score") if ls else None
            except Exception:
                lv = None
            if wv is None and lv is None:
                continue
            # If losingScore exists on winner side (some feeds put losingScore), prefer clear numbers:
            if ws and ws.get("losingScore") is not None and wv is None:
                wv = ws.get("score")
                lv = ws.get("losingScore")
            # Finally ensure string pattern "6-3"
            if wv is None:
                wv = 0
            if lv is None:
                lv = 0
            parts.append(f"{int(wv)}-{int(lv)}")
        if not parts:
            return ""
        return ", ".join(parts) + ";"

    def record_from_match(self, match, round_desc=None):
        """
        Build a record populated with the variables you listed for a single match.
        For doubles, winner_1_name and winner_2_name will be filled.
        For singles, winner_2_name will remain ''.
        """
        rec = {
            "score": "",
            "winner_1_name": "",
            "winner_1_gender": "",
            "winner_1_third_party_id": "",
            "winner_1_city": "",
            "winner_1_country": "",
            "winner_1_state": "",
            "winner_2_name": "",
            "winner_2_gender": "",
            "winner_2_third_party_id": "",
            "winner_2_city": "",
            "winner_2_state": "",
            "loser_1_name": "",
            "loser_1_gender": "",
            "loser_1_third_party_id": "",
            "loser_1_city": "",
            "loser_1_state": "",
            "loser_1_country": "",
            "loser_2_name": "",
            "loser_2_gender": "",
            "loser_2_third_party_id": "",
            "loser_2_city": "",
            "loser_2_state": "",
            "outcome": "",
            "winner_2_country": "",
            "winner_2_college": "",
            "loser_2_country": "",
            "loser_2_college": "",
            "winner_1_college": "",
            "loser_1_college": "",
            "tournament_url": "",
            "winner_1_dob": "",
            "winner_2_dob": "",
            "loser_1_dob": "",
            "loser_2_dob": "",
            "matchId": match.get("matchId"),
            "round": round_desc or "",
        }

        teams = match.get("teams") or []
        if len(teams) < 2:
            return rec

        # Determine winner side (team with isWinner True). If none flagged, pick the one with higher total score.
        winner_idx = None
        for idx, t in enumerate(teams):
            if t.get("isWinner"):
                winner_idx = idx
                break
        if winner_idx is None:
            # fallback: sum first numeric scores
            sums = []
            for t in teams:
                ssum = 0
                for s in (t.get("scores") or []):
                    if s and isinstance(s.get("score"), (int, float)):
                        ssum += s.get("score")
                sums.append(ssum)
            winner_idx = 0 if sums and sums[0] >= sums[1] else 1

        loser_idx = 1 - winner_idx
        winner_team = teams[winner_idx]
        loser_team = teams[loser_idx]

        # Players
        winner_players = [p for p in (winner_team.get("players") or []) if p]
        loser_players = [p for p in (loser_team.get("players") or []) if p]

        # Single vs doubles
        if len(winner_players) >= 1:
            rec["winner_1_name"] = self.format_name(winner_players[0])
            rec["winner_1_link"] = self.get_player_link(winner_players[0])
            rec["winner_1_third_party_id"] = self.get_player_id(winner_players[0])
            rec["winner_1_country"] = self.infer_country(winner_players[0])
        if len(winner_players) >= 2:
            rec["winner_2_name"] = self.format_name(winner_players[1])
            rec["winner_2_link"] = self.get_player_link(winner_players[1])
            rec["winner_2_third_party_id"] = self.get_player_id(winner_players[1])
            rec["winner_2_country"] = self.infer_country(winner_players[1])

        if len(loser_players) >= 1:
            rec["loser_1_name"] = self.format_name(loser_players[0])
            rec["loser_1_link"] = self.get_player_link(loser_players[0])
            rec["loser_1_third_party_id"] = self.get_player_id(loser_players[0])
            rec["loser_1_country"] = self.infer_country(loser_players[0])
        if len(loser_players) >= 2:
            rec["loser_2_name"] = self.format_name(loser_players[1])
            rec["loser_2_link"] = self.get_player_link(loser_players[1])
            rec["loser_2_third_party_id"] = self.get_player_id(loser_players[1])
            rec["loser_2_country"] = self.infer_country(loser_players[1])

        # Score: use winner team's scores vs loser team's scores
        rec["score"] = self.build_score_string(winner_team.get("scores", []), loser_team.get("scores", []))

        # Outcome mapping
        rec["outcome"] = match.get("resultStatusDesc") or match.get("playStatusDesc") or ""
        if rec["outcome"] == 'Played and completed':
            rec["outcome"] = 'Completed'

        return rec

    def extract_all_records(self, data):
        """
        Walk common shapes in the feed and extract matches.
        The sample file uses an 'koGroups' structure — we attempt to handle that and top-level 'matches' arrays.
        """
        records = []

        # 1️⃣ Structured KO traversal (preferred)
        if isinstance(data, dict) and "koGroups" in data:
            for group in data.get("koGroups") or []:
                for r in group.get("rounds") or []:
                    rd = r.get("roundDesc")
                    for m in r.get("matches") or []:
                        records.append(self.record_from_match(m, rd))

        # 2️⃣ Generic recursive walk (keeps roundDesc)
        def walk(obj, current_round_desc=None):
            if isinstance(obj, dict):
                if "roundDesc" in obj:
                    current_round_desc = obj.get("roundDesc")

                for k, v in obj.items():
                    if k == "matches" and isinstance(v, list):
                        for m in v:
                            if isinstance(m, dict) and m.get("matchId"):
                                records.append(
                                    self.record_from_match(m, current_round_desc)
                                )
                    else:
                        walk(v, current_round_desc)

            elif isinstance(obj, list):
                for item in obj:
                    walk(item, current_round_desc)

        walk(data)
        # Deduplicate by matchId
        seen = {}
        out = []
        for r in records:
            mid = r.get("matchId")
            if mid and mid not in seen:
                seen[mid] = True
                out.append(r)
        return out
