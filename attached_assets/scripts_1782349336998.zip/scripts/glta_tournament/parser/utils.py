import traceback
from scripts import helper
from assets.fct.fctlog import logger

class Utils:

    def __init__(self, proxies, fctrequest):
        self.proxies = proxies
        self.fctrequest = fctrequest

        self.known_codes = {
            "afghanistan": "AFG", "albania": "ALB", "algeria": "DZA", "angola": "ANG",
            "argentina": "ARG", "armenia": "ARM", "australia": "AUS", "austria": "AUT",
            "azerbaijan": "AZE", "bahrain": "BHR", "bangladesh": "BGD", "belarus": "BLR",
            "belgium": "BEL", "bolivia": "BOL", "bosnia": "BIH", "brazil": "BRA",
            "bulgaria": "BGR", "cameroon": "CMR", "canada": "CAN", "chile": "CHI",
            "china": "CHN", "colombia": "COL", "congo": "COD", "croatia": "CRO",
            "cuba": "CUB", "czech republic": "CZE", "czechia": "CZE", "denmark": "DEN",
            "ecuador": "ECU", "egypt": "EGY", "england": "ENG", "ethiopia": "ETH",
            "finland": "FIN", "france": "FRA", "georgia": "GEO", "germany": "GER",
            "ghana": "GHA", "greece": "GRE", "great britain": "BRI", "hungary": "HUN",
            "india": "IND", "indonesia": "IDN", "iran": "IRI", "iraq": "IRQ",
            "ireland": "IRL", "israel": "ISR", "italy": "ITA", "ivory coast": "CIV",
            "jamaica": "JAM", "japan": "JPN", "jordan": "JOR", "kazakhstan": "KAZ",
            "kenya": "KEN", "kuwait": "KUW", "kyrgyzstan": "KGZ", "latvia": "LAT",
            "lebanon": "LIB", "libya": "LBA", "lithuania": "LTU", "luxembourg": "LUX",
            "malaysia": "MAS", "mali": "MLI", "mexico": "MEX", "moldova": "MDA",
            "mongolia": "MGL", "morocco": "MAR", "mozambique": "MOZ", "myanmar": "MYA",
            "namibia": "NAM", "netherlands": "NED", "new zealand": "NZL", "nigeria": "NGR",
            "north korea": "PRK", "norway": "NOR", "oman": "OMA", "pakistan": "PAK",
            "palestine": "PLE", "panama": "PAN", "paraguay": "PAR", "peru": "PER",
            "philippines": "PHI", "poland": "POL", "portugal": "POR", "qatar": "QAT",
            "romania": "ROU", "russia": "RUS", "saudi arabia": "KSA", "senegal": "SEN",
            "serbia": "SRB", "scotland": "SCO", "slovakia": "SVK", "slovenia": "SLO",
            "somalia": "SOM", "south africa": "RSA", "south korea": "KOR", "spain": "ESP",
            "sri lanka": "SRI", "sudan": "SDN", "sweden": "SWE", "switzerland": "SUI",
            "syria": "SYR", "taiwan": "TPE", "tajikistan": "TJK", "tanzania": "TAN",
            "thailand": "THA", "tunisia": "TUN", "turkey": "TUR", "turkmenistan": "TKM",
            "ukraine": "UKR", "united arab emirates": "UAE", "uae": "UAE",
            "united kingdom": "GBR", "uk": "GBR", "united states": "USA", "usa": "USA",
            "united states of america": "USA", "uruguay": "URU", "uzbekistan": "UZB",
            "venezuela": "VEN", "vietnam": "VIE", "wales": "WAL", "yemen": "YEM",
            "zambia": "ZAM", "zimbabwe": "ZIM",
        }

        self.stop_words = {
            "the", "of", "and", "republic", "democratic", "people's", "federation",
            "united", "kingdom", "states", "islands", "island", "saint", "north",
            "south", "east", "west", "new", "central", "cape", "isle",
        }


    def convert_full_country(self, country_name, api_key):
        short_country_code = ''
        key = country_name.strip().lower()

        # 1. Try known codes first
        if key in self.known_codes:
            short_country_code = self.known_codes[key]
            return short_country_code

        # 2. Fallback to AI if not found
        if not short_country_code:
            return helper.get_country_from_claude(country_name, api_key)
        return ''


    def change_language_to_english(self):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            index_link = 'https://glta.tournamentsoftware.com/cookiewall?lcid=1033'
            response1 = self.fctrequest.request(method='GET', link=index_link, headers=headers, proxies=self.proxies, tries=3)
        except Exception:
            logger.error(traceback.format_exc())


    def accept_cookies(self):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            data = {
                'ReturnUrl': '',
                'SettingsOpen': 'false',
                'CookiePurposes': [
                    '2',
                    '4',
                    '16',
                ],
            }

            index_link = 'https://glta.tournamentsoftware.com/cookiewall/Save'
            response1 = self.fctrequest.request(method='POST', link=index_link, headers=headers, data=data, proxies=self.proxies, tries=3)

        except Exception:
            logger.error(traceback.format_exc())
