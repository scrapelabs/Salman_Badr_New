html_text1 = '''<div class="module-container">
    <ul class="match-group match-group">
        <li class="match-group__item"> 

<div class="match">
    <div class="match__header">
          <ul class="match__header-title">
              <li class="match__header-title-item">
                
      <span title="Round 2" class="nav-link"><span class="nav-link__value">Round 2</span></span>

              </li>
              <li class="match__header-title-item">
                
      <a href="/sport/draw.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;draw=17" class="nav-link"><span class="nav-link__value">Grapplesnake</span></a>

              </li>
          </ul>
              <div class="match__header-aside">
          
                    
          
      <span class="nav-link btn--primary btn match__header-aside-block has-tooltip--wide" title="USTA BJK National Tennis Center" data-toggle="tooltip" data-placement="left">  <svg class="icon-info nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-info"></use></svg>
<span class="nav-link__value"></span></span>

          
        </div>
    </div>
  <div class="match__body">
    <div class="match__row-wrapper">

<div class="match__row has-won">
<div class="match__row-title">
        <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
              <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=23" data-player-id="23" data-club-id="" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">Steve Luo</span>
</a>
                  </span>
    </div>
      <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/COL.svg" alt="COL">
                  </span>
      <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=78" data-player-id="78" data-club-id="2" data-nationality-id="COL" class="nav-link"><span class="nav-link__value">Luis Rivera</span>
</a>
              </span>
    </div>
  </div>
  
</div>      
<div class="match__row ">
<div class="match__row-title">
        <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
              <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=80" data-player-id="80" data-club-id="2" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">Harumi Jang</span>
</a>
                  </span>
    </div>
      <div class="match__row-title-value">
      <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=46" data-player-id="46" data-club-id="" data-nationality-id="" class="nav-link"><span class="nav-link__value">Alex Wilson</span>
</a>
              </span>
    </div>
  </div>
  
<span class="tag--round tag--danger tag tag--small match__status">L</span></div>    </div>
      <div class="match__result">
              <ul class="points">
          <li class="points__cell points__cell--won"> 6
          </li>
          <li class="points__cell "> 1
          </li>
      </ul>
      <ul class="points">
          <li class="points__cell points__cell--won"> 6
          </li>
          <li class="points__cell "> 3
          </li>
      </ul>

      </div>
          <div class="match__btn">
<a class="btn btn--wm-vertical nav-link match__btn-h2h" href="/head-2-head?OrganizationCode=c608e303-2cdb-4cc2-8c6c-6ec76c6d06bd&amp;T1P1MemberID=302943&amp;T1P2MemberID=212684&amp;T2P1MemberID=265201">          <span class="nav-link__value">H2H</span>
</a>      </div>
      </div>
    <div class="match__footer">
        <ul class="match__footer-list">
            <li class="match__footer-list-item">
              
      <span class="nav-link">  <svg class="icon-clock nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-clock"></use></svg>
<span class="nav-link__value">Sun 12/7/2025 8:30 PM</span></span>

            </li>
            <li class="match__footer-list-item">
              
      <span class="nav-link">  <svg class="icon-marker nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-marker"></use></svg>
<span class="nav-link__value">USTA BJK National Tennis Center</span></span>

            </li>
        </ul>
          </div>
</div></li>
        <li class="match-group__item"> 

<div class="match">
    <div class="match__header">
          <ul class="match__header-title">
              <li class="match__header-title-item">
                
      <span title="Round 1" class="nav-link"><span class="nav-link__value">Round 1</span></span>

              </li>
              <li class="match__header-title-item">
                
      <a href="/sport/draw.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;draw=17" class="nav-link"><span class="nav-link__value">Grapplesnake</span></a>

              </li>
          </ul>
              <div class="match__header-aside">
          
                    
          
      <span class="nav-link btn--primary btn match__header-aside-block has-tooltip--wide" title="USTA BJK National Tennis Center" data-toggle="tooltip" data-placement="left">  <svg class="icon-info nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-info"></use></svg>
<span class="nav-link__value"></span></span>

          
        </div>
    </div>
  <div class="match__body">
    <div class="match__row-wrapper">

<div class="match__row has-won">
<div class="match__row-title">
        <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
              <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=96" data-player-id="96" data-club-id="2" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">Matty Barbato</span>
</a>
                  </span>
    </div>
      <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
      <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=86" data-player-id="86" data-club-id="2" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">Tyler Cook</span>
</a>
              </span>
    </div>
  </div>
  
</div>      
<div class="match__row ">
<div class="match__row-title">
        <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
              <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=80" data-player-id="80" data-club-id="2" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">Harumi Jang</span>
</a>
                  </span>
    </div>
      <div class="match__row-title-value">
      <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=46" data-player-id="46" data-club-id="" data-nationality-id="" class="nav-link"><span class="nav-link__value">Alex Wilson</span>
</a>
              </span>
    </div>
  </div>
  
<span class="tag--round tag--danger tag tag--small match__status">L</span></div>    </div>
      <div class="match__result">
              <ul class="points">
          <li class="points__cell points__cell--won"> 3
          </li>
          <li class="points__cell "> 0
          </li>
      </ul>
      <ul class="points">
          <li class="points__cell points__cell--won"> 3
          </li>
          <li class="points__cell "> 0
          </li>
      </ul>

      </div>
          <div class="match__btn">
<a class="btn btn--wm-vertical nav-link match__btn-h2h" href="/head-2-head?OrganizationCode=c608e303-2cdb-4cc2-8c6c-6ec76c6d06bd&amp;T1P1MemberID=626391&amp;T1P2MemberID=864312&amp;T2P1MemberID=265201">          <span class="nav-link__value">H2H</span>
</a>      </div>
      </div>
    <div class="match__footer">
        <ul class="match__footer-list">
            <li class="match__footer-list-item">
              
      <span class="nav-link">  <svg class="icon-clock nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-clock"></use></svg>
<span class="nav-link__value">Sun 12/14/2025 8:30 PM</span></span>

            </li>
            <li class="match__footer-list-item">
              
      <span class="nav-link">  <svg class="icon-marker nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-marker"></use></svg>
<span class="nav-link__value">USTA BJK National Tennis Center</span></span>

            </li>
        </ul>
          </div>
</div></li>
        <li class="match-group__item"> 

<div class="match">
    <div class="match__header">
          <ul class="match__header-title">
              <li class="match__header-title-item">
                
      <span title="Round 3" class="nav-link"><span class="nav-link__value">Round 3</span></span>

              </li>
              <li class="match__header-title-item">
                
      <a href="/sport/draw.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;draw=17" class="nav-link"><span class="nav-link__value">Grapplesnake</span></a>

              </li>
          </ul>
              <div class="match__header-aside">
          
                    
          
      <span class="nav-link btn--primary btn match__header-aside-block has-tooltip--wide" title="USTA BJK National Tennis Center" data-toggle="tooltip" data-placement="left">  <svg class="icon-info nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-info"></use></svg>
<span class="nav-link__value"></span></span>

          
        </div>
    </div>
  <div class="match__body">
    <div class="match__row-wrapper">

<div class="match__row ">
<div class="match__row-title">
        <div class="match__row-title-value">
              <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=85" data-player-id="85" data-club-id="" data-nationality-id="" class="nav-link"><span class="nav-link__value">Sherard Bailey</span>
</a>
                  </span>
    </div>
      <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
      <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=63" data-player-id="63" data-club-id="2" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">James A Medeiros</span>
</a>
              </span>
    </div>
  </div>
  
</div>      
<div class="match__row has-won">
<div class="match__row-title">
        <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
              <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=80" data-player-id="80" data-club-id="2" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">Harumi Jang</span>
</a>
                  </span>
    </div>
      <div class="match__row-title-value">
      <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=46" data-player-id="46" data-club-id="" data-nationality-id="" class="nav-link"><span class="nav-link__value">Alex Wilson</span>
</a>
              </span>
    </div>
  </div>
  
<span class="tag--round tag--success tag tag--small match__status">W</span></div>    </div>
      <div class="match__result">
              <ul class="points">
          <li class="points__cell "> 2
          </li>
          <li class="points__cell points__cell--won"> 6
          </li>
      </ul>
      <ul class="points">
          <li class="points__cell "> 0
          </li>
          <li class="points__cell points__cell--won"> 6
          </li>
      </ul>

      </div>
          <div class="match__btn">
<a class="btn btn--wm-vertical nav-link match__btn-h2h" href="/head-2-head?OrganizationCode=c608e303-2cdb-4cc2-8c6c-6ec76c6d06bd&amp;T1P2MemberID=922649&amp;T2P1MemberID=265201">          <span class="nav-link__value">H2H</span>
</a>      </div>
      </div>
    <div class="match__footer">
        <ul class="match__footer-list">
            <li class="match__footer-list-item">
              
      <span class="nav-link">  <svg class="icon-clock nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-clock"></use></svg>
<span class="nav-link__value">Sun 1/4/2026 6:30 PM</span></span>

            </li>
            <li class="match__footer-list-item">
              
      <span class="nav-link">  <svg class="icon-marker nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-marker"></use></svg>
<span class="nav-link__value">USTA BJK National Tennis Center</span></span>

            </li>
        </ul>
          </div>
</div></li>
        <li class="match-group__item"> 

<div class="match">
    <div class="match__header">
          <ul class="match__header-title">
              <li class="match__header-title-item">
                
      <span title="Round 7" class="nav-link"><span class="nav-link__value">Round 7</span></span>

              </li>
              <li class="match__header-title-item">
                
      <a href="/sport/draw.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;draw=17" class="nav-link"><span class="nav-link__value">Grapplesnake</span></a>

              </li>
          </ul>
              <div class="match__header-aside">
          
                    
          
      <span class="nav-link btn--primary btn match__header-aside-block has-tooltip--wide" title="USTA BJK National Tennis Center" data-toggle="tooltip" data-placement="left">  <svg class="icon-info nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-info"></use></svg>
<span class="nav-link__value"></span></span>

          
        </div>
    </div>
  <div class="match__body">
    <div class="match__row-wrapper">

<div class="match__row ">
<div class="match__row-title">
        <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
              <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=3" data-player-id="3" data-club-id="2" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">Leonard Braunschweiger</span>
</a>
                  </span>
    </div>
      <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
      <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=2" data-player-id="2" data-club-id="74" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">Russell Rising</span>
</a>
              </span>
    </div>
  </div>
  
</div>      
<div class="match__row has-won">
<div class="match__row-title">
        <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
              <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=80" data-player-id="80" data-club-id="2" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">Harumi Jang</span>
</a>
                  </span>
    </div>
      <div class="match__row-title-value">
      <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=46" data-player-id="46" data-club-id="" data-nationality-id="" class="nav-link"><span class="nav-link__value">Alex Wilson</span>
</a>
              </span>
    </div>
  </div>
  
<span class="tag--round tag--success tag tag--small match__status">W</span></div>    </div>
      <div class="match__result">
              <ul class="points">
          <li class="points__cell "> 0
          </li>
          <li class="points__cell points__cell--won"> 3
          </li>
      </ul>
      <ul class="points">
          <li class="points__cell "> 0
          </li>
          <li class="points__cell points__cell--won"> 3
          </li>
      </ul>

      </div>
          <div class="match__btn">
<a class="btn btn--wm-vertical nav-link match__btn-h2h" href="/head-2-head?OrganizationCode=c608e303-2cdb-4cc2-8c6c-6ec76c6d06bd&amp;T1P1MemberID=271765&amp;T1P2MemberID=504329&amp;T2P1MemberID=265201">          <span class="nav-link__value">H2H</span>
</a>      </div>
      </div>
    <div class="match__footer">
        <ul class="match__footer-list">
            <li class="match__footer-list-item">
              
      <span class="nav-link">  <svg class="icon-clock nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-clock"></use></svg>
<span class="nav-link__value">Sun 1/11/2026 6:30 PM</span></span>

            </li>
            <li class="match__footer-list-item">
              
      <span class="nav-link">  <svg class="icon-marker nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-marker"></use></svg>
<span class="nav-link__value">USTA BJK National Tennis Center</span></span>

            </li>
        </ul>
          </div>
</div></li>
        <li class="match-group__item"> 

<div class="match">
    <div class="match__header">
          <ul class="match__header-title">
              <li class="match__header-title-item">
                
      <span title="Round 4" class="nav-link"><span class="nav-link__value">Round 4</span></span>

              </li>
              <li class="match__header-title-item">
                
      <a href="/sport/draw.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;draw=17" class="nav-link"><span class="nav-link__value">Grapplesnake</span></a>

              </li>
          </ul>
              <div class="match__header-aside">
          
                    
          
      <span class="nav-link btn--primary btn match__header-aside-block has-tooltip--wide" title="USTA BJK National Tennis Center" data-toggle="tooltip" data-placement="left">  <svg class="icon-info nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-info"></use></svg>
<span class="nav-link__value"></span></span>

          
        </div>
    </div>
  <div class="match__body">
    <div class="match__row-wrapper">

<div class="match__row has-won">
<div class="match__row-title">
        <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/CZE.svg" alt="CZE">
                  </span>
              <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=60" data-player-id="60" data-club-id="2" data-nationality-id="CZE" class="nav-link"><span class="nav-link__value">Radim Pospisil</span>
</a>
                  </span>
    </div>
      <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/CHN.svg" alt="CHN">
                  </span>
      <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=70" data-player-id="70" data-club-id="2" data-nationality-id="CHN" class="nav-link"><span class="nav-link__value">Ray Zhong</span>
</a>
              </span>
    </div>
  </div>
  
</div>      
<div class="match__row ">
<div class="match__row-title">
        <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
              <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=80" data-player-id="80" data-club-id="2" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">Harumi Jang</span>
</a>
                  </span>
    </div>
      <div class="match__row-title-value">
      <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=46" data-player-id="46" data-club-id="" data-nationality-id="" class="nav-link"><span class="nav-link__value">Alex Wilson</span>
</a>
              </span>
    </div>
  </div>
  
<span class="tag--round tag--danger tag tag--small match__status">L</span></div>    </div>
      <div class="match__result">
              <ul class="points">
          <li class="points__cell points__cell--won"> 6
          </li>
          <li class="points__cell "> 4
          </li>
      </ul>
      <ul class="points">
          <li class="points__cell points__cell--won"> 7
          </li>
          <li class="points__cell "> 5
          </li>
      </ul>

      </div>
          <div class="match__btn">
<a class="btn btn--wm-vertical nav-link match__btn-h2h" href="/head-2-head?OrganizationCode=c608e303-2cdb-4cc2-8c6c-6ec76c6d06bd&amp;T1P1MemberID=179035&amp;T1P2MemberID=559134&amp;T2P1MemberID=265201">          <span class="nav-link__value">H2H</span>
</a>      </div>
      </div>
    <div class="match__footer">
        <ul class="match__footer-list">
            <li class="match__footer-list-item">
              
      <span class="nav-link">  <svg class="icon-clock nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-clock"></use></svg>
<span class="nav-link__value">Sun 2/1/2026 6:30 PM</span></span>

            </li>
            <li class="match__footer-list-item">
              
      <span class="nav-link">  <svg class="icon-marker nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-marker"></use></svg>
<span class="nav-link__value">USTA BJK National Tennis Center</span></span>

            </li>
        </ul>
          </div>
</div></li>
        <li class="match-group__item"> 

<div class="match">
    <div class="match__header">
          <ul class="match__header-title">
              <li class="match__header-title-item">
                
      <span title="Round 5" class="nav-link"><span class="nav-link__value">Round 5</span></span>

              </li>
              <li class="match__header-title-item">
                
      <a href="/sport/draw.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;draw=17" class="nav-link"><span class="nav-link__value">Grapplesnake</span></a>

              </li>
          </ul>
              <div class="match__header-aside">
          
                    
          
      <span class="nav-link btn--primary btn match__header-aside-block has-tooltip--wide" title="USTA BJK National Tennis Center" data-toggle="tooltip" data-placement="left">  <svg class="icon-info nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-info"></use></svg>
<span class="nav-link__value"></span></span>

          
        </div>
    </div>
  <div class="match__body">
    <div class="match__row-wrapper">

<div class="match__row has-won">
<div class="match__row-title">
        <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
              <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=47" data-player-id="47" data-club-id="2" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">Matthew Johnson</span>
</a>
                  </span>
    </div>
      <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/PHI.svg" alt="PHI">
                  </span>
      <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=36" data-player-id="36" data-club-id="2" data-nationality-id="PHI" class="nav-link"><span class="nav-link__value">Rome Romulo</span>
</a>
              </span>
    </div>
  </div>
  
</div>      
<div class="match__row ">
<div class="match__row-title">
        <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
              <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=80" data-player-id="80" data-club-id="2" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">Harumi Jang</span>
</a>
                  </span>
    </div>
      <div class="match__row-title-value">
      <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=46" data-player-id="46" data-club-id="" data-nationality-id="" class="nav-link"><span class="nav-link__value">Alex Wilson</span>
</a>
              </span>
    </div>
  </div>
  
<span class="tag--round tag--danger tag tag--small match__status">L</span></div>    </div>
      <div class="match__result">
              <ul class="points">
          <li class="points__cell points__cell--won"> 6
          </li>
          <li class="points__cell "> 4
          </li>
      </ul>
      <ul class="points">
          <li class="points__cell points__cell--won"> 6
          </li>
          <li class="points__cell "> 2
          </li>
      </ul>

      </div>
          <div class="match__btn">
<a class="btn btn--wm-vertical nav-link match__btn-h2h" href="/head-2-head?OrganizationCode=c608e303-2cdb-4cc2-8c6c-6ec76c6d06bd&amp;T1P1MemberID=451540&amp;T1P2MemberID=412796&amp;T2P1MemberID=265201">          <span class="nav-link__value">H2H</span>
</a>      </div>
      </div>
    <div class="match__footer">
        <ul class="match__footer-list">
            <li class="match__footer-list-item">
              
      <span class="nav-link">  <svg class="icon-clock nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-clock"></use></svg>
<span class="nav-link__value">Sun 2/8/2026 6:30 PM</span></span>

            </li>
            <li class="match__footer-list-item">
              
      <span class="nav-link">  <svg class="icon-marker nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-marker"></use></svg>
<span class="nav-link__value">USTA BJK National Tennis Center</span></span>

            </li>
        </ul>
          </div>
</div></li>
        <li class="match-group__item"> 

<div class="match">
    <div class="match__header">
          <ul class="match__header-title">
              <li class="match__header-title-item">
                
      <span title="Round 6" class="nav-link"><span class="nav-link__value">Round 6</span></span>

              </li>
              <li class="match__header-title-item">
                
      <a href="/sport/draw.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;draw=17" class="nav-link"><span class="nav-link__value">Grapplesnake</span></a>

              </li>
          </ul>
              <div class="match__header-aside">
          
                    
          
      <span class="nav-link btn--primary btn match__header-aside-block has-tooltip--wide" title="USTA BJK National Tennis Center" data-toggle="tooltip" data-placement="left">  <svg class="icon-info nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-info"></use></svg>
<span class="nav-link__value"></span></span>

          
        </div>
    </div>
  <div class="match__body">
    <div class="match__row-wrapper">

<div class="match__row ">
<div class="match__row-title">
        <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
              <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=80" data-player-id="80" data-club-id="2" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">Harumi Jang</span>
</a>
                  </span>
    </div>
      <div class="match__row-title-value">
      <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=46" data-player-id="46" data-club-id="" data-nationality-id="" class="nav-link"><span class="nav-link__value">Alex Wilson</span>
</a>
              </span>
    </div>
  </div>
  
<span class="tag--round tag--danger tag tag--small match__status">L</span></div>      
<div class="match__row has-won">
<div class="match__row-title">
        <div class="match__row-title-value">
        <span class="match__row-title-prefix">
            <img class="icon-lang" src="//static.tournamentsoftware.com/content/images/flags/USA.svg" alt="USA">
                  </span>
              <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=54" data-player-id="54" data-club-id="2" data-nationality-id="USA" class="nav-link"><span class="nav-link__value">Timothy Hilario</span>
</a>
                  </span>
    </div>
      <div class="match__row-title-value">
      <span class="match__row-title-value-content">

      <a href="/sport/player.aspx?id=7e648176-9ed6-47ea-8126-120dbc0e776c&amp;player=90" data-player-id="90" data-club-id="" data-nationality-id="" class="nav-link"><span class="nav-link__value">Ed Teh</span>
</a>
              </span>
    </div>
  </div>
  
</div>    </div>
      <div class="match__result">
              <ul class="points">
          <li class="points__cell "> 0
          </li>
          <li class="points__cell points__cell--won"> 3
          </li>
      </ul>
      <ul class="points">
          <li class="points__cell "> 0
          </li>
          <li class="points__cell points__cell--won"> 3
          </li>
      </ul>

      </div>
          <div class="match__btn">
<a class="btn btn--wm-vertical nav-link match__btn-h2h" href="/head-2-head?OrganizationCode=c608e303-2cdb-4cc2-8c6c-6ec76c6d06bd&amp;T1P1MemberID=265201&amp;T2P1MemberID=276772">          <span class="nav-link__value">H2H</span>
</a>      </div>
      </div>
    <div class="match__footer">
        <ul class="match__footer-list">
            <li class="match__footer-list-item">
              
      <span class="nav-link">  <svg class="icon-clock nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-clock"></use></svg>
<span class="nav-link__value">Sun 3/15/2026 6:30 PM</span></span>

            </li>
            <li class="match__footer-list-item">
              
      <span class="nav-link">  <svg class="icon-marker nav-link__prefix" aria-hidden="true" width="20" height="20"><use xlink:href="/Content/images/sprite.svg?v=20241015131749#icon-marker"></use></svg>
<span class="nav-link__value">USTA BJK National Tennis Center</span></span>

            </li>
        </ul>
          </div>
</div></li>
    </ul>
            </div>'''


import re, logging, coloredlogs
from scrapy.selector import Selector
from urllib.parse import urljoin

logger = logging.getLogger("scraper")
logger.setLevel(logging.INFO)
coloredlogs.install(level="INFO", logger=logger)

class ParseSport:
    def __init__(self):
        pass

    def parse_match(self, sel):
        # -------- OUTCOME --------
        outcome = "Completed"
        if sel.xpath('.//*[contains(normalize-space(.),"Retired")]'):
            outcome = "Retired"

        # -------- PLAYERS (KEEP ROW ORDER) --------
        rows = sel.xpath(
            './/div[contains(@class,"match__row-wrapper")]/div[contains(@class,"match__row")]'
        )

        row_players = []  # index 0 = top row, index 1 = bottom row
        winner_row_index = None

        for idx, row in enumerate(rows):
            players = []
            for a in row.xpath('.//a[contains(@class,"nav-link")]'):
                name = a.xpath('.//span[@class="nav-link__value"]/text()').get()
                href = a.xpath('./@href').get()
                if name and href:
                    players.append({
                        "name": self.clean_name(name),
                        "profile_url": urljoin(
                            "https://glta.tournamentsoftware.com/",
                            href.strip()
                        )
                    })

            row_players.append(players)

            if 'has-won' in row.attrib.get('class', ''):
                winner_row_index = idx

        loser_row_index = 1 - winner_row_index

        winners = row_players[winner_row_index]
        losers = row_players[loser_row_index]

        # -------- SCORE (ROW ORDER BASED) --------
        scores = []

        for ul in sel.xpath('//div[contains(@class,"match__result")]//ul[@class="points"]'):
            cells = [c.xpath('normalize-space(text())').get() for c in ul.xpath('./li')]
            if len(cells) != 2:
                continue

            winner_games = cells[winner_row_index]
            loser_games = cells[loser_row_index]

            scores.append(f"{winner_games}-{loser_games}")

        draw_team_type = "Doubles" if len(winners) == 2 else "Singles"

        match_data = {
            "draw_team_type": draw_team_type,
            "outcome": outcome,
            "score": ", ".join(scores) + ";" if scores else "",

            "winner_1": winners[0] if len(winners) > 0 else {},
            "winner_2": winners[1] if len(winners) > 1 else {},

            "loser_1": losers[0] if len(losers) > 0 else {},
            "loser_2": losers[1] if len(losers) > 1 else {},
        }

        logger.info(f'match_data: {match_data}')

        return match_data


    def clean_name(self, name: str) -> str:
        return re.sub(r"\s*\[[^\]]+\]\s*$", "", name).strip()


if __name__ == "__main__":
    html1 = Selector(text=html_text1)
    for d1 in html1.xpath('//div[@class="module-container"]/ul/li[@class="match-group__item"]/div[@class="match"]'):
        match_data = ParseSport().parse_match(Selector(text=d1.xpath('.//div[@class="match__body"]').get()))
        logger.info(f'match_data: {match_data}')

        draw_team_type = match_data.get("draw_team_type", "")
        outcome = match_data.get("outcome", "")
        score = match_data.get("score", "")

        winner_1_name = match_data.get("winner_1", {}).get('name', '')
        winner_1_url = match_data.get("winner_1", {}).get('profile_url', '')

        winner_2_name = match_data.get("winner_2", {}).get('name', '')
        winner_2_url = match_data.get("winner_2", {}).get('profile_url', '')

        loser_1_name = match_data.get("loser_1", {}).get('name', '')
        loser_1_url = match_data.get("loser_1", {}).get('profile_url', '')

        loser_2_name = match_data.get("loser_2", {}).get('name', '')
        loser_2_url = match_data.get("loser_2", {}).get('profile_url', '')

        logger.info(f'score: {score}')
        logger.info(f'winner_1_name: {winner_1_name} | winner_2_name: {winner_2_name}')
        logger.info(f'loser_1_name: {loser_1_name} | loser_2_name: {loser_2_name}')
        logger.info('*'*50)

