import traceback
from assets.fct.fctlog import logger

class Utils:

    def __init__(self, proxies, fctrequest):
        self.proxies = proxies
        self.fctrequest = fctrequest


    def change_language_to_english(self):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            index_link = 'https://etl.tournamentsoftware.com/cookiewall?lcid=1033'
            response1 = self.fctrequest.request(method='GET', link=index_link, headers=headers, proxies=self.proxies, tries=3)
        except Exception:
            logger.error(traceback.format_exc())


    def accept_cookies(self):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            data = {
                'ReturnUrl': '',
                'SettingsOpen': 'false',
                'CookiePurposes': [
                    '2',
                    '4',
                    '16',
                ],
            }

            index_link = 'https://etl.tournamentsoftware.com/cookiewall/Save'
            response1 = self.fctrequest.request(method='POST', link=index_link, headers=headers, data=data, proxies=self.proxies, tries=3)

        except Exception:
            logger.error(traceback.format_exc())
