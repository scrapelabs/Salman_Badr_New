import traceback
from scrapy.selector import Selector
from urllib.parse import urljoin, urlparse, parse_qs
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts import helper
from scripts.log_items import ItemsLogger
from scripts.sweden_tournament.parser.utils import Utils

class TournamentParser:

    def __init__(self):
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=True, use_cffi=False, use_proxy=self.use_proxy)
        self.df_tournaments = ItemsLogger()
        self.Utils = Utils(self.proxies, self.fctrequest)
        self.Utils.change_language_to_english()
        self.Utils.accept_cookies()


    def parse_tournaments(self, job_start_date, job_end_date, job_tournament_url):
        try:
            if job_tournament_url:
                try:
                    headers = {
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                        'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                        'upgrade-insecure-requests': '1',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
                    }
                    response1 = self.fctrequest.request(method='GET', link=job_tournament_url, headers=headers, proxies=self.proxies, tries=3)
                    if response1:
                        if response1.status_code in range(200, 300):
                            html1 = Selector(text=response1.text)

                            tournament_name = fctcore.parse_field('//div[contains(@class, "page-head")]//div[@class="media__content"]//h2[contains(@class, "media__title")]//span[contains(@class, "nav-link")]/span[@class="nav-link__value"]', html1)

                            tournament_url = ''
                            tournament_id = ''
                            tournament_url_pre = fctcore.parse_field('//ul[contains(@class, "page-nav")]//li[contains(@class, "page-nav__item")]//a[@class="page-nav__link" and contains(text(), "Overview")]/@href', html1)
                            if tournament_url_pre:
                                tournament_url = urljoin(f'https://svtf.tournamentsoftware.com/', tournament_url_pre)
                                try:
                                    path_parts = urlparse(tournament_url).path.strip("/").split("/")
                                    idx = path_parts.index("tournament")
                                    tournament_id = path_parts[idx + 1]
                                except Exception:
                                    ''

                            tournament_city = ''
                            tournament_range_date = ''
                            tournament_start_date = ''
                            tournament_end_date = ''
                            for d1 in html1.xpath('//div[@class="media__content"]//small[contains(@class, "media__subheading")]//span[@class="nav-link"]//span[@class="nav-link__value"]'):
                                try:
                                    if 'calendar.svg' in d1.xpath('./svg/use').get():
                                        tournament_range_date = fctcore.parse_field('./.', d1)
                                        tournament_start_date, tournament_end_date = helper.parse_tournament_range_date(tournament_range_date, format='%m/%d/%Y')
                                except Exception:
                                    ''
                                try:
                                    if ' | ' in fctcore.parse_field('./text()', d1):
                                        tournament_city = fctcore.parse_field('./text()', d1).split('|')[-1].strip()
                                except Exception:
                                    ''

                            logger.info(f'tournament_name: {tournament_name}')
                            logger.info(f'tournament_url: {tournament_url}')
                            logger.info(f'tournament_id: {tournament_id}')
                            logger.info(f'tournament_range_date: {tournament_range_date}')
                            logger.info(f'tournament_start_date: {tournament_start_date}')
                            logger.info(f'tournament_end_date: {tournament_end_date}')
                            logger.info(f'tournament_city: {tournament_city}')

                            if tournament_id and tournament_name and tournament_url:
                                self.df_tournaments.log({
                                    "tournament_id": tournament_id,
                                    "tournament_name": tournament_name,
                                    "tournament_url": tournament_url,
                                    "tournament_start_date": tournament_start_date,
                                    "tournament_end_date": tournament_end_date,
                                    "tournament_city": tournament_city,
                                })

                except Exception:
                    logger.error(traceback.format_exc())

            else:
                try:
                    headers = {
                        'accept': '*/*',
                        'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
                        'x-requested-with': 'XMLHttpRequest',
                    }

                    data = {
                        'LoadMoreResults': 'LoadMoreResults',
                        'Page': '1',
                        'TournamentExtendedFilter.SportID': '0',
                        'TournamentFilter.Q': '',
                        'TournamentFilter.DateFilterType': '0',
                        'TournamentFilter.StartDate': '2025-12-19',
                        'TournamentFilter.EndDate': '2026-03-22',
                        'TournamentFilter.PostalCode': '',
                        'TournamentFilter.Distance': '15',
                        'TournamentExtendedFilter.StatusFilterID': 'false',
                        'TournamentExtendedFilter.EventGameTypeIDList[0]': 'false',
                        'TournamentExtendedFilter.EventGameTypeIDList[1]': 'false',
                        'TournamentExtendedFilter.EventGameTypeIDList[2]': 'false',
                        'TournamentExtendedFilter.EventGameTypeIDList[3]': 'false',
                        'TournamentExtendedFilter.EventGameTypeIDList[4]': 'false',
                        'X-Requested-With': 'XMLHttpRequest',
                    }

                    index_link = 'https://svtf.tournamentsoftware.com/find/tournament/DoSearch'

                    # job_start_date = fctcore.get_offset_date(days=14, direction='-', format='%Y-%m-%d')
                    # job_end_date = fctcore.current_date(format='%Y-%m-%d')

                    logger.info(f'job_start_date: {job_start_date}')
                    logger.info(f'job_end_date: {job_end_date}')

                    page = 0
                    while True:
                        results_found = False
                        page += 1
                        data['Page'] = page
                        data['TournamentFilter.StartDate'] = job_start_date
                        data['TournamentFilter.EndDate'] = job_end_date

                        logger.info(f'page: {page}')

                        response1 = self.fctrequest.request(method='POST', link=index_link, data=data, headers=headers, proxies=self.proxies, tries=3)
                        if response1:
                            if response1.status_code in range(200, 300):
                                html1 = Selector(text=response1.text)

                                for d1 in html1.xpath('//li[@class="list__item"]//div[@class="media__content"]'):
                                    results_found = True
                                    tournament_name = fctcore.parse_field('.//h4[@class="media__title"]/a/@title', d1)
                                    tournament_url = urljoin(f'https://svtf.tournamentsoftware.com/', fctcore.parse_field('.//h4[@class="media__title"]/a/@href', d1))
                                    tournament_id = parse_qs(urlparse(tournament_url).query).get('id', [''])[0]
                                    tournament_start_date = fctcore.convert_string_to_date_format(fctcore.parse_field('.//small[contains(@class, "media__subheading")]//span[@class="nav-link"]//span[@class="nav-link__value"]/time[1]', d1), in_format='%d/%m/%Y', out_format='%m/%d/%Y')
                                    tournament_end_date = fctcore.convert_string_to_date_format(fctcore.parse_field('.//small[contains(@class, "media__subheading")]//span[@class="nav-link"]//span[@class="nav-link__value"]/time[2]', d1), in_format='%d/%m/%Y', out_format='%m/%d/%Y')

                                    if not tournament_end_date:
                                        tournament_end_date = tournament_start_date

                                    tournament_city = ''
                                    try:
                                        tournament_city = fctcore.parse_field('.//small[@class="media__subheading"]//span[@class="nav-link"]/span[@class="nav-link__value"]', d1).split('|')[-1].strip()
                                    except Exception:
                                        ''

                                    if tournament_id and tournament_name and tournament_url:
                                        self.df_tournaments.log({
                                            "tournament_id": tournament_id,
                                            "tournament_name": tournament_name,
                                            "tournament_url": tournament_url,
                                            "tournament_start_date": tournament_start_date,
                                            "tournament_end_date": tournament_end_date,
                                            "tournament_city": tournament_city,
                                        })

                        if not results_found:
                            break

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())

        return self.df_tournaments.get_df()

