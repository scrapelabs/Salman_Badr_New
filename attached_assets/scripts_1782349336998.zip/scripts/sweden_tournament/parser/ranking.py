import traceback, math, random
import concurrent.futures
from scrapy.selector import Selector
from urllib.parse import urljoin
from os.path import basename, dirname, abspath
from django.conf import settings
from django.db import close_old_connections
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts import helper
from scripts.sweden_tournament.parser.utils import Utils
from app_spiders.models import PlayersSwedenTournamentModel

class RankingParser:

    def __init__(self, progress):
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=True, use_cffi=False, use_proxy=self.use_proxy)
        self.spider_name = basename(dirname(dirname(abspath(__file__))))
        self.Utils = Utils(self.proxies, self.fctrequest)
        self.Utils.change_language_to_english()
        self.Utils.accept_cookies()


    def parse_ranking_profile(self, max_workers):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }
            index_link = 'https://svtf.tournamentsoftware.com/ranking/'

            response1 = self.fctrequest.request(method='GET', link=index_link, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)
                    ranking_category_url_pre = fctcore.parse_field('//div[@id="content"]//table[@class="ruler"]//tr[1]/td/h5/a/@href', html1)
                    logger.info(f'ranking_category_url_pre: {ranking_category_url_pre}')
                    if ranking_category_url_pre:
                        ranking_category_url = urljoin(f'https://svtf.tournamentsoftware.com/ranking/', ranking_category_url_pre)
                        logger.info(f'ranking_category_url: {ranking_category_url}')
                        self.parse_ranking_category(ranking_category_url, max_workers)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_ranking_category(self, ranking_category_url, max_workers):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=ranking_category_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)
                    for d1 in html1.xpath('//div[@id="content"]//table[@class="ruler"]//tr/th/a[text()="More"]'):
                        ranking_page_url_pre = fctcore.parse_field('./@href', d1)
                        logger.info(f'ranking_page_url_pre: {ranking_page_url_pre}')
                        if ranking_page_url_pre:
                            ranking_page_url = urljoin(f'https://svtf.tournamentsoftware.com/ranking/', f'{ranking_page_url_pre}&ps=100')
                            logger.info(f'ranking_page_url: {ranking_page_url}')
                            self.parse_ranking_page(ranking_page_url, max_workers)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_ranking_page(self, ranking_page_url, max_workers):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=ranking_page_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    count_result = 0
                    count_page = 0
                    try:
                        count_result = int(fctcore.parse_field('//div[@class="pagenumbers"]//span[@class="page_caption"]', html1).split(' - ')[-1].strip().split()[0])
                        count_page = math.ceil(count_result/100)
                    except Exception:
                        ''
                    logger.info(f'count_result: {count_result} | count_page: {count_page}')
                    logger.info(f'page: 1/{count_page} | {ranking_page_url}')

                    self.parse_ranking_details(html1)
                    self.parse_ranking_threading(ranking_page_url, count_page, max_workers)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_ranking_threading(self, ranking_page_url, count_page, max_workers):
        try:
            page_list = list(range(1, count_page))
            page_chunks = list(fctcore.split_list_into_chunks(lst=page_list, max_workers=max_workers))
            if max_workers > len(page_chunks): max_workers=len(page_chunks)

            if max_workers:
                with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                    main_task = self.progress.add_task(description=f'{self.spider_name}_ranking', total=len(page_list))
                    for thread_id, page_chunk in enumerate(page_chunks):
                        thread_task = self.progress.add_task(f"Thread {thread_id + 1}", total=len(page_chunk))
                        executor.submit(self.parse_ranking_pagination, ranking_page_url, count_page, page_chunk, main_task, thread_task)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_ranking_pagination(self, ranking_page_url, count_page, page_chunk, main_task, thread_task):
        try:
            for page in page_chunk:
                self.progress.update(main_task, advance=1)
                self.progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    headers = {
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                        'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                        'upgrade-insecure-requests': '1',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
                    }

                    ranking_page_nav = f'{ranking_page_url}&p={page+1}'
                    logger.info(f'page: {page}/{count_page} | {ranking_page_nav}')

                    response1 = self.fctrequest.request(method='GET', link=ranking_page_nav, headers=headers, proxies=self.proxies, tries=3)
                    if response1:
                        if response1.status_code in range(200, 300):
                            html1 = Selector(text=response1.text)
                            self.parse_ranking_details(html1)

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())


    def parse_ranking_details(self, html1):
        try:
            for d1 in html1.xpath('//div[@id="content"]//table[@class="ruler"]//tr[td[@class="rank"]]'):
                country = fctcore.parse_field('.//td[4]', d1)
                player_name = fctcore.parse_field('.//td[5]/a', d1)
                third_party_id = fctcore.parse_field('.//td[7]', d1)
                yob = fctcore.parse_field('.//td[8]', d1)
                dob = ''
                if yob:
                    dob = f'1/1/{yob}'
                club = fctcore.parse_field('.//td[9]', d1)

                if third_party_id:
                    if not PlayersSwedenTournamentModel.objects.filter(spider_name=self.spider_name, third_party_id=third_party_id).exists():
                        logger.info(f'new: player_name: {player_name} | third_party_id: {third_party_id} | yob: {yob} | dob: {dob}')

                        claude_key = random.choice(settings.CLAUDE_KEYS)
                        player_name, player_gender = helper.format_name_gender_claude(player_name, claude_key)

                        PlayersSwedenTournamentModel(
                            spider_name=self.spider_name,
                            player_type='ranking',
                            third_party_id=third_party_id,
                            player_name=player_name,
                            dob=dob,
                            gender=player_gender,
                            country=country,
                            club=club,
                        ).save()

                    # else:
                    #     logger.warning(f'exist: player_name: {player_name} | third_party_id: {third_party_id}')

        except Exception:
            logger.error(traceback.format_exc())
