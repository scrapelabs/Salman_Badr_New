html_text1 = '''<html class="gt-ie8 gt-ie9 not-ie pxajs" lang="pt-BR"><!--<![endif]--><head>
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta name="robots" content="Index">
	<meta name="keywords" content="tênis, tennis, esporte, torneios, rankings, pickleball">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
	<meta name="globalsign-domain-verification" content="l4IdKDY0nbYWOlL-MKu-ZCZsTX4qhsgFq_0jV4kfaD">
	<meta name="google-site-verification" content="KbjUe4hXYXOobh6ZmleQC7B2hwjVp2nAz4bB9E9PM6g">
			<title>Sistema Tenis Integrado</title>
<base href="https://uruguay.tenisintegrado.com/"> 		<link href="images/favicon.ico" rel="icon" type="image/x-icon">
	
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,400,600,700,300&amp;subset=latin,latin-ext" rel="stylesheet" type="text/css">
	<link href="./bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
			<link href="./styles/all.min.css" rel="stylesheet">
		<script type="text/javascript" async="" charset="utf-8" src="https://www.gstatic.com/recaptcha/releases/Br0hYqpfWeFzYCAXLD4UuCIV/recaptcha__es_419.js" crossorigin="anonymous" integrity="sha384-sCuh1qnzBjbzGzwtNjmxatT+9ByKzyGe7kzdlmSaznMQaXCaHL5bNikXqPh0oO/J"></script><script async="" src="//www.google-analytics.com/analytics.js"></script><script src="https://www.google.com/recaptcha/api.js?hl=es-419" async="" defer=""></script>
<style>body.tablesorter-disableSelection { -ms-user-select: none; -moz-user-select: -moz-none;-khtml-user-select: none; -webkit-user-select: none; user-select: none; }.tablesorter-resizable-container { position: relative; height: 1px; }.tablesorter-resizable-handle { position: absolute; display: inline-block; width: 8px;top: 1px; cursor: ew-resize; z-index: 3; user-select: none; -moz-user-select: none; }</style><style type="text/css">.jqstooltip { position: absolute;left: 0px;top: 0px;visibility: hidden;background: rgb(0, 0, 0) transparent;background-color: rgba(0,0,0,0.6);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000);-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000)";color: white;font: 10px arial, san serif;text-align: left;white-space: nowrap;padding: 5px;border: 1px solid white;z-index: 10000;}.jqsfield { color: white;font: 10px arial, san serif;text-align: left;}</style><style class="automa-element-selector">@font-face { font-family: "Inter var"; font-weight: 100 900; font-display: swap; font-style: normal; font-named-instance: "Regular"; src: url("chrome-extension://infppggnoaenmfagbfknfkancpbljcca/Inter-roman-latin.var.woff2") format("woff2") }
.automa-element-selector { direction: ltr } 
 [automa-isDragging] { user-select: none } 
 [automa-el-list] {outline: 2px dashed #6366f1;}</style></head>
<!--[if lte IE 9]>
<body>
	<div class="lte-ie9-warning">
		<h1>Já é hora de atualizar seu navegador!</h1>
		<p>Você está usando uma versão do Internet Explorer desatualizada. O Sistema Tênis Integrado, assim como muitos websites não dão mais suporte a versões do Internet Explorer inferiores à versão 9. Infelizmente você não conseguirá visualizar nosso sistema até atualizar o seu navegador.</p>
		<p>Como alternativa sugerimos também o uso de navegadores gratuitos como o <a href="https://www.mozilla.org/pt-BR/firefox/new/">Firefox</a> ou o <a href="https://www.google.com.br/chrome/">Chrome</a>.</p>
	</div>
</body>
<![endif]-->
<!--[if gt IE 9]><!-->

<body class="theme-default main-menu-animated dont-animate-mm-content-sm animate-mm-md animate-mm-lg" style="">
	<script>
		var init = [];
	</script>
	<div id="main-wrapper">

		<!-- Open Header -->
		<script>
	(function(i, s, o, g, r, a, m) {
		i['GoogleAnalyticsObject'] = r;
		i[r] = i[r] || function() {
			(i[r].q = i[r].q || []).push(arguments)
		}, i[r].l = 1 * new Date();
		a = s.createElement(o),
			m = s.getElementsByTagName(o)[0];
		a.async = 1;
		a.src = g;
		m.parentNode.insertBefore(a, m)
	})(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

	ga('create', 'UA-57559881-1', 'auto');
	ga('send', 'pageview');
</script>




<input type="hidden" value="es" id="language_setter">

<div id="main-navbar" class="navbar" role="navigation">


	<!-- Main menu toggle -->
	<button type="button" id="main-menu-toggle"><i class="navbar-icon fa fa-bars icon"></i><span class="hide-menu-text">Fechar Menu</span></button>

	<div class="navbar-inner">
		<!-- Main navbar header -->
		<div class="navbar-header">

			<!-- Logo -->
			<a href="perfil2/index/204647" class="navbar-brand">
				<div><img style="width: 140px; object-fit: contain;" src="images/logo-tenisintegrado.png"></div>
			</a>
			<!-- Main navbar toggle -->
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main-navbar-collapse"><i class="navbar-icon fa fa-bars"></i></button>

		</div> <!-- / .navbar-header -->

		<div id="main-navbar-collapse" class="collapse navbar-collapse main-navbar-collapse">
			<div>

				<div style="padding: 14px;float: left;color: red;font-weight: 600;">
					<spam class="text-success text-bold">URUGUAY </spam>
				</div>

				<div class="right clearfix">
					<ul class="nav navbar-nav pull-right right-navbar-nav">

						<!-- QJT-TODO: Busca Temporariamente desabilitada aqui pois ainda não está implementada.
							<li>
								<form action="" class="navbar-form pull-left">
									<div class="input-group">
										<input type="text" placeholder="Buscar..." class="form-control">
										<button class="input-group-addon" type="Submit"><i class="fa fa-search"></i></button>
									</div>
								</form>
							</li>
							-->

						<!--
							NOTE: .nav-icon-btn triggers a dropdown menu on desktop screens only. On small screens .nav-icon-btn acts like a hyperlink.

							Classes:
							* 'nav-icon-btn-info'
							* 'nav-icon-btn-success'
							* 'nav-icon-btn-warning'
							* 'nav-icon-btn-danger' 
							-->

						
							<!-- início - Deslogado -->
							<li class="nav-icon-sign-in nav-icon-btn nav-icon-btn-danger dropdown">
								<a href="https://uruguay.tenisintegrado.com/login" class="dropdown-toggle" data-toggle="dropdown">
									<i class="nav-icon fa fa-sign-in"></i>
									<span class="small-screen-text">Ingresar Aquí</span>
								</a>
							</li>
															<li class="nav-icon-register nav-icon-btn nav-icon-btn-danger dropdown">
									<a href="https://uruguay.tenisintegrado.com/integresse" class="dropdown-toggle" data-toggle="dropdown">
										<i class="nav-icon fa fa-pencil-square-o"></i>
										<span class="small-screen-text">Registrarse</span>
									</a>
								</li>
														<p class="navbar-text">
								Hola, <a href="https://uruguay.tenisintegrado.com/login" class="navbar-link">ingresar aquí</a>
																	o <a href="https://uruguay.tenisintegrado.com/integresse" class="navbar-link">registrarse</a>.
															</p>
							<!-- Fim - Deslogado -->
						

					</ul> <!-- / .navbar-nav -->
				</div> <!-- / .right -->
			</div>
		</div> <!-- / #main-navbar-collapse -->
		<!--<div id="navbar-bottom">
				<ul class="nav navbar-nav navbar-filters">
					<li><a href="#">Todos</a></li>
					<li><a href="#">Galerias</a></li>
					<li><a href="#">Vídeos</a></li>
					<li><a href="#">Amigos</a></li>
				</ul>
			</div>-->
	</div> <!-- / .navbar-inner -->
</div> <!-- / #main-navbar -->

<!-- SUPORTE FRESHDESK -->

	<script>
		window.fwSettings = {
			'widget_id': 13000000570		};
		! function() {
			if ("function" != typeof window.FreshworksWidget) {
				var n = function() {
					n.q.push(arguments)
				};
				n.q = [], window.FreshworksWidget = n
			}
		}()
	</script>
	<script type="text/javascript" src="https://widget.freshworks.com/widgets/13000000570.js" async="" defer=""></script>
		<!-- End Header -->

		<!-- Open Main Menu -->
			<div id="main-menu" role="navigation">
		<div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 100%;"><div id="main-menu-inner" style="overflow: hidden; width: auto; height: 100%;">
			<ul class="navigation">

				<li>
					<a href="home"><i class="menu-icon fa fa-home"></i><span class="mm-text mmc-dropdown-delay animated fadeIn">Inicio</span></a>
				</li>

				<li>
										<a href="https://uy.tenisintegrado.com"><i class="menu-icon fa fa-globe"></i><span class="mm-text mmc-dropdown-delay animated fadeIn">Asociación Uruguaya de Tenis</span></a>
				</li>

				<li>
					<a href="new_torneio"><i class="menu-icon fa fa-trophy"></i><span class="mm-text mmc-dropdown-delay animated fadeIn">Torneos</span></a>
				</li>

				<li>
					<a href="new_ranking"><i class="menu-icon fa fa-list-ol"></i><span class="mm-text mmc-dropdown-delay animated fadeIn">Rankings</span></a>
				</li>

				<li>
					<a href="eventos"><i class="menu-icon fa fa-trophy"></i><span class="mm-text mmc-dropdown-delay animated fadeIn">Cursos/Eventos</span></a>
				</li>

				
									<li>
						<a href="https://uy.tenisintegrado.com/clubs"><i class="menu-icon fa fa-folder-o"></i><span class="mm-text mmc-dropdown-delay animated fadeIn">Clubes</span></a>
					</li>
									<li>
						<a href="https://uy.tenisintegrado.com/rating/wtn/wtn-rating"><i class="menu-icon fa fa-sort-alpha-desc"></i><span class="mm-text mmc-dropdown-delay animated fadeIn">World Tennis Number</span></a>
					</li>
									<li>
						<a href="politica_privacidade_publico"><i class="menu-icon fa fa-users"></i><span class="mm-text mmc-dropdown-delay animated fadeIn">Política de Privacidad</span></a>
					</li>
					
			</ul> <!-- / .navigation -->
		</div><div class="slimScrollBar" style="background: rgb(0, 0, 0); width: 7px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 393px;"></div><div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div> <!-- / #main-menu-inner -->
		<div class="main-menu-inner-bottom">
			<ul class="owners">
				<li class="owner-item">
					<label>Sistema:</label>
					<img src="./images/qjt.png" alt="">
				</li>
			</ul>
			<ul class="owners">
				<li class="owner-item">
					<div style="margin-top:3px;">
						<span class="text-bold">EMPRESA</span>
					</div>
					<div>
						INFO ESPORTES LTDA
					</div>

					<div style="margin-top:3px;">
						<span class="text-bold">CNPJ</span>
					</div>
					<div>
						07.804.000/0001-93
					</div>


					<div style="margin-top:3px;">
						<span class="text-bold">DIRECCIÓN</span>
					</div>
					<div>
						<span>Av. Mostardeiro, 777 Sala 1401</span>
					</div>
					<div>
						<span>Rio Branco - Porto Alegre - RS - Brasil</span>
					</div>
					<div style="margin-top:3px;">
						<span class="text-bold">ZONA HORARIA</span>
					</div>
					<div>
						<span>26/05/2026 21:36:24</span>
					</div>

				</li>
			</ul>
		</div>

	</div> <!-- / #main-menu -->
	<!-- /4. $MAIN_MENU -->		<!-- End Main Menu -->

		<div id="content-wrapper">

			<!-- Open alert redirect new system -->
			
			<!-- End alert redirect new system -->
						
						
		<ul class="breadcrumb">
			<li><a href="home">Inicio</a></li>	
		
		<li> <a href="https://uruguay.tenisintegrado.com/torneio_painel_jogo/index/854">G3 SUB 12 Dur Tenis DURAZNO/Partidos</a></li>		
		</ul>
		
	
			<!-- Open Content here -->
					<div class="panel no-border">

			<!-- Open Tournament Header -->
								<div class="tournament-header">
				<div class="wrap row">
					<div class="col1-3 col-sm-12 col-md-4">
						<div class="tournament-title"><a href="#"></a><a href="https://uruguay.tenisintegrado.com/torneio">G3 SUB 12 Dur Tenis DURAZNO</a></div>
						<div class="tournament-local">Durazno-UY</div>
						<div class="avatar-container">
							<a href="perfil2/index/204647">
								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id204647/fotos/avatar.jpg" alt="" class="avatar">
							</a>
							<span class="avatar-info">
								Creado por <a href="perfil2/index/204647" class="avatar-name">AUT</a>
							</span>
						</div>

													<div class="tournament-share">
								<button type="button" data-toggle="popover" data-placement="bottom" class="btn btn-xs" data-original-title="" title=""><i class="fa fa-share-alt"></i>&nbsp;Compartir la URL de la página</button>
								<div class="popover-header hide">Copie la URL abajo y comparta</div>
								<div class="popover-content hide">
									<input type="text" class="form-control" value="https://uruguay.tenisintegrado.com/torneio_painel_jogo/index/854">
								</div>
							</div>
						
					</div>
					<div class="col2-3 col-sm-12 col-md-4">
						<div class="tournament-period">
							<div class="info-label">Período previsto</div>
							<div class="info">25/04/2026 a 26/04/2026</div>
							<div class="info-label">Cancelaciones hasta</div>
							<div class="info">21/04/2026</div>

							
						</div>
					</div>
					<div class="col3-3 col-sm-12 col-md-4">
						<div class="insc-period">
							<span class="label label-info">Finalizado</span>
							<div class="insc-dates">(20/01/2026 a 21/04/2026)</div>
						</div>
						<div class="tournement-entries pull-right">
							<div class="entries">22</div>
							<div>Inscripciones</div>
							<div>21:36:24</div>
															<div><sup>America/Montevideo</sup></div>
													</div>
					</div>
				</div>
			</div>
					<!-- End Tournament Header -->

			<div class="panel-body">

				<!-- Tournament Mainbanner -->
						
	<div class="row">
		<div class="col-sm-12">
			<div class="well well-sm">
				<a href="http://uruguay.tenisintegrado.com" target="_blank" class="center-block" style="max-width:728px;">
					<img class="img-responsive" src="uploads/id204647/banners/BannerAUT_728x90_v05.gif" alt="" qaaay9usq="">
				</a>
			</div>
		</div>	
	</div>



				<!-- End Tournament Mainbanner -->

				<!-- Open Tournament Folders -->
				<ul class="nav nav-tabs nav-tabs-xs bs-tabdrop"><li class="dropdown pull-right tabdrop hide"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-bars"></i> <b class="caret"></b></a><ul class="dropdown-menu"></ul></li>
	<li>
		<a href="torneio_painel_info">Información</a>
	</li>

			<li>
			<a href="torneio_painel_insc">Inscripciones</a>
		</li>
	
					<li>
				<a href="torneio_painel_prog">Programación</a>
			</li>
					<li>
				<a href="torneio_painel_classif/index">Clasificación</a>
			</li>
					<li class="active">
				<a href="torneio_painel_jogo">Cuadros</a>
			</li>
				<li>
			<a href="torneio_painel_regul">Reglamento</a>
		</li>

			<!-- FIM de edição por parte do perfil do usuário que possui permissão -->

</ul>
				<!-- End Tournament Folders -->

				
					<form action="https://uruguay.tenisintegrado.com/torneio_painel_jogo" method="post" accept-charset="utf-8" name="frm-maintenance" id="frm-maintenance" onsubmit="" enctype="multipart/form-data">

						<div class="panel-group" id="filters-accordion" style="margin-top:20px;">
							<div class="panel">
								<div class="panel-heading">
									<a class="accordion-toggle loader-container collapsed" data-toggle="collapse" data-parent="#filters-accordion" href="#collapseOne">Seleccionar categoría:</a>
								</div> <!-- / .panel-heading -->
								<div id="collapseOne" class="panel-collapse collapse in">
									<div class="panel-body">
										<div class="row filters">
											<div class="col-sm-12">
												<div class="filter-controls">
													<div class="form-group">
														<label class="control-label">Categoría:</label>
														<select id="id_categoria" name="id_categoria" class="form-ajax-select form-control input-sm heading-form-el " data-ajax-call="https://uruguay.tenisintegrado.com/ajax/getGruposJogos" data-ajax-target="id_parametro">
																																<option value="9" selected="selected">Caballeros 12 años Singles</option>
																													</select>
													</div>

													
														<div class="form-group">
															<label class="control-label">Fase/Grupo:</label>
															<select id="id_parametro" name="id_parametro" class="form-control input-sm heading-form-el">

																																	<option value="4188" selected="selected">1º Fase - Grupo 1 - Round-Robin</option>
																																	<option value="4189">1º Fase - Grupo 2 - Round-Robin</option>
																																	<option value="4190">1º Fase - Grupo 3 - Round-Robin</option>
																																	<option value="4191">1º Fase - Grupo 4 - Round-Robin</option>
																																	<option value="4192">1º Fase - Grupo 5 - Round-Robin</option>
																																	<option value="4193">1º Fase - Grupo 6 - Round-Robin</option>
																																	<option value="4194">1º Fase - Grupo 7 - Round-Robin</option>
																																	<option value="4222">#1-Chave principal</option>
																
															</select>
														</div>

													
													
														<div class="form-group">
															<label class="control-label">Período de Partidos:</label>
															<select id="id_periodo" name="id_periodo" class="form-control input-sm heading-form-el">
																																		<option value="862" selected="selected">25/04/2026 - 26/04/2026</option>
																															</select>
														</div>

													
													<div class="form-group no-label">
														<button class="btn btn-submit btn-sm btn-info btn-outline" data-action="https://uruguay.tenisintegrado.com/torneio_painel_jogo" data-form="frm-maintenance"><span class="fa fa-refresh"></span>&nbsp;&nbsp;Actualizar</button>
													</div>
												</div>
											</div>
										</div>
									</div> <!-- / .panel-body -->
								</div> <!-- / .collapse -->
							</div> <!-- / .panel -->
						</div>

						
						<hr>

						<h4>Caballeros 12 años Singles - 1º Fase -  Grupo 1 (Round-Robin)</h4>

						
							<div style="margin-top:20px;">
								<div class="row">
									<div class="col-sm-12">
										<div class="pull-right">

											
											<!--				
										<button class="btn btn-labeled btn-primary btn-submit" type="submit" formtarget="_blank" data-form="frm-maintenance" data-action="torneio_painel_jogo/printerHtml"><span class="btn-label icon fa fa-print"></span>Visualizar Chave</button>
										-->
											<button class="btn btn-labeled btn-primary btn-submit" type="submit" formtarget="_blank" data-form="frm-maintenance" data-action="https://uruguay.tenisintegrado.com/torneio_painel_jogo/printer"><span class="btn-label icon fa fa-print"></span>Imprimir</button>

											
										</div>
									</div>
								</div>
							</div>

						
						<hr class="top-line">

						
							<div class="games">

								
								<div class="row ">
									<div class="col-sm-12">

										
											<div class="game">
												<div class="game-top">
													<span>25/04/2026 10:15&nbsp;</span>
																										
												</div>
												<ul class="list-group">
													<li class="list-group-item">
														<div class="players">

															
																	<div class="avatar-container">
																																					<a href="perfil2/index/723603">
																				<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id723603/fotos/avatar.jpg" alt="" class="avatar">
																			</a>
																			<span class="avatar-info">
																				<a href="perfil2/index/723603">
																					Salvador Mangarelli 																				</a>
																				<sup>  (Llamador)</sup>
																																							</span>
																																			</div>

																														</div>

														<div class="score pull-right">

															
																		<div class="set" style="font-size: 10pt;">

																			
																				0
																			
																		</div>

																	
														</div>
													</li>

													<li class="list-group-item">
														<div class="players">

																																	<div class="avatar-container">
																			<a href="perfil2/index/520381">
																				<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id520381/fotos/avatar.jpg" alt="" class="avatar">
																			</a>
																			<span class="avatar-info">
																				<a href="perfil2/index/520381">
																					Bastian Munch 																				</a>
																				<sup> </sup>
																				<img src="https://uruguay.tenisintegrado.com//images/logo_wtn_min.png" style="width:15px;" title="World Tennis Number ITF actualizado el 15/04/2026"><span class="text-bold text-danger" style="font-size:11px;" title="World Tennis Number ITF actualizado el 15/04/2026">38,06</span>																			</span>
																		</div>

																	
														</div>

														<div class="score pull-right">

															
																		<div class="set" style="font-size: 10pt;">

																			
																				9
																			
																		</div>

																	
														</div>

													</li>
												</ul>
												<div class="game-bottom">VENCEDOR: Bastian Munch - 1 X 0</div>
											</div>

										
											<div class="game">
												<div class="game-top">
													<span>25/04/2026 13:30&nbsp;</span>
																										
												</div>
												<ul class="list-group">
													<li class="list-group-item">
														<div class="players">

															
																	<div class="avatar-container">
																																					<a href="perfil2/index/499538">
																				<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id499538/fotos/avatar.jpg" alt="" class="avatar">
																			</a>
																			<span class="avatar-info">
																				<a href="perfil2/index/499538">
																					Joaquin Lorenzo 																				</a>
																				<sup>10º  (Llamador)</sup>
																				<img src="https://uruguay.tenisintegrado.com//images/logo_wtn_min.png" style="width:15px;" title="World Tennis Number ITF actualizado el 15/04/2026"><span class="text-bold text-danger" style="font-size:11px;" title="World Tennis Number ITF actualizado el 15/04/2026">37,43</span>																			</span>
																																			</div>

																														</div>

														<div class="score pull-right">

															
																		<div class="set" style="font-size: 10pt;">

																			
																				9
																			
																		</div>

																	
														</div>
													</li>

													<li class="list-group-item">
														<div class="players">

																																	<div class="avatar-container">
																			<a href="perfil2/index/723603">
																				<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id723603/fotos/avatar.jpg" alt="" class="avatar">
																			</a>
																			<span class="avatar-info">
																				<a href="perfil2/index/723603">
																					Salvador Mangarelli 																				</a>
																				<sup> </sup>
																																							</span>
																		</div>

																	
														</div>

														<div class="score pull-right">

															
																		<div class="set" style="font-size: 10pt;">

																			
																				0
																			
																		</div>

																	
														</div>

													</li>
												</ul>
												<div class="game-bottom">VENCEDOR: Joaquin Lorenzo - 1 X 0</div>
											</div>

										
											<div class="game">
												<div class="game-top">
													<span>25/04/2026 18:30&nbsp;</span>
																										
												</div>
												<ul class="list-group">
													<li class="list-group-item">
														<div class="players">

															
																	<div class="avatar-container">
																																					<a href="perfil2/index/520381">
																				<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id520381/fotos/avatar.jpg" alt="" class="avatar">
																			</a>
																			<span class="avatar-info">
																				<a href="perfil2/index/520381">
																					Bastian Munch 																				</a>
																				<sup>  (Llamador)</sup>
																				<img src="https://uruguay.tenisintegrado.com//images/logo_wtn_min.png" style="width:15px;" title="World Tennis Number ITF actualizado el 15/04/2026"><span class="text-bold text-danger" style="font-size:11px;" title="World Tennis Number ITF actualizado el 15/04/2026">38,06</span>																			</span>
																																			</div>

																														</div>

														<div class="score pull-right">

															
																		<div class="set" style="font-size: 10pt;">

																			
																				5
																			
																		</div>

																	
														</div>
													</li>

													<li class="list-group-item">
														<div class="players">

																																	<div class="avatar-container">
																			<a href="perfil2/index/499538">
																				<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id499538/fotos/avatar.jpg" alt="" class="avatar">
																			</a>
																			<span class="avatar-info">
																				<a href="perfil2/index/499538">
																					Joaquin Lorenzo 																				</a>
																				<sup>10º </sup>
																				<img src="https://uruguay.tenisintegrado.com//images/logo_wtn_min.png" style="width:15px;" title="World Tennis Number ITF actualizado el 15/04/2026"><span class="text-bold text-danger" style="font-size:11px;" title="World Tennis Number ITF actualizado el 15/04/2026">37,43</span>																			</span>
																		</div>

																	
														</div>

														<div class="score pull-right">

															
																		<div class="set" style="font-size: 10pt;">

																			
																				9
																			
																		</div>

																	
														</div>

													</li>
												</ul>
												<div class="game-bottom">VENCEDOR: Joaquin Lorenzo - 1 X 0</div>
											</div>

										
									</div>
								</div>
							</div>

						
						<input name="id_torneio" type="hidden" value="854">
					</form>

				
				<!-- Tournament Mainbanner -->
								<!-- End Tournament Mainbanner -->

			</div>

		</div>			<!-- End Content -->

		</div> <!-- / #content-wrapper -->

		<div id="main-menu-bg"></div>
	</div> <!-- / #main-wrapper -->

	<script src="./bower_components/jquery/jquery.min.js"></script>
	<script src="./bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
	<script src="./scripts/main.min.js"></script>

	
	<script type="text/javascript">
		window.PixelAdmin.start(init);
	</script>

	<!-- INICIO SUPORTE CHAT ON LINE -->
	<!-- FINAL SUPORTE CHAT ON LINE -->




<div id="automa-palette"><template shadowrootmode="open"><style>.tippy-box[data-animation=shift-toward-subtle][data-state=hidden]{opacity:0}.tippy-box[data-animation=shift-toward-subtle][data-state=hidden][data-placement^=top][data-state=hidden]{transform:translateY(-5px)}.tippy-box[data-animation=shift-toward-subtle][data-state=hidden][data-placement^=bottom][data-state=hidden]{transform:translateY(5px)}.tippy-box[data-animation=shift-toward-subtle][data-state=hidden][data-placement^=left][data-state=hidden]{transform:translateX(-5px)}.tippy-box[data-animation=shift-toward-subtle][data-state=hidden][data-placement^=right][data-state=hidden]{transform:translateX(5px)}

.input-ui input[type='color'] {
  padding-top: 0 !important;
  padding-bottom: 0 !important;
}


.root {
  font-size: 16px;
  z-index: 99999;
  line-height: 1.5 !important;
  font-family: 'Inter var', sans-serif;
  font-feature-settings: 'cv02', 'cv03', 'cv04', 'cv11';
}
.root-card:hover .drag-button {
  transform: scale(1);
}
.drag-button {
  transform: scale(0);
  transition: transform 200ms ease-in-out;
}
.main-tab {
  background-color: transparent !important;
  padding: 0 !important;
}
.main-tab .ui-tab.is-active.fill {
  --tw-bg-opacity: 1 !important;
  background-color: rgb(var(--color-accent) / var(--tw-bg-opacity, 1)) !important;
  --tw-text-opacity: 1 !important;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1)) !important;
}


.ui-tab[data-v-681b5d14] {
  z-index: 1;
  border-bottom-width: 2px;
  border-color: transparent;
  padding-top: 12px;
  padding-bottom: 12px;
  padding-left: 8px;
  padding-right: 8px;
}
.ui-tab.small[data-v-681b5d14] {
  padding: 8px;
}
.ui-tab.fill[data-v-681b5d14] {
  border-radius: 8px;
  border-bottom-width: 0px;
  padding-left: 16px;
  padding-right: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
}
.ui-tab.fill.small[data-v-681b5d14] {
  padding: 8px;
}
.ui-tab.is-active[data-v-681b5d14] {
  --tw-border-opacity: 1;
  border-color: rgb(var(--color-accent) / var(--tw-border-opacity, 1));
  --tw-text-opacity: 1;
  color: rgb(39 39 42 / var(--tw-text-opacity, 1));
}
.ui-tab.is-active[data-v-681b5d14]:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(244 244 245 / var(--tw-border-opacity, 1));
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}
.ui-tab.is-active.fill[data-v-681b5d14] {
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.ui-tab.is-active.fill[data-v-681b5d14]:is(.dark *) {
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.ui-tab.is-active[data-v-681b5d14] {
  --tw-border-opacity: 1;
  border-color: rgb(var(--color-accent) / var(--tw-border-opacity, 1));
  --tw-text-opacity: 1;
  color: rgb(39 39 42 / var(--tw-text-opacity, 1));
}
.ui-tab.is-active[data-v-681b5d14]:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(244 244 245 / var(--tw-border-opacity, 1));
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}


.ui-tabs__indicator {
  min-height: 24px;
  min-width: 50px;
  transition-duration: 200ms;
  transition-property: transform, width;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}


.button-loading {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}


.ui-select__arrow {
  top: 50%;
  transform: translateY(-50%) rotate(90deg);
}
.ui-select option,
.ui-select optgroup {
  --tw-bg-opacity: 1;
  background-color: rgb(244 244 245 / var(--tw-bg-opacity, 1));
}
.ui-select option:is(.dark *),
.ui-select optgroup:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(63 63 70 / var(--tw-bg-opacity, 1));
}


.ui-switch[data-v-cc5de7b2] {
  overflow: hidden;
  transition: all 250ms ease;
}
.ui-switch[data-v-cc5de7b2]:active {
  transform: scale(0.93);
}
.ui-switch__ball[data-v-cc5de7b2] {
  transition: all 250ms ease;
  left: 6px;
}
.ui-switch__background[data-v-cc5de7b2] {
  transition: all 250ms ease;
  margin-left: -100%;
}
.ui-switch:hover .ui-switch__ball[data-v-cc5de7b2] {
  transform: scale(1.1);
}
.ui-switch input:focus ~ .ui-switch__ball[data-v-cc5de7b2] {
  transform: scale(1.1);
}
.ui-switch input:checked ~ .ui-switch__ball[data-v-cc5de7b2]:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(24 24 27 / var(--tw-bg-opacity, 1));
}
.ui-switch input:checked ~ .ui-switch__ball[data-v-cc5de7b2] {
  background-color: white;
  left: calc(100% - 21px);
}
.ui-switch input:checked ~ .ui-switch__background[data-v-cc5de7b2] {
  margin-left: 0;
}


.checkbox-ui__input:checked ~ .checkbox-ui__mark .v-remixicon[data-v-32d46196],
.checkbox-ui__input.indeterminate ~ .checkbox-ui__mark .v-remixicon[data-v-32d46196] {
  transform: scale(1) !important;
}
.checkbox-ui .v-remixicon[data-v-32d46196] {
  transform: scale(0);
}
.checkbox-ui__input:checked ~ .checkbox-ui__mark[data-v-32d46196],
.checkbox-ui__input.indeterminate ~ .checkbox-ui__mark[data-v-32d46196] {
  --tw-border-opacity: 1;
  border-color: rgb(var(--color-accent) / var(--tw-border-opacity, 1));
  background-color: rgb(var(--color-accent) / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 1;
}
.checkbox-ui__mark[data-v-32d46196] {
  width: 100%;
  height: 100%;
  transition-property: background-color, border-color;
  transition-timing-function: ease;
  transition-duration: 200ms;
  display: flex;
  align-items: center;
  justify-content: center;
}
.checkbox-ui__mark .v-remixicon[data-v-32d46196] {
  transform: scale(0) !important;
  transition: transform 200ms ease;
}


.expand-enter-active,
.expand-leave-active {
  transition: height 0.2s ease-in-out;
  overflow: hidden;
}
.expand-enter,
.expand-leave-to {
  height: 0;
}

*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}

::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}/*
! tailwindcss v3.4.17 | MIT License | https://tailwindcss.com
*//*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: #e4e4e7; /* 2 */
}

::before,
::after {
  --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured `sans` font-family by default.
5. Use the user's configured `sans` font-feature-settings by default.
6. Use the user's configured `sans` font-variation-settings by default.
7. Disable tap highlights on iOS
*/

html,
:host {
  line-height: 1.5; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
  -moz-tab-size: 4; /* 3 */
  -o-tab-size: 4;
     tab-size: 4; /* 3 */
  font-family: Poppins, sans-serif; /* 4 */
  font-feature-settings: normal; /* 5 */
  font-variation-settings: normal; /* 6 */
  -webkit-tap-highlight-color: transparent; /* 7 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from `html` so users can set them as a class directly on the `html` element.
*/

body {
  margin: 0; /* 1 */
  line-height: inherit; /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
  border-top-width: 1px; /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  -webkit-text-decoration: underline dotted;
          text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
1. Use the user's configured `mono` font-family by default.
2. Use the user's configured `mono` font-feature-settings by default.
3. Use the user's configured `mono` font-variation-settings by default.
4. Correct the odd `em` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: Source Code Pro, monospace; /* 1 */
  font-feature-settings: normal; /* 2 */
  font-variation-settings: normal; /* 3 */
  font-size: 1em; /* 4 */
}

/*
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
Prevent `sub` and `sup` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
  border-collapse: collapse; /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-feature-settings: inherit; /* 1 */
  font-variation-settings: inherit; /* 1 */
  font-size: 100%; /* 1 */
  font-weight: inherit; /* 1 */
  line-height: inherit; /* 1 */
  letter-spacing: inherit; /* 1 */
  color: inherit; /* 1 */
  margin: 0; /* 2 */
  padding: 0; /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/

button,
select {
  text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/

button,
input:where([type='button']),
input:where([type='reset']),
input:where([type='submit']) {
  -webkit-appearance: button; /* 1 */
  background-color: transparent; /* 2 */
  background-image: none; /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
Remove the additional `:invalid` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield; /* 1 */
  outline-offset: -2px; /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to `inherit` in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

fieldset {
  margin: 0;
  padding: 0;
}

legend {
  padding: 0;
}

ol,
ul,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/*
Reset default styling for dialogs.
*/
dialog {
  padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/

input::-moz-placeholder, textarea::-moz-placeholder {
  opacity: 1; /* 1 */
  color: #a1a1aa; /* 2 */
}

input::placeholder,
textarea::placeholder {
  opacity: 1; /* 1 */
  color: #a1a1aa; /* 2 */
}

/*
Set the default cursor for buttons.
*/

button,
[role="button"] {
  cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/
:disabled {
  cursor: default;
}

/*
1. Make replaced elements `display: block` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add `vertical-align: middle` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */
[hidden]:where(:not([hidden="until-found"])) {
  display: none;
}
.\!container {
  width: 100% !important;
  margin-right: auto !important;
  margin-left: auto !important;
  padding-right: 1rem !important;
  padding-left: 1rem !important;
}
.container {
  width: 100%;
  margin-right: auto;
  margin-left: auto;
  padding-right: 1rem;
  padding-left: 1rem;
}
@media (min-width: 640px) {

  .\!container {
    max-width: 640px !important;
    padding-right: 2rem !important;
    padding-left: 2rem !important;
  }

  .container {
    max-width: 640px;
    padding-right: 2rem;
    padding-left: 2rem;
  }
}
@media (min-width: 768px) {

  .\!container {
    max-width: 768px !important;
  }

  .container {
    max-width: 768px;
  }
}
@media (min-width: 1024px) {

  .\!container {
    max-width: 1024px !important;
  }

  .container {
    max-width: 1024px;
  }
}
@media (min-width: 1280px) {

  .\!container {
    max-width: 1280px !important;
  }

  .container {
    max-width: 1280px;
  }
}
@media (min-width: 1536px) {

  .\!container {
    max-width: 1536px !important;
  }

  .container {
    max-width: 1536px;
  }
}
.prose {
  color: var(--tw-prose-body);
  max-width: 65ch;
}
.prose :where(p):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.25em;
  margin-bottom: 1.25em;
}
.prose :where([class~="lead"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-lead);
  font-size: 1.25em;
  line-height: 1.6;
  margin-top: 1.2em;
  margin-bottom: 1.2em;
}
.prose :where(a):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-links);
  text-decoration: underline;
  font-weight: 500;
}
.prose :where(strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-bold);
  font-weight: 600;
}
.prose :where(a strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(blockquote strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(thead th strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(ol):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: decimal;
  margin-top: 1.25em;
  margin-bottom: 1.25em;
  padding-inline-start: 1.625em;
}
.prose :where(ol[type="A"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: upper-alpha;
}
.prose :where(ol[type="a"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: lower-alpha;
}
.prose :where(ol[type="A" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: upper-alpha;
}
.prose :where(ol[type="a" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: lower-alpha;
}
.prose :where(ol[type="I"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: upper-roman;
}
.prose :where(ol[type="i"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: lower-roman;
}
.prose :where(ol[type="I" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: upper-roman;
}
.prose :where(ol[type="i" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: lower-roman;
}
.prose :where(ol[type="1"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: decimal;
}
.prose :where(ul):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: disc;
  margin-top: 1.25em;
  margin-bottom: 1.25em;
  padding-inline-start: 1.625em;
}
.prose :where(ol > li):not(:where([class~="not-prose"],[class~="not-prose"] *))::marker {
  font-weight: 400;
  color: var(--tw-prose-counters);
}
.prose :where(ul > li):not(:where([class~="not-prose"],[class~="not-prose"] *))::marker {
  color: var(--tw-prose-bullets);
}
.prose :where(dt):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  margin-top: 1.25em;
}
.prose :where(hr):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-color: var(--tw-prose-hr);
  border-top-width: 1px;
  margin-top: 3em;
  margin-bottom: 3em;
}
.prose :where(blockquote):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 500;
  font-style: italic;
  color: var(--tw-prose-quotes);
  border-inline-start-width: 0.25rem;
  border-inline-start-color: var(--tw-prose-quote-borders);
  quotes: "\201C""\201D""\2018""\2019";
  margin-top: 1.6em;
  margin-bottom: 1.6em;
  padding-inline-start: 1em;
}
.prose :where(blockquote p:first-of-type):not(:where([class~="not-prose"],[class~="not-prose"] *))::before {
  content: open-quote;
}
.prose :where(blockquote p:last-of-type):not(:where([class~="not-prose"],[class~="not-prose"] *))::after {
  content: close-quote;
}
.prose :where(h1):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 800;
  font-size: 2.25em;
  margin-top: 0;
  margin-bottom: 0.8888889em;
  line-height: 1.1111111;
}
.prose :where(h1 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 900;
  color: inherit;
}
.prose :where(h2):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 700;
  font-size: 1.5em;
  margin-top: 2em;
  margin-bottom: 1em;
  line-height: 1.3333333;
}
.prose :where(h2 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 800;
  color: inherit;
}
.prose :where(h3):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  font-size: 1.25em;
  margin-top: 1.6em;
  margin-bottom: 0.6em;
  line-height: 1.6;
}
.prose :where(h3 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 700;
  color: inherit;
}
.prose :where(h4):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  margin-top: 1.5em;
  margin-bottom: 0.5em;
  line-height: 1.5;
}
.prose :where(h4 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 700;
  color: inherit;
}
.prose :where(img):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 2em;
  margin-bottom: 2em;
}
.prose :where(picture):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  display: block;
  margin-top: 2em;
  margin-bottom: 2em;
}
.prose :where(video):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 2em;
  margin-bottom: 2em;
}
.prose :where(kbd):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 500;
  font-family: inherit;
  color: var(--tw-prose-kbd);
  box-shadow: 0 0 0 1px rgb(var(--tw-prose-kbd-shadows) / 10%), 0 3px 0 rgb(var(--tw-prose-kbd-shadows) / 10%);
  font-size: 0.875em;
  border-radius: 0.3125rem;
  padding-top: 0.1875em;
  padding-inline-end: 0.375em;
  padding-bottom: 0.1875em;
  padding-inline-start: 0.375em;
}
.prose :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-code);
  font-weight: 600;
  font-size: 0.875em;
}
.prose :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *))::before {
  content: "`";
}
.prose :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *))::after {
  content: "`";
}
.prose :where(a code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(h1 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(h2 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
  font-size: 0.875em;
}
.prose :where(h3 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
  font-size: 0.9em;
}
.prose :where(h4 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(blockquote code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(thead th code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(pre):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-pre-code);
  background-color: var(--tw-prose-pre-bg);
  overflow-x: auto;
  font-weight: 400;
  font-size: 0.875em;
  line-height: 1.7142857;
  margin-top: 1.7142857em;
  margin-bottom: 1.7142857em;
  border-radius: 0.375rem;
  padding-top: 0.8571429em;
  padding-inline-end: 1.1428571em;
  padding-bottom: 0.8571429em;
  padding-inline-start: 1.1428571em;
}
.prose :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  background-color: transparent;
  border-width: 0;
  border-radius: 0;
  padding: 0;
  font-weight: inherit;
  color: inherit;
  font-size: inherit;
  font-family: inherit;
  line-height: inherit;
}
.prose :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *))::before {
  content: none;
}
.prose :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *))::after {
  content: none;
}
.prose :where(table):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  width: 100%;
  table-layout: auto;
  margin-top: 2em;
  margin-bottom: 2em;
  font-size: 0.875em;
  line-height: 1.7142857;
}
.prose :where(thead):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-bottom-width: 1px;
  border-bottom-color: var(--tw-prose-th-borders);
}
.prose :where(thead th):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  vertical-align: bottom;
  padding-inline-end: 0.5714286em;
  padding-bottom: 0.5714286em;
  padding-inline-start: 0.5714286em;
}
.prose :where(tbody tr):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-bottom-width: 1px;
  border-bottom-color: var(--tw-prose-td-borders);
}
.prose :where(tbody tr:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-bottom-width: 0;
}
.prose :where(tbody td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  vertical-align: baseline;
}
.prose :where(tfoot):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-top-width: 1px;
  border-top-color: var(--tw-prose-th-borders);
}
.prose :where(tfoot td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  vertical-align: top;
}
.prose :where(th, td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  text-align: start;
}
.prose :where(figure > *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
  margin-bottom: 0;
}
.prose :where(figcaption):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-captions);
  font-size: 0.875em;
  line-height: 1.4285714;
  margin-top: 0.8571429em;
}
.prose {
  --tw-prose-body: #374151;
  --tw-prose-headings: #111827;
  --tw-prose-lead: #4b5563;
  --tw-prose-links: #111827;
  --tw-prose-bold: #111827;
  --tw-prose-counters: #6b7280;
  --tw-prose-bullets: #d1d5db;
  --tw-prose-hr: #e5e7eb;
  --tw-prose-quotes: #111827;
  --tw-prose-quote-borders: #e5e7eb;
  --tw-prose-captions: #6b7280;
  --tw-prose-kbd: #111827;
  --tw-prose-kbd-shadows: 17 24 39;
  --tw-prose-code: #111827;
  --tw-prose-pre-code: #e5e7eb;
  --tw-prose-pre-bg: #1f2937;
  --tw-prose-th-borders: #d1d5db;
  --tw-prose-td-borders: #e5e7eb;
  --tw-prose-invert-body: #d1d5db;
  --tw-prose-invert-headings: #fff;
  --tw-prose-invert-lead: #9ca3af;
  --tw-prose-invert-links: #fff;
  --tw-prose-invert-bold: #fff;
  --tw-prose-invert-counters: #9ca3af;
  --tw-prose-invert-bullets: #4b5563;
  --tw-prose-invert-hr: #374151;
  --tw-prose-invert-quotes: #f3f4f6;
  --tw-prose-invert-quote-borders: #374151;
  --tw-prose-invert-captions: #9ca3af;
  --tw-prose-invert-kbd: #fff;
  --tw-prose-invert-kbd-shadows: 255 255 255;
  --tw-prose-invert-code: #fff;
  --tw-prose-invert-pre-code: #d1d5db;
  --tw-prose-invert-pre-bg: rgb(0 0 0 / 50%);
  --tw-prose-invert-th-borders: #4b5563;
  --tw-prose-invert-td-borders: #374151;
  font-size: 1rem;
  line-height: 1.75;
}
.prose :where(picture > img):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
  margin-bottom: 0;
}
.prose :where(li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.5em;
  margin-bottom: 0.5em;
}
.prose :where(ol > li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0.375em;
}
.prose :where(ul > li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0.375em;
}
.prose :where(.prose > ul > li p):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.75em;
  margin-bottom: 0.75em;
}
.prose :where(.prose > ul > li > p:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.25em;
}
.prose :where(.prose > ul > li > p:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-bottom: 1.25em;
}
.prose :where(.prose > ol > li > p:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.25em;
}
.prose :where(.prose > ol > li > p:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-bottom: 1.25em;
}
.prose :where(ul ul, ul ol, ol ul, ol ol):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.75em;
  margin-bottom: 0.75em;
}
.prose :where(dl):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.25em;
  margin-bottom: 1.25em;
}
.prose :where(dd):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.5em;
  padding-inline-start: 1.625em;
}
.prose :where(hr + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}
.prose :where(h2 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}
.prose :where(h3 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}
.prose :where(h4 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}
.prose :where(thead th:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0;
}
.prose :where(thead th:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-end: 0;
}
.prose :where(tbody td, tfoot td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-top: 0.5714286em;
  padding-inline-end: 0.5714286em;
  padding-bottom: 0.5714286em;
  padding-inline-start: 0.5714286em;
}
.prose :where(tbody td:first-child, tfoot td:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0;
}
.prose :where(tbody td:last-child, tfoot td:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-end: 0;
}
.prose :where(figure):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 2em;
  margin-bottom: 2em;
}
.prose :where(.prose > :first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}
.prose :where(.prose > :last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-bottom: 0;
}
.prose-zinc {
  --tw-prose-body: #3f3f46;
  --tw-prose-headings: #18181b;
  --tw-prose-lead: #52525b;
  --tw-prose-links: #18181b;
  --tw-prose-bold: #18181b;
  --tw-prose-counters: #71717a;
  --tw-prose-bullets: #d4d4d8;
  --tw-prose-hr: #e4e4e7;
  --tw-prose-quotes: #18181b;
  --tw-prose-quote-borders: #e4e4e7;
  --tw-prose-captions: #71717a;
  --tw-prose-kbd: #18181b;
  --tw-prose-kbd-shadows: 24 24 27;
  --tw-prose-code: #18181b;
  --tw-prose-pre-code: #e4e4e7;
  --tw-prose-pre-bg: #27272a;
  --tw-prose-th-borders: #d4d4d8;
  --tw-prose-td-borders: #e4e4e7;
  --tw-prose-invert-body: #d4d4d8;
  --tw-prose-invert-headings: #fff;
  --tw-prose-invert-lead: #a1a1aa;
  --tw-prose-invert-links: #fff;
  --tw-prose-invert-bold: #fff;
  --tw-prose-invert-counters: #a1a1aa;
  --tw-prose-invert-bullets: #52525b;
  --tw-prose-invert-hr: #3f3f46;
  --tw-prose-invert-quotes: #f4f4f5;
  --tw-prose-invert-quote-borders: #3f3f46;
  --tw-prose-invert-captions: #a1a1aa;
  --tw-prose-invert-kbd: #fff;
  --tw-prose-invert-kbd-shadows: 255 255 255;
  --tw-prose-invert-code: #fff;
  --tw-prose-invert-pre-code: #d4d4d8;
  --tw-prose-invert-pre-bg: rgb(0 0 0 / 50%);
  --tw-prose-invert-th-borders: #52525b;
  --tw-prose-invert-td-borders: #3f3f46;
}
.pointer-events-none {
  pointer-events: none;
}
.pointer-events-auto {
  pointer-events: auto;
}
.visible {
  visibility: visible;
}
.invisible {
  visibility: hidden;
}
.static {
  position: static;
}
.fixed {
  position: fixed;
}
.absolute {
  position: absolute;
}
.relative {
  position: relative;
}
.sticky {
  position: sticky;
}
.-right-2 {
  right: -8px;
}
.-top-1 {
  top: -4px;
}
.-top-2 {
  top: -8px;
}
.bottom-0 {
  bottom: 0px;
}
.bottom-2 {
  bottom: 8px;
}
.bottom-5 {
  bottom: 20px;
}
.bottom-8 {
  bottom: 32px;
}
.left-0 {
  left: 0px;
}
.left-1\/2 {
  left: 50%;
}
.left-2 {
  left: 8px;
}
.right-0 {
  right: 0px;
}
.right-2 {
  right: 8px;
}
.right-4 {
  right: 16px;
}
.right-8 {
  right: 32px;
}
.top-0 {
  top: 0px;
}
.top-1\/2 {
  top: 50%;
}
.top-2 {
  top: 8px;
}
.top-4 {
  top: 16px;
}
.top-8 {
  top: 32px;
}
.top-full {
  top: 100%;
}
.z-0 {
  z-index: 0;
}
.z-10 {
  z-index: 10;
}
.z-20 {
  z-index: 20;
}
.z-40 {
  z-index: 40;
}
.z-50 {
  z-index: 50;
}
.z-\[1\] {
  z-index: 1;
}
.col-span-1 {
  grid-column: span 1 / span 1;
}
.col-span-2 {
  grid-column: span 2 / span 2;
}
.col-span-3 {
  grid-column: span 3 / span 3;
}
.col-span-4 {
  grid-column: span 4 / span 4;
}
.col-span-5 {
  grid-column: span 5 / span 5;
}
.col-span-6 {
  grid-column: span 6 / span 6;
}
.m-4 {
  margin: 16px;
}
.m-5 {
  margin: 20px;
}
.mx-1 {
  margin-left: 4px;
  margin-right: 4px;
}
.mx-2 {
  margin-left: 8px;
  margin-right: 8px;
}
.mx-4 {
  margin-left: 16px;
  margin-right: 16px;
}
.mx-auto {
  margin-left: auto;
  margin-right: auto;
}
.my-1 {
  margin-top: 4px;
  margin-bottom: 4px;
}
.my-2 {
  margin-top: 8px;
  margin-bottom: 8px;
}
.my-4 {
  margin-top: 16px;
  margin-bottom: 16px;
}
.my-6 {
  margin-top: 24px;
  margin-bottom: 24px;
}
.my-8 {
  margin-top: 32px;
  margin-bottom: 32px;
}
.-ml-1 {
  margin-left: -4px;
}
.-ml-2 {
  margin-left: -8px;
}
.-ml-6 {
  margin-left: -24px;
}
.-mr-1 {
  margin-right: -4px;
}
.-mr-2 {
  margin-right: -8px;
}
.-mt-1 {
  margin-top: -4px;
}
.-mt-2 {
  margin-top: -8px;
}
.mb-1 {
  margin-bottom: 4px;
}
.mb-10 {
  margin-bottom: 40px;
}
.mb-12 {
  margin-bottom: 48px;
}
.mb-2 {
  margin-bottom: 8px;
}
.mb-4 {
  margin-bottom: 16px;
}
.mb-6 {
  margin-bottom: 24px;
}
.mb-8 {
  margin-bottom: 32px;
}
.ml-1 {
  margin-left: 4px;
}
.ml-12 {
  margin-left: 48px;
}
.ml-2 {
  margin-left: 8px;
}
.ml-3 {
  margin-left: 12px;
}
.ml-4 {
  margin-left: 16px;
}
.ml-6 {
  margin-left: 24px;
}
.mr-0\.5 {
  margin-right: 2px;
}
.mr-1 {
  margin-right: 4px;
}
.mr-12 {
  margin-right: 48px;
}
.mr-2 {
  margin-right: 8px;
}
.mr-3 {
  margin-right: 12px;
}
.mr-4 {
  margin-right: 16px;
}
.mr-6 {
  margin-right: 24px;
}
.mr-8 {
  margin-right: 32px;
}
.mt-1 {
  margin-top: 4px;
}
.mt-10 {
  margin-top: 40px;
}
.mt-12 {
  margin-top: 48px;
}
.mt-2 {
  margin-top: 8px;
}
.mt-3 {
  margin-top: 12px;
}
.mt-4 {
  margin-top: 16px;
}
.mt-5 {
  margin-top: 20px;
}
.mt-6 {
  margin-top: 24px;
}
.mt-8 {
  margin-top: 32px;
}
.\!block {
  display: block !important;
}
.block {
  display: block;
}
.inline-block {
  display: inline-block;
}
.inline {
  display: inline;
}
.\!flex {
  display: flex !important;
}
.flex {
  display: flex;
}
.inline-flex {
  display: inline-flex;
}
.\!table {
  display: table !important;
}
.table {
  display: table;
}
.grid {
  display: grid;
}
.hidden {
  display: none;
}
.\!h-8 {
  height: 32px !important;
}
.h-10 {
  height: 40px;
}
.h-12 {
  height: 48px;
}
.h-28 {
  height: 112px;
}
.h-3 {
  height: 12px;
}
.h-32 {
  height: 128px;
}
.h-4 {
  height: 16px;
}
.h-40 {
  height: 160px;
}
.h-48 {
  height: 192px;
}
.h-5 {
  height: 20px;
}
.h-56 {
  height: 224px;
}
.h-6 {
  height: 24px;
}
.h-7 {
  height: 28px;
}
.h-72 {
  height: 288px;
}
.h-8 {
  height: 32px;
}
.h-\[105px\] {
  height: 105px;
}
.h-\[1px\] {
  height: 1px;
}
.h-\[22px\] {
  height: 22px;
}
.h-full {
  height: 100%;
}
.h-screen {
  height: 100vh;
}
.max-h-56 {
  max-height: 224px;
}
.max-h-60 {
  max-height: 240px;
}
.max-h-80 {
  max-height: 320px;
}
.max-h-96 {
  max-height: 384px;
}
.w-10 {
  width: 40px;
}
.w-11\/12 {
  width: 91.666667%;
}
.w-12 {
  width: 48px;
}
.w-14 {
  width: 56px;
}
.w-16 {
  width: 64px;
}
.w-2 {
  width: 8px;
}
.w-2\/12 {
  width: 16.666667%;
}
.w-20 {
  width: 80px;
}
.w-24 {
  width: 96px;
}
.w-28 {
  width: 112px;
}
.w-3 {
  width: 12px;
}
.w-3\/12 {
  width: 25%;
}
.w-32 {
  width: 128px;
}
.w-36 {
  width: 144px;
}
.w-4 {
  width: 16px;
}
.w-4\/12 {
  width: 33.333333%;
}
.w-40 {
  width: 160px;
}
.w-44 {
  width: 176px;
}
.w-48 {
  width: 192px;
}
.w-5 {
  width: 20px;
}
.w-5\/12 {
  width: 41.666667%;
}
.w-52 {
  width: 208px;
}
.w-56 {
  width: 224px;
}
.w-6\/12 {
  width: 50%;
}
.w-60 {
  width: 240px;
}
.w-64 {
  width: 256px;
}
.w-72 {
  width: 288px;
}
.w-8 {
  width: 32px;
}
.w-8\/12 {
  width: 66.666667%;
}
.w-80 {
  width: 320px;
}
.w-96 {
  width: 384px;
}
.w-full {
  width: 100%;
}
.w-px {
  width: 1px;
}
.min-w-\[52px\] {
  min-width: 52px;
}
.min-w-\[90px\] {
  min-width: 90px;
}
.max-w-2xl {
  max-width: 672px;
}
.max-w-3xl {
  max-width: 768px;
}
.max-w-4xl {
  max-width: 896px;
}
.max-w-5xl {
  max-width: 1024px;
}
.max-w-\[170px\] {
  max-width: 170px;
}
.max-w-lg {
  max-width: 512px;
}
.max-w-md {
  max-width: 448px;
}
.max-w-none {
  max-width: none;
}
.max-w-sm {
  max-width: 384px;
}
.max-w-xl {
  max-width: 576px;
}
.flex-1 {
  flex: 1 1 0%;
}
.flex-shrink {
  flex-shrink: 1;
}
.flex-shrink-0 {
  flex-shrink: 0;
}
.shrink-0 {
  flex-shrink: 0;
}
.grow {
  flex-grow: 1;
}
.-translate-x-1\/2 {
  --tw-translate-x: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.-translate-y-1 {
  --tw-translate-y: -4px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.-translate-y-1\/2 {
  --tw-translate-y: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.rotate-180 {
  --tw-rotate: 180deg;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.scale-0 {
  --tw-scale-x: 0;
  --tw-scale-y: 0;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
@keyframes ping {

  75%, 100% {
    transform: scale(2);
    opacity: 0;
  }
}
.animate-ping {
  animation: ping 1s cubic-bezier(0, 0, 0.2, 1) infinite;
}
@keyframes pulse {

  50% {
    opacity: .5;
  }
}
.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
@keyframes spin {

  to {
    transform: rotate(360deg);
  }
}
.animate-spin {
  animation: spin 1s linear infinite;
}
.cursor-default {
  cursor: default;
}
.cursor-grab {
  cursor: grab;
}
.cursor-grabbing {
  cursor: grabbing;
}
.cursor-move {
  cursor: move;
}
.cursor-not-allowed {
  cursor: not-allowed;
}
.cursor-pointer {
  cursor: pointer;
}
.select-none {
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
}
.resize-none {
  resize: none;
}
.resize {
  resize: both;
}
.list-inside {
  list-style-position: inside;
}
.list-decimal {
  list-style-type: decimal;
}
.list-disc {
  list-style-type: disc;
}
.appearance-none {
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none;
}
.grid-cols-1 {
  grid-template-columns: repeat(1, minmax(0, 1fr));
}
.grid-cols-12 {
  grid-template-columns: repeat(12, minmax(0, 1fr));
}
.grid-cols-2 {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
.grid-cols-5 {
  grid-template-columns: repeat(5, minmax(0, 1fr));
}
.grid-cols-6 {
  grid-template-columns: repeat(6, minmax(0, 1fr));
}
.grid-cols-7 {
  grid-template-columns: repeat(7, minmax(0, 1fr));
}
.flex-col {
  flex-direction: column;
}
.flex-col-reverse {
  flex-direction: column-reverse;
}
.flex-wrap {
  flex-wrap: wrap;
}
.items-start {
  align-items: flex-start;
}
.items-end {
  align-items: flex-end;
}
.items-center {
  align-items: center;
}
.\!items-stretch {
  align-items: stretch !important;
}
.justify-end {
  justify-content: flex-end;
}
.justify-center {
  justify-content: center;
}
.justify-between {
  justify-content: space-between;
}
.justify-items-center {
  justify-items: center;
}
.gap-1 {
  gap: 4px;
}
.gap-2 {
  gap: 8px;
}
.gap-3 {
  gap: 12px;
}
.gap-4 {
  gap: 16px;
}
.gap-x-2 {
  -moz-column-gap: 8px;
       column-gap: 8px;
}
.gap-x-4 {
  -moz-column-gap: 16px;
       column-gap: 16px;
}
.gap-y-2 {
  row-gap: 8px;
}
.space-x-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(4px * var(--tw-space-x-reverse));
  margin-left: calc(4px * calc(1 - var(--tw-space-x-reverse)));
}
.space-x-2 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(8px * var(--tw-space-x-reverse));
  margin-left: calc(8px * calc(1 - var(--tw-space-x-reverse)));
}
.space-x-3 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(12px * var(--tw-space-x-reverse));
  margin-left: calc(12px * calc(1 - var(--tw-space-x-reverse)));
}
.space-x-4 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(16px * var(--tw-space-x-reverse));
  margin-left: calc(16px * calc(1 - var(--tw-space-x-reverse)));
}
.space-x-6 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(24px * var(--tw-space-x-reverse));
  margin-left: calc(24px * calc(1 - var(--tw-space-x-reverse)));
}
.space-y-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(4px * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(4px * var(--tw-space-y-reverse));
}
.space-y-2 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(8px * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(8px * var(--tw-space-y-reverse));
}
.space-y-4 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(16px * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(16px * var(--tw-space-y-reverse));
}
.divide-y > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-y-reverse: 0;
  border-top-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width: calc(1px * var(--tw-divide-y-reverse));
}
.overflow-auto {
  overflow: auto;
}
.overflow-hidden {
  overflow: hidden;
}
.overflow-x-auto {
  overflow-x: auto;
}
.overflow-y-auto {
  overflow-y: auto;
}
.overflow-y-hidden {
  overflow-y: hidden;
}
.whitespace-nowrap {
  white-space: nowrap;
}
.whitespace-pre-wrap {
  white-space: pre-wrap;
}
.rounded {
  border-radius: 4px;
}
.rounded-full {
  border-radius: 9999px;
}
.rounded-lg {
  border-radius: 8px;
}
.rounded-md {
  border-radius: 6px;
}
.rounded-sm {
  border-radius: 2px;
}
.rounded-b-2xl {
  border-bottom-right-radius: 16px;
  border-bottom-left-radius: 16px;
}
.rounded-l-lg {
  border-top-left-radius: 8px;
  border-bottom-left-radius: 8px;
}
.rounded-l-none {
  border-top-left-radius: 0px;
  border-bottom-left-radius: 0px;
}
.rounded-r-lg {
  border-top-right-radius: 8px;
  border-bottom-right-radius: 8px;
}
.rounded-r-none {
  border-top-right-radius: 0px;
  border-bottom-right-radius: 0px;
}
.rounded-t-none {
  border-top-left-radius: 0px;
  border-top-right-radius: 0px;
}
.rounded-bl-\[22px\] {
  border-bottom-left-radius: 22px;
}
.rounded-bl-lg {
  border-bottom-left-radius: 8px;
}
.rounded-br-lg {
  border-bottom-right-radius: 8px;
}
.rounded-tr-lg {
  border-top-right-radius: 8px;
}
.border {
  border-width: 1px;
}
.border-2 {
  border-width: 2px;
}
.border-x {
  border-left-width: 1px;
  border-right-width: 1px;
}
.border-b {
  border-bottom-width: 1px;
}
.border-b-0 {
  border-bottom-width: 0px;
}
.border-b-2 {
  border-bottom-width: 2px;
}
.border-l {
  border-left-width: 1px;
}
.border-r {
  border-right-width: 1px;
}
.border-r-0 {
  border-right-width: 0px;
}
.border-t {
  border-top-width: 1px;
}
.border-dashed {
  border-style: dashed;
}
.border-none {
  border-style: none;
}
.border-accent {
  --tw-border-opacity: 1;
  border-color: rgb(var(--color-accent) / var(--tw-border-opacity, 1));
}
.border-blue-200 {
  --tw-border-opacity: 1;
  border-color: rgb(191 219 254 / var(--tw-border-opacity, 1));
}
.border-blue-500 {
  --tw-border-opacity: 1;
  border-color: rgb(59 130 246 / var(--tw-border-opacity, 1));
}
.border-cyan-200 {
  --tw-border-opacity: 1;
  border-color: rgb(165 243 252 / var(--tw-border-opacity, 1));
}
.border-gray-100 {
  --tw-border-opacity: 1;
  border-color: rgb(244 244 245 / var(--tw-border-opacity, 1));
}
.border-gray-200 {
  --tw-border-opacity: 1;
  border-color: rgb(228 228 231 / var(--tw-border-opacity, 1));
}
.border-gray-300 {
  --tw-border-opacity: 1;
  border-color: rgb(212 212 216 / var(--tw-border-opacity, 1));
}
.border-green-200 {
  --tw-border-opacity: 1;
  border-color: rgb(187 247 208 / var(--tw-border-opacity, 1));
}
.border-lime-200 {
  --tw-border-opacity: 1;
  border-color: rgb(217 249 157 / var(--tw-border-opacity, 1));
}
.border-orange-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 215 170 / var(--tw-border-opacity, 1));
}
.border-red-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 202 202 / var(--tw-border-opacity, 1));
}
.border-red-500 {
  --tw-border-opacity: 1;
  border-color: rgb(239 68 68 / var(--tw-border-opacity, 1));
}
.border-transparent {
  border-color: transparent;
}
.border-yellow-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 240 138 / var(--tw-border-opacity, 1));
}
.bg-\[\#79FFEB\] {
  --tw-bg-opacity: 1;
  background-color: rgb(121 255 235 / var(--tw-bg-opacity, 1));
}
.bg-\[\#e4e4e7\] {
  --tw-bg-opacity: 1;
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
}
.bg-\[\#f2f2f2\] {
  --tw-bg-opacity: 1;
  background-color: rgb(242 242 242 / var(--tw-bg-opacity, 1));
}
.bg-accent {
  --tw-bg-opacity: 1;
  background-color: rgb(var(--color-accent) / var(--tw-bg-opacity, 1));
}
.bg-amber-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(253 230 138 / var(--tw-bg-opacity, 1));
}
.bg-black {
  --tw-bg-opacity: 1;
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
}
.bg-blue-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(191 219 254 / var(--tw-bg-opacity, 1));
}
.bg-blue-300 {
  --tw-bg-opacity: 1;
  background-color: rgb(147 197 253 / var(--tw-bg-opacity, 1));
}
.bg-blue-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(59 130 246 / var(--tw-bg-opacity, 1));
}
.bg-blue-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(37 99 235 / var(--tw-bg-opacity, 1));
}
.bg-cyan-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(165 243 252 / var(--tw-bg-opacity, 1));
}
.bg-gray-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(244 244 245 / var(--tw-bg-opacity, 1));
}
.bg-gray-300 {
  --tw-bg-opacity: 1;
  background-color: rgb(212 212 216 / var(--tw-bg-opacity, 1));
}
.bg-gray-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(250 250 250 / var(--tw-bg-opacity, 1));
}
.bg-gray-700 {
  --tw-bg-opacity: 1;
  background-color: rgb(63 63 70 / var(--tw-bg-opacity, 1));
}
.bg-gray-900 {
  --tw-bg-opacity: 1;
  background-color: rgb(24 24 27 / var(--tw-bg-opacity, 1));
}
.bg-green-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(187 247 208 / var(--tw-bg-opacity, 1));
}
.bg-green-300 {
  --tw-bg-opacity: 1;
  background-color: rgb(134 239 172 / var(--tw-bg-opacity, 1));
}
.bg-indigo-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(199 210 254 / var(--tw-bg-opacity, 1));
}
.bg-indigo-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(99 102 241 / var(--tw-bg-opacity, 1));
}
.bg-lime-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(217 249 157 / var(--tw-bg-opacity, 1));
}
.bg-orange-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 215 170 / var(--tw-bg-opacity, 1));
}
.bg-primary {
  --tw-bg-opacity: 1;
  background-color: rgb(var(--color-primary) / var(--tw-bg-opacity, 1));
}
.bg-red-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 202 202 / var(--tw-bg-opacity, 1));
}
.bg-red-300 {
  --tw-bg-opacity: 1;
  background-color: rgb(252 165 165 / var(--tw-bg-opacity, 1));
}
.bg-red-400 {
  --tw-bg-opacity: 1;
  background-color: rgb(248 113 113 / var(--tw-bg-opacity, 1));
}
.bg-sky-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(186 230 253 / var(--tw-bg-opacity, 1));
}
.bg-transparent {
  background-color: transparent;
}
.bg-white {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity, 1));
}
.bg-yellow-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 240 138 / var(--tw-bg-opacity, 1));
}
.bg-opacity-10 {
  --tw-bg-opacity: 0.1;
}
.bg-opacity-20 {
  --tw-bg-opacity: 0.2;
}
.bg-opacity-30 {
  --tw-bg-opacity: 0.3;
}
.bg-opacity-5 {
  --tw-bg-opacity: 0.05;
}
.bg-opacity-50 {
  --tw-bg-opacity: 0.5;
}
.bg-opacity-75 {
  --tw-bg-opacity: 0.75;
}
.bg-scroll {
  background-attachment: scroll;
}
.bg-center {
  background-position: center;
}
.bg-no-repeat {
  background-repeat: no-repeat;
}
.fill-blue-200 {
  fill: #bfdbfe;
}
.fill-cyan-200 {
  fill: #a5f3fc;
}
.fill-green-200 {
  fill: #bbf7d0;
}
.fill-lime-200 {
  fill: #d9f99d;
}
.fill-orange-200 {
  fill: #fed7aa;
}
.fill-red-200 {
  fill: #fecaca;
}
.fill-yellow-200 {
  fill: #fef08a;
}
.\!p-0 {
  padding: 0px !important;
}
.p-0 {
  padding: 0px;
}
.p-0\.5 {
  padding: 2px;
}
.p-1 {
  padding: 4px;
}
.p-2 {
  padding: 8px;
}
.p-3 {
  padding: 12px;
}
.p-4 {
  padding: 16px;
}
.p-5 {
  padding: 20px;
}
.p-6 {
  padding: 24px;
}
.\!px-3 {
  padding-left: 12px !important;
  padding-right: 12px !important;
}
.\!py-2 {
  padding-top: 8px !important;
  padding-bottom: 8px !important;
}
.px-1 {
  padding-left: 4px;
  padding-right: 4px;
}
.px-2 {
  padding-left: 8px;
  padding-right: 8px;
}
.px-3 {
  padding-left: 12px;
  padding-right: 12px;
}
.px-4 {
  padding-left: 16px;
  padding-right: 16px;
}
.px-5 {
  padding-left: 20px;
  padding-right: 20px;
}
.py-1 {
  padding-top: 4px;
  padding-bottom: 4px;
}
.py-12 {
  padding-top: 48px;
  padding-bottom: 48px;
}
.py-16 {
  padding-top: 64px;
  padding-bottom: 64px;
}
.py-2 {
  padding-top: 8px;
  padding-bottom: 8px;
}
.py-3 {
  padding-top: 12px;
  padding-bottom: 12px;
}
.py-4 {
  padding-top: 16px;
  padding-bottom: 16px;
}
.py-6 {
  padding-top: 24px;
  padding-bottom: 24px;
}
.py-8 {
  padding-top: 32px;
  padding-bottom: 32px;
}
.py-px {
  padding-top: 1px;
  padding-bottom: 1px;
}
.pb-1 {
  padding-bottom: 4px;
}
.pb-2 {
  padding-bottom: 8px;
}
.pb-4 {
  padding-bottom: 16px;
}
.pb-5 {
  padding-bottom: 20px;
}
.pb-8 {
  padding-bottom: 32px;
}
.pl-1 {
  padding-left: 4px;
}
.pl-10 {
  padding-left: 40px;
}
.pl-14 {
  padding-left: 56px;
}
.pl-16 {
  padding-left: 64px;
}
.pl-2 {
  padding-left: 8px;
}
.pl-4 {
  padding-left: 16px;
}
.pl-6 {
  padding-left: 24px;
}
.pl-8 {
  padding-left: 32px;
}
.pl-\[28px\] {
  padding-left: 28px;
}
.pr-10 {
  padding-right: 40px;
}
.pr-4 {
  padding-right: 16px;
}
.pt-1 {
  padding-top: 4px;
}
.pt-2 {
  padding-top: 8px;
}
.pt-24 {
  padding-top: 96px;
}
.pt-4 {
  padding-top: 16px;
}
.pt-8 {
  padding-top: 32px;
}
.text-left {
  text-align: left;
}
.text-center {
  text-align: center;
}
.text-right {
  text-align: right;
}
.align-baseline {
  vertical-align: baseline;
}
.align-middle {
  vertical-align: middle;
}
.align-bottom {
  vertical-align: bottom;
}
.align-text-top {
  vertical-align: text-top;
}
.align-text-bottom {
  vertical-align: text-bottom;
}
.align-sub {
  vertical-align: sub;
}
.font-mono {
  font-family: Source Code Pro, monospace;
}
.text-2xl {
  font-size: 24px;
  line-height: 32px;
}
.text-3xl {
  font-size: 30px;
  line-height: 36px;
}
.text-\[14px\] {
  font-size: 14px;
}
.text-\[16px\] {
  font-size: 16px;
}
.text-base {
  font-size: 16px;
  line-height: 24px;
}
.text-lg {
  font-size: 18px;
  line-height: 28px;
}
.text-sm {
  font-size: 14px;
  line-height: 20px;
}
.text-xl {
  font-size: 20px;
  line-height: 28px;
}
.text-xs {
  font-size: 12px;
  line-height: 16px;
}
.font-semibold {
  font-weight: 600;
}
.uppercase {
  text-transform: uppercase;
}
.lowercase {
  text-transform: lowercase;
}
.\!capitalize {
  text-transform: capitalize !important;
}
.capitalize {
  text-transform: capitalize;
}
.italic {
  font-style: italic;
}
.tabular-nums {
  --tw-numeric-spacing: tabular-nums;
  font-variant-numeric: var(--tw-ordinal) var(--tw-slashed-zero) var(--tw-numeric-figure) var(--tw-numeric-spacing) var(--tw-numeric-fraction);
}
.leading-\[24px\] {
  line-height: 24px;
}
.leading-none {
  line-height: 1;
}
.leading-normal {
  line-height: 1.5;
}
.leading-tight {
  line-height: 1.25;
}
.text-accent {
  --tw-text-opacity: 1;
  color: rgb(var(--color-accent) / var(--tw-text-opacity, 1));
}
.text-black {
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity, 1));
}
.text-blue-300 {
  --tw-text-opacity: 1;
  color: rgb(147 197 253 / var(--tw-text-opacity, 1));
}
.text-blue-400 {
  --tw-text-opacity: 1;
  color: rgb(96 165 250 / var(--tw-text-opacity, 1));
}
.text-gray-100 {
  --tw-text-opacity: 1;
  color: rgb(244 244 245 / var(--tw-text-opacity, 1));
}
.text-gray-200 {
  --tw-text-opacity: 1;
  color: rgb(228 228 231 / var(--tw-text-opacity, 1));
}
.text-gray-300 {
  --tw-text-opacity: 1;
  color: rgb(212 212 216 / var(--tw-text-opacity, 1));
}
.text-gray-400 {
  --tw-text-opacity: 1;
  color: rgb(161 161 170 / var(--tw-text-opacity, 1));
}
.text-gray-500 {
  --tw-text-opacity: 1;
  color: rgb(113 113 122 / var(--tw-text-opacity, 1));
}
.text-gray-600 {
  --tw-text-opacity: 1;
  color: rgb(82 82 91 / var(--tw-text-opacity, 1));
}
.text-gray-700 {
  --tw-text-opacity: 1;
  color: rgb(63 63 70 / var(--tw-text-opacity, 1));
}
.text-gray-800 {
  --tw-text-opacity: 1;
  color: rgb(39 39 42 / var(--tw-text-opacity, 1));
}
.text-green-400 {
  --tw-text-opacity: 1;
  color: rgb(74 222 128 / var(--tw-text-opacity, 1));
}
.text-green-500 {
  --tw-text-opacity: 1;
  color: rgb(34 197 94 / var(--tw-text-opacity, 1));
}
.text-green-600 {
  --tw-text-opacity: 1;
  color: rgb(22 163 74 / var(--tw-text-opacity, 1));
}
.text-primary {
  --tw-text-opacity: 1;
  color: rgb(var(--color-primary) / var(--tw-text-opacity, 1));
}
.text-red-400 {
  --tw-text-opacity: 1;
  color: rgb(248 113 113 / var(--tw-text-opacity, 1));
}
.text-red-500 {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}
.text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}
.text-yellow-400 {
  --tw-text-opacity: 1;
  color: rgb(250 204 21 / var(--tw-text-opacity, 1));
}
.text-yellow-500 {
  --tw-text-opacity: 1;
  color: rgb(234 179 8 / var(--tw-text-opacity, 1));
}
.underline {
  text-decoration-line: underline;
}
.opacity-0 {
  opacity: 0;
}
.opacity-25 {
  opacity: 0.25;
}
.opacity-50 {
  opacity: 0.5;
}
.opacity-70 {
  opacity: 0.7;
}
.opacity-75 {
  opacity: 0.75;
}
.shadow {
  --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-2xl {
  --tw-shadow: 0 25px 50px -12px rgb(0 0 0 / 0.25);
  --tw-shadow-colored: 0 25px 50px -12px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-lg {
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-md {
  --tw-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-xl {
  --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.outline {
  outline-style: solid;
}
.ring {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.ring-2 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.ring-accent {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(var(--color-accent) / var(--tw-ring-opacity, 1));
}
.ring-red-400 {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(248 113 113 / var(--tw-ring-opacity, 1));
}
.blur {
  --tw-blur: blur(8px);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.invert {
  --tw-invert: invert(100%);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.backdrop-blur {
  --tw-backdrop-blur: blur(8px);
  -webkit-backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.backdrop-filter {
  -webkit-backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.transition {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, -webkit-backdrop-filter;
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter, -webkit-backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-transform {
  transition-property: transform;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.duration-200 {
  transition-duration: 200ms;
}
.ease-out {
  transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
.hoverable:hover {
  background-color: rgb(39 39 42 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.hoverable:hover:is(.dark *) {
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.bg-input {
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.bg-input:hover {
  --tw-bg-opacity: 0.1;
}
.bg-input:is(.dark *) {
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.bg-input:hover:is(.dark *) {
  --tw-bg-opacity: 0.1;
}
.bg-box-transparent {
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.bg-box-transparent:is(.dark *) {
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.bg-box-transparent-2 {
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.1;
}
.bg-box-transparent-2:is(.dark *) {
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.1;
}

:host, :root {
  --color-primary: 59 130 246;
  --color-secondary: 96 165 250;
  --color-accent: 24 24 27;
}
.dark {
  --color-primary: 96 165 250;
  --color-secondary: 59 130 246;
  --color-accent: 244 244 245;
}

*:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(63 63 70 / var(--tw-border-opacity, 1));
}

html.dark {
  --tw-bg-opacity: 1;
  background-color: rgb(24 24 27 / var(--tw-bg-opacity, 1));
}

body, :host {
  font-family: 'Inter var', sans-serif !important;
  font-size: 16px !important;
  font-feature-settings: 'cv02', 'cv03', 'cv04', 'cv11';
  --tw-bg-opacity: 1;
  background-color: rgb(250 250 250 / var(--tw-bg-opacity, 1));
  line-height: 1.5;
}

body:is(.dark *), :host:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(24 24 27 / var(--tw-bg-opacity, 1));
}
table th,
table td {
  padding-top: 8px;
  padding-bottom: 8px;
  padding-left: 16px;
  padding-right: 16px;
}
input:focus,
button:focus,
textarea:focus,
select:focus,
[role='button']:focus {
  outline: none;
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(var(--color-accent) / var(--tw-ring-opacity, 1));
}
input:focus:is(.dark *),
button:focus:is(.dark *),
textarea:focus:is(.dark *),
select:focus:is(.dark *),
[role='button']:focus:is(.dark *) {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(228 228 231 / var(--tw-ring-opacity, 1));
}

.text-overflow {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.line-clamp {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
}


.custom-table thead {
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}


.custom-table thead:is(.dark *) {
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.custom-table thead th {
  font-weight: 600;
}
.custom-table thead th:first-child {
  border-top-left-radius: 8px;
  border-bottom-left-radius: 8px;
}
.custom-table thead th:last-child {
  border-top-right-radius: 8px;
  border-bottom-right-radius: 8px;
}
.custom-table tbody > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-y-reverse: 0;
  border-top-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width: calc(1px * var(--tw-divide-y-reverse));
}



pre {
  font-size: 15px;
}

.scroll::-webkit-scrollbar, .scroll .cm-scroller::-webkit-scrollbar {
    width: 7px;
    height: 9px;
  }

.scroll::-webkit-scrollbar-thumb, .scroll .cm-scroller::-webkit-scrollbar-thumb {
  --tw-bg-opacity: 1;
  background-color: rgb(212 212 216 / var(--tw-bg-opacity, 1));
}

.scroll:is(.dark *)::-webkit-scrollbar-thumb, .scroll .cm-scroller:is(.dark *)::-webkit-scrollbar-thumb {
  --tw-bg-opacity: 1;
  background-color: rgb(63 63 70 / var(--tw-bg-opacity, 1));
}

.scroll::-webkit-scrollbar-thumb, .scroll .cm-scroller::-webkit-scrollbar-thumb {
    border-radius: 8px;
  }

.scroll::-webkit-scrollbar-track, .scroll .cm-scroller::-webkit-scrollbar-track {
    background: transparent;
  }

.scroll.scroll-xs::-webkit-scrollbar, .scroll .cm-scroller.scroll-xs::-webkit-scrollbar {
    width: 5px;
    height: 5px;
  }


.tippy-box[data-theme~='tooltip-theme'] {
  border-radius: 6px;
  --tw-bg-opacity: 1;
  background-color: rgb(24 24 27 / var(--tw-bg-opacity, 1));
  padding-left: 8px;
  padding-right: 8px;
  padding-top: 4px;
  padding-bottom: 4px;
  font-size: 14px;
  line-height: 20px;
  --tw-text-opacity: 1;
  color: rgb(228 228 231 / var(--tw-text-opacity, 1));
}


.tippy-box[data-theme~='tooltip-theme']:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity, 1));
}
.Vue-Toastification__toast {
  font-family: inherit !important;
}
.ProseMirror > * + * {
  margin-top: 0.75em;
}
.ProseMirror img {
  max-width: 100%;
  height: auto;
}
.ProseMirror img.ProseMirror-selectednode {
  outline: 3px solid #68CEF8;
}

.input-label {
  margin-left: 4px;
  font-size: 14px;
  line-height: 20px;
  --tw-text-opacity: 1;
  color: rgb(82 82 91 / var(--tw-text-opacity, 1));
}

.input-label:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(228 228 231 / var(--tw-text-opacity, 1));
}

.dark\:prose-invert:is(.dark *) {
  --tw-prose-body: var(--tw-prose-invert-body);
  --tw-prose-headings: var(--tw-prose-invert-headings);
  --tw-prose-lead: var(--tw-prose-invert-lead);
  --tw-prose-links: var(--tw-prose-invert-links);
  --tw-prose-bold: var(--tw-prose-invert-bold);
  --tw-prose-counters: var(--tw-prose-invert-counters);
  --tw-prose-bullets: var(--tw-prose-invert-bullets);
  --tw-prose-hr: var(--tw-prose-invert-hr);
  --tw-prose-quotes: var(--tw-prose-invert-quotes);
  --tw-prose-quote-borders: var(--tw-prose-invert-quote-borders);
  --tw-prose-captions: var(--tw-prose-invert-captions);
  --tw-prose-kbd: var(--tw-prose-invert-kbd);
  --tw-prose-kbd-shadows: var(--tw-prose-invert-kbd-shadows);
  --tw-prose-code: var(--tw-prose-invert-code);
  --tw-prose-pre-code: var(--tw-prose-invert-pre-code);
  --tw-prose-pre-bg: var(--tw-prose-invert-pre-bg);
  --tw-prose-th-borders: var(--tw-prose-invert-th-borders);
  --tw-prose-td-borders: var(--tw-prose-invert-td-borders);
}

.placeholder\:text-black::-moz-placeholder {
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity, 1));
}

.placeholder\:text-black::placeholder {
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity, 1));
}

.focus-within\:ring-2:focus-within {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.focus-within\:ring-accent:focus-within {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(var(--color-accent) / var(--tw-ring-opacity, 1));
}

.focus-within\:bg-box-transparent-2:focus-within {
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.1;
}

.focus-within\:bg-box-transparent-2:focus-within:is(.dark *) {
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.1;
}

.hover\:-translate-y-1:hover {
  --tw-translate-y: -4px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.hover\:scale-110:hover {
  --tw-scale-x: 1.1;
  --tw-scale-y: 1.1;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.hover\:bg-gray-100:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(244 244 245 / var(--tw-bg-opacity, 1));
}

.hover\:bg-gray-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(63 63 70 / var(--tw-bg-opacity, 1));
}

.hover\:bg-red-400:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(248 113 113 / var(--tw-bg-opacity, 1));
}

.hover\:bg-secondary:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(var(--color-secondary) / var(--tw-bg-opacity, 1));
}

.hover\:text-black:hover {
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity, 1));
}

.hover\:shadow-xl:hover {
  --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.hover\:ring-2:hover {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.hover\:ring-accent:hover {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(var(--color-accent) / var(--tw-ring-opacity, 1));
}

.hover\:ring-gray-900:hover {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(24 24 27 / var(--tw-ring-opacity, 1));
}

.focus\:outline-none:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
}

.focus\:ring-0:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.focus\:ring-2:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.focus\:ring-red-400:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(248 113 113 / var(--tw-ring-opacity, 1));
}

.group:hover .group-hover\:visible {
  visibility: visible;
}

.group:hover .group-hover\:invisible {
  visibility: hidden;
}

.group:hover .group-hover\:scale-100 {
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.dark\:divide-gray-700:is(.dark *) > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(63 63 70 / var(--tw-divide-opacity, 1));
}

.dark\:divide-gray-800:is(.dark *) > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(39 39 42 / var(--tw-divide-opacity, 1));
}

.dark\:border-accent:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(var(--color-accent) / var(--tw-border-opacity, 1));
}

.dark\:border-blue-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(147 197 253 / var(--tw-border-opacity, 1));
}

.dark\:border-blue-400:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(96 165 250 / var(--tw-border-opacity, 1));
}

.dark\:border-cyan-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(103 232 249 / var(--tw-border-opacity, 1));
}

.dark\:border-gray-100:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(244 244 245 / var(--tw-border-opacity, 1));
}

.dark\:border-gray-700:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(63 63 70 / var(--tw-border-opacity, 1));
}

.dark\:border-gray-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(39 39 42 / var(--tw-border-opacity, 1));
}

.dark\:border-green-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(134 239 172 / var(--tw-border-opacity, 1));
}

.dark\:border-lime-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(190 242 100 / var(--tw-border-opacity, 1));
}

.dark\:border-orange-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(253 186 116 / var(--tw-border-opacity, 1));
}

.dark\:border-red-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(252 165 165 / var(--tw-border-opacity, 1));
}

.dark\:border-transparent:is(.dark *) {
  border-color: transparent;
}

.dark\:border-yellow-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(253 224 71 / var(--tw-border-opacity, 1));
}

.dark\:border-opacity-40:is(.dark *) {
  --tw-border-opacity: 0.4;
}

.dark\:border-opacity-50:is(.dark *) {
  --tw-border-opacity: 0.5;
}

.dark\:bg-\[\#2DD4BF\]:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(45 212 191 / var(--tw-bg-opacity, 1));
}

.dark\:bg-amber-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(252 211 77 / var(--tw-bg-opacity, 1));
}

.dark\:bg-blue-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(147 197 253 / var(--tw-bg-opacity, 1));
}

.dark\:bg-cyan-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(103 232 249 / var(--tw-bg-opacity, 1));
}

.dark\:bg-gray-100:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(244 244 245 / var(--tw-bg-opacity, 1));
}

.dark\:bg-gray-200:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
}

.dark\:bg-gray-600:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(82 82 91 / var(--tw-bg-opacity, 1));
}

.dark\:bg-gray-700:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(63 63 70 / var(--tw-bg-opacity, 1));
}

.dark\:bg-gray-800:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(39 39 42 / var(--tw-bg-opacity, 1));
}

.dark\:bg-gray-900:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(24 24 27 / var(--tw-bg-opacity, 1));
}

.dark\:bg-green-200:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(187 247 208 / var(--tw-bg-opacity, 1));
}

.dark\:bg-green-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(134 239 172 / var(--tw-bg-opacity, 1));
}

.dark\:bg-indigo-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(165 180 252 / var(--tw-bg-opacity, 1));
}

.dark\:bg-indigo-400:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(129 140 248 / var(--tw-bg-opacity, 1));
}

.dark\:bg-lime-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(190 242 100 / var(--tw-bg-opacity, 1));
}

.dark\:bg-orange-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(253 186 116 / var(--tw-bg-opacity, 1));
}

.dark\:bg-red-200:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(254 202 202 / var(--tw-bg-opacity, 1));
}

.dark\:bg-red-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(252 165 165 / var(--tw-bg-opacity, 1));
}

.dark\:bg-red-400:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(248 113 113 / var(--tw-bg-opacity, 1));
}

.dark\:bg-red-500:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(239 68 68 / var(--tw-bg-opacity, 1));
}

.dark\:bg-secondary:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(var(--color-secondary) / var(--tw-bg-opacity, 1));
}

.dark\:bg-sky-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(125 211 252 / var(--tw-bg-opacity, 1));
}

.dark\:bg-yellow-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(253 224 71 / var(--tw-bg-opacity, 1));
}

.dark\:bg-opacity-10:is(.dark *) {
  --tw-bg-opacity: 0.1;
}

.dark\:bg-opacity-60:is(.dark *) {
  --tw-bg-opacity: 0.6;
}

.dark\:bg-none:is(.dark *) {
  background-image: none;
}

.dark\:fill-blue-300:is(.dark *) {
  fill: #93c5fd;
}

.dark\:fill-cyan-300:is(.dark *) {
  fill: #67e8f9;
}

.dark\:fill-green-300:is(.dark *) {
  fill: #86efac;
}

.dark\:fill-lime-300:is(.dark *) {
  fill: #bef264;
}

.dark\:fill-orange-300:is(.dark *) {
  fill: #fdba74;
}

.dark\:fill-red-300:is(.dark *) {
  fill: #fca5a5;
}

.dark\:fill-yellow-300:is(.dark *) {
  fill: #fde047;
}

.dark\:text-black:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity, 1));
}

.dark\:text-gray-100:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(244 244 245 / var(--tw-text-opacity, 1));
}

.dark\:text-gray-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(228 228 231 / var(--tw-text-opacity, 1));
}

.dark\:text-gray-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(212 212 216 / var(--tw-text-opacity, 1));
}

.dark\:text-gray-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(161 161 170 / var(--tw-text-opacity, 1));
}

.dark\:text-gray-600:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(82 82 91 / var(--tw-text-opacity, 1));
}

.dark\:text-gray-900:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(24 24 27 / var(--tw-text-opacity, 1));
}

.dark\:text-green-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(74 222 128 / var(--tw-text-opacity, 1));
}

.dark\:text-red-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 165 165 / var(--tw-text-opacity, 1));
}

.dark\:text-red-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(248 113 113 / var(--tw-text-opacity, 1));
}

.dark\:text-red-500:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}

.dark\:text-red-600:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}

.dark\:text-secondary:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(var(--color-secondary) / var(--tw-text-opacity, 1));
}

.dark\:text-yellow-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(253 224 71 / var(--tw-text-opacity, 1));
}

.dark\:invert:is(.dark *) {
  --tw-invert: invert(100%);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}

.dark\:hover\:bg-gray-200:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
}

.dark\:hover\:bg-gray-700:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(63 63 70 / var(--tw-bg-opacity, 1));
}

.dark\:hover\:bg-primary:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(var(--color-primary) / var(--tw-bg-opacity, 1));
}

.dark\:hover\:bg-red-500:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(239 68 68 / var(--tw-bg-opacity, 1));
}

.dark\:hover\:text-gray-100:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(244 244 245 / var(--tw-text-opacity, 1));
}

.dark\:hover\:ring-gray-200:hover:is(.dark *) {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(228 228 231 / var(--tw-ring-opacity, 1));
}

@media (min-width: 768px) {

  .md\:relative {
    position: relative;
  }

  .md\:-ml-1 {
    margin-left: -4px;
  }

  .md\:mb-0 {
    margin-bottom: 0px;
  }

  .md\:ml-0 {
    margin-left: 0px;
  }

  .md\:ml-4 {
    margin-left: 16px;
  }

  .md\:mt-0 {
    margin-top: 0px;
  }

  .md\:block {
    display: block;
  }

  .md\:flex {
    display: flex;
  }

  .md\:hidden {
    display: none;
  }

  .md\:w-auto {
    width: auto;
  }

  .md\:flex-1 {
    flex: 1 1 0%;
  }

  .md\:grid-cols-2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .md\:items-center {
    align-items: center;
  }

  .md\:justify-between {
    justify-content: space-between;
  }

  .md\:space-x-4 > :not([hidden]) ~ :not([hidden]) {
    --tw-space-x-reverse: 0;
    margin-right: calc(16px * var(--tw-space-x-reverse));
    margin-left: calc(16px * calc(1 - var(--tw-space-x-reverse)));
  }

  .md\:px-4 {
    padding-left: 16px;
    padding-right: 16px;
  }

  .md\:pr-60 {
    padding-right: 240px;
  }

  .md\:text-left {
    text-align: left;
  }
}

@media (min-width: 1024px) {

  .lg\:mb-0 {
    margin-bottom: 0px;
  }

  .lg\:ml-8 {
    margin-left: 32px;
  }

  .lg\:mt-0 {
    margin-top: 0px;
  }

  .lg\:block {
    display: block;
  }

  .lg\:inline-block {
    display: inline-block;
  }

  .lg\:flex {
    display: flex;
  }

  .lg\:hidden {
    display: none;
  }

  .lg\:w-4\/12 {
    width: 33.333333%;
  }

  .lg\:w-auto {
    width: auto;
  }

  .lg\:flex-1 {
    flex: 1 1 0%;
  }

  .lg\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }

  .lg\:flex-row {
    flex-direction: row;
  }

  .lg\:items-center {
    align-items: center;
  }

  .lg\:justify-between {
    justify-content: space-between;
  }
}

@media (min-width: 1536px) {

  .\32xl\:grid-cols-4 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
}

</style><style>.list-item-active svg { visibility: visible }</style><div id="app" data-v-app=""><!----></div></template></div><div id="small-screen-width-point" style="position:absolute;top:-10000px;width:10px;height:10px;background:#fff;"></div><div id="tablet-screen-width-point" style="position:absolute;top:-10000px;width:10px;height:10px;background:#fff;"></div></body><!--<![endif]--></html>'''

import logging, traceback, coloredlogs, re
from scrapy.selector import Selector
from datetime import datetime

logger = logging.getLogger("scraper")
logger.setLevel(logging.INFO)
coloredlogs.install(level="INFO", logger=logger)


class Parser:
    # ---------- Static spec values --------------------------------------
    BALL_TYPE = "Yellow"
    COUNTRY = "Uruguay"
    COUNTRY_CODE = "URY"
    ID_TYPE = "Uruguay"
    IMPORT_SOURCE = "AUT"
    SANCTION_BODY = "AUT"
    EVENT_TYPE = "Tournament"

    # game-top header — two real layouts observed in the wild:
    #   (a) "5º Jogo - 2º Rodada - 29/01/2026 11:00"
    #   (b) "1º Rodada - "              (no Jogo prefix, no date)
    _RE_GAME_TOP = re.compile(
        r"^\s*\d+\s*º?\s*Jogo\s*-\s*(?P<round>[^-]+?)\s*-\s*"
        r"(?P<date>\d{2}/\d{2}/\d{4})(?:\s+\d{1,2}:\d{2})?\s*$",
        re.IGNORECASE,
    )
    # Short header: round label only, no Jogo prefix, no date.
    _RE_GAME_TOP_SHORT = re.compile(
        r"^\s*(?P<round>\d+\s*º?\s*Rodada|Final|Semi[-\s]?final|"
        r"Quartas?(?:\s+de\s+final)?|Oitavas?(?:\s+de\s+final)?|"
        r"16[ªa]s?|32[ªa]s?|64[ªa]s?|Repescagem|Quali(?:fica[çc][ãa]o)?)"
        r"\s*-?\s*$",
        re.IGNORECASE,
    )
    _RE_DATE_IN_HEADER = re.compile(r"(\d{2}/\d{2}/\d{4})")
    _RE_BYE = re.compile(r"^\s*BYE\s*$", re.IGNORECASE)

    # Any of these tokens introduces the winner's name in the bottom strip.
    # We intentionally keep the regex loose: the winner phrase is just
    # "<token> <name>" and may be followed by " - <tail>" or end of line.
    _WINNER_TOKEN = r"(?:vencedor(?:\(a\)|a)?|ganhador(?:\(a\)|a)?|camp[eê]ao|champion)"
    _RE_WINNER_LINE = re.compile(
        rf"{_WINNER_TOKEN}\s*[:\-]\s*(?P<name>[^\n\r]+?)(?:\s+-\s+(?P<tail>[^\n\r]+))?\s*$",
        re.IGNORECASE | re.MULTILINE,
    )
    # Fallback: a standalone "Vencedor" token immediately before a name link.
    _RE_WINNER_TOKEN_ONLY = re.compile(rf"\b{_WINNER_TOKEN}\b", re.IGNORECASE)

    # Outcome detection: look at full block text.
    _RE_WO = re.compile(r"\b(w\.?o\.?|walkover)\b", re.IGNORECASE)
    _RE_RETIRED = re.compile(
        r"\b(des(?:ist[eê]ncia|istiu)?|abandono|retirou|retirado|ret\.?)\b",
        re.IGNORECASE,
    )

    _RE_PROFILE_ID = re.compile(r"perfil2/index/(\d+)")
    _RE_MATCH_ID = re.compile(r"\((\d+)\)")
    _RE_PERIOD = re.compile(r"(\d{2}/\d{2}/\d{4})\s*a\s*(\d{2}/\d{2}/\d{4})")
    _RE_TRAILING_PAREN = re.compile(r"\s*\([^)]*\)\s*$")

    # ---------- Init -----------------------------------------------------
    def __init__(self, spider_name, selector):
        self.spider_name = spider_name
        self._extract_tournament(selector)
        self._extract_draw(selector)

    # ================================================================
    # Helpers
    # ================================================================
    @staticmethod
    def _clean(text: str) -> str:
        if not text:
            return ""
        return re.sub(r"\s+", " ", text).strip()

    @classmethod
    def _join_text(cls, sel) -> str:
        return cls._clean(" ".join(sel.xpath(".//text()").getall()))

    @classmethod
    def _format_date(cls, d: str) -> str:
        d = cls._clean(d)
        if not d:
            return ""
        try:
            dt = datetime.strptime(d, "%d/%m/%Y")
        except ValueError:
            return d
        return dt.strftime("%m/%d/%Y")

    @classmethod
    def _strip_markers(cls, name: str) -> str:
        return cls._RE_TRAILING_PAREN.sub("", cls._clean(name)).strip()

    @classmethod
    def _last_first(cls, full_name: str) -> str:
        name = cls._strip_markers(full_name)
        if not name:
            return ""
        parts = name.split()
        if len(parts) == 1:
            return parts[0]
        return f"{parts[-1]}, {' '.join(parts[:-1])}"

    @classmethod
    def _profile_id_from_href(cls, href: str) -> str:
        if not href:
            return ""
        m = cls._RE_PROFILE_ID.search(href)
        return m.group(1) if m else ""

    @staticmethod
    def _set_to_pair(set_text):
        """'6-3' -> (6,3); '7-6(5)' -> (7,6); returns (None,None) on junk."""
        if not set_text:
            return (None, None)
        m = re.match(r"\s*(\d{1,2})\s*[-x×]\s*(\d{1,2})", set_text)
        if not m:
            return (None, None)
        return (int(m.group(1)), int(m.group(2)))

    # ================================================================
    # Tournament-level extraction
    # ================================================================
    def _extract_tournament(self, selector) -> None:
        title_sel = selector.xpath(".//div[@class='tournament-title']")
        self.tournament_name = self._join_text(title_sel) if title_sel else ""

        local_parts = selector.xpath(".//div[@class='tournament-local']/descendant-or-self::text()").getall()
        local_text = self._clean(" ".join(local_parts))
        self.tournament_city = local_text.split("-", 1)[0].strip() if "-" in local_text else local_text

        self.tournament_start_date = ""
        self.tournament_end_date = ""
        for info_text in selector.xpath(".//div[@class='tournament-period']//div[@class='info']/text()").getall():
            m = self._RE_PERIOD.match(self._clean(info_text))
            if m:
                self.tournament_start_date = self._format_date(m.group(1))
                self.tournament_end_date = self._format_date(m.group(2))
                break

        share_url = selector.xpath(".//div[@class='tournament-share']//input[@class='form-control']/@value").get()
        if share_url:
            self.tournament_url = share_url.strip()
        else:
            id_torneio = selector.xpath(".//input[@name='id_torneio']/@value").get()
            if id_torneio:
                self.tournament_url = (
                    "https://www.tenisintegrado.com.br/torneio_painel_info/index/"
                    f"{id_torneio.strip()}"
                )
            else:
                self.tournament_url = ""

        self.tournament_state = ""
        self.tournament_country = self.COUNTRY
        self.tournament_country_code = self.COUNTRY_CODE
        self.tournament_host = ""
        self.tournament_location_type = ""
        self.tournament_surface = ""
        self.tournament_event_category = ""
        self.tournament_event_grade = ""
        self.tournament_event_type = self.EVENT_TYPE
        self.tournament_import_source = self.IMPORT_SOURCE
        self.tournament_sanction_body = self.SANCTION_BODY

    # ================================================================
    # Draw extraction
    # ================================================================
    def _extract_draw(self, selector) -> None:
        name = ""
        for txt in selector.xpath(".//h4/text() | .//h3/text() | .//h2/text()").getall():
            txt = self._clean(txt)
            if "Simples" in txt or "Duplas" in txt:
                name = txt
                break
        if not name:
            opt = selector.xpath(".//select[@id='id_categoria']//option[@selected]/text()").get()
            if opt:
                name = self._clean(opt)

        self.draw_name = name
        low = name.lower()
        self.draw_gender = "Male" if "masculino" in low else ("Female" if "feminino" in low else "")
        self.draw_team_type = "Doubles" if "duplas" in low else ("Singles" if "simples" in low else "")
        self.draw_bracket_value = ""
        self.draw_bracket_type = ""
        self.draw_type = ""

    def _players_in_row(self, li_sel):
        players = []
        # avatar-container can sit one or two levels below the <li>
        # (real markup nests it inside <div class="players">).
        for ac in li_sel.xpath('.//div[@class="avatar-container"]'):
            player_name = self._join_text(ac.xpath('./span[@class="avatar-info"]/a'))
            player_link = ac.xpath(".//span[contains(@class,'avatar-info')]/a/@href").get()
            third_party_id = self._profile_id_from_href(player_link)

            logger.info(f'player_name: {player_name}')
            logger.info(f'player_link: {player_link}')
            logger.info(f'third_party_id: {third_party_id}')
            logger.info('*'*50)

            '''
            if not third_party_id and player_name:
                third_party_id = helper.sha256_id(player_name)

            if third_party_id:
                objs = PlayersUruguayResultsModel.objects.filter(
                    spider_name=self.spider_name, third_party_id=third_party_id
                )
                if objs.exists():
                    player_name = objs.first().player_name
                else:
                    try:
                        claude_key = random.choice(settings.CLAUDE_KEYS)
                        player_name, _gender = helper.format_name_gender_claude(player_name, claude_key)
                    except Exception:
                        logger.error(traceback.format_exc())
                    PlayersUruguayResultsModel(
                        spider_name=self.spider_name,
                        third_party_id=third_party_id,
                        player_name=player_name,
                    ).save()
            '''

            if player_name:
                players.append((player_name, third_party_id))

        return players


    def _row_score(self, li_sel):
        score_sel = li_sel.xpath(".//div[@class='score pull-right']")
        if not score_sel:
            return []
        if score_sel.xpath(".//div[@class='wo text-danger']") or self._RE_WO.search(self._join_text(score_sel)):
            return ["W.O."]
        sets = [self._join_text(s) for s in score_sel.xpath(".//div[@class='set']")]
        return [s for s in sets if s]

    @staticmethod
    def _row_has_winner_marker(li_sel) -> bool:
        """True if this <li> looks like the winner row by CSS / icon."""
        cls = (li_sel.attrib.get("class") or "").lower()
        if any(tok in cls for tok in ("winner", "vencedor", "is-winner", "champ")):
            return True
        # any descendant icon that screams 'win'
        icon_classes = " ".join(li_sel.xpath(".//@class").getall()).lower()
        if any(tok in icon_classes for tok in ("fa-trophy", "fa-check", "win-icon", "vencedor")):
            return True
        return False

    @staticmethod
    def _build_score(winner_sets, loser_sets, outcome: str) -> str:
        if outcome == "Walkover":
            return "W.O.;"
        pairs = []
        for i in range(max(len(winner_sets), len(loser_sets))):
            w = winner_sets[i] if i < len(winner_sets) else ""
            l = loser_sets[i] if i < len(loser_sets) else ""
            if (not w and not l) or "W.O." in (w, l):
                continue
            # Each set string is either "games" (e.g. "6") or
            # "games tiebreak" (e.g. "7 8") when the set went to a tiebreak.
            w_parts = w.split()
            l_parts = l.split()
            w_games = w_parts[0] if w_parts else ""
            l_games = l_parts[0] if l_parts else ""
            l_tb = l_parts[1] if len(l_parts) > 1 else ""
            w_tb = w_parts[1] if len(w_parts) > 1 else ""
            # By convention the loser's tiebreak score goes in parens.
            tb = l_tb or w_tb
            if tb:
                pairs.append(f"{w_games}-{l_games}({tb})")
            else:
                pairs.append(f"{w_games}-{l_games}")
        score = ", ".join(pairs)
        if outcome == "retired" and score:
            score += " ret."
        return f"{score};" if score else ";"

    @classmethod
    def _outcome_from_block(cls, block_text: str) -> str:
        if cls._RE_WO.search(block_text):
            return "Walkover"
        if cls._RE_RETIRED.search(block_text):
            return "retired"
        return "Completed"

    # ================================================================
    # Winner-detection strategies
    # ================================================================
    def _winner_name_from_text(self, block_text: str):
        """Strategy A: explicit winner phrase anywhere in the block."""
        m = self._RE_WINNER_LINE.search(block_text)
        if m:
            return self._strip_markers(m.group("name"))
        return None

    def _winner_row_index_from_markup(self, rows) -> int | None:
        """Strategy B: a row carries an explicit CSS / icon marker."""
        marked = [i for i, r in enumerate(rows) if self._row_has_winner_marker(r)]
        if len(marked) == 1:
            return marked[0]
        return None

    def _winner_row_index_from_score(self, row_a_sets, row_b_sets) -> int | None:
        """Strategy C: whoever won more sets is the winner.

        Each row carries that row's per-set scores as individual numbers
        (e.g. row_a=['6','3'], row_b=['2','3']  ->  set1: 6-2, set2: 3-3).
        Compare set-by-set across the two rows.
        """
        a_wins = b_wins = 0
        for i in range(max(len(row_a_sets), len(row_b_sets))):
            a = row_a_sets[i] if i < len(row_a_sets) else ""
            b = row_b_sets[i] if i < len(row_b_sets) else ""
            am = re.match(r"\s*(\d+)", a or "")
            bm = re.match(r"\s*(\d+)", b or "")
            if not am or not bm:
                continue
            ai, bi = int(am.group(1)), int(bm.group(1))
            if ai > bi:
                a_wins += 1
            elif bi > ai:
                b_wins += 1
        if a_wins == b_wins:
            return None
        return 0 if a_wins > b_wins else 1

    # ================================================================
    # Parse one match
    # ================================================================
    def parse_match(self, game_sel):
        match_data = {}
        try:
            # ---- header (match_id, round, date) -----------------------------
            spans = game_sel.xpath('./div[@class="game-top"]/span')
            header_text = self._clean(self._join_text(spans[0])) if spans else ""
            match_id = ""
            if len(spans) >= 2:
                m = self._RE_MATCH_ID.search(self._join_text(spans[1]))
                if m:
                    match_id = m.group(1)

            round_ = ""
            date = ""
            m = self._RE_GAME_TOP.match(header_text)
            if m:
                round_ = self._clean(m.group("round"))
                date = self._format_date(m.group("date"))
            else:
                # Short header layout — round only, no date.
                m2 = self._RE_GAME_TOP_SHORT.match(header_text)
                if m2:
                    round_ = self._clean(m2.group("round"))
                # opportunistic date scan anywhere in the header text
                dm = self._RE_DATE_IN_HEADER.search(header_text)
                if dm:
                    date = self._format_date(dm.group(1))
            # Final fallback: use the tournament start date when the block
            # header doesn't include a per-match date.
            if not date and getattr(self, "tournament_start_date", ""):
                date = self.tournament_start_date

            # ---- rows -------------------------------------------------------
            rows = game_sel.xpath('./ul[@class="list-group"]/li[@class="list-group-item"]')
            if len(rows) < 2:
                logger.info('len(rows) < 2')
                return None

            row_a_players = self._players_in_row(rows[0])
            row_b_players = self._players_in_row(rows[1])
            logger.info(f'row_a_players: {row_a_players}')
            logger.info(f'row_b_players: {row_b_players}')

            row_a_sets = self._row_score(rows[0])
            row_b_sets = self._row_score(rows[1])
            logger.info(f'row_a_sets: {row_a_sets}')
            logger.info(f'row_b_sets: {row_b_sets}')
            logger.info('*'*50)

            if not row_a_players or not row_b_players:
                logger.info('not row_a_players or not row_b_players')
                return None

            # Skip BYE blocks: if either side is BYE, this isn't a real match.
            if any(p[0] == "__BYE__" for p in row_a_players) or any(p[0] == "__BYE__" for p in row_b_players):
                logger.info('any(p[0] == "__BYE__" for p in row_a_players) or any(p[0] == "__BYE__" for p in row_b_players)')
                return None

            # ---- full block text (for winner + outcome) ---------------------
            block_text = self._join_text(game_sel.xpath(".//div[@class='game-bottom']")) or self._join_text(game_sel)
            outcome = self._outcome_from_block(block_text)

            # ---- find the winner with progressive fallback ------------------
            winner_idx = None
            strategy = None

            # A) text-based winner phrase
            winner_name_raw = self._winner_name_from_text(block_text)
            if winner_name_raw:
                target = self._strip_markers(winner_name_raw).lower()
                for idx, players in enumerate((row_a_players, row_b_players)):
                    if any(self._strip_markers(p[0]).lower() == target or
                           self._strip_markers(p[0]).lower() in target or
                           target in self._strip_markers(p[0]).lower()
                           for p in players):
                        winner_idx = idx
                        strategy = "text"
                        break

            # B) CSS marker on a row
            if winner_idx is None:
                wi = self._winner_row_index_from_markup(rows)
                if wi is not None:
                    winner_idx = wi
                    strategy = "markup"

            # C) score comparison
            if winner_idx is None:
                wi = self._winner_row_index_from_score(row_a_sets, row_b_sets)
                if wi is not None:
                    winner_idx = wi
                    strategy = "score"

            # D) walkover / retired clearly indicated but no name match:
            #    if outcome != Completed and exactly one row has scores, the row
            #    *with* scores is the survivor.
            if winner_idx is None and outcome != "Completed":
                if row_a_sets and not row_b_sets:
                    winner_idx, strategy = 0, "outcome-only-scored"
                elif row_b_sets and not row_a_sets:
                    winner_idx, strategy = 1, "outcome-only-scored"

            if winner_idx is None:
                logger.info('winner_idx is None')
                return None

            if winner_idx == 0:
                winners, losers = row_a_players, row_b_players
                winner_sets, loser_sets = row_a_sets, row_b_sets
            else:
                winners, losers = row_b_players, row_a_players
                winner_sets, loser_sets = row_b_sets, row_a_sets

            logger.debug(f"[parser] match {match_id or '----'} winner via {strategy}")

            # ---- field assembly ---------------------------------------------
            ball_type = self.BALL_TYPE
            draw_bracket_value = self.draw_bracket_value
            draw_name = self.draw_name
            draw_team_type = self.draw_team_type
            tournament_name = self.tournament_name
            score = self._build_score(winner_sets, loser_sets, outcome)

            # Winner 1
            winner_1_name = self._last_first(winners[0][0]) if winners else ""
            winner_1_third_party_id = winners[0][1] if winners else ""
            winner_1_country = self.COUNTRY if winner_1_name else ""
            winner_1_gender = self.draw_gender
            winner_1_city = ""; winner_1_state = ""; winner_1_college = ""; winner_1_dob = ""

            # Winner 2
            if len(winners) >= 2:
                winner_2_name = self._last_first(winners[1][0])
                winner_2_third_party_id = winners[1][1]
                winner_2_gender = self.draw_gender
                winner_2_country = self.COUNTRY
            else:
                winner_2_name = ""; winner_2_third_party_id = ""
                winner_2_gender = ""; winner_2_country = ""
            winner_2_city = ""; winner_2_state = ""; winner_2_college = ""; winner_2_dob = ""

            # Loser 1
            loser_1_name = self._last_first(losers[0][0]) if losers else ""
            loser_1_third_party_id = losers[0][1] if losers else ""
            loser_1_country = self.COUNTRY if loser_1_name else ""
            loser_1_gender = self.draw_gender
            loser_1_city = ""; loser_1_state = ""; loser_1_college = ""; loser_1_dob = ""

            # Loser 2
            if len(losers) >= 2:
                loser_2_name = self._last_first(losers[1][0])
                loser_2_third_party_id = losers[1][1]
                loser_2_gender = self.draw_gender
                loser_2_country = self.COUNTRY
            else:
                loser_2_name = ""; loser_2_third_party_id = ""
                loser_2_gender = ""; loser_2_country = ""
            loser_2_city = ""; loser_2_state = ""; loser_2_college = ""; loser_2_dob = ""

            id_type = self.ID_TYPE
            draw_gender = self.draw_gender
            draw_bracket_type = self.draw_bracket_type
            draw_type = self.draw_type
            tournament_city = self.tournament_city
            tournament_state = self.tournament_state
            tournament_country_code = self.tournament_country_code
            tournament_host = self.tournament_host
            tournament_location_type = self.tournament_location_type
            tournament_surface = self.tournament_surface
            tournament_event_category = self.tournament_event_category
            tournament_event_grade = self.tournament_event_grade
            tournament_import_source = self.tournament_import_source
            tournament_sanction_body = self.tournament_sanction_body
            tournament_event_type = self.tournament_event_type
            tournament_url = self.tournament_url
            tournament_country = self.tournament_country
            tournament_start_date = self.tournament_start_date
            tournament_end_date = self.tournament_end_date

            match_data = {
                "match_id": match_id,
                "ball_type": ball_type,
                "draw_bracket_value": draw_bracket_value,
                "draw_name": draw_name,
                "draw_team_type": draw_team_type,
                "tournament_name": tournament_name,
                "date": date,
                "round": round_,
                "score": score,
                "winner_1_name": winner_1_name,
                "winner_1_gender": winner_1_gender,
                "winner_1_third_party_id": winner_1_third_party_id,
                "winner_1_city": winner_1_city,
                "winner_1_country": winner_1_country,
                "winner_1_state": winner_1_state,
                "winner_2_name": winner_2_name,
                "winner_2_gender": winner_2_gender,
                "winner_2_third_party_id": winner_2_third_party_id,
                "winner_2_city": winner_2_city,
                "winner_2_state": winner_2_state,
                "loser_1_name": loser_1_name,
                "loser_1_gender": loser_1_gender,
                "loser_1_third_party_id": loser_1_third_party_id,
                "loser_1_city": loser_1_city,
                "loser_1_state": loser_1_state,
                "loser_1_country": loser_1_country,
                "loser_2_name": loser_2_name,
                "loser_2_gender": loser_2_gender,
                "loser_2_third_party_id": loser_2_third_party_id,
                "loser_2_city": loser_2_city,
                "loser_2_state": loser_2_state,
                "outcome": outcome,
                "id_type": id_type,
                "draw_gender": draw_gender,
                "draw_bracket_type": draw_bracket_type,
                "draw_type": draw_type,
                "tournament_city": tournament_city,
                "tournament_state": tournament_state,
                "tournament_country_code": tournament_country_code,
                "tournament_host": tournament_host,
                "tournament_location_type": tournament_location_type,
                "tournament_surface": tournament_surface,
                "tournament_event_category": tournament_event_category,
                "tournament_event_grade": tournament_event_grade,
                "tournament_import_source": tournament_import_source,
                "tournament_sanction_body": tournament_sanction_body,
                "winner_2_country": winner_2_country,
                "winner_2_college": winner_2_college,
                "loser_2_country": loser_2_country,
                "loser_2_college": loser_2_college,
                "tournament_event_type": tournament_event_type,
                "winner_1_college": winner_1_college,
                "loser_1_college": loser_1_college,
                "tournament_url": tournament_url,
                "winner_1_dob": winner_1_dob,
                "winner_2_dob": winner_2_dob,
                "loser_1_dob": loser_1_dob,
                "loser_2_dob": loser_2_dob,
                "tournament_country": tournament_country,
                "tournament_start_date": tournament_start_date,
                "tournament_end_date": tournament_end_date,
            }

        except Exception:
            logger.error(traceback.format_exc())

        return match_data



if __name__ == "__main__":
    html1 = Selector(text=html_text1)
    parser = Parser('spider_name', html1)

    matchs_data = []
    for d1 in html1.xpath('//div[@class="game"]'):
        match = parser.parse_match(d1)
        matchs_data.append(match)
    logger.info(f'matchs_data: {matchs_data}')
    logger.info(f'matchs_data: {len(matchs_data)}')
