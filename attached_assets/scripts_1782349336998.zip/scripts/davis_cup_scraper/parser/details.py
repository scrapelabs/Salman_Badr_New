import traceback, calendar
from datetime import datetime
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts.log_items import ItemsLogger
from app_spiders.models import JobsItemsDavisCupScraperModel

class DetailsParser:

    def __init__(self, progress):
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=True, use_proxy=self.use_proxy)

        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0',
        }

        self.df_ties = ItemsLogger()

        self.seen_ties_rows = getattr(self, "seen_ties_rows", set())
        self.seen_results_rows = getattr(self, "seen_results_rows", set())
        self.seen_matchs_rows = getattr(self, "seen_matchs_rows", set())


    def parse_ties(self, job_rank_year):
        try:
            index_link = f'https://api.itf-production.sports-data.stadion.io/custom/wcotDrawsModeled/dc/{job_rank_year}'
            logger.info(f'index_link: {index_link}')

            response1 = self.fctrequest.request(method='GET', link=index_link, headers=self.headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    results1 = response1.json()

                    for data in results1.get('data', []):
                        for event in data.get('events', []):
                            for draw in event.get('draws', []):
                                contents = draw.get('content', None)
                                if isinstance(contents, list):
                                    for content in contents:
                                        for tie in content.get('ties', []):
                                            tie_id = tie.get('id', '')
                                            tie_date = self.parse_dates(tie.get('formattedDate', ''))

                                            row_key = f"{tie_id}"
                                            if row_key not in self.seen_ties_rows:
                                                self.df_ties.log({
                                                    "tie_id": tie_id,
                                                    "tie_date": tie_date,
                                                })
                                                self.seen_ties_rows.add(row_key)


                                elif isinstance(contents, dict):
                                    for tie in contents.get('recent', []):

                                        tie_id = tie.get('id', '')
                                        tie_date = self.parse_dates(tie.get('formattedDate', ''))

                                        row_key = f"{tie_id}"
                                        if row_key not in self.seen_ties_rows:
                                            self.df_ties.log({
                                                "tie_id": tie_id,
                                                "tie_date": tie_date,
                                            })
                                            self.seen_ties_rows.add(row_key)

        except Exception:
            logger.error(traceback.format_exc())

        return self.df_ties.get_df()


    def parse_site(self, spider_id, job_id, ties_chunk, main_task, thread_task, progress):
        try:
            for ties_data in ties_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    tie_id = ties_data.get("tie_id", "")
                    tie_date = ties_data.get("tie_date", "")
                    index_link = f'https://api.itf-production.sports-data.stadion.io/custom/tieCentre/{tie_id}'

                    row_key = f"{tie_id}"
                    if row_key not in self.seen_results_rows:
                        logger.info(f'tie_id: {tie_id} | tie_date: {tie_date} | {index_link}')
                        response1 = self.fctrequest.request(method='GET', link=index_link, headers=self.headers, proxies=self.proxies, tries=3)
                        if response1:
                            if response1.status_code in range(200, 300):
                                results1 = response1.json()
                                self.parse_match(spider_id, job_id, tie_id, tie_date, results1)

                        self.seen_results_rows.add(row_key)

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())


    def parse_match(self, spider_id, job_id, tie_id, tie_date, results1):
        try:
            for match in results1.get('data', {}).get('tie', {}).get('matches', []):
                match_id = match.get('id', '')
                # match_id = '90debb55-3cad-4e1d-994f-b4479ac17a35'

                row_key = f"{match_id}"
                if row_key not in self.seen_matchs_rows:
                    logger.info(f'new: match_id: {match_id}')
                    match_score = self.parse_match_score(match)
                    self.parse_profile(spider_id, job_id, tie_id, tie_date, match_id, match_score)
                    self.seen_matchs_rows.add(row_key)

        except Exception:
            logger.error(traceback.format_exc())

    def parse_profile(self, spider_id, job_id, tie_id, tie_date, match_id, match_score):
        try:
            # 'https://www.daviscup.com/en/match/804fa303-c86f-4f77-9012-192f536a9b7e'#double
            # 'https://www.daviscup.com/en/match/7c0adebe-da06-4ed8-b6be-b9fdb193bde0'#single

            index_link = f'https://api.itf-production.sports-data.stadion.io/match/{match_id}?include=sides.sidePlayer.player.person.country.images,sides.sidePlayer.player.person.images,sides.sideSets.set,matchStatus,scoringType,court,round.draw.event.venue.country,round.draw.event.surface,round.draw.event.discipline,round.draw.event.eventCategory.images,round.draw.event.venue.country.images,round.draw.discipline,tie.teams.country,tie.tieStatus,tie.teams.country.images,tie.round.draw.event,tie.round.draw.event.surface,tie.round.draw.event.venue.country.images'
            response1 = self.fctrequest.request(method='GET', link=index_link, headers=self.headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    results1 = response1.json()

                    draw_date = tie_date
                    draw_bracket_type = 'Age'
                    draw_bracket_value = 'Open'
                    draw_gender = 'Male'
                    draw_name = f"Match {results1.get('data', {}).get('orderInRound', '')}" if results1.get('data', {}).get('orderInRound', '') else ''
                    draw_size = ''
                    draw_team_type = ''
                    draw_type = ''

                    id_type = 'DavisCup'
                    loser_1_city = ''
                    loser_1_college = ''
                    loser_1_country = ''
                    loser_1_dob = '' #empty
                    loser_1_gender = ''
                    loser_1_name = ''
                    loser_1_state = ''
                    loser_1_third_party_id = ''
                    loser_2_city = ''
                    loser_2_college = ''
                    loser_2_country = ''
                    loser_2_dob = '' #empty
                    loser_2_gender = ''
                    loser_2_name = ''
                    loser_2_state = ''
                    loser_2_third_party_id = ''
                    outcome = ''
                    score = match_score

                    tournament_city = ''
                    tournament_country = ''
                    tournament_country_code = ''
                    tournament_end_date = ''
                    tournament_host = ''
                    tournament_name = ''
                    tournament_start_date = ''
                    try:
                        tournament_city = results1.get('data', {}).get('round', {}).get('draw', {}).get('event', {}).get('venue', {}).get('city', '').split(',')[0].strip()
                    except Exception:
                        ''
                    try:
                        tournament_country = results1.get('data', {}).get('round', {}).get('draw', {}).get('event', {}).get('venue', {}).get('country', {}).get('name', '')
                    except Exception:
                        ''
                    try:
                        tournament_country_code = results1.get('data', {}).get('round', {}).get('draw', {}).get('event', {}).get('venue', {}).get('country', {}).get('ISOcode', '')
                    except Exception:
                        ''
                    try:
                        tournament_end_date = fctcore.convert_string_to_date_format(results1.get('data', {}).get('round', {}).get('draw', {}).get('event', {}).get('endDate', ''), in_format='%Y-%m-%dT%H:%M:%SZ', out_format='%m/%d/%Y')
                    except Exception:
                        ''
                    tournament_event_category = 'Pro Circuit'
                    tournament_event_grade = ''
                    tournament_event_type = 'Team Match'
                    try:
                        tournament_host = results1.get('data', {}).get('round', {}).get('draw', {}).get('event', {}).get('venue', {}).get('_name', '')
                    except Exception:
                        ''
                    tournament_import_source = ''
                    tournament_location_type = 'Outdoor'
                    try:
                        tournament_name = results1.get('data', {}).get('tie', {}).get('round', {}).get('draw', {}).get('event', {}).get('name', '') + ' - ' + " vs ".join(map(str, [item["country"]["name"] for item in sorted(results1.get('data', {}).get('tie', {}).get('teams', {}), key=lambda x: x["teamOrder"])]))
                    except Exception:
                        ''
                    tournament_sanction_body = 'ITF'
                    try:
                        tournament_start_date = fctcore.convert_string_to_date_format(results1.get('data', {}).get('round', {}).get('draw', {}).get('event', {}).get('startDate', ''), in_format='%Y-%m-%dT%H:%M:%SZ', out_format='%m/%d/%Y')
                    except Exception:
                        ''
                    tournament_state = ''
                    tournament_surface = '' #empty
                    # tournament_url = f'https://www.daviscup.com/en/tie/{tie_id}'#old
                    tournament_url = f'https://www.daviscup.com/en/match/{match_id}'
                    winner_1_city = ''
                    winner_1_college = ''
                    winner_1_country = ''
                    winner_1_dob = '' #empty
                    winner_1_gender = ''
                    winner_1_name = ''
                    winner_1_state = ''
                    winner_1_third_party_id = ''
                    winner_2_city = ''
                    winner_2_college = ''
                    winner_2_country = ''
                    winner_2_dob = '' #empty
                    winner_2_gender = ''
                    winner_2_name = ''
                    winner_2_state = ''
                    winner_2_third_party_id = ''

                    winners, losers = self.find_winner_loser_team_orders(results1)
                    if winners and losers:
                        win_info = [self.extract_player(sp) for sp in winners.get("sidePlayer", [])]
                        lose_info = [self.extract_player(sp) for sp in losers.get("sidePlayer", [])]

                        draw_team_type = 'Doubles' if len(win_info) > 1 else 'Singles'

                        if win_info:
                            winner_1_name = win_info[0]['last_name'].title() + ', '+ win_info[0]['first_name'].title()
                            winner_1_country = win_info[0]['country']
                            winner_1_gender = 'M'
                            winner_1_third_party_id = win_info[0]['third_party_id']

                        if len(win_info) > 1:
                            winner_2_name = win_info[1]['last_name'].title() + ', '+ win_info[1]['first_name'].title()
                            winner_2_country = win_info[1]['country']
                            winner_2_gender = 'M'
                            winner_2_third_party_id = win_info[1]['third_party_id']

                        if lose_info:
                            loser_1_name = lose_info[0]['last_name'].title() + ', '+ lose_info[0]['first_name'].title()
                            loser_1_country = lose_info[0]['country']
                            loser_1_gender = 'M'
                            loser_1_third_party_id = lose_info[0]['third_party_id']

                        if len(lose_info) > 1:
                            loser_2_name = lose_info[1]['last_name'].title() + ', '+ lose_info[1]['first_name'].title()
                            loser_2_country = lose_info[1]['country']
                            loser_2_gender = 'M'
                            loser_2_third_party_id = lose_info[1]['third_party_id']

                        logger.info(f'tie_id: {tie_id}')
                        logger.info(f'match_id: {match_id}')
                        logger.info(f'draw_date: {draw_date}')
                        logger.info(f'draw_bracket_type: {draw_bracket_type}')
                        logger.info(f'draw_bracket_value: {draw_bracket_value}')
                        logger.info(f'draw_gender: {draw_gender}')
                        logger.info(f'draw_name: {draw_name}')
                        logger.info(f'draw_size: {draw_size}')
                        logger.info(f'draw_team_type: {draw_team_type}')
                        logger.info(f'draw_type: {draw_type}')
                        logger.info(f'id_type: {id_type}')
                        logger.info(f'loser_1_city: {loser_1_city}')
                        logger.info(f'loser_1_college: {loser_1_college}')
                        logger.info(f'loser_1_country: {loser_1_country}')
                        logger.info(f'loser_1_dob: {loser_1_dob}')
                        logger.info(f'loser_1_gender: {loser_1_gender}')
                        logger.info(f'loser_1_name: {loser_1_name}')
                        logger.info(f'loser_1_state: {loser_1_state}')
                        logger.info(f'loser_1_third_party_id: {loser_1_third_party_id}')
                        logger.info(f'loser_2_city: {loser_2_city}')
                        logger.info(f'loser_2_college: {loser_2_college}')
                        logger.info(f'loser_2_country: {loser_2_country}')
                        logger.info(f'loser_2_dob: {loser_2_dob}')
                        logger.info(f'loser_2_gender: {loser_2_gender}')
                        logger.info(f'loser_2_name: {loser_2_name}')
                        logger.info(f'loser_2_state: {loser_2_state}')
                        logger.info(f'loser_2_third_party_id: {loser_2_third_party_id}')
                        logger.info(f'outcome: {outcome}')
                        logger.info(f'score: {score}')
                        logger.info(f'tournament_city: {tournament_city}')
                        logger.info(f'tournament_country: {tournament_country}')
                        logger.info(f'tournament_country_code: {tournament_country_code}')
                        logger.info(f'tournament_end_date: {tournament_end_date}')
                        logger.info(f'tournament_event_category: {tournament_event_category}')
                        logger.info(f'tournament_event_grade: {tournament_event_grade}')
                        logger.info(f'tournament_event_type: {tournament_event_type}')
                        logger.info(f'tournament_host: {tournament_host}')
                        logger.info(f'tournament_import_source: {tournament_import_source}')
                        logger.info(f'tournament_location_type: {tournament_location_type}')
                        logger.info(f'tournament_name: {tournament_name}')
                        logger.info(f'tournament_sanction_body: {tournament_sanction_body}')
                        logger.info(f'tournament_start_date: {tournament_start_date}')
                        logger.info(f'tournament_state: {tournament_state}')
                        logger.info(f'tournament_surface: {tournament_surface}')
                        logger.info(f'tournament_url: {tournament_url}')
                        logger.info(f'winner_1_city: {winner_1_city}')
                        logger.info(f'winner_1_college: {winner_1_college}')
                        logger.info(f'winner_1_country: {winner_1_country}')
                        logger.info(f'winner_1_dob: {winner_1_dob}')
                        logger.info(f'winner_1_gender: {winner_1_gender}')
                        logger.info(f'winner_1_name: {winner_1_name}')
                        logger.info(f'winner_1_state: {winner_1_state}')
                        logger.info(f'winner_1_third_party_id: {winner_1_third_party_id}')
                        logger.info(f'winner_2_city: {winner_2_city}')
                        logger.info(f'winner_2_college: {winner_2_college}')
                        logger.info(f'winner_2_country: {winner_2_country}')
                        logger.info(f'winner_2_dob: {winner_2_dob}')
                        logger.info(f'winner_2_gender: {winner_2_gender}')
                        logger.info(f'winner_2_name: {winner_2_name}')
                        logger.info(f'winner_2_state: {winner_2_state}')
                        logger.info(f'winner_2_third_party_id: {winner_2_third_party_id}')
                        logger.info(f'*'*50)

                        JobsItemsDavisCupScraperModel(
                            spider_id=spider_id,
                            job_id=job_id,
                            tie_id=tie_id,
                            match_id=match_id,
                            date=draw_date,
                            draw_bracket_type=draw_bracket_type,
                            draw_bracket_value=draw_bracket_value,
                            draw_gender=draw_gender,
                            draw_name=draw_name,
                            draw_size=draw_size,
                            draw_team_type=draw_team_type,
                            draw_type=draw_type,
                            id_type=id_type,
                            loser_1_city=loser_1_city,
                            loser_1_college=loser_1_college,
                            loser_1_country=loser_1_country,
                            loser_1_dob=loser_1_dob,
                            loser_1_gender=loser_1_gender,
                            loser_1_name=loser_1_name,
                            loser_1_state=loser_1_state,
                            loser_1_third_party_id=loser_1_third_party_id,
                            loser_2_city=loser_2_city,
                            loser_2_college=loser_2_college,
                            loser_2_country=loser_2_country,
                            loser_2_dob=loser_2_dob,
                            loser_2_gender=loser_2_gender,
                            loser_2_name=loser_2_name,
                            loser_2_state=loser_2_state,
                            loser_2_third_party_id=loser_2_third_party_id,
                            outcome=outcome,
                            score=score,
                            tournament_city=tournament_city,
                            tournament_country=tournament_country,
                            tournament_country_code=tournament_country_code,
                            tournament_end_date=tournament_end_date,
                            tournament_event_category=tournament_event_category,
                            tournament_event_grade=tournament_event_grade,
                            tournament_event_type=tournament_event_type,
                            tournament_host=tournament_host,
                            tournament_import_source=tournament_import_source,
                            tournament_location_type=tournament_location_type,
                            tournament_name=tournament_name,
                            tournament_sanction_body=tournament_sanction_body,
                            tournament_start_date=tournament_start_date,
                            tournament_state=tournament_state,
                            tournament_surface=tournament_surface,
                            tournament_url=tournament_url,
                            winner_1_city=winner_1_city,
                            winner_1_college=winner_1_college,
                            winner_1_country=winner_1_country,
                            winner_1_dob=winner_1_dob,
                            winner_1_gender=winner_1_gender,
                            winner_1_name=winner_1_name,
                            winner_1_state=winner_1_state,
                            winner_1_third_party_id=winner_1_third_party_id,
                            winner_2_city=winner_2_city,
                            winner_2_college=winner_2_college,
                            winner_2_country=winner_2_country,
                            winner_2_dob=winner_2_dob,
                            winner_2_gender=winner_2_gender,
                            winner_2_name=winner_2_name,
                            winner_2_state=winner_2_state,
                            winner_2_third_party_id=winner_2_third_party_id,
                        ).save()

        except Exception:
            logger.error(traceback.format_exc())

    def find_winner_loser_team_orders(self, match_data):
        try:
            sides = match_data["data"]["sides"]
            winner_side_id = match_data["data"]["winnerSideId"]

            winner_side = None
            loser_side = None

            for side in sides:
                if side["id"] == winner_side_id:
                    winner_side = side
                else:
                    loser_side = side

            return winner_side, loser_side
        except Exception:
            logger.error(traceback.format_exc())

        return None, None

    def parse_match_score(self, match):
        try:
            winner_id = match.get("winnerSideId")
            if not winner_id:
                return ""

            # Build: { setNumber: { sideId: (games, tb_points_or_None) } }
            sets = {}
            for side in match.get("sides", []):
                sid = side.get("id")
                for ss in (side.get("sideSets") or []):
                    sn = ss.get("setNumber")
                    if sn is None:
                        continue
                    score = ss.get("setScore")
                    if score is None:
                        continue
                    tb = ss.get("setTieBreakScore")
                    sets.setdefault(int(sn), {})[sid] = (int(score), int(tb) if tb is not None else None)

            if not sets:
                return ""

            pieces = []
            for sn in sorted(sets):
                scores = sets[sn]
                if winner_id not in scores or len(scores) < 2:
                    continue  # can't format this set safely

                my_score, my_tb = scores[winner_id]
                # find the other side
                opp_id = next(s for s in scores.keys() if s != winner_id)
                opp_score, opp_tb = scores[opp_id]

                part = f"{my_score}-{opp_score}"

                # Add TB only when a tiebreak was played (typically 7-6 / 6-7),
                # and show the LOSER's TB points in parentheses per tennis convention.
                tb_played = (my_tb or 0) > 0 or (opp_tb or 0) > 0
                if tb_played and ((my_score == 7 and opp_score == 6) or (my_score == 6 and opp_score == 7)):
                    loser_tb = opp_tb if my_score > opp_score else my_tb
                    if loser_tb is not None and loser_tb > 0:
                        part += f"({loser_tb})"

                pieces.append(part)

            return ", ".join(pieces)+';'

        except Exception:
            logger.error(traceback.format_exc())

        return ''


    def extract_player(self, side_player):
        person = side_player['player']['person']
        country = person.get('country') or {}
        return {
            'first_name': person.get('firstName', '').title(),
            'last_name': person.get('lastName', '').title(),
            'country': country.get('name', ''),
            'third_party_id': side_player.get('player', {}).get('personId', '')
        }

    def parse_dates(self, date_str):
        if ' - ' in date_str:
            parts = date_str.split(' - ')
            start_parts = parts[0].strip().split()
            if len(start_parts) == 2:  # cross-month: "31 January - 28 February 2025"
                year = parts[1].strip().split()[-1]
                start_date = datetime.strptime(f"{parts[0].strip()} {year}", "%d %B %Y").strftime("%Y-%m-%d")
                end_date = datetime.strptime(parts[1].strip(), "%d %B %Y").strftime("%Y-%m-%d")
            else:  # same month: "16 - 21 June 2025"
                month_year = parts[1].split(' ', 1)[1]
                start_date = datetime.strptime(f"{parts[0].strip()} {month_year}", "%d %B %Y").strftime("%Y-%m-%d")
                end_date = datetime.strptime(parts[1].strip(), "%d %B %Y").strftime("%Y-%m-%d")

        elif len(date_str.strip().split()) == 4:  # "31 January February 2025"
            parts = date_str.strip().split()
            day, month1, month2, year = parts
            start_date = datetime.strptime(f"{day} {month1} {year}", "%d %B %Y").strftime("%Y-%m-%d")
            # Use last day of end month to avoid invalid dates like 31 February
            end_month_dt = datetime.strptime(f"{month2} {year}", "%B %Y")
            last_day = calendar.monthrange(end_month_dt.year, end_month_dt.month)[1]
            end_date = end_month_dt.replace(day=last_day).strftime("%Y-%m-%d")

        else:  # single date: "13 September 2025"
            start_date = end_date = datetime.strptime(date_str.strip(), "%d %B %Y").strftime("%Y-%m-%d")