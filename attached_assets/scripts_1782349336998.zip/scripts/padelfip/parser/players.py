import traceback
import datetime
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.requests.fctrequest import Request
from scripts.log_items import ItemsLogger

class PlayersParser:

    def __init__(self, max_workers, progress):
        self.per_page = 500
        self.max_workers = max_workers
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=True, use_proxy=self.use_proxy)

        self.df_players = ItemsLogger()
        self.seen_rows = getattr(self, "seen_rows", set())


    def parse_site(self):
        self.parse_players(gender='male')
        self.parse_players(gender='female')
        return self.df_players.get_df()


    def parse_players(self, gender):
        try:
            player_gender = ''
            if gender == 'male':
                player_gender = 'M'
            elif gender == 'female':
                player_gender = 'F'

            page = 0
            while 1:
                close_old_connections()
                logger.info(f'gender: {gender} | page: {page+1}')

                headers = {
                    'accept': '*/*',
                    'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',
                }

                year, week, weekday = datetime.date.today().isocalendar()
                params = {
                    'gender': gender,
                    'category': 'master',
                    'year': year,
                    'week': week,
                    'offset': self.per_page * page,
                    'limit': self.per_page,
                    'country': '',
                }

                index_link = 'https://www.padelfip.com/wp-json/fip/v1/ranking/load-more'
                response1 = self.fctrequest.request(method='GET', link=index_link, params=params, headers=headers, proxies=self.proxies, tries=3)

                results1 = {}
                if response1:
                    if response1.status_code in range(200, 300):
                        try:
                            results1 = response1.json()
                        except Exception:
                            ''

                        if results1:
                            self.parse_page(player_gender, results1)

                if not results1:
                    break

                page += 1

        except Exception:
            logger.error(traceback.format_exc())


    def parse_page(self, player_gender, results1):
        try:
            for result in results1:
                player_name = result.get('name', '')
                player_link = result.get('url', '')

                row_key = f"{player_link}"
                if row_key not in self.seen_rows:
                    logger.info(f'player_name: {player_name} | {player_link}')
                    self.df_players.log({
                        "player_name": player_name,
                        "player_link": player_link,
                        "player_gender": player_gender,
                    })
                    self.seen_rows.add(row_key)

        except Exception:
            logger.error(traceback.format_exc())
