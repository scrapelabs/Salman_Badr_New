import traceback, random, json
from os.path import basename, dirname, abspath
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scrapy.selector import Selector
from openai import OpenAI
from app_spiders.models import JobsItemsPadelfipModel, NamesPadelfipModel

class DetailsParser:

    def __init__(self):
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=True, use_proxy=self.use_proxy)
        self.headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,fr;q=0.8',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0',
        }
        self.api_key = random.choice(settings.API_KEYS)

        self.seen_rows = getattr(self, "seen_rows", set())


    def parse_site(self, spider_id, job_id, players_chunk, main_task, thread_task, progress):
        try:
            for players_data in players_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    player_name = players_data.get("player_name", "")
                    player_link = players_data.get("player_link", "")
                    player_gender = players_data.get("player_gender", "")

                    row_key = f"{player_link}"
                    if row_key not in self.seen_rows:
                        logger.info(f'player_name: {player_name} | {player_link}')
                        response1 = self.fctrequest.request(method='GET', link=player_link, headers=self.headers, proxies=self.proxies, tries=3)
                        if response1:
                            if response1.status_code in range(200, 300):
                                str1 = response1.text
                                html1 = Selector(text=str1)
                                self.parse_page(spider_id, job_id, player_link, player_gender, html1)

                        self.seen_rows.add(row_key)

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())


    def parse_page(self, spider_id, job_id, player_link, player_gender, html1):
        try:
            full_name = ''
            first_name = ''
            last_name = ''
            player_name = ''
            player_rank = ''
            player_dob = ''
            player_country = ''
            player_fip = ''
            player_points = ''
            publish_date = ''

            full_name = fctcore.parse_field('//h2[contains(@class, "player__name")]', html1)
            player_name, first_name, last_name = self.convert_name(full_name)
            player_rank = fctcore.parse_field('//span[contains(@class, "player__number")]/text()', html1)
            try:
                player_dob = fctcore.convert_string_to_date_format(
                    date_str=fctcore.parse_field('//div[@class="section__additionalInfo"]//div[@class="additionalInfo__birth"]//span[@class="additionalInfo__data"]', html1),
                    in_format='%d/%m/%Y', out_format='%m/%d/%Y'
                )
            except Exception:
                ''
            player_country = fctcore.parse_field('//p[contains(@class, "player__country")]', html1)
            try:
                player_fip = fctcore.preg_repace(patt="/$", repl="", subj=player_link).split('/')[-1].strip()
            except Exception:
                ''
            player_points = fctcore.parse_field('//span[contains(@class, "player__pointTNumber")]', html1)
            try:
                publish_date = fctcore.convert_string_to_date_format(
                    date_str=fctcore.parse_field('//div[contains(@class, "topRanking__update")]', html1),
                    in_format='%d/%m/%Y',
                    out_format='%m/%d/%Y'
                )
            except Exception:
                ''

            logger.info(f'player_link: {player_link}')
            logger.info(f'first_name: {first_name}')
            logger.info(f'last_name: {last_name}')
            logger.info(f'player_name: {player_name}')
            logger.info(f'player_rank: {player_rank}')
            logger.info(f'player_dob: {player_dob}')
            logger.info(f'player_country: {player_country}')
            logger.info(f'player_fip: {player_fip}')
            logger.info(f'player_gender: {player_gender}')
            logger.info(f'player_points: {player_points}')
            logger.info(f'publish_date: {publish_date}')
            logger.info('*' * 50)

            JobsItemsPadelfipModel(
                spider_id=spider_id,
                job_id=job_id,
                player_link=player_link,
                full_name=full_name,
                first_name=first_name,
                last_name=last_name,
                player_name=player_name,
                player_rank=player_rank,
                player_dob=player_dob,
                player_country=player_country,
                player_fip=player_fip,
                player_gender=player_gender,
                player_points=player_points,
                publish_date=publish_date,
            ).save()

        except Exception:
            logger.error(traceback.format_exc())


    def convert_name(self, input_name):
        full_name = ''
        first_name = ''
        last_name = ''
        try:
            namesObj = NamesPadelfipModel.objects.filter(full_name__iexact=input_name)
            if not namesObj.exists():
                logger.info(f'new: convert_name input_name: {input_name}')
                first_name, last_name = self.convert_name_gpt(input_name, self.api_key)
                first_name = first_name.title()
                last_name = last_name.title()
                full_name = f'{last_name}, {first_name}'

                logger.info(f'final | convert_name | input_name: {input_name} | full_name: {full_name} | first_name: {first_name} | last_name: {last_name}')
                spider_name = basename(dirname(dirname(abspath(__file__))))
                NamesPadelfipModel(spider_name=spider_name, input_name=input_name, full_name=full_name, first_name=first_name, last_name=last_name).save()

            else:
                first_name = namesObj.first().first_name
                last_name = namesObj.first().last_name
                full_name = f'{last_name}, {first_name}'
                logger.warning(f'exist from db | convert_name | input_name: {input_name} | full_name: {full_name} | first_name: {first_name} | last_name: {last_name}')

        except Exception:
            logger.error(traceback.format_exc())
        return full_name, first_name, last_name


    def convert_name_gpt(self, input_name, api_key):
        first_name = ''
        last_name = ''
        try:
            prompt = 'given this player name : "' + str(input_name) + '" return a concise response that must be in JSON format. The JSON object you return must have two keys first_name and last_name.'
            results_ai = self.ai_parse_string(model=settings.AI_MODEL, api_key=api_key, prompt=prompt, input_string=input_name)
            try:
                first_name = results_ai['first_name'].title()
            except Exception:
                ''
            try:
                last_name = results_ai['last_name'].upper()
            except Exception:
                ''
            logger.info(f'convert_name_gpt | name: {input_name} | results_ai: {results_ai} | first_name: {first_name} | last_name: {last_name}')
        except Exception:
            ''
        return first_name, last_name


    def ai_parse_string(self, model: str="gpt-4o-mini", api_key: str=None, prompt: str=None, input_string: str=None) -> dict:
        results = {}
        try:
            if input_string:
                client = OpenAI(
                    api_key=api_key,
                )

                completion = client.chat.completions.create(
                    model=model,
                    messages=[
                        {
                            "role": "user",
                            "content": prompt,
                        },
                    ],
                )

                results = completion.choices[0].message.content
                results = json.loads(results.replace("```", "").replace("json", "").strip())

        except Exception:
            logger.error(traceback.format_exc())

        return results

