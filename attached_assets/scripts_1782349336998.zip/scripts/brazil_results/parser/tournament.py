import traceback
import concurrent.futures
from django.db import close_old_connections
from django.conf import settings
from urllib.parse import urljoin
from scrapy.selector import Selector
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts.log_items import ItemsLogger


class TournamentParser:

    def __init__(self, spider_name, max_workers, progress):
        self.spider_name = spider_name
        self.progress = progress
        self.max_workers = max_workers
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=True, use_cffi=False, use_proxy=self.use_proxy)
        self.df_tournaments = ItemsLogger()

        self.headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0',
        }


    def parse_tournaments(self, job_rank_year, job_month):
        try:
            data = {
                'busca': '',
                'ano': job_rank_year,
                'id_pais': '0',
                'id_uf': '0',
                'id_tab': '2',
                'id_depto': '2',
                'mes': '1',
            }

            response1 = self.session_post_with_retry('https://www.tenisintegrado.com.br/new_torneio/index2', data)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    options_list = []
                    for d1 in html1.xpath('//ul[contains(@class,"nav-tabs")]//li[a[contains(text(), "Juvenil")]]/ancestor::ul[contains(@class,"nav-tabs")]//li[not(@class="disabled")]/a'):
                        pre_link = fctcore.parse_field('./@href', d1)
                        if pre_link:
                            options_list.append(urljoin('https://www.tenisintegrado.com.br/', pre_link))

                    logger.info(f'options_list: {len(options_list)} | {options_list}')

                    options_chunks = list(fctcore.split_list_into_chunks(lst=options_list, max_workers=self.max_workers))
                    if self.max_workers > len(options_chunks): self.max_workers = len(options_chunks)
                    logger.info(f'max_workers: {self.max_workers}')

                    with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                        main_task = self.progress.add_task(description=f'{self.spider_name}_tournaments', total=len(options_list))
                        for thread_id, options_chunk in enumerate(options_chunks):
                            thread_task = self.progress.add_task(f"Thread {thread_id + 1}", total=len(options_chunk))
                            executor.submit(self.parse_tournament, job_month, options_chunk, main_task, thread_task)

        except Exception:
            logger.error(traceback.format_exc())

        return self.df_tournaments.get_df()


    def parse_tournament(self, job_month, options_chunk, main_task, thread_task):
        try:
            for options_link in options_chunk:
                self.progress.update(main_task, advance=1)
                self.progress.update(thread_task, advance=1)
                close_old_connections()

                logger.info(f'options_link: {options_link}')
                self.parse_month(job_month, options_link)

        except Exception:
            logger.error(traceback.format_exc())



    def parse_month(self, job_month, options_link):
        try:
            response1 = self.session_get_with_retry(options_link)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    month_urls_list = []
                    for d1 in html1.xpath('//ul[contains(@class,"nav-tabs")]//li[a[contains(., "Fev")]]/ancestor::ul[contains(@class,"nav-tabs")]//li[not(@class="disabled")]/a[not(@class="dropdown-toggle")]'):
                        pre_link = fctcore.parse_field('./@href', d1)
                        if pre_link:
                            if job_month == 0:
                                month_urls_list.append(urljoin('https://www.tenisintegrado.com.br/', pre_link))
                            else:
                                if pre_link.endswith(f'/{job_month}'):
                                    month_urls_list.append(urljoin('https://www.tenisintegrado.com.br/', pre_link))

                    logger.info(f'month_urls_list: {len(month_urls_list)} | {month_urls_list}')

                    if month_urls_list:
                        for month_url in month_urls_list:
                            logger.info(f'month_url: {month_url}')
                            self.parse_page(month_url)
                            logger.info('*'*50)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_page(self, month_url):
        try:
            response1 = self.session_get_with_retry(month_url)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    for d1 in html1.xpath('//table[@id="tournaments"]//tr[not(th)]/td[5]/a[@class="td-link"]'):
                        tournament_url = fctcore.parse_field('./@href', d1)
                        logger.info(f'tournament_url: {tournament_url}')

                        if tournament_url:
                            self.df_tournaments.log({
                                "tournament_url": tournament_url,
                            })

        except Exception:
            logger.error(traceback.format_exc())


    def session_get_with_retry(self, url, tries=5):
        for attempt in range(1, tries + 1):
            try:
                response = self.fctrequest.session.get(
                    url,
                    headers=self.headers,
                    proxies=self.fctrequest.generate_proxy(self.proxies)
                )
                if response and response.status_code in range(200, 300):
                    return response
                logger.warning(f'Attempt {attempt}/{tries} failed with status {response.status_code if response else "None"} for {url}')
            except Exception:
                logger.warning(f'Attempt {attempt}/{tries} raised exception for {url}:\n{traceback.format_exc()}')
        logger.error(f'All {tries} attempts failed for {url}')
        return None


    def session_post_with_retry(self, url, data, tries=5):
        for attempt in range(1, tries + 1):
            try:
                response = self.fctrequest.session.post(
                    url,
                    headers=self.headers,
                    files={k: (None, v) for k, v in data.items()},
                    proxies=self.fctrequest.generate_proxy(self.proxies)
                )
                if response and response.status_code in range(200, 300):
                    return response
                logger.warning(f'Attempt {attempt}/{tries} failed with status {response.status_code if response else "None"} for {url}')
            except Exception:
                logger.warning(f'Attempt {attempt}/{tries} raised exception for {url}:\n{traceback.format_exc()}')
        logger.error(f'All {tries} attempts failed for {url}')
        return None