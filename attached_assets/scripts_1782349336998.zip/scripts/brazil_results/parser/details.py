import traceback, random, re
from scrapy.selector import Selector
from datetime import datetime
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from scripts import helper
from assets.requests.fctrequest import Request
from app_spiders.models import JobsItemsBrazilResultsModel, PlayersBrazilResultsModel


class DetailsParser:

    def __init__(self, spider_name, spider_id, job_id, main_task, thread_task, progress):
        self.spider_name = spider_name
        self.spider_id = spider_id
        self.job_id = job_id
        self.main_task = main_task
        self.thread_task = thread_task
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = False
        self.fctrequest = Request(use_session=True, use_cffi=True, use_proxy=self.use_proxy)


    def parse_site(self, tournaments_chunk):
        try:
            for tournaments_data in tournaments_chunk:
                self.progress.update(self.main_task, advance=1)
                self.progress.update(self.thread_task, advance=1)
                close_old_connections()

                tournament_url = tournaments_data['tournament_url']
                logger.info(f'tournament_url: {tournament_url}')

                try:
                    headers = {
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                        'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                        'upgrade-insecure-requests': '1',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0',
                    }

                    response1 = self.fctrequest.request(method='GET', link=tournament_url, headers=headers, proxies=self.proxies, tries=3)
                    if response1:
                        if response1.status_code in range(200, 300):
                            self.parse_chaves(tournament_url)

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())


    def parse_chaves(self, tournament_url):
        try:
            # The bare GET /torneio_painel_jogo returns whatever
            # tournament the cffi session last touched, which means
            # iterating multiple tournaments silently re-scrapes the
            # same one. Always fetch the bracket page with an explicit
            # /index/{tournament_id} so the response is deterministic.
            m = re.search(r"/index/(\d+)", tournament_url or "")
            tournament_id = m.group(1) if m else ""
            panel_url = (
                f"https://www.tenisintegrado.com.br/torneio_painel_jogo/index/{tournament_id}"
                if tournament_id
                else "https://www.tenisintegrado.com.br/torneio_painel_jogo"
            )

            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'priority': 'u=0, i',
                'referer': tournament_url or 'https://www.tenisintegrado.com.br/',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=panel_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)
                    cats_found = len(html1.xpath('//select[@id="id_categoria"]/option/@value').extract())
                    logger.info(f'parse_chaves: {panel_url} -> {cats_found} categories')
                    self.parse_category(tournament_url, html1)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_category(self, tournament_url, html1):
        try:
            id_categorias = html1.xpath('//select[@id="id_categoria"]/option/@value').extract()
            id_parametros = html1.xpath('//select[@id="id_parametro"]/option/@value').extract()
            id_periodo = fctcore.parse_field('//select[@id="id_periodo"]/option[@selected="selected"]/@value', html1)
            nr_rodada = fctcore.parse_field('//select[@id="round-selector"]/option[1]/@value', html1)
            id_torneio = fctcore.parse_field('//input[@name="id_torneio"]/@value', html1)
            id_categoria_ant = fctcore.parse_field('//input[@name="id_categoria_ant"]/@value', html1)

            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0',
            }

            for id_categoria in id_categorias:
                for id_parametro in id_parametros:
                    data = {
                        'id_categoria': id_categoria,
                        'id_parametro': id_parametro,
                        'id_periodo': id_periodo,
                        'nr_rodada': nr_rodada,
                        'id_torneio': id_torneio,
                        'id_categoria_ant': id_categoria_ant,
                    }

                    if not nr_rodada: del data['nr_rodada']
                    if not id_categoria_ant: del data['id_categoria_ant']

                    response1 = self.fctrequest.request(method='POST', link='https://www.tenisintegrado.com.br/torneio_painel_jogo', data=data, headers=headers, proxies=self.proxies, tries=3)
                    # fctcore.open_html_in_browser(f'<body style="background: red; padding: 5%; margin-left: 14%;">first | tournament_url: {tournament_url} | data: {data}</body>{response1.text}')
                    if response1:
                        if response1.status_code in range(200, 300):
                            html1 = Selector(text=response1.text)
                            nr_rodadas = html1.xpath('//select[@id="round-selector"]/option/@value').extract()
                            id_periodo = fctcore.parse_field('//select[@id="id_periodo"]/option[@selected="selected"]/@value', html1)
                            nr_rodada = fctcore.parse_field('//select[@id="round-selector"]/option[1]/@value', html1)
                            id_torneio = fctcore.parse_field('//input[@name="id_torneio"]/@value', html1)
                            id_categoria_ant = fctcore.parse_field('//input[@name="id_categoria_ant"]/@value', html1)

                            if nr_rodadas:
                                for nr_rodada in nr_rodadas:
                                    data = {
                                        'id_categoria': id_categoria,
                                        'id_parametro': id_parametro,
                                        'id_periodo': id_periodo,
                                        'nr_rodada': nr_rodada,
                                        'id_torneio': id_torneio,
                                        'id_categoria_ant': id_categoria_ant,
                                    }

                                    if not nr_rodada: del data['nr_rodada']
                                    if not id_categoria_ant: del data['id_categoria_ant']

                                    response1 = self.fctrequest.request(method='POST', link='https://www.tenisintegrado.com.br/torneio_painel_jogo', data=data, headers=headers, proxies=self.proxies, tries=3)
                                    # fctcore.open_html_in_browser(f'<body style="background: red; padding: 5%; margin-left: 14%;">second | tournament_url: {tournament_url}<br><br>data: {data}</body>{response1.text}')
                                    if response1:
                                        if response1.status_code in range(200, 300):
                                            html1 = Selector(text=response1.text)
                                            self.parse_games(html1)

                            else:
                                self.parse_games(html1)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_games(self, html1):
        try:
            parser = Parser(self.spider_name, html1)

            for d1 in html1.xpath('//div[@class="game"]'):
                try:
                    match_data = parser.parse_match(d1)
                    logger.info(f'match_data: {match_data}')

                    if match_data:
                        match_id = match_data.get("match_id", "")
                        ball_type = match_data.get("ball_type", "")
                        draw_bracket_value = match_data.get("draw_bracket_value", "")
                        draw_name = match_data.get("draw_name", "")
                        draw_team_type = match_data.get("draw_team_type", "")
                        tournament_name = match_data.get("tournament_name", "")
                        date = match_data.get("date", "")
                        round_ = match_data.get("round", "")
                        score = match_data.get("score", "")
                        winner_1_name = match_data.get("winner_1_name", "")
                        winner_1_gender = match_data.get("winner_1_gender", "")
                        winner_1_third_party_id = match_data.get("winner_1_third_party_id", "")
                        winner_1_city = match_data.get("winner_1_city", "")
                        winner_1_country = match_data.get("winner_1_country", "")
                        winner_1_state = match_data.get("winner_1_state", "")
                        winner_2_name = match_data.get("winner_2_name", "")
                        winner_2_gender = match_data.get("winner_2_gender", "")
                        winner_2_third_party_id = match_data.get("winner_2_third_party_id", "")
                        winner_2_city = match_data.get("winner_2_city", "")
                        winner_2_state = match_data.get("winner_2_state", "")
                        loser_1_name = match_data.get("loser_1_name", "")
                        loser_1_gender = match_data.get("loser_1_gender", "")
                        loser_1_third_party_id = match_data.get("loser_1_third_party_id", "")
                        loser_1_city = match_data.get("loser_1_city", "")
                        loser_1_state = match_data.get("loser_1_state", "")
                        loser_1_country = match_data.get("loser_1_country", "")
                        loser_2_name = match_data.get("loser_2_name", "")
                        loser_2_gender = match_data.get("loser_2_gender", "")
                        loser_2_third_party_id = match_data.get("loser_2_third_party_id", "")
                        loser_2_city = match_data.get("loser_2_city", "")
                        loser_2_state = match_data.get("loser_2_state", "")
                        outcome = match_data.get("outcome", "")
                        id_type = match_data.get("id_type", "")
                        draw_gender = match_data.get("draw_gender", "")
                        draw_bracket_type = match_data.get("draw_bracket_type", "")
                        draw_type = match_data.get("draw_type", "")
                        tournament_city = match_data.get("tournament_city", "")
                        tournament_state = match_data.get("tournament_state", "")
                        tournament_country_code = match_data.get("tournament_country_code", "")
                        tournament_host = match_data.get("tournament_host", "")
                        tournament_location_type = match_data.get("tournament_location_type", "")
                        tournament_surface = match_data.get("tournament_surface", "")
                        tournament_event_category = match_data.get("tournament_event_category", "")
                        tournament_event_grade = match_data.get("tournament_event_grade", "")
                        tournament_import_source = match_data.get("tournament_import_source", "")
                        tournament_sanction_body = match_data.get("tournament_sanction_body", "")
                        winner_2_country = match_data.get("winner_2_country", "")
                        winner_2_college = match_data.get("winner_2_college", "")
                        loser_2_country = match_data.get("loser_2_country", "")
                        loser_2_college = match_data.get("loser_2_college", "")
                        tournament_event_type = match_data.get("tournament_event_type", "")
                        winner_1_college = match_data.get("winner_1_college", "")
                        loser_1_college = match_data.get("loser_1_college", "")
                        tournament_url = match_data.get("tournament_url", "")
                        winner_1_dob = match_data.get("winner_1_dob", "")
                        winner_2_dob = match_data.get("winner_2_dob", "")
                        loser_1_dob = match_data.get("loser_1_dob", "")
                        loser_2_dob = match_data.get("loser_2_dob", "")
                        tournament_country = match_data.get("tournament_country", "")
                        tournament_start_date = match_data.get("tournament_start_date", "")
                        tournament_end_date = match_data.get("tournament_end_date", "")

                        if not JobsItemsBrazilResultsModel.objects.filter(spider_id=self.spider_id, job_id=self.job_id,
                                                                          winner_1_name=winner_1_name,
                                                                          loser_1_name=loser_1_name,
                                                                          winner_2_name=winner_2_name,
                                                                          loser_2_name=loser_2_name, score=score,
                                                                          match_id=match_id).exists():
                            logger.info(f'match_id: {match_id}')
                            logger.info(f'draw_name: {draw_name}')
                            logger.info(f'draw_team_type: {draw_team_type}')
                            logger.info(f'tournament_name: {tournament_name}')
                            logger.info(f'date: {date}')
                            logger.info(f'round: {round_}')
                            logger.info(f'score: {score}')
                            logger.info(f'winner_1_name: {winner_1_name}')
                            logger.info(f'winner_1_gender: {winner_1_gender}')
                            logger.info(f'winner_1_third_party_id: {winner_1_third_party_id}')
                            logger.info(f'winner_1_dob: {winner_1_dob}')
                            logger.info(f'winner_2_name: {winner_2_name}')
                            logger.info(f'winner_2_gender: {winner_2_gender}')
                            logger.info(f'winner_2_third_party_id: {winner_2_third_party_id}')
                            logger.info(f'winner_2_dob: {winner_2_dob}')
                            logger.info(f'loser_1_name: {loser_1_name}')
                            logger.info(f'loser_1_gender: {loser_1_gender}')
                            logger.info(f'loser_1_third_party_id: {loser_1_third_party_id}')
                            logger.info(f'loser_1_dob: {loser_1_dob}')
                            logger.info(f'loser_2_name: {loser_2_name}')
                            logger.info(f'loser_2_gender: {loser_2_gender}')
                            logger.info(f'loser_2_third_party_id: {loser_2_third_party_id}')
                            logger.info(f'loser_2_dob: {loser_2_dob}')
                            logger.info(f'outcome: {outcome}')
                            logger.info(f'draw_gender: {draw_gender}')
                            logger.info(f'tournament_city: {tournament_city}')
                            logger.info(f'tournament_country_code: {tournament_country_code}')
                            logger.info(f'tournament_url: {tournament_url}')
                            logger.info(f'tournament_country: {tournament_country}')
                            logger.info(f'tournament_start_date: {tournament_start_date}')
                            logger.info(f'tournament_end_date: {tournament_end_date}')
                            logger.info('*' * 50)

                            JobsItemsBrazilResultsModel(
                                spider_id=self.spider_id,
                                job_id=self.job_id,
                                match_id=match_id,
                                ball_type=ball_type,
                                id_type=id_type,
                                draw_bracket_value=draw_bracket_value,
                                draw_name=draw_name,
                                draw_team_type=draw_team_type,
                                tournament_name=tournament_name,
                                date=date,
                                round=round_,
                                score=score,
                                winner_1_name=winner_1_name,
                                winner_1_gender=winner_1_gender,
                                winner_1_dob=winner_1_dob,
                                winner_1_third_party_id=winner_1_third_party_id,
                                winner_1_city=winner_1_city,
                                winner_1_state=winner_1_state,
                                winner_1_country=winner_1_country,
                                winner_2_name=winner_2_name,
                                winner_2_gender=winner_2_gender,
                                winner_2_dob=winner_2_dob,
                                winner_2_third_party_id=winner_2_third_party_id,
                                winner_2_city=winner_2_city,
                                winner_2_state=winner_2_state,
                                winner_2_country=winner_2_country,
                                loser_1_name=loser_1_name,
                                loser_1_gender=loser_1_gender,
                                loser_1_dob=loser_1_dob,
                                loser_1_third_party_id=loser_1_third_party_id,
                                loser_1_city=loser_1_city,
                                loser_1_state=loser_1_state,
                                loser_1_country=loser_1_country,
                                loser_2_name=loser_2_name,
                                loser_2_gender=loser_2_gender,
                                loser_2_dob=loser_2_dob,
                                loser_2_third_party_id=loser_2_third_party_id,
                                loser_2_city=loser_2_city,
                                loser_2_state=loser_2_state,
                                loser_2_country=loser_2_country,
                                outcome=outcome,
                                draw_gender=draw_gender,
                                draw_bracket_type=draw_bracket_type,
                                draw_type=draw_type,
                                tournament_city=tournament_city,
                                tournament_state=tournament_state,
                                tournament_country_code=tournament_country_code,
                                tournament_host=tournament_host,
                                tournament_location_type=tournament_location_type,
                                tournament_surface=tournament_surface,
                                tournament_event_category=tournament_event_category,
                                tournament_event_grade=tournament_event_grade,
                                tournament_import_source=tournament_import_source,
                                tournament_sanction_body=tournament_sanction_body,
                                winner_2_college=winner_2_college,
                                loser_2_college=loser_2_college,
                                tournament_event_type=tournament_event_type,
                                winner_1_college=winner_1_college,
                                loser_1_college=loser_1_college,
                                tournament_url=tournament_url,
                                tournament_country=tournament_country,
                                tournament_start_date=tournament_start_date,
                                tournament_end_date=tournament_end_date,
                            ).save()

                except Exception:
                    logger.error(traceback.format_exc())
        except Exception:
            logger.error(traceback.format_exc())


class Parser:
    # ---------- Static spec values --------------------------------------
    BALL_TYPE = "Yellow"
    COUNTRY = "Brasil"
    COUNTRY_CODE = "BRA"
    ID_TYPE = "Brasil"
    IMPORT_SOURCE = "CBT"
    SANCTION_BODY = "CBT"
    EVENT_TYPE = "Tournament"

    # game-top header — two real layouts observed in the wild:
    #   (a) "5º Jogo - 2º Rodada - 29/01/2026 11:00"
    #   (b) "1º Rodada - "              (no Jogo prefix, no date)
    _RE_GAME_TOP = re.compile(
        r"^\s*\d+\s*º?\s*Jogo\s*-\s*(?P<round>[^-]+?)\s*-\s*"
        r"(?P<date>\d{2}/\d{2}/\d{4})(?:\s+\d{1,2}:\d{2})?\s*$",
        re.IGNORECASE,
    )
    # Short header: round label only, no Jogo prefix, no date.
    _RE_GAME_TOP_SHORT = re.compile(
        r"^\s*(?P<round>\d+\s*º?\s*Rodada|Final|Semi[-\s]?final|"
        r"Quartas?(?:\s+de\s+final)?|Oitavas?(?:\s+de\s+final)?|"
        r"16[ªa]s?|32[ªa]s?|64[ªa]s?|Repescagem|Quali(?:fica[çc][ãa]o)?)"
        r"\s*-?\s*$",
        re.IGNORECASE,
    )
    _RE_DATE_IN_HEADER = re.compile(r"(\d{2}/\d{2}/\d{4})")
    _RE_BYE = re.compile(r"^\s*BYE\s*$", re.IGNORECASE)

    # Any of these tokens introduces the winner's name in the bottom strip.
    # We intentionally keep the regex loose: the winner phrase is just
    # "<token> <name>" and may be followed by " - <tail>" or end of line.
    _WINNER_TOKEN = r"(?:vencedor(?:\(a\)|a)?|ganhador(?:\(a\)|a)?|camp[eê]ao|champion)"
    _RE_WINNER_LINE = re.compile(
        rf"{_WINNER_TOKEN}\s*[:\-]\s*(?P<name>[^\n\r]+?)(?:\s+-\s+(?P<tail>[^\n\r]+))?\s*$",
        re.IGNORECASE | re.MULTILINE,
    )
    # Fallback: a standalone "Vencedor" token immediately before a name link.
    _RE_WINNER_TOKEN_ONLY = re.compile(rf"\b{_WINNER_TOKEN}\b", re.IGNORECASE)

    # Outcome detection: look at full block text.
    _RE_WO = re.compile(r"\b(w\.?o\.?|walkover)\b", re.IGNORECASE)
    _RE_RETIRED = re.compile(
        r"\b(des(?:ist[eê]ncia|istiu)?|abandono|retirou|retirado|ret\.?)\b",
        re.IGNORECASE,
    )

    _RE_PROFILE_ID = re.compile(r"perfil2/index/(\d+)")
    _RE_MATCH_ID = re.compile(r"\((\d+)\)")
    _RE_PERIOD = re.compile(r"(\d{2}/\d{2}/\d{4})\s*a\s*(\d{2}/\d{2}/\d{4})")
    _RE_TRAILING_PAREN = re.compile(r"\s*\([^)]*\)\s*$")

    # ---------- Init -----------------------------------------------------
    def __init__(self, spider_name, selector):
        self.spider_name = spider_name
        self._extract_tournament(selector)
        self._extract_draw(selector)

    # ================================================================
    # Helpers
    # ================================================================
    @staticmethod
    def _clean(text: str) -> str:
        if not text:
            return ""
        return re.sub(r"\s+", " ", text).strip()

    @classmethod
    def _join_text(cls, sel) -> str:
        return cls._clean(" ".join(sel.xpath(".//text()").getall()))

    @classmethod
    def _format_date(cls, d: str) -> str:
        d = cls._clean(d)
        if not d:
            return ""
        try:
            dt = datetime.strptime(d, "%d/%m/%Y")
        except ValueError:
            return d
        return dt.strftime("%m/%d/%Y")

    @classmethod
    def _strip_markers(cls, name: str) -> str:
        return cls._RE_TRAILING_PAREN.sub("", cls._clean(name)).strip()

    @classmethod
    def _name_tokens(cls, name):
        """Lower-cased alphanumeric tokens from a name, accent-folded.

        Handles "Last, First", "First Last", trailing rank markers
        ("12\u00ba"), and a wide variety of punctuation.
        """
        if not name:
            return set()
        s = cls._strip_markers(name)
        try:
            import unicodedata
            s = unicodedata.normalize("NFKD", s)
            s = "".join(ch for ch in s if not unicodedata.combining(ch))
        except Exception:
            pass
        s = s.lower()
        toks = re.findall(r"[a-z0-9]+", s)
        # Drop trivial fragments and rank-marker leftovers.
        return {t for t in toks if len(t) >= 2 and not t.isdigit()}

    @classmethod
    def _names_match(cls, target_tokens, candidate_name) -> bool:
        """True if candidate_name plausibly refers to the same person
        as the target. We require either a subset relationship or at
        least two shared name tokens (covers "Last, First" vs
        "First Last", accent differences, and trailing rank markers).
        """
        if not target_tokens:
            return False
        cand = cls._name_tokens(candidate_name)
        if not cand:
            return False
        if target_tokens.issubset(cand) or cand.issubset(target_tokens):
            return True
        return len(target_tokens & cand) >= 2

    @classmethod
    def _last_first(cls, full_name: str) -> str:
        name = cls._strip_markers(full_name)
        if not name:
            return ""
        parts = name.split()
        if len(parts) == 1:
            return parts[0].rstrip(",").strip()
        return f"{parts[-1]}, {' '.join(parts[:-1])}".rstrip(",").strip()

    @classmethod
    def _profile_id_from_href(cls, href: str) -> str:
        if not href:
            return ""
        m = cls._RE_PROFILE_ID.search(href)
        return m.group(1) if m else ""

    @staticmethod
    def _set_to_pair(set_text):
        """'6-3' -> (6,3); '7-6(5)' -> (7,6); returns (None,None) on junk."""
        if not set_text:
            return (None, None)
        m = re.match(r"\s*(\d{1,2})\s*[-x×]\s*(\d{1,2})", set_text)
        if not m:
            return (None, None)
        return (int(m.group(1)), int(m.group(2)))

    # ================================================================
    # Tournament-level extraction
    # ================================================================
    def _extract_tournament(self, selector) -> None:
        title_sel = selector.xpath(".//div[@class='tournament-title']")
        self.tournament_name = self._join_text(title_sel) if title_sel else ""

        local_parts = selector.xpath(".//div[@class='tournament-local']/descendant-or-self::text()").getall()
        local_text = self._clean(" ".join(local_parts))
        self.tournament_city = local_text.split("-", 1)[0].strip() if "-" in local_text else local_text

        self.tournament_start_date = ""
        self.tournament_end_date = ""
        for info_text in selector.xpath(".//div[@class='tournament-period']//div[@class='info']/text()").getall():
            m = self._RE_PERIOD.match(self._clean(info_text))
            if m:
                self.tournament_start_date = self._format_date(m.group(1))
                self.tournament_end_date = self._format_date(m.group(2))
                break

        share_url = selector.xpath(".//div[@class='tournament-share']//input[@class='form-control']/@value").get()
        if share_url:
            self.tournament_url = share_url.strip()
        else:
            id_torneio = selector.xpath(".//input[@name='id_torneio']/@value").get()
            if id_torneio:
                self.tournament_url = (
                    "https://www.tenisintegrado.com.br/torneio_painel_info/index/"
                    f"{id_torneio.strip()}"
                )
            else:
                self.tournament_url = ""

        self.tournament_state = ""
        self.tournament_country = self.COUNTRY
        self.tournament_country_code = self.COUNTRY_CODE
        self.tournament_host = ""
        self.tournament_location_type = ""
        self.tournament_surface = ""
        self.tournament_event_category = ""
        self.tournament_event_grade = ""
        self.tournament_event_type = self.EVENT_TYPE
        self.tournament_import_source = self.IMPORT_SOURCE
        self.tournament_sanction_body = self.SANCTION_BODY

    # ================================================================
    # Draw extraction
    # ================================================================
    def _extract_draw(self, selector) -> None:
        name = ""
        for txt in selector.xpath(".//h4/text() | .//h3/text() | .//h2/text()").getall():
            txt = self._clean(txt)
            if "Simples" in txt or "Duplas" in txt:
                name = txt
                break
        if not name:
            opt = selector.xpath(".//select[@id='id_categoria']//option[@selected]/text()").get()
            if opt:
                name = self._clean(opt)

        self.draw_name = name
        low = name.lower()
        self.draw_gender = "Male" if "masculino" in low else ("Female" if "feminino" in low else "")
        self.draw_team_type = "Doubles" if "duplas" in low else ("Singles" if "simples" in low else "")
        self.draw_bracket_value = ""
        self.draw_bracket_type = ""
        self.draw_type = ""

    def _players_in_row(self, li_sel):
        players = []
        for ac in li_sel.xpath('./div[@class="avatar-container"]'):
            player_name = self._join_text(ac.xpath('./span[@class="avatar-info"]/a'))

            if not player_name:
                player_name = self._join_text(ac.xpath("./a"))

            if not player_name:
                player_name = self._join_text(ac)

            if self._RE_BYE.match(player_name or ""):
                players.append(("__BYE__", ""))
                continue

            player_link = ac.xpath(".//span[contains(@class,'avatar-info')]/a/@href").get()
            third_party_id = self._profile_id_from_href(player_link)

            logger.info(f'player_name: {player_name}')
            logger.info(f'player_link: {player_link}')
            logger.info(f'third_party_id: {third_party_id}')

            if not third_party_id and player_name:
                third_party_id = helper.sha256_id(player_name)

            logger.info(f'third_party_id sha256_id: {third_party_id}')
            logger.info('*'*50)

            if third_party_id:
                objs = PlayersBrazilResultsModel.objects.filter(
                    spider_name=self.spider_name, third_party_id=third_party_id
                )
                if objs.exists():
                    player_name = objs.first().player_name
                else:
                    try:
                        claude_key = random.choice(settings.CLAUDE_KEYS)
                        player_name, _gender = helper.format_name_gender_claude(player_name, claude_key)
                    except Exception:
                        logger.error(traceback.format_exc())
                    PlayersBrazilResultsModel(
                        spider_name=self.spider_name,
                        third_party_id=third_party_id,
                        player_name=player_name,
                    ).save()

            logger.info(f'player_name: {player_name}')

            if player_name:
                players.append((player_name, third_party_id))

            logger.info(f'players: {players}')

        return players


    def _row_score(self, li_sel):
        score_sel = li_sel.xpath(".//div[@class='score pull-right']")
        if not score_sel:
            return []
        if score_sel.xpath(".//div[@class='wo text-danger']") or self._RE_WO.search(self._join_text(score_sel)):
            return ["W.O."]
        sets = [self._join_text(s) for s in score_sel.xpath(".//div[@class='set']")]
        return [s for s in sets if s]

    @staticmethod
    def _row_has_winner_marker(li_sel) -> bool:
        """True if this <li> looks like the winner row by CSS / icon."""
        cls = (li_sel.attrib.get("class") or "").lower()
        if any(tok in cls for tok in ("winner", "vencedor", "is-winner", "champ")):
            return True
        # any descendant icon that screams 'win'
        icon_classes = " ".join(li_sel.xpath(".//@class").getall()).lower()
        if any(tok in icon_classes for tok in ("fa-trophy", "fa-check", "win-icon", "vencedor")):
            return True
        return False

    @staticmethod
    def _build_score(winner_sets, loser_sets, outcome: str) -> str:
        if outcome == "Walkover":
            return "W.O.;"
        pairs = []
        for i in range(max(len(winner_sets), len(loser_sets))):
            w = winner_sets[i] if i < len(winner_sets) else ""
            l = loser_sets[i] if i < len(loser_sets) else ""
            if (not w and not l) or "W.O." in (w, l):
                continue
            pairs.append(f"{w}-{l}")
        score = ", ".join(pairs)
        if outcome == "retired" and score:
            score += " ret."
        return f"{score};" if score else ";"

    @classmethod
    def _outcome_from_block(cls, block_text: str) -> str:
        if cls._RE_WO.search(block_text):
            return "Walkover"
        if cls._RE_RETIRED.search(block_text):
            return "retired"
        return "Completed"

    # ================================================================
    # Winner-detection strategies
    # ================================================================
    def _winner_name_from_text(self, block_text: str):
        """Strategy A: explicit winner phrase anywhere in the block."""
        m = self._RE_WINNER_LINE.search(block_text)
        if m:
            return self._strip_markers(m.group("name"))
        return None

    def _winner_row_index_from_markup(self, rows) -> int | None:
        """Strategy B: a row carries an explicit CSS / icon marker."""
        marked = [i for i, r in enumerate(rows) if self._row_has_winner_marker(r)]
        if len(marked) == 1:
            return marked[0]
        return None

    @staticmethod
    def _set_games(cell):
        """Return the integer games count for one set cell.

        The live site renders one ``<div class="set">`` per player per
        set, containing just the games count (e.g. ``"6"``). Older or
        alternate layouts use a ``"X-Y"`` pair. Accept both, plus an
        optional tie-break suffix like ``"7(5)"``.
        """
        if cell is None:
            return None
        s = str(cell).strip()
        if not s:
            return None
        m = re.match(r"\s*(\d{1,2})\s*[-x\u00d7]\s*\d{1,2}", s)
        if m:
            return int(m.group(1))
        m = re.match(r"\s*(\d{1,2})", s)
        if m:
            return int(m.group(1))
        return None

    def _winner_row_index_from_score(self, row_a_sets, row_b_sets):
        """Strategy C: whoever won more sets is the winner.

        Compares games per set column-by-column. Works whether each
        cell is a plain integer (``"6"``) or a winner-loser pair
        (``"6-2"``).
        """
        a_wins = b_wins = 0
        for i in range(max(len(row_a_sets), len(row_b_sets))):
            a = row_a_sets[i] if i < len(row_a_sets) else ""
            b = row_b_sets[i] if i < len(row_b_sets) else ""
            ai = self._set_games(a)
            bi = self._set_games(b)
            if ai is None or bi is None:
                continue
            if ai > bi:
                a_wins += 1
            elif bi > ai:
                b_wins += 1
        if a_wins == b_wins:
            return None
        return 0 if a_wins > b_wins else 1

    # ================================================================
    # Parse one match
    # ================================================================
    def parse_match(self, game_sel):
        match_data = {}
        try:
            # ---- header (match_id, round, date) -----------------------------
            spans = game_sel.xpath('./div[@class="game-top"]/span')
            header_text = self._clean(self._join_text(spans[0])) if spans else ""
            match_id = ""
            if len(spans) >= 2:
                m = self._RE_MATCH_ID.search(self._join_text(spans[1]))
                if m:
                    match_id = m.group(1)

            round_ = ""
            date = ""
            m = self._RE_GAME_TOP.match(header_text)
            if m:
                round_ = self._clean(m.group("round"))
                date = self._format_date(m.group("date"))
            else:
                # Short header layout — round only, no date.
                m2 = self._RE_GAME_TOP_SHORT.match(header_text)
                if m2:
                    round_ = self._clean(m2.group("round"))
                # opportunistic date scan anywhere in the header text
                dm = self._RE_DATE_IN_HEADER.search(header_text)
                if dm:
                    date = self._format_date(dm.group(1))
            # Final fallback: use the tournament start date when the block
            # header doesn't include a per-match date.
            if not date and getattr(self, "tournament_start_date", ""):
                date = self.tournament_start_date

            # ---- rows -------------------------------------------------------
            rows = game_sel.xpath('./ul[@class="list-group"]/li[@class="list-group-item"]')
            if len(rows) < 2:
                logger.info('len(rows) < 2')
                return None

            row_a_players = self._players_in_row(rows[0])
            row_b_players = self._players_in_row(rows[1])
            logger.info(f'row_a_players: {row_a_players}')
            logger.info(f'row_b_players: {row_b_players}')

            row_a_sets = self._row_score(rows[0])
            row_b_sets = self._row_score(rows[1])
            logger.info(f'row_a_sets: {row_a_sets}')
            logger.info(f'row_b_sets: {row_b_sets}')
            logger.info('*'*50)

            if not row_a_players or not row_b_players:
                logger.info('not row_a_players or not row_b_players')
                return None

            # Skip BYE blocks: if either side is BYE, this isn't a real match.
            if any(p[0] == "__BYE__" for p in row_a_players) or any(p[0] == "__BYE__" for p in row_b_players):
                logger.info('any(p[0] == "__BYE__" for p in row_a_players) or any(p[0] == "__BYE__" for p in row_b_players)')
                return None

            # ---- full block text (for winner + outcome) ---------------------
            block_text = self._join_text(game_sel.xpath(".//div[@class='game-bottom']")) or self._join_text(game_sel)
            outcome = self._outcome_from_block(block_text)

            # ---- find the winner with progressive fallback ------------------
            winner_idx = None
            strategy = None

            # A) text-based winner phrase
            winner_name_raw = self._winner_name_from_text(block_text)
            if winner_name_raw:
                target_tokens = self._name_tokens(winner_name_raw)
                for idx, players in enumerate((row_a_players, row_b_players)):
                    if any(self._names_match(target_tokens, p[0]) for p in players):
                        winner_idx = idx
                        strategy = "text"
                        break

            # B) CSS marker on a row
            if winner_idx is None:
                wi = self._winner_row_index_from_markup(rows)
                if wi is not None:
                    winner_idx = wi
                    strategy = "markup"

            # C) score comparison
            if winner_idx is None:
                wi = self._winner_row_index_from_score(row_a_sets, row_b_sets)
                if wi is not None:
                    winner_idx = wi
                    strategy = "score"

            # D) walkover / retired clearly indicated but no name match:
            #    if outcome != Completed and exactly one row has scores, the row
            #    *with* scores is the survivor.
            if winner_idx is None and outcome != "Completed":
                if row_a_sets and not row_b_sets:
                    winner_idx, strategy = 0, "outcome-only-scored"
                elif row_b_sets and not row_a_sets:
                    winner_idx, strategy = 1, "outcome-only-scored"

            if winner_idx is None:
                logger.info('winner_idx is None')
                return None

            if winner_idx == 0:
                winners, losers = row_a_players, row_b_players
                winner_sets, loser_sets = row_a_sets, row_b_sets
            else:
                winners, losers = row_b_players, row_a_players
                winner_sets, loser_sets = row_b_sets, row_a_sets

            logger.debug(f"[parser] match {match_id or '----'} winner via {strategy}")

            # ---- field assembly ---------------------------------------------
            ball_type = self.BALL_TYPE
            draw_bracket_value = self.draw_bracket_value
            draw_name = self.draw_name
            draw_team_type = self.draw_team_type
            tournament_name = self.tournament_name
            score = self._build_score(winner_sets, loser_sets, outcome)

            # Winner 1
            winner_1_name = self._last_first(winners[0][0]) if winners else ""
            winner_1_third_party_id = winners[0][1] if winners else ""
            winner_1_country = self.COUNTRY if winner_1_name else ""
            winner_1_gender = self.expand_gender(self.draw_gender)
            winner_1_city = ""; winner_1_state = ""; winner_1_college = ""; winner_1_dob = ""

            # Winner 2
            if len(winners) >= 2:
                winner_2_name = self._last_first(winners[1][0])
                winner_2_third_party_id = winners[1][1]
                winner_2_gender = self.expand_gender(self.draw_gender)
                winner_2_country = self.COUNTRY
            else:
                winner_2_name = ""; winner_2_third_party_id = ""
                winner_2_gender = ""; winner_2_country = ""
            winner_2_city = ""; winner_2_state = ""; winner_2_college = ""; winner_2_dob = ""

            # Loser 1
            loser_1_name = self._last_first(losers[0][0]) if losers else ""
            loser_1_third_party_id = losers[0][1] if losers else ""
            loser_1_country = self.COUNTRY if loser_1_name else ""
            loser_1_gender = self.expand_gender(self.draw_gender)
            loser_1_city = ""; loser_1_state = ""; loser_1_college = ""; loser_1_dob = ""

            # Loser 2
            if len(losers) >= 2:
                loser_2_name = self._last_first(losers[1][0])
                loser_2_third_party_id = losers[1][1]
                loser_2_gender = self.expand_gender(self.draw_gender)
                loser_2_country = self.COUNTRY
            else:
                loser_2_name = ""; loser_2_third_party_id = ""
                loser_2_gender = ""; loser_2_country = ""
            loser_2_city = ""; loser_2_state = ""; loser_2_college = ""; loser_2_dob = ""

            id_type = self.ID_TYPE
            draw_gender = self.draw_gender
            draw_bracket_type = self.draw_bracket_type
            draw_type = self.draw_type
            tournament_city = self.tournament_city
            tournament_state = self.tournament_state
            tournament_country_code = self.tournament_country_code
            tournament_host = self.tournament_host
            tournament_location_type = self.tournament_location_type
            tournament_surface = self.tournament_surface
            tournament_event_category = self.tournament_event_category
            tournament_event_grade = self.tournament_event_grade
            tournament_import_source = self.tournament_import_source
            tournament_sanction_body = self.tournament_sanction_body
            tournament_event_type = self.tournament_event_type
            tournament_url = self.tournament_url
            tournament_country = self.tournament_country
            tournament_start_date = self.tournament_start_date
            tournament_end_date = self.tournament_end_date

            match_data = {
                "match_id": match_id,
                "ball_type": ball_type,
                "draw_bracket_value": draw_bracket_value,
                "draw_name": draw_name,
                "draw_team_type": draw_team_type,
                "tournament_name": tournament_name,
                "date": date,
                "round": round_,
                "score": score,
                "winner_1_name": winner_1_name,
                "winner_1_gender": winner_1_gender,
                "winner_1_third_party_id": winner_1_third_party_id,
                "winner_1_city": winner_1_city,
                "winner_1_country": winner_1_country,
                "winner_1_state": winner_1_state,
                "winner_2_name": winner_2_name,
                "winner_2_gender": winner_2_gender,
                "winner_2_third_party_id": winner_2_third_party_id,
                "winner_2_city": winner_2_city,
                "winner_2_state": winner_2_state,
                "loser_1_name": loser_1_name,
                "loser_1_gender": loser_1_gender,
                "loser_1_third_party_id": loser_1_third_party_id,
                "loser_1_city": loser_1_city,
                "loser_1_state": loser_1_state,
                "loser_1_country": loser_1_country,
                "loser_2_name": loser_2_name,
                "loser_2_gender": loser_2_gender,
                "loser_2_third_party_id": loser_2_third_party_id,
                "loser_2_city": loser_2_city,
                "loser_2_state": loser_2_state,
                "outcome": outcome,
                "id_type": id_type,
                "draw_gender": draw_gender,
                "draw_bracket_type": draw_bracket_type,
                "draw_type": draw_type,
                "tournament_city": tournament_city,
                "tournament_state": tournament_state,
                "tournament_country_code": tournament_country_code,
                "tournament_host": tournament_host,
                "tournament_location_type": tournament_location_type,
                "tournament_surface": tournament_surface,
                "tournament_event_category": tournament_event_category,
                "tournament_event_grade": tournament_event_grade,
                "tournament_import_source": tournament_import_source,
                "tournament_sanction_body": tournament_sanction_body,
                "winner_2_country": winner_2_country,
                "winner_2_college": winner_2_college,
                "loser_2_country": loser_2_country,
                "loser_2_college": loser_2_college,
                "tournament_event_type": tournament_event_type,
                "winner_1_college": winner_1_college,
                "loser_1_college": loser_1_college,
                "tournament_url": tournament_url,
                "winner_1_dob": winner_1_dob,
                "winner_2_dob": winner_2_dob,
                "loser_1_dob": loser_1_dob,
                "loser_2_dob": loser_2_dob,
                "tournament_country": tournament_country,
                "tournament_start_date": tournament_start_date,
                "tournament_end_date": tournament_end_date,
            }

        except Exception:
            logger.error(traceback.format_exc())

        return match_data


    def expand_gender(self, gender_code):
        """
        Expand short gender code from XML player attributes to long form.
        F -> Female, M -> Male
        (DrawGender is already in long form in the feed, so this is only
         used for Winner1Gender, Winner2Gender, Loser1Gender, Loser2Gender)
        """
        if gender_code == 'F':
            return 'Female'
        elif gender_code == 'M':
            return 'Male'
        return ''

