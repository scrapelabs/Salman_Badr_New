html_text1 = '''
<body style="background: red; padding: 5%; margin-left: 14%;">second | tournament_url: https://www.tenisintegrado.com.br/torneio_painel_info/index/22039<br><br>data: {'id_categoria': '5', 'id_parametro': '217452', 'id_periodo': '22911', 'nr_rodada': '3', 'id_torneio': '22039', 'id_categoria_ant': '5'}</body><!DOCTYPE html>
<!--[if lte IE 9]>
<html class="lte-ie9" lang="pt-BR">
<![endif]-->
<!--[if gt IE 9]><!-->
<html class="gt-ie8 gt-ie9 not-ie" lang="pt-BR">
<!--<![endif]-->

<head>
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta name="robots" content="Index">
	<meta name="keywords" content="tênis, tennis, esporte, torneios, rankings, pickleball">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
	<meta name="globalsign-domain-verification" content="l4IdKDY0nbYWOlL-MKu-ZCZsTX4qhsgFq_0jV4kfaD" />
	<meta name="google-site-verification" content="KbjUe4hXYXOobh6ZmleQC7B2hwjVp2nAz4bB9E9PM6g" />
			<title>Sistema Tênis Integrado</title>
<base href="https://www.tenisintegrado.com.br/"> 		<link href="images/favicon.ico" rel="icon" type="image/x-icon">
	</base>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,400,600,700,300&subset=latin,latin-ext" rel="stylesheet" type="text/css">
	<link href="./bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
			<link href="./styles/all.min.css" rel="stylesheet">
		<script src="https://www.google.com/recaptcha/api.js?hl=pt-BR" async defer></script>
</head>
<!--[if lte IE 9]>
<body>
	<div class="lte-ie9-warning">
		<h1>Já é hora de atualizar seu navegador!</h1>
		<p>Você está usando uma versão do Internet Explorer desatualizada. O Sistema Tênis Integrado, assim como muitos websites não dão mais suporte a versões do Internet Explorer inferiores à versão 9. Infelizmente você não conseguirá visualizar nosso sistema até atualizar o seu navegador.</p>
		<p>Como alternativa sugerimos também o uso de navegadores gratuitos como o <a href="https://www.mozilla.org/pt-BR/firefox/new/">Firefox</a> ou o <a href="https://www.google.com.br/chrome/">Chrome</a>.</p>
	</div>
</body>
<![endif]-->
<!--[if gt IE 9]><!-->

<body class="theme-default main-menu-animated">
	<script>
		var init = [];
	</script>
	<div id="main-wrapper">

		<!-- Open Header -->
		<script>
	(function(i, s, o, g, r, a, m) {
		i['GoogleAnalyticsObject'] = r;
		i[r] = i[r] || function() {
			(i[r].q = i[r].q || []).push(arguments)
		}, i[r].l = 1 * new Date();
		a = s.createElement(o),
			m = s.getElementsByTagName(o)[0];
		a.async = 1;
		a.src = g;
		m.parentNode.insertBefore(a, m)
	})(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

	ga('create', 'UA-57559881-1', 'auto');
	ga('send', 'pageview');
</script>




<input type="hidden" value="pt-br" id="language_setter">

<div id="main-navbar" class="navbar" role="navigation">


	<!-- Main menu toggle -->
	<button type="button" id="main-menu-toggle"><i class="navbar-icon fa fa-bars icon"></i><span class="hide-menu-text">Fechar Menu</span></button>

	<div class="navbar-inner">
		<!-- Main navbar header -->
		<div class="navbar-header">

			<!-- Logo -->
			<a href="perfil2/index/19822" class="navbar-brand">
				<div><img style="width: 140px; object-fit: contain;" src="images/logo-tenisintegrado.png"></div>
			</a>
			<!-- Main navbar toggle -->
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main-navbar-collapse"><i class="navbar-icon fa fa-bars"></i></button>

		</div> <!-- / .navbar-header -->

		<div id="main-navbar-collapse" class="collapse navbar-collapse main-navbar-collapse">
			<div>

				<div style="padding: 14px;float: left;color: red;font-weight: 600;">
					<spam class="text-success text-bold">BRASIL </spam>
				</div>

				<div class="right clearfix">
					<ul class="nav navbar-nav pull-right right-navbar-nav">

						<!-- QJT-TODO: Busca Temporariamente desabilitada aqui pois ainda não está implementada.
							<li>
								<form action="" class="navbar-form pull-left">
									<div class="input-group">
										<input type="text" placeholder="Buscar..." class="form-control">
										<button class="input-group-addon" type="Submit"><i class="fa fa-search"></i></button>
									</div>
								</form>
							</li>
							-->

						<!--
							NOTE: .nav-icon-btn triggers a dropdown menu on desktop screens only. On small screens .nav-icon-btn acts like a hyperlink.

							Classes:
							* 'nav-icon-btn-info'
							* 'nav-icon-btn-success'
							* 'nav-icon-btn-warning'
							* 'nav-icon-btn-danger' 
							-->

						
							<!-- início - Deslogado -->
							<li class="nav-icon-sign-in nav-icon-btn nav-icon-btn-danger dropdown">
								<a href="https://www.tenisintegrado.com.br/login" class="dropdown-toggle" data-toggle="dropdown">
									<i class="nav-icon fa fa-sign-in"></i>
									<span class="small-screen-text">Entre AQUI</span>
								</a>
							</li>
															<li class="nav-icon-register nav-icon-btn nav-icon-btn-danger dropdown">
									<a href="https://www.tenisintegrado.com.br/integresse" class="dropdown-toggle" data-toggle="dropdown">
										<i class="nav-icon fa fa-pencil-square-o"></i>
										<span class="small-screen-text">Cadastre-se</span>
									</a>
								</li>
														<p class="navbar-text">
								Olá, <a href="https://www.tenisintegrado.com.br/login" class="navbar-link">entre aqui</a>
																	ou <a href="https://www.tenisintegrado.com.br/integresse" class="navbar-link">cadastre-se</a>.
															</p>
							<!-- Fim - Deslogado -->
						

					</ul> <!-- / .navbar-nav -->
				</div> <!-- / .right -->
			</div>
		</div> <!-- / #main-navbar-collapse -->
		<!--<div id="navbar-bottom">
				<ul class="nav navbar-nav navbar-filters">
					<li><a href="#">Todos</a></li>
					<li><a href="#">Galerias</a></li>
					<li><a href="#">Vídeos</a></li>
					<li><a href="#">Amigos</a></li>
				</ul>
			</div>-->
	</div> <!-- / .navbar-inner -->
</div> <!-- / #main-navbar -->

<!-- SUPORTE FRESHDESK -->

	<script>
		window.fwSettings = {
			'widget_id': 13000000094		};
		! function() {
			if ("function" != typeof window.FreshworksWidget) {
				var n = function() {
					n.q.push(arguments)
				};
				n.q = [], window.FreshworksWidget = n
			}
		}()
	</script>
	<script type='text/javascript' src='https://widget.freshworks.com/widgets/13000000094.js' async defer></script>
		<!-- End Header -->

		<!-- Open Main Menu -->
			<div id="main-menu" role="navigation">
		<div id="main-menu-inner">
			<ul class="navigation">

				<li >
					<a href="home"><i class="menu-icon fa fa-home"></i><span class="mm-text">Início</span></a>
				</li>

				<li>
										<a href="https://cbt-tenis.com.br"><i class="menu-icon fa fa-globe"></i><span class="mm-text">Confederação</span></a>
				</li>

				<li >
					<a href="new_torneio"><i class="menu-icon fa fa-trophy"></i><span class="mm-text">Torneios</span></a>
				</li>

				<li >
					<a href="new_ranking"><i class="menu-icon fa fa-list-ol"></i><span class="mm-text">Rankings</span></a>
				</li>

				<li >
					<a href="eventos"><i class="menu-icon fa fa-trophy"></i><span class="mm-text">Cursos/Eventos</span></a>
				</li>

									<li >
						<a href="https://cbt-tenis.com.br/federation"><i class="menu-icon fa fa-bank"></i><span class="mm-text">Federações</span></a>
					</li>
				
									<li>
						<a href="https://cbt-tenis.com.br/rating/wtn/wtn-rating"><i class="menu-icon fa fa-sort-alpha-desc"></i><span class="mm-text">World Tennis Number</span></a>
					</li>
									<li >
						<a href="politica_privacidade_publico"><i class="menu-icon fa fa-users"></i><span class="mm-text">Política de Privacidade</span></a>
					</li>
					
			</ul> <!-- / .navigation -->
		</div> <!-- / #main-menu-inner -->
		<div class="main-menu-inner-bottom">
			<ul class="owners">
				<li class="owner-item">
					<label>Sistema:</label>
					<img src="./images/qjt.png" alt="">
				</li>
			</ul>
			<ul class="owners">
				<li class="owner-item">
					<div style="margin-top:3px;">
						<span class="text-bold">EMPRESA</span>
					</div>
					<div>
						INFO ESPORTES LTDA
					</div>

					<div style="margin-top:3px;">
						<span class="text-bold">CNPJ</span>
					</div>
					<div>
						07.804.000/0001-93
					</div>


					<div style="margin-top:3px;">
						<span class="text-bold">ENDERECO</span>
					</div>
					<div>
						<span>Av. Mostardeiro, 777 Sala 1401</span>
					</div>
					<div>
						<span>Rio Branco - Porto Alegre - RS - Brasil</span>
					</div>
					<div style="margin-top:3px;">
						<span class="text-bold">FUSO HORÁRIO</span>
					</div>
					<div>
						<span>17/05/2026 10:48:01</span>
					</div>

				</li>
			</ul>
		</div>

	</div> <!-- / #main-menu -->
	<!-- /4. $MAIN_MENU -->		<!-- End Main Menu -->

		<div id="content-wrapper">

			<!-- Open alert redirect new system -->
			
			<!-- End alert redirect new system -->
						
						
		<ul class="breadcrumb">
			<li><a href="home">Início</a></li>	
		
		<li> <a href="https://www.tenisintegrado.com.br/torneio_painel_jogo">Circuito Rota do Sol - Sururu Bowl Open - 4ª Etapa Maceió/Jogos</a></li>		
		</ul>
		
	
			<!-- Open Content here -->
					<div class="panel no-border">

			<!-- Open Tournament Header -->
								<div class="tournament-header">
				<div class="wrap row">
					<div class="col1-3 col-sm-12 col-md-4">
						<div class="tournament-title"><a href="#"><a href="https://www.tenisintegrado.com.br/torneio">Circuito Rota do Sol - Sururu Bowl Open - 4ª Etapa Maceió</a></div>
						<div class="tournament-local">Maceio-AL</div>
						<div class="avatar-container">
							<a href="perfil2/index/22798">
								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id22798/fotos/avatar.jpg" alt="" class="avatar">
							</a>
							<span class="avatar-info">
								Criado por <a href="perfil2/index/22798" class="avatar-name">CBT</a>
							</span>
						</div>

													<div class="tournament-share">
								<button type="button" data-toggle="popover" data-placement="bottom" class="btn btn-xs"><i class="fa fa-share-alt"></i>&nbsp;Compartilhar URL desta página</button>
								<div class="popover-header hide">Copie a URL abaixo e compartilhe</div>
								<div class="popover-content hide">
									<input type="text" class="form-control" value="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039">
								</div>
							</div>
						
					</div>
					<div class="col2-3 col-sm-12 col-md-4">
						<div class="tournament-period">
							<div class="info-label">Período Previsto</div>
							<div class="info">20/01/2026 a 23/01/2026</div>
							<div class="info-label">Cancelamentos até</div>
							<div class="info">06/01/2026</div>

							
						</div>
					</div>
					<div class="col3-3 col-sm-12 col-md-4">
						<div class="insc-period">
							<span class="label label-info">Finalizado</span>
							<div class="insc-dates">(01/12/2025 a 05/01/2026)</div>
						</div>
						<div class="tournement-entries pull-right">
							<div class="entries">231</div>
							<div>Inscrições</div>
							<div>10:48:01</div>
													</div>
					</div>
				</div>
			</div>
					<!-- End Tournament Header -->

			<div class="panel-body">

				<!-- Tournament Mainbanner -->
				

				<!-- End Tournament Mainbanner -->

				<!-- Open Tournament Folders -->
				<ul class="nav nav-tabs nav-tabs-xs bs-tabdrop">
	<li >
		<a href="torneio_painel_info">Informações</a>
	</li>

			<li >
			<a href="torneio_painel_insc">Inscrições</a>
		</li>
	
					<li >
				<a href="torneio_painel_prog">Programação</a>
			</li>
					<li >
				<a href="torneio_painel_classif/index">Classificação</a>
			</li>
					<li  class="active">
				<a href="torneio_painel_jogo">Chaves</a>
			</li>
				<li >
			<a href="torneio_painel_regul">Regulamento</a>
		</li>

			<!-- FIM de edição por parte do perfil do usuário que possui permissão -->

</ul>
				<!-- End Tournament Folders -->

				
					<form action="https://www.tenisintegrado.com.br/torneio_painel_jogo" method="post" accept-charset="utf-8" name="frm-maintenance" id="frm-maintenance" onsubmit="" enctype="multipart/form-data">

						<div class="panel-group" id="filters-accordion" style="margin-top:20px;">
							<div class="panel">
								<div class="panel-heading">
									<a class="accordion-toggle loader-container" data-toggle="collapse" data-parent="#filters-accordion" href="#collapseOne">Selecionar Categoria:</a>
								</div> <!-- / .panel-heading -->
								<div id="collapseOne" class="panel-collapse collapse in">
									<div class="panel-body">
										<div class="row filters">
											<div class="col-sm-12">
												<div class="filter-controls">
													<div class="form-group">
														<label class="control-label">Categoria:</label>
														<select id="id_categoria" name="id_categoria" class="form-ajax-select form-control input-sm heading-form-el " data-ajax-call="https://www.tenisintegrado.com.br/torneio_painel_jogo/getGruposJogos" data-ajax-target="id_parametro">
																																<option value="5" selected="selected">12 Anos Masculino Simples</option>
																																<option value="6" >14 Anos Masculino Simples</option>
																																<option value="7" >16 Anos Masculino Simples</option>
																																<option value="8" >18 Anos Masculino Simples</option>
																																<option value="9" >12 Anos Feminino Simples</option>
																																<option value="10" >14 Anos Feminino Simples</option>
																																<option value="11" >16 Anos Feminino Simples</option>
																																<option value="12" >18 Anos Feminino Simples</option>
																																<option value="229" >12 Anos Masculino Duplas</option>
																																<option value="17" >14 Anos Masculino Duplas</option>
																																<option value="18" >16 Anos Masculino Duplas</option>
																																<option value="19" >18 Anos Masculino Duplas</option>
																																<option value="21" >12 Anos Feminino Duplas</option>
																																<option value="225" >14 Anos Feminino Duplas</option>
																																<option value="226" >16 Anos Feminino Duplas</option>
																																<option value="13" >10 Anos Masculino Simples</option>
																													</select>
													</div>

													
														<div class="form-group">
															<label class="control-label">Fase/Grupo:</label>
															<select id="id_parametro" name="id_parametro" class="form-control input-sm heading-form-el">

																																	<option value="217452" selected="selected">#1-Chave principal</option>
																
															</select>
														</div>

													
													
														<div class="form-group">
															<label class="control-label">Períodos de Jogos:</label>
															<select id="id_periodo" name="id_periodo" class="form-control input-sm heading-form-el">
																																		<option value="22911" selected="selected">20/01/2026 - 23/01/2026</option>
																															</select>
														</div>

													
													<div class="form-group no-label">
														<button class="btn btn-submit btn-sm btn-info btn-outline" data-action="https://www.tenisintegrado.com.br/torneio_painel_jogo" data-form="frm-maintenance"><span class="fa fa-refresh"></span>&nbsp;&nbsp;Atualizar</button>
													</div>
												</div>
											</div>
										</div>
									</div> <!-- / .panel-body -->
								</div> <!-- / .collapse -->
							</div> <!-- / .panel -->
						</div>

						
						<h4>12 Anos Masculino Simples</h4>

						
							<div style="margin-top:20px;">
								<div class="row">
									<div class="col-sm-12">
										<div class="pull-right">

											<!--				
										<button class="btn btn-labeled btn-primary btn-submit" type="submit" formtarget="_blank" data-form="frm-maintenance" data-action="torneio_painel_jogo/printerHtml"><span class="btn-label icon fa fa-print"></span>Visualizar Chave</button>
										-->
											<button class="btn btn-labeled btn-primary btn-submit" type="submit" formtarget="_blank" data-form="frm-maintenance"  data-action="https://www.tenisintegrado.com.br/torneio_painel_jogo/printer"><span class="btn-label icon fa fa-file-pdf-o"></span>Chave PDF</button>

											
										</div>
									</div>
								</div>
							</div>

						
						<hr class="top-line">

						
							<div class="panel-heading games-heading">

								
																	<div class="heading-select form-group">
										<select id="round-selector" name="nr_rodada" class="form-control input-sm heading-form-el">
																								<option value="3" selected>1º Rodada</option>
																								<option value="4" >2º Rodada</option>
																								<option value="5" >Oitavas</option>
																								<option value="6" >Quartas</option>
																								<option value="7" >Semi</option>
																					</select>
									</div>
								
																	<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-xs btn-outline pull-right"><span class="btn-label">Fase seguinte&nbsp;&nbsp;</span><span class="fa fa-chevron-right"></span></a>
								
							</div>

							<!--
						Incluir atualização da classe abaixo para final e duplas
						class="row double"
					-->

							<div class="games">

								
								<div class="row ">

									<div class="col-sm-12">
										<div class="wrapper-2-rounds">

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352926)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/387961">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id387961/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/387961">
																									Bernardo Soares																								</a>
																								<sup>8º</sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352927)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/487941">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id487941/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/487941">
																										Felipe Aratangy																									</a>
																									<sup></sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>2º Jogo - 2º Rodada - 20/01/2026 08:00</span>
																		<span>(2352958)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/387961">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id387961/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/387961">
																									Bernardo Soares 																								</a>
																								<sup>8º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/487941">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id487941/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/487941">
																									Felipe Aratangy 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Bernardo Soares - 2 X 0</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352928)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/511239">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id511239/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/511239">
																									Matheus Paes Manso																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352929)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/420389">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id420389/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/420389">
																										Tobias Azevedo																									</a>
																									<sup>108º</sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>3º Jogo - 2º Rodada - 20/01/2026 08:00</span>
																		<span>(2352959)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/511239">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id511239/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/511239">
																									Matheus Paes Manso 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/420389">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id420389/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/420389">
																									Tobias Azevedo 																								</a>
																								<sup>108º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									1
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									2
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Matheus Paes Manso - 2 X 0</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352930)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/409160">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id409160/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/409160">
																									Henri Fernandes																								</a>
																								<sup>73º</sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352931)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/508024">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id508024/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/508024">
																										Matheus Farias																									</a>
																									<sup></sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>4º Jogo - 2º Rodada - 20/01/2026 09:00</span>
																		<span>(2352960)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/409160">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id409160/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/409160">
																									Henri Fernandes 																								</a>
																								<sup>73º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									7
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									2
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									11
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/508024">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id508024/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/508024">
																									Matheus Farias 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									9
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Henri Fernandes - 2 X 1</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352932)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/442894">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id442894/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/442894">
																									Davi Nascimento																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352933)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/441522">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id441522/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/441522">
																										Lucas Leschinski																									</a>
																									<sup>54º</sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>5º Jogo - 2º Rodada - 20/01/2026 11:30</span>
																		<span>(2352961)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/442894">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id442894/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/442894">
																									Davi Nascimento 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/441522">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id441522/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/441522">
																									Lucas Leschinski 																								</a>
																								<sup>54º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Lucas Leschinski - 2 X 0</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352934)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/423177">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id423177/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/423177">
																									Theo Grimaldi																								</a>
																								<sup>25º</sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352935)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/489137">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id489137/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/489137">
																										Theo Cortese																									</a>
																									<sup></sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>6º Jogo - 2º Rodada - 20/01/2026 09:00</span>
																		<span>(2352962)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/423177">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id423177/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/423177">
																									Theo Grimaldi 																								</a>
																								<sup>25º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/489137">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id489137/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/489137">
																									Theo Cortese 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Theo Grimaldi - 2 X 0</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352936)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/445973">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id445973/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/445973">
																									Thomaz Accioly																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352937)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/394819">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id394819/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/394819">
																										Henrique Mavignier																									</a>
																									<sup>146º</sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>7º Jogo - 2º Rodada - 20/01/2026 10:30</span>
																		<span>(2352963)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/445973">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id445973/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/445973">
																									Thomaz Accioly 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									4
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									1
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/394819">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id394819/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/394819">
																									Henrique Mavignier 																								</a>
																								<sup>146º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Henrique Mavignier - 2 X 0</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352938)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/373749">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id373749/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/373749">
																									Henrique Moreira																								</a>
																								<sup>59º</sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352939)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/488001">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id488001/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/488001">
																										Francisco Villa																									</a>
																									<sup></sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>8º Jogo - 2º Rodada - 20/01/2026 10:30</span>
																		<span>(2352964)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/373749">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id373749/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/373749">
																									Henrique Moreira 																								</a>
																								<sup>59º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/488001">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id488001/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/488001">
																									Francisco Villa 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Henrique Moreira - 2 X 0</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352940)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/512262">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id512262/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/512262">
																									Francisco Alencar																								</a>
																								<sup>213º</sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352941)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/427147">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id427147/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/427147">
																										Mateus Calasans																									</a>
																									<sup>58º</sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>9º Jogo - 2º Rodada - 20/01/2026 10:30</span>
																		<span>(2352965)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/512262">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id512262/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/512262">
																									Francisco Alencar 																								</a>
																								<sup>213º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									1
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/427147">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id427147/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/427147">
																									Mateus Calasans 																								</a>
																								<sup>58º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Mateus Calasans - 2 X 0</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352942)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/402058">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id402058/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/402058">
																									Guilherme Rossiter																								</a>
																								<sup>47º</sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352943)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/488927">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id488927/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/488927">
																										Raul Luna																									</a>
																									<sup></sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>10º Jogo - 2º Rodada - 20/01/2026 11:30</span>
																		<span>(2352966)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/402058">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id402058/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/402058">
																									Guilherme Rossiter 																								</a>
																								<sup>47º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/488927">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id488927/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/488927">
																									Raul Luna 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Guilherme Rossiter - 2 X 0</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352944)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/479654">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id479654/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/479654">
																									Pedro Grecco																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352945)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/426927">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id426927/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/426927">
																										Raphael Alves																									</a>
																									<sup>67º</sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>11º Jogo - 2º Rodada - 20/01/2026 11:30</span>
																		<span>(2352967)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/479654">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id479654/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/479654">
																									Pedro Grecco 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				<div class="wo text-danger">W.O.</div>
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/426927">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id426927/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/426927">
																									Raphael Alves 																								</a>
																								<sup>67º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				<div class="wo text-danger">W.O.</div>
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Nenhum</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352946)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/475051">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id475051/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/475051">
																									Joao Sa Leitao																								</a>
																								<sup>100º</sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352947)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/506207">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id506207/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/506207">
																										Arthur Farias																									</a>
																									<sup></sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>12º Jogo - 2º Rodada - 20/01/2026 11:30</span>
																		<span>(2352968)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/475051">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id475051/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/475051">
																									Joao Sa Leitao 																								</a>
																								<sup>100º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									2
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									4
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/506207">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id506207/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/506207">
																									Arthur Farias 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									4
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									10
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Arthur Farias - 2 X 1</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352948)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/412884">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id412884/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/412884">
																									Felipe Sales																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352949)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/454954">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id454954/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/454954">
																										Noah Bruere																									</a>
																									<sup>30º</sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>13º Jogo - 2º Rodada - 20/01/2026 13:00</span>
																		<span>(2352969)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/412884">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id412884/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/412884">
																									Felipe Sales 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									5
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									3
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/454954">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id454954/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/454954">
																									Noah Bruere 																								</a>
																								<sup>30º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									7
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Noah Bruere - 2 X 0</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352950)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/412778">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id412778/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/412778">
																									Luiz Frugoni																								</a>
																								<sup>34º</sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352951)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/469394">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id469394/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/469394">
																										Andre Vasconcelos																									</a>
																									<sup></sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>14º Jogo - 2º Rodada - 20/01/2026 13:00</span>
																		<span>(2352970)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/412778">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id412778/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/412778">
																									Luiz Frugoni 																								</a>
																								<sup>34º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/469394">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id469394/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/469394">
																									Andre Vasconcelos 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Luiz Frugoni - 2 X 0</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352952)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/490462">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id490462/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/490462">
																									Rafael Fernandes																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352953)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/414374">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id414374/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/414374">
																										Felipe Vera																									</a>
																									<sup>61º</sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>15º Jogo - 2º Rodada - 20/01/2026 13:00</span>
																		<span>(2352971)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/490462">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id490462/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/490462">
																									Rafael Fernandes 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									1
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									2
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/414374">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id414374/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/414374">
																									Felipe Vera 																								</a>
																								<sup>61º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Felipe Vera - 2 X 0</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352954)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/429383">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id429383/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/429383">
																									Enrico Almussa																								</a>
																								<sup>80º</sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Jogo - 1º Rodada - 20/01/2026 08:00</span>
																		<span>(2352955)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																																															<a href="perfil2/index/459194">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id459194/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/459194">
																										Arthur Thorp 																									</a>
																									<sup>218º</sup>
																									<img src="https://www.tenisintegrado.com.br//images/logo_wtn_min.png" style="width:15px;" title="World Tennis Number ITF atualizado em 23/04/2026"><span class="text-bold text-danger" style="font-size:11px;" title="World Tennis Number ITF atualizado em 23/04/2026">31,75</span>																								</span>
																																													</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									2
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																																															<a href="perfil2/index/413203">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id413203/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/413203">
																										Eduardo Argolo 																									</a>
																									<sup></sup>
																									<img src="https://www.tenisintegrado.com.br//images/logo_wtn_min.png" style="width:15px;" title="World Tennis Number ITF atualizado em 23/04/2026"><span class="text-bold text-danger" style="font-size:11px;" title="World Tennis Number ITF atualizado em 23/04/2026">30,99</span>																								</span>
																																													</div>

																						
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Eduardo Argolo - 2 X 0</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>16º Jogo - 2º Rodada - 20/01/2026 14:30</span>
																		<span>(2352972)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/429383">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id429383/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/429383">
																									Enrico Almussa (Des)																								</a>
																								<sup>80º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									0
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/413203">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id413203/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/413203">
																									Eduardo Argolo 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									1
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Eduardo Argolo - por DES</div>
																</div>
															</div>

														
													</div>
												</div>

											
												<div class="row">
													<div class="col-sm-12 col-md-6">
														<div class="wrapper-2">

															<!--
												***********************************************************************************
													J O G O S  E M  M O D E L O  D E  C H A V E
												***********************************************************************************
												-->

															<div class="game">
																<div class="game-top">
																	<span>1º Rodada -  </span>
																	<span>(2352956)</span>
																	
																</div>
																<ul class="list-group">
																	<li class="list-group-item">

																		
																			
																						<div class="avatar-container">
																							<a href="perfil2/index/441254">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id441254/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/441254">
																									Rafa Esteves																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>

																	</li>
																	<li class="list-group-item">

																		
																			
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																			
																		<div class="score pull-right">

																			
																					<div class="set">
																					</div>

																			
																		</div>
																	</li>
																</ul>
																<div class="game-bottom">&nbsp</div>
															</div>

																															<div class="game">
																	<div class="game-top">
																		<span>1º Rodada -  </span>
																		<span>(2352957)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																					<div class="avatar-container">
																						<img src="images/avatars/1.jpg" alt="" class="avatar">
																						<span class="avatar-info">
																							BYE																						</span>
																					</div>

																					
																				
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																							<div class="avatar-container">
																								<a href="perfil2/index/247805">
																									<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id247805/fotos/avatar.jpg" alt="" class="avatar">
																								</a>
																								<span class="avatar-info">
																									<a href="perfil2/index/247805">
																										Miguel Ribeiro																									</a>
																									<sup>13º</sup>
																								</span>
																							</div>

																						
																			<div class="score pull-right">

																				
																						<div class="set">
																						</div>

																				
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">&nbsp</div>
																</div>
																													</div>
																													<div class="right-divider">
																<div></div>
																<a href="https://www.tenisintegrado.com.br/torneio_painel_jogo/index/22039/5/4/217452/22911" class="btn btn-sm btn-outline"><i class="fa fa-chevron-right"></i></a>
															</div>
																											</div>

													<!-- 2º Coluna -->
													<div class="col-sm-12 col-md-6">
																													<div class="left-divider">
																<div></div>
															</div>
																													<div class="wrapper-1">
																<div class="game">
																	<div class="game-top">
																		<span>17º Jogo - 2º Rodada - 20/01/2026 14:30</span>
																		<span>(2352973)</span>
																		
																	</div>
																	<ul class="list-group">
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/441254">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id441254/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/441254">
																									Rafa Esteves 																								</a>
																								<sup></sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									2
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									8
																								
																							</div>

																						
																			</div>
																		</li>
																		<li class="list-group-item">

																			
																				
																						<div class="avatar-container">
																							<a href="perfil2/index/247805">
																								<img src="https://tenis-integrado-prod.s3.amazonaws.com/sync-prod/id247805/fotos/avatar.jpg" alt="" class="avatar">
																							</a>
																							<span class="avatar-info">
																								<a href="perfil2/index/247805">
																									Miguel Ribeiro 																								</a>
																								<sup>13º</sup>
																							</span>
																						</div>

																					
																				
																			<div class="score pull-right">

																				
																							<div class="set" style="font-size: 10pt;">

																								
																									6
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									3
																								
																							</div>

																						
																							<div class="set" style="font-size: 10pt;">

																								
																									10
																								
																							</div>

																						
																			</div>
																		</li>
																	</ul>
																	<div class="game-bottom">VENCEDOR: Miguel Ribeiro - 2 X 1</div>
																</div>
															</div>

														
													</div>
												</div>

																						<!-- 
										fim do bloco de 3 jogos
										Fase atual e fase posterior
									-->

										</div>

									</div>
								</div>
							</div>

						
						<input name="id_torneio" type="hidden" value="22039">
						<input name="id_categoria_ant" type="hidden" value="5">
					</form>


				
				<!-- Tournament Mainbanner -->
								<!-- End Tournament Mainbanner -->

			</div>

		</div>
		<script>
			init.push(function() {
				var formAction = $('#frm-maintenance').attr('action');

				$('#round-selector').change(function() {
					$('#frm-maintenance').attr('action', formAction);
					$('#frm-maintenance').removeAttr('target');
					$('#frm-maintenance').submit();
				});
			});
		</script>			<!-- End Content -->

		</div> <!-- / #content-wrapper -->

		<div id="main-menu-bg"></div>
	</div> <!-- / #main-wrapper -->

	<script src="./bower_components/jquery/jquery.min.js"></script>
	<script src="./bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
	<script src="./scripts/main.min.js"></script>

	
	<script type="text/javascript">
		window.PixelAdmin.start(init);
	</script>

	<!-- INICIO SUPORTE CHAT ON LINE -->
	<!-- FINAL SUPORTE CHAT ON LINE -->

</body>
<!--<![endif]-->

</html>'''


import logging, traceback, coloredlogs, re
from scrapy.selector import Selector
from datetime import datetime

logger = logging.getLogger("scraper")
logger.setLevel(logging.INFO)
coloredlogs.install(level="INFO", logger=logger)

class Parser:
    # ---------- Static spec values --------------------------------------
    BALL_TYPE = "Yellow"
    COUNTRY = "Brasil"
    COUNTRY_CODE = "BRA"
    ID_TYPE = "Brasil"
    IMPORT_SOURCE = "CBT"
    SANCTION_BODY = "CBT"
    EVENT_TYPE = "Tournament"

    # game-top header — two real layouts observed in the wild:
    #   (a) "5º Jogo - 2º Rodada - 29/01/2026 11:00"
    #   (b) "1º Rodada - "              (no Jogo prefix, no date)
    _RE_GAME_TOP = re.compile(
        r"^\s*\d+\s*º?\s*Jogo\s*-\s*(?P<round>[^-]+?)\s*-\s*"
        r"(?P<date>\d{2}/\d{2}/\d{4})(?:\s+\d{1,2}:\d{2})?\s*$",
        re.IGNORECASE,
    )
    # Short header: round label only, no Jogo prefix, no date.
    _RE_GAME_TOP_SHORT = re.compile(
        r"^\s*(?P<round>\d+\s*º?\s*Rodada|Final|Semi[-\s]?final|"
        r"Quartas?(?:\s+de\s+final)?|Oitavas?(?:\s+de\s+final)?|"
        r"16[ªa]s?|32[ªa]s?|64[ªa]s?|Repescagem|Quali(?:fica[çc][ãa]o)?)"
        r"\s*-?\s*$",
        re.IGNORECASE,
    )
    _RE_DATE_IN_HEADER = re.compile(r"(\d{2}/\d{2}/\d{4})")
    _RE_BYE = re.compile(r"^\s*BYE\s*$", re.IGNORECASE)

    # Any of these tokens introduces the winner's name in the bottom strip.
    # We intentionally keep the regex loose: the winner phrase is just
    # "<token> <name>" and may be followed by " - <tail>" or end of line.
    _WINNER_TOKEN = r"(?:vencedor(?:\(a\)|a)?|ganhador(?:\(a\)|a)?|camp[eê]ao|champion)"
    _RE_WINNER_LINE = re.compile(
        rf"{_WINNER_TOKEN}\s*[:\-]\s*(?P<name>[^\n\r]+?)(?:\s+-\s+(?P<tail>[^\n\r]+))?\s*$",
        re.IGNORECASE | re.MULTILINE,
    )
    # Fallback: a standalone "Vencedor" token immediately before a name link.
    _RE_WINNER_TOKEN_ONLY = re.compile(rf"\b{_WINNER_TOKEN}\b", re.IGNORECASE)

    # Outcome detection: look at full block text.
    _RE_WO = re.compile(r"\b(w\.?o\.?|walkover)\b", re.IGNORECASE)
    _RE_RETIRED = re.compile(
        r"\b(des(?:ist[eê]ncia|istiu)?|abandono|retirou|retirado|ret\.?)\b",
        re.IGNORECASE,
    )

    _RE_PROFILE_ID = re.compile(r"perfil2/index/(\d+)")
    _RE_MATCH_ID = re.compile(r"\((\d+)\)")
    _RE_PERIOD = re.compile(r"(\d{2}/\d{2}/\d{4})\s*a\s*(\d{2}/\d{2}/\d{4})")
    _RE_TRAILING_PAREN = re.compile(r"\s*\([^)]*\)\s*$")

    # ---------- Init -----------------------------------------------------
    def __init__(self, spider_name, selector):
        self.spider_name = spider_name
        self._extract_tournament(selector)
        self._extract_draw(selector)

    # ================================================================
    # Helpers
    # ================================================================
    @staticmethod
    def _clean(text: str) -> str:
        if not text:
            return ""
        return re.sub(r"\s+", " ", text).strip()

    @classmethod
    def _join_text(cls, sel) -> str:
        return cls._clean(" ".join(sel.xpath(".//text()").getall()))

    @classmethod
    def _format_date(cls, d: str) -> str:
        d = cls._clean(d)
        if not d:
            return ""
        try:
            dt = datetime.strptime(d, "%d/%m/%Y")
        except ValueError:
            return d
        return dt.strftime("%m/%d/%Y")

    @classmethod
    def _strip_markers(cls, name: str) -> str:
        return cls._RE_TRAILING_PAREN.sub("", cls._clean(name)).strip()

    @classmethod
    def _last_first(cls, full_name: str) -> str:
        name = cls._strip_markers(full_name)
        if not name:
            return ""
        parts = name.split()
        if len(parts) == 1:
            return parts[0]
        return f"{parts[-1]}, {' '.join(parts[:-1])}"

    @classmethod
    def _profile_id_from_href(cls, href: str) -> str:
        if not href:
            return ""
        m = cls._RE_PROFILE_ID.search(href)
        return m.group(1) if m else ""

    @staticmethod
    def _set_to_pair(set_text):
        """'6-3' -> (6,3); '7-6(5)' -> (7,6); returns (None,None) on junk."""
        if not set_text:
            return (None, None)
        m = re.match(r"\s*(\d{1,2})\s*[-x×]\s*(\d{1,2})", set_text)
        if not m:
            return (None, None)
        return (int(m.group(1)), int(m.group(2)))

    # ================================================================
    # Tournament-level extraction
    # ================================================================
    def _extract_tournament(self, selector) -> None:
        title_sel = selector.xpath(".//div[@class='tournament-title']")
        self.tournament_name = self._join_text(title_sel) if title_sel else ""

        local_parts = selector.xpath(".//div[@class='tournament-local']/descendant-or-self::text()").getall()
        local_text = self._clean(" ".join(local_parts))
        self.tournament_city = local_text.split("-", 1)[0].strip() if "-" in local_text else local_text

        self.tournament_start_date = ""
        self.tournament_end_date = ""
        for info_text in selector.xpath(".//div[@class='tournament-period']//div[@class='info']/text()").getall():
            m = self._RE_PERIOD.match(self._clean(info_text))
            if m:
                self.tournament_start_date = self._format_date(m.group(1))
                self.tournament_end_date = self._format_date(m.group(2))
                break

        share_url = selector.xpath(".//div[@class='tournament-share']//input[@class='form-control']/@value").get()
        if share_url:
            self.tournament_url = share_url.strip()
        else:
            id_torneio = selector.xpath(".//input[@name='id_torneio']/@value").get()
            if id_torneio:
                self.tournament_url = (
                    "https://www.tenisintegrado.com.br/torneio_painel_info/index/"
                    f"{id_torneio.strip()}"
                )
            else:
                self.tournament_url = ""

        self.tournament_state = ""
        self.tournament_country = self.COUNTRY
        self.tournament_country_code = self.COUNTRY_CODE
        self.tournament_host = ""
        self.tournament_location_type = ""
        self.tournament_surface = ""
        self.tournament_event_category = ""
        self.tournament_event_grade = ""
        self.tournament_event_type = self.EVENT_TYPE
        self.tournament_import_source = self.IMPORT_SOURCE
        self.tournament_sanction_body = self.SANCTION_BODY

    # ================================================================
    # Draw extraction
    # ================================================================
    def _extract_draw(self, selector) -> None:
        name = ""
        for txt in selector.xpath(".//h4/text() | .//h3/text() | .//h2/text()").getall():
            txt = self._clean(txt)
            if "Simples" in txt or "Duplas" in txt:
                name = txt
                break
        if not name:
            opt = selector.xpath(".//select[@id='id_categoria']//option[@selected]/text()").get()
            if opt:
                name = self._clean(opt)

        self.draw_name = name
        low = name.lower()
        self.draw_gender = "Male" if "masculino" in low else ("Female" if "feminino" in low else "")
        self.draw_team_type = "Doubles" if "duplas" in low else ("Singles" if "simples" in low else "")
        self.draw_bracket_value = ""
        self.draw_bracket_type = ""
        self.draw_type = ""

    def _players_in_row(self, li_sel):
        players = []
        for ac in li_sel.xpath('./div[@class="avatar-container"]'):
            player_name = self._join_text(ac.xpath('./span[@class="avatar-info"]/a'))
            player_link = ac.xpath(".//span[contains(@class,'avatar-info')]/a/@href").get()
            third_party_id = self._profile_id_from_href(player_link)

            logger.info(f'player_name: {player_name}')
            logger.info(f'player_link: {player_link}')
            logger.info(f'third_party_id: {third_party_id}')
            logger.info('*'*50)

            '''
            if not third_party_id and player_name:
                third_party_id = helper.sha256_id(player_name)

            if third_party_id:
                objs = PlayersBrazilResultsModel.objects.filter(
                    spider_name=self.spider_name, third_party_id=third_party_id
                )
                if objs.exists():
                    player_name = objs.first().player_name
                else:
                    try:
                        claude_key = random.choice(settings.CLAUDE_KEYS)
                        player_name, _gender = helper.format_name_gender_claude(player_name, claude_key)
                    except Exception:
                        logger.error(traceback.format_exc())
                    PlayersBrazilResultsModel(
                        spider_name=self.spider_name,
                        third_party_id=third_party_id,
                        player_name=player_name,
                    ).save()
            '''

            if player_name:
                players.append((player_name, third_party_id))

        return players


    def _row_score(self, li_sel):
        score_sel = li_sel.xpath(".//div[@class='score pull-right']")
        if not score_sel:
            return []
        if score_sel.xpath(".//div[@class='wo text-danger']") or self._RE_WO.search(self._join_text(score_sel)):
            return ["W.O."]
        sets = [self._join_text(s) for s in score_sel.xpath(".//div[@class='set']")]
        return [s for s in sets if s]

    @staticmethod
    def _row_has_winner_marker(li_sel) -> bool:
        """True if this <li> looks like the winner row by CSS / icon."""
        cls = (li_sel.attrib.get("class") or "").lower()
        if any(tok in cls for tok in ("winner", "vencedor", "is-winner", "champ")):
            return True
        # any descendant icon that screams 'win'
        icon_classes = " ".join(li_sel.xpath(".//@class").getall()).lower()
        if any(tok in icon_classes for tok in ("fa-trophy", "fa-check", "win-icon", "vencedor")):
            return True
        return False

    @staticmethod
    def _build_score(winner_sets, loser_sets, outcome: str) -> str:
        if outcome == "Walkover":
            return "W.O.;"
        pairs = []
        for i in range(max(len(winner_sets), len(loser_sets))):
            w = winner_sets[i] if i < len(winner_sets) else ""
            l = loser_sets[i] if i < len(loser_sets) else ""
            if (not w and not l) or "W.O." in (w, l):
                continue
            pairs.append(f"{w}-{l}")
        score = ", ".join(pairs)
        if outcome == "retired" and score:
            score += " ret."
        return f"{score};" if score else ";"

    @classmethod
    def _outcome_from_block(cls, block_text: str) -> str:
        if cls._RE_WO.search(block_text):
            return "Walkover"
        if cls._RE_RETIRED.search(block_text):
            return "retired"
        return "Completed"

    # ================================================================
    # Winner-detection strategies
    # ================================================================
    def _winner_name_from_text(self, block_text: str):
        """Strategy A: explicit winner phrase anywhere in the block."""
        m = self._RE_WINNER_LINE.search(block_text)
        if m:
            return self._strip_markers(m.group("name"))
        return None

    def _winner_row_index_from_markup(self, rows) -> int | None:
        """Strategy B: a row carries an explicit CSS / icon marker."""
        marked = [i for i, r in enumerate(rows) if self._row_has_winner_marker(r)]
        if len(marked) == 1:
            return marked[0]
        return None

    def _winner_row_index_from_score(self, row_a_sets, row_b_sets) -> int | None:
        """Strategy C: whoever won more sets is the winner."""
        a_wins = b_wins = 0
        for i in range(max(len(row_a_sets), len(row_b_sets))):
            a = row_a_sets[i] if i < len(row_a_sets) else ""
            b = row_b_sets[i] if i < len(row_b_sets) else ""
            ai, _ = self._set_to_pair(a)
            bi, _ = self._set_to_pair(b)
            if ai is None or bi is None:
                continue
            if ai > bi:
                a_wins += 1
            elif bi > ai:
                b_wins += 1
        if a_wins == b_wins:
            return None
        return 0 if a_wins > b_wins else 1

    # ================================================================
    # Parse one match
    # ================================================================
    def parse_match(self, game_sel):
        match_data = {}
        try:
            # ---- header (match_id, round, date) -----------------------------
            spans = game_sel.xpath('./div[@class="game-top"]/span')
            header_text = self._clean(self._join_text(spans[0])) if spans else ""
            match_id = ""
            if len(spans) >= 2:
                m = self._RE_MATCH_ID.search(self._join_text(spans[1]))
                if m:
                    match_id = m.group(1)

            round_ = ""
            date = ""
            m = self._RE_GAME_TOP.match(header_text)
            if m:
                round_ = self._clean(m.group("round"))
                date = self._format_date(m.group("date"))
            else:
                # Short header layout — round only, no date.
                m2 = self._RE_GAME_TOP_SHORT.match(header_text)
                if m2:
                    round_ = self._clean(m2.group("round"))
                # opportunistic date scan anywhere in the header text
                dm = self._RE_DATE_IN_HEADER.search(header_text)
                if dm:
                    date = self._format_date(dm.group(1))
            # Final fallback: use the tournament start date when the block
            # header doesn't include a per-match date.
            if not date and getattr(self, "tournament_start_date", ""):
                date = self.tournament_start_date

            # ---- rows -------------------------------------------------------
            rows = game_sel.xpath('./ul[@class="list-group"]/li[@class="list-group-item"]')
            if len(rows) < 2:
                logger.info('len(rows) < 2')
                return None

            row_a_players = self._players_in_row(rows[0])
            row_b_players = self._players_in_row(rows[1])
            logger.info(f'row_a_players: {row_a_players}')
            logger.info(f'row_b_players: {row_b_players}')

            row_a_sets = self._row_score(rows[0])
            row_b_sets = self._row_score(rows[1])
            logger.info(f'row_a_sets: {row_a_sets}')
            logger.info(f'row_b_sets: {row_b_sets}')
            logger.info('*'*50)

            if not row_a_players or not row_b_players:
                logger.info('not row_a_players or not row_b_players')
                return None

            # Skip BYE blocks: if either side is BYE, this isn't a real match.
            if any(p[0] == "__BYE__" for p in row_a_players) or any(p[0] == "__BYE__" for p in row_b_players):
                logger.info('any(p[0] == "__BYE__" for p in row_a_players) or any(p[0] == "__BYE__" for p in row_b_players)')
                return None

            # ---- full block text (for winner + outcome) ---------------------
            block_text = self._join_text(game_sel.xpath(".//div[@class='game-bottom']")) or self._join_text(game_sel)
            outcome = self._outcome_from_block(block_text)

            # ---- find the winner with progressive fallback ------------------
            winner_idx = None
            strategy = None

            # A) text-based winner phrase
            winner_name_raw = self._winner_name_from_text(block_text)
            if winner_name_raw:
                target = self._strip_markers(winner_name_raw).lower()
                for idx, players in enumerate((row_a_players, row_b_players)):
                    if any(self._strip_markers(p[0]).lower() == target or
                           self._strip_markers(p[0]).lower() in target or
                           target in self._strip_markers(p[0]).lower()
                           for p in players):
                        winner_idx = idx
                        strategy = "text"
                        break

            # B) CSS marker on a row
            if winner_idx is None:
                wi = self._winner_row_index_from_markup(rows)
                if wi is not None:
                    winner_idx = wi
                    strategy = "markup"

            # C) score comparison
            if winner_idx is None:
                wi = self._winner_row_index_from_score(row_a_sets, row_b_sets)
                if wi is not None:
                    winner_idx = wi
                    strategy = "score"

            # D) walkover / retired clearly indicated but no name match:
            #    if outcome != Completed and exactly one row has scores, the row
            #    *with* scores is the survivor.
            if winner_idx is None and outcome != "Completed":
                if row_a_sets and not row_b_sets:
                    winner_idx, strategy = 0, "outcome-only-scored"
                elif row_b_sets and not row_a_sets:
                    winner_idx, strategy = 1, "outcome-only-scored"

            if winner_idx is None:
                logger.info('winner_idx is None')
                return None

            if winner_idx == 0:
                winners, losers = row_a_players, row_b_players
                winner_sets, loser_sets = row_a_sets, row_b_sets
            else:
                winners, losers = row_b_players, row_a_players
                winner_sets, loser_sets = row_b_sets, row_a_sets

            logger.debug(f"[parser] match {match_id or '----'} winner via {strategy}")

            # ---- field assembly ---------------------------------------------
            ball_type = self.BALL_TYPE
            draw_bracket_value = self.draw_bracket_value
            draw_name = self.draw_name
            draw_team_type = self.draw_team_type
            tournament_name = self.tournament_name
            score = self._build_score(winner_sets, loser_sets, outcome)

            # Winner 1
            winner_1_name = self._last_first(winners[0][0]) if winners else ""
            winner_1_third_party_id = winners[0][1] if winners else ""
            winner_1_country = self.COUNTRY if winner_1_name else ""
            winner_1_gender = self.draw_gender
            winner_1_city = ""; winner_1_state = ""; winner_1_college = ""; winner_1_dob = ""

            # Winner 2
            if len(winners) >= 2:
                winner_2_name = self._last_first(winners[1][0])
                winner_2_third_party_id = winners[1][1]
                winner_2_gender = self.draw_gender
                winner_2_country = self.COUNTRY
            else:
                winner_2_name = ""; winner_2_third_party_id = ""
                winner_2_gender = ""; winner_2_country = ""
            winner_2_city = ""; winner_2_state = ""; winner_2_college = ""; winner_2_dob = ""

            # Loser 1
            loser_1_name = self._last_first(losers[0][0]) if losers else ""
            loser_1_third_party_id = losers[0][1] if losers else ""
            loser_1_country = self.COUNTRY if loser_1_name else ""
            loser_1_gender = self.draw_gender
            loser_1_city = ""; loser_1_state = ""; loser_1_college = ""; loser_1_dob = ""

            # Loser 2
            if len(losers) >= 2:
                loser_2_name = self._last_first(losers[1][0])
                loser_2_third_party_id = losers[1][1]
                loser_2_gender = self.draw_gender
                loser_2_country = self.COUNTRY
            else:
                loser_2_name = ""; loser_2_third_party_id = ""
                loser_2_gender = ""; loser_2_country = ""
            loser_2_city = ""; loser_2_state = ""; loser_2_college = ""; loser_2_dob = ""

            id_type = self.ID_TYPE
            draw_gender = self.draw_gender
            draw_bracket_type = self.draw_bracket_type
            draw_type = self.draw_type
            tournament_city = self.tournament_city
            tournament_state = self.tournament_state
            tournament_country_code = self.tournament_country_code
            tournament_host = self.tournament_host
            tournament_location_type = self.tournament_location_type
            tournament_surface = self.tournament_surface
            tournament_event_category = self.tournament_event_category
            tournament_event_grade = self.tournament_event_grade
            tournament_import_source = self.tournament_import_source
            tournament_sanction_body = self.tournament_sanction_body
            tournament_event_type = self.tournament_event_type
            tournament_url = self.tournament_url
            tournament_country = self.tournament_country
            tournament_start_date = self.tournament_start_date
            tournament_end_date = self.tournament_end_date

            match_data = {
                "match_id": match_id,
                "ball_type": ball_type,
                "draw_bracket_value": draw_bracket_value,
                "draw_name": draw_name,
                "draw_team_type": draw_team_type,
                "tournament_name": tournament_name,
                "date": date,
                "round": round_,
                "score": score,
                "winner_1_name": winner_1_name,
                "winner_1_gender": winner_1_gender,
                "winner_1_third_party_id": winner_1_third_party_id,
                "winner_1_city": winner_1_city,
                "winner_1_country": winner_1_country,
                "winner_1_state": winner_1_state,
                "winner_2_name": winner_2_name,
                "winner_2_gender": winner_2_gender,
                "winner_2_third_party_id": winner_2_third_party_id,
                "winner_2_city": winner_2_city,
                "winner_2_state": winner_2_state,
                "loser_1_name": loser_1_name,
                "loser_1_gender": loser_1_gender,
                "loser_1_third_party_id": loser_1_third_party_id,
                "loser_1_city": loser_1_city,
                "loser_1_state": loser_1_state,
                "loser_1_country": loser_1_country,
                "loser_2_name": loser_2_name,
                "loser_2_gender": loser_2_gender,
                "loser_2_third_party_id": loser_2_third_party_id,
                "loser_2_city": loser_2_city,
                "loser_2_state": loser_2_state,
                "outcome": outcome,
                "id_type": id_type,
                "draw_gender": draw_gender,
                "draw_bracket_type": draw_bracket_type,
                "draw_type": draw_type,
                "tournament_city": tournament_city,
                "tournament_state": tournament_state,
                "tournament_country_code": tournament_country_code,
                "tournament_host": tournament_host,
                "tournament_location_type": tournament_location_type,
                "tournament_surface": tournament_surface,
                "tournament_event_category": tournament_event_category,
                "tournament_event_grade": tournament_event_grade,
                "tournament_import_source": tournament_import_source,
                "tournament_sanction_body": tournament_sanction_body,
                "winner_2_country": winner_2_country,
                "winner_2_college": winner_2_college,
                "loser_2_country": loser_2_country,
                "loser_2_college": loser_2_college,
                "tournament_event_type": tournament_event_type,
                "winner_1_college": winner_1_college,
                "loser_1_college": loser_1_college,
                "tournament_url": tournament_url,
                "winner_1_dob": winner_1_dob,
                "winner_2_dob": winner_2_dob,
                "loser_1_dob": loser_1_dob,
                "loser_2_dob": loser_2_dob,
                "tournament_country": tournament_country,
                "tournament_start_date": tournament_start_date,
                "tournament_end_date": tournament_end_date,
            }

        except Exception:
            logger.error(traceback.format_exc())

        return match_data


if __name__ == "__main__":
    html1 = Selector(text=html_text1)
    parser = Parser('spider_name', html1)

    for d1 in html1.xpath('//div[@class="game"]'):
        match = parser.parse_match(d1)
        logger.info(f'match: {match}')
