import time
import concurrent.futures
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn
from assets.fct.fctlog import logger
from assets.fct import fctcore
from scripts import helper
from scripts.brazil_results.parser.tournament import TournamentParser
from scripts.brazil_results.parser.details import DetailsParser
from app_spiders.models import jobsModel

start_dt = time.time()

def run(*args):
    params = list(args)
    job_id = int(params[0])
    spider_name = params[1]
    folder_path = params[2]
    max_workers = int(params[3])

    base_file = f'{spider_name}__{job_id}__{fctcore.current_date("%Y-%m-%d_%H-%M")}.csv'

    job_obj = jobsModel.objects.get(id=job_id)
    spider_id = job_obj.spider_id
    job_settings = job_obj.job_settings
    job_rank_year = job_settings.get('rank_year', '')
    job_month = int(job_settings.get('month', ''))

    logger.info(f'spider_name: {spider_name} | job_id: {job_id} | job_rank_year: {job_rank_year} | job_month: {job_month}')

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(), TextColumn("{task.completed}/{task.total}"), TimeElapsedColumn(), TimeRemainingColumn(), transient=False) as progress:
        df_tournaments = TournamentParser(spider_name, max_workers, progress).parse_tournaments(job_rank_year, job_month)
        logger.info(f'df_tournaments: {len(df_tournaments)}')

        if not df_tournaments.empty:
            tournaments_list = df_tournaments.to_dict("records")
            tournaments_chunks = list(fctcore.split_list_into_chunks(lst=tournaments_list, max_workers=max_workers))
            if max_workers > len(tournaments_chunks): max_workers=len(tournaments_chunks)

            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                main_task = progress.add_task(description=f'{spider_name}_results', total=len(tournaments_list))
                for thread_id, tournaments_chunk in enumerate(tournaments_chunks):
                    thread_task = progress.add_task(f"Thread {thread_id + 1}", total=len(tournaments_chunk))
                    executor.submit(DetailsParser(spider_name, spider_id, job_id, main_task, thread_task, progress).parse_site, tournaments_chunk)

        helper.finalize_items_from_db(job_obj, folder_path, base_file)
        helper.finalize_job(job_obj, base_file, folder_path)

    logger.info(f'script take {round(time.time()-start_dt, 2)} sec to finished')
