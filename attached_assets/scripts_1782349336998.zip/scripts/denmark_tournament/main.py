import time
import concurrent.futures
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn
from assets.fct.fctlog import logger
from assets.fct import fctcore
from scripts import helper
from scripts.denmark_tournament.parser.ranking import RankingParser
from scripts.denmark_tournament.parser.tournament import TournamentParser
from scripts.denmark_tournament.parser.players import PlayersParser
from scripts.denmark_tournament.parser.details import DetailsParser
from app_spiders.models import jobsModel

start_dt = time.time()

def run(*args):
    params = list(args)
    job_id = int(params[0])
    spider_name = params[1]
    folder_path = params[2]
    max_workers = int(params[3])

    base_file = f'{spider_name}__{job_id}__{fctcore.current_date("%Y-%m-%d_%H-%M")}.csv'

    job_obj = jobsModel.objects.get(id=job_id)
    spider_id = job_obj.spider_id
    job_settings = job_obj.job_settings
    job_tournament_url = job_settings.get('tournament_url', '')
    job_range_date = job_settings.get('range_date', '')
    job_start_date = job_end_date = ''
    if job_range_date and ' to ' in job_range_date:
        job_tab_date = job_range_date.split(' to ')
        job_start_date = fctcore.convert_string_to_date_format(date_str=job_tab_date[0], in_format='%m/%d/%Y', out_format='%Y-%m-%d')
        job_end_date = fctcore.convert_string_to_date_format(date_str=job_tab_date[1], in_format='%m/%d/%Y', out_format='%Y-%m-%d')
    logger.info(f'spider_name: {spider_name} | job_id: {job_id} | job_range_date: {job_range_date} | job_start_date: {job_start_date} | job_end_date: {job_end_date} | job_tournament_url: {job_tournament_url}')

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(), TextColumn("{task.completed}/{task.total}"), TimeElapsedColumn(), TimeRemainingColumn(), transient=False) as progress:
        RankingParser(progress).parse_ranking_profile(max_workers)

        df_tournaments = TournamentParser().parse_tournaments(job_start_date, job_end_date, job_tournament_url)
        logger.info(f'df_tournaments: {len(df_tournaments)}')

        if not df_tournaments.empty:
            tournaments_list = df_tournaments.to_dict("records")
            tournaments_chunks = list(fctcore.split_list_into_chunks(lst=tournaments_list, max_workers=max_workers))
            if max_workers > len(tournaments_chunks): max_workers=len(tournaments_chunks)

            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                main_task = progress.add_task(description=f'{spider_name}_players', total=len(tournaments_list))
                for thread_id, tournaments_chunk in enumerate(tournaments_chunks):
                    thread_task = progress.add_task(f"Thread {thread_id + 1}", total=len(tournaments_chunk))
                    executor.submit(PlayersParser(progress).parse_site, tournaments_chunk, main_task, thread_task, progress)

            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                main_task = progress.add_task(description=f'{spider_name}_results', total=len(tournaments_list))
                for thread_id, tournaments_chunk in enumerate(tournaments_chunks):
                    thread_task = progress.add_task(f"Thread {thread_id + 1}", total=len(tournaments_chunk))
                    executor.submit(DetailsParser(progress).parse_site, spider_id, job_id, tournaments_chunk, main_task, thread_task, progress)

        helper.finalize_items_from_db(job_obj, folder_path, base_file)
        helper.finalize_job(job_obj, base_file, folder_path)

    logger.info(f'script take {round(time.time()-start_dt, 2)} sec to finished')
