import traceback, time, math
from django.conf import settings
from django.db import close_old_connections
from datetime import datetime
from assets.requests.fctrequest import Request
from assets.fct.fctlog import logger
from assets.fct import fctcore
from scripts.log_items import ItemsLogger

counter = 0

class TiesParser:

    def __init__(self, progress):
        global counter
        self.counter = counter
        self.end_counter = 60
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=True, use_proxy=self.use_proxy)

        self.login_user = '8138382730'
        self.login_pass = 'Asma&1234'

        self.df_ties = ItemsLogger()
        self.seen_rows = getattr(self, "seen_rows", set())


    def login(self):
        refresh_token = ''
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0',
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json',
            }
            json_data = {
                'credentials': {
                    'country_code': '+1',
                    'phone': self.login_user,
                    'password': self.login_pass,
                },
            }
            index_link = 'https://api.ioncourt.com/api/auth/login'
            response1 = self.fctrequest.request(method='POST', link=index_link, json=json_data, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    try:
                        refresh_token = dict(response1.headers).get('refresh-token')
                    except Exception:
                        ''
                    logger.info(f'refresh_token: {refresh_token}')

        except Exception:
            logger.error(traceback.format_exc())

        return refresh_token


    def parse_site(self, start_date, end_date):
        try:
            refresh_token = self.login()
            if refresh_token:

                page = 0
                results = self.get_tie_data(start_date, end_date, page, refresh_token)
                if results:
                    count_result = 0
                    count_page = 0
                    try:
                        count_result = results.get('data', {}).get('pagination', {}).get('totalRecords', 0)
                    except Exception:
                        ''
                    try:
                        count_page = math.ceil(count_result/30)
                    except Exception:
                        ''

                    logger.info(f'count_result: {count_result} | count_page: {count_page}')

                    logger.info(f'page: {page+1} | count_page: {count_page}')
                    self.parse_page(start_date, end_date, results)
                    time.sleep(10)

                    main_task = self.progress.add_task(description='ioncourt_matches', total=count_page-1)
                    for page in range(1, count_page):
                        self.progress.update(main_task, advance=1)
                        close_old_connections()

                        logger.info(f'page: {page+1} | count_page: {count_page}')

                        results = self.get_tie_data(start_date, end_date, page, refresh_token)
                        if results:
                            self.parse_page(start_date, end_date, results)
                            if self.counter > self.end_counter:
                                break
                            time.sleep(10)

        except Exception:
            logger.error(traceback.format_exc())

        return self.df_ties.get_df()


    def get_tie_data(self, start_date=None, end_date=None, page=0, refresh_token=''):
        results = {}
        try:
            headers = {
                'Refresh-Token': refresh_token,
                'sec-ch-ua-platform': '"Windows"',
                'Authorization': refresh_token,
                'Accept': 'application/json, text/plain, */*',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0',
            }

            # json_data = {
            #     'filter': {
            #         # 'from': fctcore.get_offset_date(days=1, direction='-', format='%Y-%m-%d')+'T23:00:00.000Z', #start_date+'T23:00:00.000Z'
            #         'from': fctcore.current_date(format='%Y')+'-01-01T23:00:00.000Z', #start_date+'T23:00:00.000Z'
            #         'to': None, #end_date+'T23:00:00.000Z',
            #         'organisationAbbreviation': 'ITA',
            #         'type': 'college',
            #         'subtype': None,
            #         'matchStatus': 'COMPLETED',
            #         'page': page,
            #     },
            # }

            json_data = {
                'filter': {
                    'from': None,
                    'to': None,
                    'organisationAbbreviation': 'ITA',
                    'type': 'college',
                    'subtype': None,
                    'gender': None,
                    'matchStatus': 'COMPLETED',
                    'page': page,
                },
            }

            index_link = 'https://ioncourt.com/search/ties'
            index_link = 'https://api.ioncourt.com/api/search/ties'
            response1 = self.fctrequest.request(method='POST', link=index_link, json=json_data, headers=headers, proxies=self.proxies, tries=3)

            # fctcore.open_html_in_browser(json.dumps(json_data) + '<br><br><br>' + response1.text)
            # fctcore.exit()

            if response1:
                if response1.status_code in range(200, 300):
                    try:
                        results = response1.json()
                    except Exception:
                        ''

        except Exception:
            logger.error(traceback.format_exc())

        return results


    def parse_page(self, start_date, end_date, results):
        try:
            for result in results.get('data', {}).get('ties', []):
                try:
                    tie_id = ''
                    tie_date = ''
                    try:
                        tie_id = result.get('_id', '')
                    except Exception:
                        ''
                    try:
                        tie_date = fctcore.convert_string_to_date_format(date_str=result.get('startDate', ''), in_format='%Y-%m-%dT%H:%M:%S.%fZ', out_format="%Y-%m-%d")
                    except Exception:
                        ''

                    if tie_id:
                        tie_dt = datetime.strptime(tie_date, "%Y-%m-%d").date()
                        start_dt = datetime.strptime(start_date, "%Y-%m-%d").date()
                        end_dt = datetime.strptime(end_date, "%Y-%m-%d").date()

                        if start_dt <= tie_dt <= end_dt:
                            row_key = f"{tie_id}"
                            if row_key not in self.seen_rows:
                                logger.info(f'tie_date: {tie_date} | tie_dt: {tie_dt} in {start_date} and {end_date} | tie_id: {tie_id} | counter: {self.counter}')
                                self.df_ties.log({
                                    "tie_id": tie_id,
                                })
                                self.seen_rows.add(row_key)

                        else:
                            logger.warning(f'tie_date: {tie_date} | tie_dt: {tie_dt} not in {start_date} and {end_date} | counter: {self.counter}')
                            self.counter += 1
                            if self.counter > self.end_counter:
                                break

                except Exception:
                    logger.error(traceback.format_exc())
        except Exception:
            logger.error(traceback.format_exc())

