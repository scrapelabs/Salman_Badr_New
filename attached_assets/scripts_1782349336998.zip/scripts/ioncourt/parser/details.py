import traceback, re
from openai import OpenAI
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts import helper
from app_spiders.models import JobsItemsIoncourtModel, tournamentsModel


class DetailsParser:

    def __init__(self, thread_id):
        self.thread_id = thread_id
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=True, use_proxy=self.use_proxy)

        self.ai_client = OpenAI(api_key=settings.API_KEYS[self.thread_id])

        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0',
            'device-id': 'cdfb6c04-6ee4-4cf2-9666-52630499812e',
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json',
        }
        self.json_data = {'skipCache': False,}

        self.seen_rows = getattr(self, "seen_rows", set())


    def parse_site(self, spider_id, job_id, ties_chunk, main_task, thread_task, progress):
        try:
            for ties_data in ties_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                tie_id = ties_data.get("tie_id", "")
                # tie_id = '68bb03eb36cd30e2cc089240'

                if tie_id:
                    tournament_url = f'https://ioncourt.com/ties/{tie_id}'
                    logger.info(f'new: tie_id: {tie_id} | tournament_url: {tournament_url}')

                    info_url = f'https://api.ioncourt.com/api/tie/{tie_id}/info'
                    response1 = self.fctrequest.request(method='POST', link=info_url, json=self.json_data, headers=self.headers, proxies=self.proxies, tries=3)
                    if response1:
                        if response1.status_code in range(200, 300):
                            results_info = {}
                            try:
                                results_info = response1.json()
                            except Exception:
                                ''

                            if results_info:
                                self.parse_info_page(spider_id, job_id, tournament_url, tie_id, results_info)
                                if not tournamentsModel.objects.filter(tournament_url=tournament_url).exists():
                                    tournamentsModel(tournament_url=tournament_url).save()

        except Exception:
            logger.error(traceback.format_exc())


    def parse_info_page(self, spider_id, job_id, tournament_url, tie_id, results_info):
        try:
            date = ''
            loser_1_gender = ''
            loser_2_gender = ''
            loser_team = ''
            team_score = ''
            winner_1_gender = ''
            winner_2_gender = ''
            winner_team = ''
            winning_side = ''

            try:
                date = fctcore.convert_string_to_date_format(date_str=results_info.get('data', {}).get('startDate', ''), in_format='%Y-%m-%dT%H:%M:%S.%fZ', out_format='%m/%d/%Y')
            except Exception:
                ''

            try:
                winning_side = results_info.get('data', {}).get('winningSide', '')
            except Exception:
                ''

            if not winning_side:
                winning_side = 1

            try:
                for result in results_info.get('data', {}).get('sides', []):
                    if result.get('sideNumber', '') == winning_side:
                        winner_team, winner_team_gender = self.parse_team_name_gender(result.get('team', {}).get('name', ''))
                        winner_1_gender = winner_2_gender = winner_team_gender
                    else:
                        loser_team, loser_team_gender = self.parse_team_name_gender(result.get('team', {}).get('name', ''))
                        loser_1_gender = loser_2_gender = loser_team_gender
            except Exception:
                ''

            try:
                team_score = self.reverse_number_with_larger_first(results_info.get('data', {}).get('score', ''))
            except Exception:
                ''

            logger.info(f'date: {date}')
            logger.info(f'winner_team: {winner_team}')
            logger.info(f'winner_1_gender: {winner_1_gender}')
            logger.info(f'winner_2_gender: {winner_2_gender}')
            logger.info(f'loser_team: {loser_team}')
            logger.info(f'loser_1_gender: {loser_1_gender}')
            logger.info(f'loser_2_gender: {loser_2_gender}')
            logger.info(f'team_score: {team_score}')
            logger.info(f'winning_side: {winning_side}')
            logger.info(f'*' * 50)

            self.parse_matches_site(spider_id, job_id, tournament_url, tie_id, date, loser_1_gender, loser_2_gender, loser_team, team_score, winner_1_gender, winner_2_gender, winner_team, results_info)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_matches_site(self, spider_id, job_id, tournament_url, tie_id, date, loser_1_gender, loser_2_gender, loser_team, team_score, winner_1_gender, winner_2_gender, winner_team, results_info):
        try:
            matches_url = f'https://api.ioncourt.com/api/match/{tie_id}/tie-matches'
            response1 = self.fctrequest.request(method='POST', link=matches_url, json=self.json_data, headers=self.headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    results_matches = {}
                    try:
                        results_matches = response1.json()
                    except Exception:
                        ''

                    if results_matches:
                        self.parse_matches_page(spider_id, job_id, tournament_url, date, loser_1_gender, loser_2_gender, loser_team, team_score, winner_1_gender, winner_2_gender, winner_team, results_info, results_matches)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_matches_page(self, spider_id, job_id, tournament_url, date, loser_1_gender, loser_2_gender, loser_team, team_score, winner_1_gender, winner_2_gender, winner_team, results_info, results_matches):
        try:
            for results in results_matches.get('data', []):
                match_id = ''
                try:
                    match_id = results.get('matchId', '')
                except Exception:
                    ''

                row_key = f"{match_id}"
                if row_key not in self.seen_rows:
                    ball_type = 'Yellow'
                    draw_bracket_type = ''
                    draw_bracket_value = ''
                    draw_gender = ''
                    draw_name = ''
                    draw_size = ''
                    draw_team_type = ''
                    draw_type = ''
                    id_type = 'Ioncourt'
                    loser_1_city = ''
                    loser_1_college = ''
                    loser_1_country = ''
                    loser_1_dob = ''
                    loser_1_name = ''
                    loser_1_state = ''
                    loser_1_third_party_id = ''
                    loser_2_city = ''
                    loser_2_college = ''
                    loser_2_country = ''
                    loser_2_dob = ''
                    loser_2_name = ''
                    loser_2_state = ''
                    loser_2_third_party_id = ''
                    loser_team_type = 'College'
                    outcome = ''
                    round = ''
                    score = ''
                    tournament_city = ''
                    tournament_country = ''
                    tournament_country_code = ''
                    tournament_end_date = date
                    tournament_event_category = ''
                    tournament_event_grade = ''
                    tournament_event_type = 'Dual Match'
                    tournament_host = ''
                    tournament_import_source = 'College'
                    tournament_location_type = ''
                    tournament_name = ''
                    tournament_sanction_body = 'College'
                    tournament_start_date = date
                    tournament_state = ''
                    tournament_surface = ''
                    winner_1_city = ''
                    winner_1_college = ''
                    winner_1_country = ''
                    winner_1_dob = ''
                    winner_1_name = ''
                    winner_1_state = ''
                    winner_1_third_party_id = ''
                    winner_2_city = ''
                    winner_2_college = ''
                    winner_2_country = ''
                    winner_2_dob = ''
                    winner_2_name = ''
                    winner_2_state = ''
                    winner_2_third_party_id = ''
                    winner_team_type = 'College'
                    tournament_gender = ''

                    winning_side = ''
                    try:
                        winning_side = results.get('winningSide', '')
                    except Exception:
                        ''

                    if not winning_side:
                        winning_side = 1

                    if winner_1_gender == 'M':
                        draw_gender = 'Male'
                        tournament_gender = 'Men'

                    elif winner_1_gender == 'F':
                        draw_gender = 'Female'
                        tournament_gender = 'Women'

                    player_college_map = {}
                    for side in results_info["data"]["sides"]:
                        college_name = side["team"]["name"]
                        for participant in side["team"]["participants"]:
                            try:
                                player_college_map[participant["person"]["_id"]] = college_name
                            except Exception:
                                logger.error(traceback.format_exc())

                    logger.info(f'player_college_map: {player_college_map}')

                    for result in results.get('sides', []):
                        if result.get('sideNumber', '') == winning_side:
                            try:
                                winner_1_participant = result.get('players', [])[0].get('participant', {})
                                winner_1_third_party_id = winner_1_participant.get('_id', '')
                                winner_1_name = f"{winner_1_participant.get('last_name', '')}, {winner_1_participant.get('first_name', '')}".title()
                                winner_1_college = helper.get_official_college_name(fctcore.preg_repace(patt="\(.*", repl="", subj=player_college_map.get(winner_1_third_party_id, '')), self.ai_client)
                            except Exception:
                                ''

                            try:
                                winner_2_participant = result.get('players', [])[1].get('participant', {})
                                winner_2_third_party_id = winner_2_participant.get('_id', '')
                                winner_2_name = f"{winner_2_participant.get('last_name', '')}, {winner_2_participant.get('first_name', '')}".title()
                                winner_2_college = helper.get_official_college_name(fctcore.preg_repace(patt="\(.*", repl="", subj=player_college_map.get(winner_2_third_party_id, '')), self.ai_client)
                            except Exception:
                                ''

                            if not winner_2_name:
                                winner_2_gender = ''

                        else:
                            try:
                                loser_1_participant = result.get('players', [])[0].get('participant', {})
                                loser_1_third_party_id = loser_1_participant.get('_id', '')
                                loser_1_name = f"{loser_1_participant.get('last_name', '')}, {loser_1_participant.get('first_name', '')}".title()
                                loser_1_college = helper.get_official_college_name(fctcore.preg_repace(patt="\(.*", repl="", subj=player_college_map.get(loser_1_third_party_id, '')), self.ai_client)
                            except Exception:
                                ''

                            try:
                                loser_2_participant = result.get('players', [])[1].get('participant', {})
                                loser_2_third_party_id = loser_2_participant.get('_id', '')
                                loser_2_name = f"{loser_2_participant.get('last_name', '')}, {loser_2_participant.get('first_name', '')}".title()
                                loser_2_college = helper.get_official_college_name(fctcore.preg_repace(patt="\(.*", repl="", subj=player_college_map.get(loser_2_third_party_id, '')), self.ai_client)
                            except Exception:
                                ''

                            if not loser_2_name:
                                loser_2_gender = ''

                    try:
                        score = self.formatter_match_score(results.get('score', {}).get(f'scoreStringSide{winning_side}', ''))
                    except Exception:
                        ''

                    try:
                        matchType = results.get('matchType', '')
                        if matchType == 'S':
                            draw_team_type = 'Singles'
                        elif matchType == 'D':
                            draw_team_type = 'Doubles'
                    except Exception:
                        ''

                    try:
                        if draw_team_type:
                            draw_name = f"#{results.get('collectionPosition', '')} {draw_team_type}"
                    except Exception:
                        ''

                    try:
                        tournament_name = f'{tournament_event_type}: {winner_team} vs {loser_team} - {tournament_gender}'
                    except Exception:
                        ''

                    try:
                        outcome = results.get('matchStatus', '').title()
                        if outcome == 'Incomplete':
                            outcome = 'Tie'
                    except Exception:
                        ''

                    logger.info(f'new: match_id: {match_id}')
                    logger.info(f'draw_gender: {draw_gender}')
                    logger.info(f'winner_1_gender: {winner_1_gender}')
                    logger.info(f'winner_1_name: {winner_1_name}')
                    logger.info(f'winner_2_name: {winner_2_name}')
                    logger.info(f'loser_1_name: {loser_1_name}')
                    logger.info(f'loser_2_name: {loser_2_name}')
                    logger.info(f'team_score: {team_score}')
                    logger.info(f'score: {score}')
                    logger.info(f'draw_name: {draw_name}')
                    logger.info(f'draw_team_type: {draw_team_type}')
                    logger.info(f'tournament_name: {tournament_name}')
                    logger.info(f'winner_1_college: {winner_1_college}')
                    logger.info(f'winner_2_college: {winner_2_college}')
                    logger.info(f'loser_1_college: {loser_1_college}')
                    logger.info(f'loser_2_college: {loser_2_college}')
                    logger.info(f'outcome: {outcome}')
                    logger.info(f'*' * 50)

                    JobsItemsIoncourtModel(
                        spider_id=spider_id,
                        job_id=job_id,
                        match_id=match_id,
                        ball_type=ball_type,
                        date=date,
                        draw_bracket_type=draw_bracket_type,
                        draw_bracket_value=draw_bracket_value,
                        draw_gender=draw_gender,
                        draw_name=draw_name,
                        draw_size=draw_size,
                        draw_team_type=draw_team_type,
                        draw_type=draw_type,
                        id_type=id_type,
                        loser_1_city=loser_1_city,
                        loser_1_college=loser_1_college,
                        loser_1_country=loser_1_country,
                        loser_1_dob=loser_1_dob,
                        loser_1_gender=loser_1_gender,
                        loser_1_name=loser_1_name,
                        loser_1_state=loser_1_state,
                        loser_1_third_party_id=loser_1_third_party_id,
                        loser_2_city=loser_2_city,
                        loser_2_college=loser_2_college,
                        loser_2_country=loser_2_country,
                        loser_2_dob=loser_2_dob,
                        loser_2_gender=loser_2_gender,
                        loser_2_name=loser_2_name,
                        loser_2_state=loser_2_state,
                        loser_2_third_party_id=loser_2_third_party_id,
                        loser_team=loser_team,
                        loser_team_type=loser_team_type,
                        outcome=outcome,
                        round=round,
                        score=score,
                        team_score=team_score,
                        tournament_city=tournament_city,
                        tournament_country=tournament_country,
                        tournament_country_code=tournament_country_code,
                        tournament_end_date=tournament_end_date,
                        tournament_event_category=tournament_event_category,
                        tournament_event_grade=tournament_event_grade,
                        tournament_event_type=tournament_event_type,
                        tournament_host=tournament_host,
                        tournament_import_source=tournament_import_source,
                        tournament_location_type=tournament_location_type,
                        tournament_name=tournament_name,
                        tournament_sanction_body=tournament_sanction_body,
                        tournament_start_date=tournament_start_date,
                        tournament_state=tournament_state,
                        tournament_surface=tournament_surface,
                        tournament_url=tournament_url,
                        winner_1_city=winner_1_city,
                        winner_1_college=winner_1_college,
                        winner_1_country=winner_1_country,
                        winner_1_dob=winner_1_dob,
                        winner_1_gender=winner_1_gender,
                        winner_1_name=winner_1_name,
                        winner_1_state=winner_1_state,
                        winner_1_third_party_id=winner_1_third_party_id,
                        winner_2_city=winner_2_city,
                        winner_2_college=winner_2_college,
                        winner_2_country=winner_2_country,
                        winner_2_dob=winner_2_dob,
                        winner_2_gender=winner_2_gender,
                        winner_2_name=winner_2_name,
                        winner_2_state=winner_2_state,
                        winner_2_third_party_id=winner_2_third_party_id,
                        winner_team=winner_team,
                        winner_team_type=winner_team_type,
                    ).save()

                    self.seen_rows.add(row_key)

        except Exception:
            logger.error(traceback.format_exc())

    def parse_team_name_gender(self, text):
        name = ''
        gender = ''
        try:
            match = re.match(r"(.+?) \((M|W|F)\)", text)
            if match:
                name = helper.get_official_college_name(match.group(1), self.ai_client)
                gender = match.group(2)

                if gender == 'W':
                    gender = 'F'

        except Exception:
            logger.error(traceback.format_exc())
        return name, gender


    def reverse_number_with_larger_first(self, input_string):
        a, b = map(int, input_string.split('-'))
        return f"{max(a, b)}-{min(a, b)};"


    def formatter_match_score(self, score_str):
        # Remove parentheses content only if it contains a dash
        def replacer(match):
            content = match.group(1)
            return '' if '-' in content else f'({content})'
        return re.sub(r'\(([^)]+)\)', replacer, score_str).strip()+';'


    # def formatter_match_score(self, input_string):
    #     return ", ".join(input_string.split()) + ";"
    #     return ", ".join(input_string.split()).replace('(','[').replace(')',']') + ";"
