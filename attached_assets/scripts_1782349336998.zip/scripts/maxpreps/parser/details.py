import traceback
import xml.etree.ElementTree as ET
from datetime import datetime
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from app_spiders.models import JobsItemsMaxprepsModel

class DetailsParser:

    def __init__(self, main_task, thread_task, progress):
        self.main_task = main_task
        self.thread_task = thread_task
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = False
        self.fctrequest = Request(use_session=False, use_cffi=True, use_proxy=self.use_proxy)
        self.headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,fr;q=0.8',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
        }
        # self.base_link = 'https://www.maxpreps.com/feeds/affiliates/ut/results.ashx?ssid=e59ca771-23ee-484f-8ccf-d2b8c3ef4878&type=singles&updated=4/24/2026&apikey=50B280F4-5F20-4191-8AEC-726AA3AD800C&state=UTR'
        self.base_link = 'https://www.maxpreps.com/feeds/affiliates/ut/results.ashx?ssid={job_ssid}&type={job_type}&updated={job_date}&apikey={job_api_key}&state=UTR'
        self.job_api_key = '50B280F4-5F20-4191-8AEC-726AA3AD800C'


    def parse_site(self, spider_id, job_id, job_date_chunk, job_ssid):
        try:
            for job_type in ['Singles', 'Doubles']:
                for job_date in job_date_chunk:
                    self.progress.update(self.main_task, advance=1)
                    self.progress.update(self.thread_task, advance=1)
                    close_old_connections()

                    job_date = fctcore.convert_string_to_date_format(job_date, in_format='%Y-%m-%d', out_format='%m/%d/%Y')

                    index_link = self.base_link.format(job_ssid=job_ssid, job_type=job_type.lower(), job_api_key=self.job_api_key , job_date=job_date)
                    logger.info(f'job_date: {job_date} | {index_link}')

                    matches = []
                    try:
                        response1 = self.fctrequest.request(method='GET', link=index_link, headers=self.headers, proxies=self.proxies, tries=3, timeout=60*4)
                        if response1:
                            if response1.status_code in range(200, 300):
                                try:
                                    # Strip BOM if present, then parse XML
                                    xml_text = response1.content.decode('utf-8-sig')
                                    root = ET.fromstring(xml_text)
                                    matches = root.findall('Match')
                                except Exception:
                                    logger.error(traceback.format_exc())
                    except Exception:
                        logger.error(traceback.format_exc())

                    if matches:
                        self.parse_page(spider_id, job_id, matches)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_page(self, spider_id, job_id, matches):
        try:
            # FIX: iterate flat <Match> XML elements (not nested games/matches JSON)
            for m in matches:
                a = m.attrib  # all fields are XML attributes

                # ── Identifiers ──────────────────────────────────────────────────
                # FIX: MatchID is a direct XML attribute, not a composite of gameReportId + eventResultId
                match_id           = a.get('MatchID', '')
                ball_type          = 'Yellow'
                id_type            = 'Maxpreps'
                draw_bracket_value = a.get('DrawBracketValue', '')

                # ── Draw info ────────────────────────────────────────────────────
                # FIX: read directly from XML attributes instead of JSON match dict
                draw_name         = a.get('DrawName', '')
                draw_team_type    = a.get('DrawTeamType', '')       # e.g. "Singles" / "Doubles"
                draw_gender       = a.get('DrawGender', '')         # already "Female" / "Male"
                draw_bracket_type = a.get('DrawBracketType', '')
                draw_type         = a.get('DrawType', '')

                # ── Match date & score ───────────────────────────────────────────
                # FIX: date comes from 'Date' attribute in M/D/YYYY format, not ISO
                raw_date = a.get('Date', '')
                date     = self.parse_date(raw_date)
                score = a.get('Score', '') + (';' if a.get('Score', '') else '')
                outcome  = 'Completed'

                # ── Tournament ───────────────────────────────────────────────────
                # FIX: TournamentName is always blank in feed — construct from school names
                w1_school       = a.get('Winner1SchoolName', '')
                l1_school       = a.get('Loser1SchoolName', '')
                tournament_name = a.get('TournamentName', '') or f'Dual Match: {w1_school} vs {l1_school}'

                tournament_city           = a.get('TournamentCity', '')
                tournament_state          = a.get('TournamentState', '')
                # FIX: read TournamentCountryCode from XML, fallback to 'USA'
                tournament_country_code   = a.get('TournamentCountryCode', '') or 'USA'
                tournament_host           = a.get('TournamentHost', '')
                tournament_location_type  = a.get('LocationType', '')
                tournament_surface        = a.get('Surface', '')
                tournament_event_category = a.get('EventCategory', '')
                tournament_event_grade    = a.get('EventGrade', '')
                tournament_import_source  = 'Maxpreps'
                tournament_sanction_body  = 'Maxpreps'
                # FIX: read EventType from XML, fallback to 'Dual Match'
                tournament_event_type     = a.get('EventType', '') or 'Dual Match'
                tournament_url            = a.get('TournamentURL', '')
                tournament_country        = a.get('TournamentCountry', '') or 'USA'
                # FIX: TournamentStartDate/EndDate are blank in feed — fall back to match date
                t_start = a.get('TournamentStartDate', '')
                t_end   = a.get('TournamentEndDate', '')
                tournament_start_date = self.parse_date(t_start) if t_start else date
                tournament_end_date   = self.parse_date(t_end)   if t_end   else date

                # ── Doubles detection ────────────────────────────────────────────
                # FIX: use DrawTeamType attribute, not presence of JSON winner2/loser2 objects
                is_doubles = draw_team_type.strip().lower() == 'doubles'

                # ── Winner 1 ─────────────────────────────────────────────────────
                # FIX: names from Winner1FirstName/Winner1LastName XML attributes
                # FIX: city/state from Winner1SchoolCity/Winner1SchoolState (not Winner1City/State)
                winner_1_name           = self.format_name_attrs(a, 'Winner1')
                winner_1_gender         = a.get('Winner1Gender', '')
                winner_1_dob            = a.get('Winner1DOB', '')
                winner_1_third_party_id = a.get('Winner1ThirdPartyID', '')
                winner_1_city           = a.get('Winner1SchoolCity', '')
                winner_1_state          = a.get('Winner1SchoolState', '')
                winner_1_country        = a.get('Winner1Country', '') or 'USA'
                winner_1_college        = ''

                # ── Winner 2 (Doubles only) ───────────────────────────────────────
                winner_2_name           = self.format_name_attrs(a, 'Winner2') if is_doubles else ''
                winner_2_gender         = a.get('Winner2Gender', '') if is_doubles else ''
                winner_2_dob            = a.get('Winner2DOB', '') if is_doubles else ''
                winner_2_third_party_id = a.get('Winner2ThirdPartyID', '') if is_doubles else ''
                winner_2_city           = a.get('Winner2SchoolCity', '') if is_doubles else ''
                winner_2_state          = a.get('Winner2SchoolState', '') if is_doubles else ''
                winner_2_country        = (a.get('Winner2Country', '') or 'USA') if is_doubles else ''
                winner_2_college        = ''

                # ── Loser 1 ──────────────────────────────────────────────────────
                loser_1_name            = self.format_name_attrs(a, 'Loser1')
                loser_1_gender          = a.get('Loser1Gender', '')
                loser_1_dob             = a.get('Loser1DOB', '')
                loser_1_third_party_id  = a.get('Loser1ThirdPartyID', '')
                loser_1_city            = a.get('Loser1SchoolCity', '')
                loser_1_state           = a.get('Loser1SchoolState', '')
                loser_1_country         = a.get('Loser1Country', '') or 'USA'
                loser_1_college         = ''

                # ── Loser 2 (Doubles only) ────────────────────────────────────────
                loser_2_name            = self.format_name_attrs(a, 'Loser2') if is_doubles else ''
                loser_2_gender          = a.get('Loser2Gender', '') if is_doubles else ''
                loser_2_dob             = a.get('Loser2DOB', '') if is_doubles else ''
                loser_2_third_party_id  = a.get('Loser2ThirdPartyID', '') if is_doubles else ''
                loser_2_city            = a.get('Loser2SchoolCity', '') if is_doubles else ''
                loser_2_state           = a.get('Loser2SchoolState', '') if is_doubles else ''
                loser_2_country         = (a.get('Loser2Country', '') or 'USA') if is_doubles else ''
                loser_2_college         = ''

                if not JobsItemsMaxprepsModel.objects.filter(spider_id=spider_id, job_id=job_id, winner_1_name=winner_1_name, loser_1_name=loser_1_name, winner_2_name=winner_2_name, loser_2_name=loser_2_name, score=score, match_id=match_id).exists():
                    logger.info(f'match_id: {match_id}')
                    logger.info(f'draw_name: {draw_name}')
                    logger.info(f'draw_team_type: {draw_team_type}')
                    logger.info(f'tournament_name: {tournament_name}')
                    logger.info(f'date: {date}')
                    logger.info(f'score: {score}')
                    logger.info(f'winner_1_name: {winner_1_name}')
                    logger.info(f'winner_1_gender: {winner_1_gender}')
                    logger.info(f'winner_1_third_party_id: {winner_1_third_party_id}')
                    logger.info(f'winner_1_dob: {winner_1_dob}')
                    logger.info(f'winner_2_name: {winner_2_name}')
                    logger.info(f'winner_2_gender: {winner_2_gender}')
                    logger.info(f'winner_2_third_party_id: {winner_2_third_party_id}')
                    logger.info(f'winner_2_dob: {winner_2_dob}')
                    logger.info(f'loser_1_name: {loser_1_name}')
                    logger.info(f'loser_1_gender: {loser_1_gender}')
                    logger.info(f'loser_1_third_party_id: {loser_1_third_party_id}')
                    logger.info(f'loser_1_dob: {loser_1_dob}')
                    logger.info(f'loser_2_name: {loser_2_name}')
                    logger.info(f'loser_2_gender: {loser_2_gender}')
                    logger.info(f'loser_2_third_party_id: {loser_2_third_party_id}')
                    logger.info(f'loser_2_dob: {loser_2_dob}')
                    logger.info(f'outcome: {outcome}')
                    logger.info(f'draw_gender: {draw_gender}')
                    logger.info(f'tournament_city: {tournament_city}')
                    logger.info(f'tournament_country_code: {tournament_country_code}')
                    logger.info(f'tournament_url: {tournament_url}')
                    logger.info(f'tournament_country: {tournament_country}')
                    logger.info(f'tournament_start_date: {tournament_start_date}')
                    logger.info(f'tournament_end_date: {tournament_end_date}')
                    logger.info('*' * 50)

                    JobsItemsMaxprepsModel(
                        spider_id=spider_id,
                        job_id=job_id,
                        match_id=match_id,
                        ball_type=ball_type,
                        id_type=id_type,
                        draw_bracket_value=draw_bracket_value,
                        draw_name=draw_name,
                        draw_team_type=draw_team_type,
                        tournament_name=tournament_name,
                        date=date,
                        score=score,
                        winner_1_name=winner_1_name,
                        winner_1_gender=winner_1_gender,
                        winner_1_dob=winner_1_dob,
                        winner_1_third_party_id=winner_1_third_party_id,
                        winner_1_city=winner_1_city,
                        winner_1_state=winner_1_state,
                        winner_1_country=winner_1_country,
                        winner_2_name=winner_2_name,
                        winner_2_gender=winner_2_gender,
                        winner_2_dob=winner_2_dob,
                        winner_2_third_party_id=winner_2_third_party_id,
                        winner_2_city=winner_2_city,
                        winner_2_state=winner_2_state,
                        winner_2_country=winner_2_country,
                        loser_1_name=loser_1_name,
                        loser_1_gender=loser_1_gender,
                        loser_1_dob=loser_1_dob,
                        loser_1_third_party_id=loser_1_third_party_id,
                        loser_1_city=loser_1_city,
                        loser_1_state=loser_1_state,
                        loser_1_country=loser_1_country,
                        loser_2_name=loser_2_name,
                        loser_2_gender=loser_2_gender,
                        loser_2_dob=loser_2_dob,
                        loser_2_third_party_id=loser_2_third_party_id,
                        loser_2_city=loser_2_city,
                        loser_2_state=loser_2_state,
                        loser_2_country=loser_2_country,
                        outcome=outcome,
                        draw_gender=draw_gender,
                        draw_bracket_type=draw_bracket_type,
                        draw_type=draw_type,
                        tournament_city=tournament_city,
                        tournament_state=tournament_state,
                        tournament_country_code=tournament_country_code,
                        tournament_host=tournament_host,
                        tournament_location_type=tournament_location_type,
                        tournament_surface=tournament_surface,
                        tournament_event_category=tournament_event_category,
                        tournament_event_grade=tournament_event_grade,
                        tournament_import_source=tournament_import_source,
                        tournament_sanction_body=tournament_sanction_body,
                        winner_2_college=winner_2_college,
                        loser_2_college=loser_2_college,
                        tournament_event_type=tournament_event_type,
                        winner_1_college=winner_1_college,
                        loser_1_college=loser_1_college,
                        tournament_url=tournament_url,
                        tournament_country=tournament_country,
                        tournament_start_date=tournament_start_date,
                        tournament_end_date=tournament_end_date,
                    ).save()

        except Exception:
            logger.error(traceback.format_exc())


    # ── Helpers ──────────────────────────────────────────────────────────────────
    def format_name_attrs(self, attribs, prefix):
        """
        Returns 'lastName, firstName' from XML attributes.
        prefix: 'Winner1', 'Winner2', 'Loser1', or 'Loser2'
        Returns '' if both names are absent.
        """
        last  = attribs.get(f'{prefix}LastName', '')
        first = attribs.get(f'{prefix}FirstName', '')
        return f'{last}, {first}' if last or first else ''

    def parse_date(self, date_str):
        """
        Parse date from multiple formats and return YYYY-MM-DD string.
        Handles:
          M/D/YYYY        - XML feed format  (e.g. '4/24/2026')
          ISO datetime    - e.g. '2026-04-24T00:00:00'
          ISO date        - e.g. '2026-04-24'
        Returns the original string unchanged if no format matches.
        """
        if not date_str:
            return ''
        for fmt in ('%m/%d/%Y', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d'):
            try:
                return datetime.strptime(date_str.strip(), fmt).strftime('%Y-%m-%d')
            except ValueError:
                continue
        return date_str
