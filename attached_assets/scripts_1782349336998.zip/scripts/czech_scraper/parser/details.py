import re
import traceback
from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse

from django.db import close_old_connections
from django.conf import settings
from parsel import Selector

from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts.log_items import ItemsLogger
from app_spiders.models import JobsItemsCzechScraperModel

BASE = "https://cesky-tenis.cz"


# ─────────────────────────────────────────────────────────────────────────────
# Helpers (verified against live cesky-tenis.cz markup)
# ─────────────────────────────────────────────────────────────────────────────

def _parse_start_date(raw):
    """'8.-9. 5. 2026' or '07.05.2026 …'  →  m/d/yyyy"""
    raw = (raw or "").strip()
    m = re.match(r"(\d+)\.\s*(?:-\s*\d+\.)?\s*(\d+)\.\s*(\d{4})", raw)
    if m:
        return f"{int(m.group(2))}/{int(m.group(1))}/{m.group(3)}"
    m = re.match(r"(\d{2})\.(\d{2})\.(\d{4})", raw)
    if m:
        return f"{int(m.group(2))}/{int(m.group(1))}/{m.group(3)}"
    return raw


def _parse_end_date(raw):
    """'8.-9. 5. 2026'  →  end date as m/d/yyyy; single day → same as start."""
    raw = (raw or "").strip()
    m = re.match(r"\d+\.\s*-\s*(\d+)\.\s*(\d+)\.\s*(\d{4})", raw)
    if m:
        return f"{int(m.group(2))}/{int(m.group(1))}/{m.group(3)}"
    return _parse_start_date(raw)


def _normalise_name(raw):
    """
    Czech pages list names as 'Lastname Firstname' (sometimes with extra spaces).
    Convert to 'Lastname, Firstname'.
    """
    raw = re.sub(r"\s+", " ", (raw or "").strip())
    if not raw:
        return ""
    parts = raw.split(" ", 1)
    return f"{parts[0]}, {parts[1]}" if len(parts) == 2 else raw


def _info_blocks(sel):
    """Return {label: value} for every <p class="info"> on the page."""
    result = {}
    for p in sel.css("p.info"):
        label = (p.css("span::text").get() or "").strip()
        if not label:
            continue
        texts = [t.strip() for t in p.css("*::text").getall()
                 if t.strip() and t.strip() != label]
        result[label] = " ".join(texts).strip()
    return result


def _td_classes(td):
    return (td.attrib.get("class") or "").split()


def _tournament_id_from_url(url):
    m = re.search(r"/turnaj/(\d+)", url or "")
    return m.group(1) if m else ""


# Czech (and English) category words that identify a draw's gender. Female is
# matched first and male patterns explicitly exclude female stems
# ("žák" but not "žákyně", "junior" but not "juniorky").
_FEMALE_WORDS = re.compile(
    r"\bžen\w*|žákyn\w*|dorostenk\w*|juniork\w*|dívk\w*"
    r"|\bwom[ae]n\b|\bgirls?\b|\bladies\b|\bfemale\b",
    re.IGNORECASE,
)
_MALE_WORDS = re.compile(
    r"\bmuž\w*|\bžác\w*|\bžák(?!yn)\w*|dorostenc\w*|junioř\w*|junior(?!k)\w*|chlapc\w*"
    r"|\bm[ae]n\b|\bboys?\b|\bmale\b",
    re.IGNORECASE,
)


def _detect_gender(sel, tournament_type="", tid=""):
    """
    Decide the draw gender ("M"/"F").

    Priority:
      1. The ``tournament_type`` label from the date-range listing file.
      2. Czech category words in the page header (h1, page title, draw
         name, info blocks): "ženy/žákyně/dorostenky/juniorky/dívky" → F,
         "muži/žáci/dorostenci/junioři/chlapci" → M.
      3. Legacy tournament-id heuristic (women's ids start with "2").
    """
    t = (tournament_type or "").strip()
    if t:
        u = t.upper()
        if u in ("F", "W", "Z", "Ž", "ZENY", "ŽENY", "WOMEN"):
            return "F"
        if u in ("M", "MUZI", "MUŽI", "MEN"):
            return "M"
        f, m = bool(_FEMALE_WORDS.search(t)), bool(_MALE_WORDS.search(t))
        if f and not m:
            return "F"
        if m and not f:
            return "M"

    header_texts = (
        sel.css("h1 ::text").getall()
        + sel.css("title::text").getall()
        + sel.css("div.box--blue h4::text").getall()
        + sel.css("p.info ::text").getall()
    )
    page = " ".join(x.strip() for x in header_texts if x and x.strip())
    f, m = bool(_FEMALE_WORDS.search(page)), bool(_MALE_WORDS.search(page))
    if f and not m:
        return "F"
    if m and not f:
        return "M"

    # No keyword found, or both genders mentioned on one page → fall back.
    return "F" if str(tid).startswith("2") else "M"

def _build_urls(tournament_url):
    """
    Build (results_url, seznam_url) from the incoming tournament URL while
    preserving its query params (e.g. ``sezona=L26``) so we read the intended
    event/season rather than the current default. The results page is the
    default tab; the seznam (registration) page adds ``tab=seznam``.
    """
    results = ""
    seznam = ""
    tid = _tournament_id_from_url(tournament_url)
    if tid:
        parts = urlparse(tournament_url)
        if not parts.scheme:
            parts = urlparse(f"{BASE}/turnaj/{tid}")
        query = {k: v for k, v in parse_qsl(parts.query) if k != "tab"}
        results = urlunparse(parts._replace(query=urlencode(query)))
        seznam = urlunparse(parts._replace(query=urlencode({**query, "tab": "seznam"})))
    return tid, results, seznam


# ─────────────────────────────────────────────────────────────────────────────
# Tournament-level parsing
# ─────────────────────────────────────────────────────────────────────────────

def parse_tournament(sel, tournament_id="", tournament_url="", tournament_type=""):
    """Parse all tournament-level fields from a page (seznam or results)."""
    info = _info_blocks(sel)

    tournament_name = (sel.css("h1::text").get() or "").strip()
    draw_name = (sel.css("div.box--blue h4::text").get() or "").strip()

    date_raw = info.get("Datum", "")
    tournament_start_date = _parse_start_date(date_raw)
    tournament_end_date = _parse_end_date(date_raw)
    date = tournament_start_date  # match date = event start

    surface_raw = next(
        (v for k, v in info.items() if "Dvorců" in k or "povrch" in k), ""
    )

    # e.g. "TK Kunštát (C - 500), U hřiště 514, Kunštát"
    organiser_raw = info.get("Pořadatel", "")
    org_parts = [x.strip() for x in organiser_raw.split(",") if x.strip()]
    tournament_host = org_parts[0] if org_parts else ""
    tournament_city = org_parts[-1] if len(org_parts) >= 2 else ""

    tid = str(tournament_id) if tournament_id else ""
    if not tid:
        code = info.get("Kódové číslo", "")
        cm = re.search(r"\d+", code)
        if cm:
            tid = cm.group(0)
    if not tid:
        first_link = sel.xpath('//a[contains(@href, "/turnaj/")]/@href').get("") or ""
        tid = _tournament_id_from_url(first_link)

    # Gender comes from the listing's type label and the page's own category
    # wording; the old id-prefix rule ("2..." = women) only survives as a
    # last-resort fallback because it does not hold for all listings.
    draw_gender = _detect_gender(sel, tournament_type, tid)

    return {
        "draw_name": draw_name,
        "draw_team_type": "Singles",
        "draw_gender": draw_gender,
        "draw_bracket_value": "",
        "draw_bracket_type": "",
        "draw_type": "",
        "ball_type": "Yellow",  # spec: always Yellow
        "tournament_name": tournament_name,
        "tournament_host": tournament_host,
        "tournament_city": tournament_city,
        "tournament_state": "",
        "tournament_country": "Czech",
        "tournament_country_code": "CZ",
        "tournament_location_type": "",
        "tournament_event_category": "",
        "tournament_event_grade": "",
        "tournament_import_source": "",
        "tournament_sanction_body": "",
        "tournament_event_type": "",
        "tournament_url": tournament_url,
        "tournament_start_date": tournament_start_date,
        "tournament_end_date": tournament_end_date,
        "date": date,
        "outcome": "Completed",
        "id_type": "Czech",
        "winner_1_country": "Czech",
        "loser_1_country": "Czech",
        "winner_2_country": "",
        "loser_2_country": "",
        "_tid": tid,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Player parsing (registration list "seznam" page)
# ─────────────────────────────────────────────────────────────────────────────

def parse_players(sel, draw_gender):
    """
    Returns {third_party_id: player_dict} for every player in every
    registration table on the page (main draw, alternates, withdrawn).
    """
    players = {}
    for row in sel.xpath("//table/tbody/tr"):
        tds = row.xpath("td")
        if len(tds) < 3:
            continue
        link = tds[1].xpath(".//a/@href").get("") or ""
        mid = re.search(r"/hrac/(\d+)", link)
        pid = mid.group(1) if mid else ""
        if not pid or pid in players:
            continue
        raw_name = (
            tds[1].xpath(".//a/@title").get("")
            or tds[1].xpath(".//a/text()").get("")
            or ""
        )
        name = _normalise_name(raw_name)
        yob = (tds[2].xpath("text()").get() or "").strip()
        players[pid] = {
            "name": name,
            "gender": draw_gender,
            "third_party_id": pid,
            "dob": f"1/1/{yob}" if re.fullmatch(r"\d{4}", yob) else "",
            "city": "",
            "state": "",
            "country": "Czech",
            "college": "",
        }
    return players


# ─────────────────────────────────────────────────────────────────────────────
# Match-row / match-block parsing
# ─────────────────────────────────────────────────────────────────────────────

def _row_side(row):
    """Extract player ids, names, set-scores and winner flag from one bracket row."""
    ids, names = [], []
    for a in row.css("span.name a"):
        href = a.attrib.get("href", "")
        mid = re.search(r"/hrac/(\d+)", href)
        raw = a.attrib.get("title") or " ".join(a.css("::text").getall())
        name = _normalise_name(raw)
        if mid:
            ids.append(mid.group(1))
            names.append(name)
        elif name:
            names.append(name)
    sets = []
    for td in row.css("td"):
        cls = _td_classes(td)
        if "result" in cls and "live-cell" not in cls:
            sets.append((td.css("::text").get() or "").strip())
    return {"ids": ids, "names": names, "sets": sets, "winner": bool(row.css("strong"))}


def _resolve_player(players, draw_gender, pid, fallback_name=""):
    p = players.get(pid)
    if p is None:
        return {
            "name": fallback_name, "gender": draw_gender,
            "third_party_id": pid, "dob": "",
            "city": "", "state": "", "country": "Czech", "college": "",
        }
    p = dict(p)
    if not p["name"]:
        p["name"] = fallback_name
    return p


def _build_score(win_sets, lose_sets):
    """
    Winner-perspective score, e.g. "6-1, 6-4;".
    Numeric columns are completed sets; a non-numeric cell (e.g. "scr.", "w.o")
    is a retirement/walkover marker, not a set half, and is appended once after
    the completed sets ("3-0 scr.;").
    """
    pairs, status = [], ""
    for w, l in zip(win_sets, lose_sets):
        if w.isdigit() and l.isdigit():
            pairs.append(f"{w}-{l}")
        else:
            token = w if (w and not w.isdigit()) else (l if (l and not l.isdigit()) else "")
            if token:
                status = token
    score = ", ".join(pairs)
    if status:
        score = f"{score} {status}".strip()
    if score and not score.endswith(";"):
        score += ";"
    return score


def parse_match_block(match_sel, players, tournament, draw_team_type="Singles", position=0):
    """Parse one <div class="bracket__match"> into (record, match_id) or None."""
    rows = match_sel.css("tr.player-row")
    if len(rows) < 2:
        return None
    a = _row_side(rows[0])
    b = _row_side(rows[1])

    # Need both sides populated (skip byes / unplayed slots).
    if not (a["ids"] or a["names"]) or not (b["ids"] or b["names"]):
        return None

    # Winner is the side rendered in bold; default to side A if neither flag.
    if b["winner"] and not a["winner"]:
        win, lose = b, a
    else:
        win, lose = a, b

    # Skip matches that were never played (no score on either side).
    if not any(win["sets"]) and not any(lose["sets"]):
        return None

    score = _build_score(win["sets"], lose["sets"])

    team_type = "Doubles" if max(len(a["names"]), len(b["names"])) >= 2 else draw_team_type
    gender = tournament["draw_gender"]

    def side_player(side, idx):
        pid = side["ids"][idx] if idx < len(side["ids"]) else ""
        nm = side["names"][idx] if idx < len(side["names"]) else ""
        if not pid and not nm:
            return None
        return _resolve_player(players, gender, pid, nm)

    winner1 = side_player(win, 0)
    loser1 = side_player(lose, 0)
    winner2 = side_player(win, 1) if team_type == "Doubles" else None
    loser2 = side_player(lose, 1) if team_type == "Doubles" else None

    record = _build_match_record(tournament, winner1, loser1, score, team_type, winner2, loser2)

    # No per-match GUID exists in the markup, so build a stable dedup key from
    # the tournament id + bracket position + player ids. The position keeps the
    # same matchup/score from colliding (round-robin / repeat meetings).
    ids = [p["third_party_id"] for p in (winner1, winner2, loser1, loser2) if p]
    match_id = "-".join([tournament.get("_tid", ""), str(position)] + ids).strip("-")

    return record, match_id


def _build_match_record(tournament, winner, loser, score, draw_team_type, winner2, loser2):
    """Combine tournament fields + players into a full flat match record."""

    def player_fields(prefix, p):
        if p is None:
            return {
                f"{prefix}_name": "", f"{prefix}_gender": "",
                f"{prefix}_third_party_id": "", f"{prefix}_city": "",
                f"{prefix}_state": "", f"{prefix}_country": "",
                f"{prefix}_college": "", f"{prefix}_dob": "",
            }
        return {
            f"{prefix}_name": p["name"],
            f"{prefix}_gender": p["gender"],
            f"{prefix}_third_party_id": p["third_party_id"],
            f"{prefix}_city": p["city"],
            f"{prefix}_state": p["state"],
            f"{prefix}_country": p["country"],
            f"{prefix}_college": p["college"],
            f"{prefix}_dob": p["dob"],
        }

    rec = {
        "ball_type": tournament["ball_type"],
        "draw_bracket_value": tournament["draw_bracket_value"],
        "draw_name": tournament["draw_name"],
        "draw_team_type": draw_team_type,
        "date": tournament["date"],
        "score": score,
        "outcome": tournament["outcome"],
        "id_type": tournament["id_type"],
        "draw_gender": tournament["draw_gender"],
        "draw_bracket_type": tournament["draw_bracket_type"],
        "draw_type": tournament["draw_type"],
    }
    rec.update(player_fields("winner_1", winner))
    rec.update(player_fields("winner_2", winner2))
    rec.update(player_fields("loser_1", loser))
    rec.update(player_fields("loser_2", loser2))
    rec.update({
        "tournament_name": tournament["tournament_name"],
        "tournament_city": tournament["tournament_city"],
        "tournament_state": tournament["tournament_state"],
        "tournament_country": tournament["tournament_country"],
        "tournament_country_code": tournament["tournament_country_code"],
        "tournament_host": tournament["tournament_host"],
        "tournament_location_type": tournament["tournament_location_type"],
        "tournament_event_category": tournament["tournament_event_category"],
        "tournament_event_grade": tournament["tournament_event_grade"],
        "tournament_import_source": tournament["tournament_import_source"],
        "tournament_sanction_body": tournament["tournament_sanction_body"],
        "tournament_event_type": tournament["tournament_event_type"],
        "tournament_url": tournament["tournament_url"],
        "tournament_start_date": tournament["tournament_start_date"],
        "tournament_end_date": tournament["tournament_end_date"],
    })
    # Doubles partners share the singles country default.
    if draw_team_type == "Doubles":
        if winner2:
            rec["winner_2_country"] = winner2.get("country", "Czech")
        if loser2:
            rec["loser_2_country"] = loser2.get("country", "Czech")
    return rec


class DetailsParser:

    def __init__(self, progress):
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=True, use_proxy=self.use_proxy)

    def parse_site(self, spider_id, job_id, tournament_chunk, main_task, thread_task, progress):
        try:
            for tournament_data in tournament_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    tournament_url = tournament_data.get("tournament_url", "")
                    tournament_type = tournament_data.get("tournament_type", "")
                    logger.info(f'tournament_type: {tournament_type} | {tournament_url}')

                    headers = {
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                        'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6,fr-FR;q=0.5',
                        'upgrade-insecure-requests': '1',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0',
                    }

                    # cesky-tenis.cz needs two pages: the registration list ("seznam")
                    # for tournament info + players (year of birth), and the results
                    # page for the singles/doubles match brackets. Query params from
                    # the source URL (e.g. sezona) are preserved.
                    tid, results_url, seznam_url = _build_urls(tournament_url)

                    if tid:
                        seznam_resp = self.fctrequest.request(method='GET', link=seznam_url, headers=headers, proxies=self.proxies, tries=3)
                        results_resp = self.fctrequest.request(method='GET', link=results_url, headers=headers, proxies=self.proxies, tries=3)

                        if not seznam_resp or seznam_resp.status_code not in range(200, 300):
                            logger.error(f'seznam request failed: {seznam_url}')
                            continue
                        if not results_resp or results_resp.status_code not in range(200, 300):
                            logger.error(f'results request failed: {results_url}')
                            continue

                        seznam_sel = Selector(text=seznam_resp.text)
                        results_sel = Selector(text=results_resp.text)

                        tournament = parse_tournament(seznam_sel, tid, tournament_url, tournament_type)
                        players = parse_players(seznam_sel, tournament["draw_gender"])

                        self.parse_match(spider_id, job_id, tournament, players, results_sel)

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())

    def parse_match(self, spider_id, job_id, tournament, players, results_sel):
        try:
            for position, match_div in enumerate(results_sel.css("div.bracket__match")):
                parsed = parse_match_block(match_div, players, tournament, position=position)
                if not parsed:
                    continue
                record, match_id = parsed
                logger.info(f'new: match_id: {match_id}')
                self.parse_profile(spider_id, job_id, match_id, record)
        except Exception:
            logger.error(traceback.format_exc())

    def parse_profile(self, spider_id, job_id, match_id, record):
        try:
            winner_1_name = record["winner_1_name"]
            winner_2_name = record["winner_2_name"]
            loser_1_name = record["loser_1_name"]
            loser_2_name = record["loser_2_name"]
            score = record["score"]

            if record["draw_gender"] == 'F':
                draw_gender = 'Female'
            else:
                draw_gender = 'Male'

            if not JobsItemsCzechScraperModel.objects.filter(
                spider_id=spider_id, job_id=job_id,
                winner_1_name=winner_1_name, loser_1_name=loser_1_name,
                winner_2_name=winner_2_name, loser_2_name=loser_2_name,
                score=score,
            ).exists():
                logger.info(f'match_id: {match_id}')
                logger.info(f'draw_name: {record["draw_name"]}')
                logger.info(f'draw_team_type: {record["draw_team_type"]}')
                logger.info(f'tournament_name: {record["tournament_name"]}')
                logger.info(f'date: {record["date"]}')
                logger.info(f'score: {score}')
                logger.info(f'winner_1_name: {winner_1_name}')
                logger.info(f'winner_1_gender: {record["winner_1_gender"]}')
                logger.info(f'winner_1_third_party_id: {record["winner_1_third_party_id"]}')
                logger.info(f'winner_1_dob: {record["winner_1_dob"]}')
                logger.info(f'winner_2_name: {winner_2_name}')
                logger.info(f'winner_2_gender: {record["winner_2_gender"]}')
                logger.info(f'winner_2_third_party_id: {record["winner_2_third_party_id"]}')
                logger.info(f'winner_2_dob: {record["winner_2_dob"]}')
                logger.info(f'loser_1_name: {loser_1_name}')
                logger.info(f'loser_1_gender: {record["loser_1_gender"]}')
                logger.info(f'loser_1_third_party_id: {record["loser_1_third_party_id"]}')
                logger.info(f'loser_1_dob: {record["loser_1_dob"]}')
                logger.info(f'loser_2_name: {loser_2_name}')
                logger.info(f'loser_2_gender: {record["loser_2_gender"]}')
                logger.info(f'loser_2_third_party_id: {record["loser_2_third_party_id"]}')
                logger.info(f'loser_2_dob: {record["loser_2_dob"]}')
                logger.info(f'outcome: {record["outcome"]}')
                logger.info(f'draw_gender: {draw_gender}')
                logger.info(f'tournament_city: {record["tournament_city"]}')
                logger.info(f'tournament_country_code: {record["tournament_country_code"]}')
                logger.info(f'tournament_url: {record["tournament_url"]}')
                logger.info(f'tournament_country: {record["tournament_country"]}')
                logger.info(f'tournament_start_date: {record["tournament_start_date"]}')
                logger.info(f'tournament_end_date: {record["tournament_end_date"]}')
                logger.info('*' * 50)

                JobsItemsCzechScraperModel(
                    spider_id=spider_id,
                    job_id=job_id,
                    ball_type=record["ball_type"],
                    draw_bracket_value=record["draw_bracket_value"],
                    draw_name=record["draw_name"],
                    draw_team_type=record["draw_team_type"],
                    tournament_name=record["tournament_name"],
                    date=record["date"],
                    score=score,
                    winner_1_name=winner_1_name,
                    winner_1_gender=record["winner_1_gender"],
                    winner_1_third_party_id=record["winner_1_third_party_id"],
                    winner_1_city=record["winner_1_city"],
                    winner_1_state=record["winner_1_state"],
                    winner_2_name=winner_2_name,
                    winner_2_gender=record["winner_2_gender"],
                    winner_2_third_party_id=record["winner_2_third_party_id"],
                    winner_2_city=record["winner_2_city"],
                    winner_2_state=record["winner_2_state"],
                    loser_1_name=loser_1_name,
                    loser_1_gender=record["loser_1_gender"],
                    loser_1_third_party_id=record["loser_1_third_party_id"],
                    loser_1_city=record["loser_1_city"],
                    loser_1_state=record["loser_1_state"],
                    loser_2_name=loser_2_name,
                    loser_2_gender=record["loser_2_gender"],
                    loser_2_third_party_id=record["loser_2_third_party_id"],
                    loser_2_city=record["loser_2_city"],
                    loser_2_state=record["loser_2_state"],
                    outcome=record["outcome"],
                    id_type=record["id_type"],
                    draw_gender=draw_gender,
                    draw_bracket_type=record["draw_bracket_type"],
                    draw_type=record["draw_type"],
                    tournament_city=record["tournament_city"],
                    tournament_state=record["tournament_state"],
                    tournament_country_code=record["tournament_country_code"],
                    tournament_host=record["tournament_host"],
                    tournament_location_type=record["tournament_location_type"],
                    tournament_surface="",
                    tournament_event_category=record["tournament_event_category"],
                    tournament_event_grade=record["tournament_event_grade"],
                    tournament_import_source=record["tournament_import_source"],
                    tournament_sanction_body=record["tournament_sanction_body"],
                    winner_2_country=record["winner_2_country"],
                    winner_2_college=record["winner_2_college"],
                    loser_2_country=record["loser_2_country"],
                    loser_2_college=record["loser_2_college"],
                    tournament_event_type=record["tournament_event_type"],
                    winner_1_college=record["winner_1_college"],
                    loser_1_college=record["loser_1_college"],
                    tournament_url=record["tournament_url"],
                    winner_1_dob=record["winner_1_dob"],
                    winner_2_dob=record["winner_2_dob"],
                    loser_1_dob=record["loser_1_dob"],
                    loser_2_dob=record["loser_2_dob"],
                    winner_1_country=record["winner_1_country"],
                    loser_1_country=record["loser_1_country"],
                    tournament_country=record["tournament_country"],
                    tournament_start_date=record["tournament_start_date"],
                    tournament_end_date=record["tournament_end_date"],
                ).save()
        except Exception:
            logger.error(traceback.format_exc())
