import traceback, re
from datetime import datetime
from django.conf import settings
from scrapy.selector import Selector
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts.log_items import ItemsLogger

class SeasonParser:
    def __init__(self):
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=True, use_proxy=self.use_proxy)

        self.df_season = ItemsLogger()
        self.filter_years = [datetime.now().year, datetime.now().year - 1]
        self.menu_slugs = ['dospeli', 'dorost', 'starsi-zactvo', 'mladsi-zactvo']


    def parse_season(self):
        try:
            for menu_slug in self.menu_slugs:
                index_link = f'https://cesky-tenis.cz/jednotlivci/{menu_slug}?v=1&individualsControl-sort=datumOd&individualsControl-direction=asc'
                logger.info(f'index_link: {index_link}')

                headers = {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                    'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6,fr-FR;q=0.5',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0',
                }

                response1 = self.fctrequest.request(method='GET', link=index_link, headers=headers, proxies=self.proxies, tries=3)
                if response1:
                    if response1.status_code in range(200, 300):
                        html1 = Selector(text=response1.text)

                        for d1 in html1.xpath('//select[@id="frm-individualsControl-individualsForm-sezona"]/option'):
                            season_name = fctcore.parse_field('./text()', d1)
                            season_value = fctcore.parse_field('./@value', d1)

                            if self.filter_by_years(season_name):
                                self.df_season.log({
                                    "menu_slug": menu_slug,
                                    "season_name": season_name,
                                    "season_value": season_value,
                                })

        except Exception:
            logger.error(traceback.format_exc())

        return self.df_season.get_df()

    def filter_by_years(self, text):
        items = [item.strip() for item in text.split(",")]
        result = []

        for item in items:
            found_years = set(int(y) for y in re.findall(r'\b\d{4}\b', item))
            if found_years and found_years.issubset(self.filter_years):
                result.append(item)

        return result