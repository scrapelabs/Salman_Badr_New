import traceback, re
from datetime import datetime, date
from django.db import close_old_connections
from django.conf import settings
from scrapy.selector import Selector
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts.log_items import ItemsLogger

class TournamentParser:
    def __init__(self, progress, job_start_date, job_end_date):
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=False, use_cffi=True, use_proxy=self.use_proxy)

        self.df_tournament = ItemsLogger()
        # Dedup guard: the same tournament can show up in more than one
        # season listing (and the season POST is not guaranteed to filter),
        # so remember every draw already logged. Keyed by tournament id +
        # gender column when an id exists, else by the raw URL.
        self.seen_draws = set()

        self.job_start_date = datetime.strptime(job_start_date, "%Y-%m-%d").date()
        self.job_end_date = datetime.strptime(job_end_date, "%Y-%m-%d").date()

    def parse_tournament(self, season_chunk, main_task, thread_task, progress):
        try:
            for season_data in season_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                menu_slug = season_data['menu_slug']
                season_name = season_data['season_name']
                season_value = season_data['season_value']

                headers = {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                    'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6,fr-FR;q=0.5',
                    'content-type': 'application/x-www-form-urlencoded',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0',
                }

                data = {
                    'sezona': season_value,
                    'nazev': '',
                    '_do': 'individualsControl-individualsForm-submit',
                }

                index_link = f'https://cesky-tenis.cz/jednotlivci/{menu_slug}?v=1&individualsControl-sort=datumOd&individualsControl-direction=asc'
                logger.info(f'index_link: {index_link}')

                response1 = self.fctrequest.request(method='POST', link=index_link, headers=headers, data=data, proxies=self.proxies, tries=3)
                if response1:
                    if response1.status_code in range(200, 300):
                        html1 = Selector(text=response1.text)
                        # 'the draws on the left (muzi) are Male and right (Zeny) is Female, his is where it gets the player gender too'

                        # Column 5 holds the men's draw link, column 6 the
                        # women's. One pass per column instead of two copies
                        # of the same loop; identical draws already logged in
                        # a previous season/listing are skipped.
                        for td_index, tournament_type in ((5, 'male'), (6, 'female')):
                            for d1 in html1.xpath('//table[@class="table__table"]//tr[not(th)]'):
                                tournament_date = fctcore.parse_field('./td[1]/text()[1]', d1)
                                tournament_url = fctcore.parse_field(f'./td[{td_index}]/span[@class="icons"]/a[contains(@href, "tab=seznam")]/@href', d1)

                                if tournament_date and tournament_url:
                                    tid_match = re.search(r'/turnaj/(\d+)', tournament_url)
                                    dedup_key = (tid_match.group(1), tournament_type) if tid_match else (tournament_url, tournament_type)
                                    if dedup_key in self.seen_draws:
                                        continue

                                    s, e = self.parse_european_range(tournament_date)
                                    is_included = self.is_range_included(tournament_date, self.job_start_date, self.job_end_date)
                                    # logger.info(f"{tournament_date:<30} {str(s):<14} {str(e):<14} {is_included}")

                                    if is_included:
                                        self.seen_draws.add(dedup_key)
                                        logger.info(f'tournament_date: {(tournament_date)}')
                                        logger.info(f'tournament_url: {(tournament_url)}')
                                        logger.info(f'tournament_type: {(tournament_type)}')
                                        logger.info(f'*'*50)

                                        self.df_tournament.log({
                                            "menu_slug": menu_slug,
                                            "season_name": season_name,
                                            "season_value": season_value,
                                            "tournament_date": tournament_date,
                                            "formatted_date": f"{tournament_date:<30} {str(s):<14} {str(e):<14} {is_included}",
                                            "tournament_url": tournament_url,
                                            "tournament_type": tournament_type,
                                        })

        except Exception:
            logger.error(traceback.format_exc())

        return self.df_tournament.get_df()

    def parse_european_range(self, range_str: str) -> tuple[date, date]:
        """
        Parses a European-style date range string into a (start, end) tuple.

        Supported formats:
            "28. 11.-2. 12. 2025"   -> cross-month range
            "1. 3.-15. 3. 2025"     -> same-month shorthand (month omitted on start)
            "18.-20. 4. 2026"       -> range, start month omitted
            "18. 7. 2026"           -> single day (start == end)

        Args:
            range_str: The European range string to parse.

        Returns:
            A tuple (start_date, end_date).

        Raises:
            ValueError: If the string cannot be parsed.
        """
        s = re.sub(r"\s+", " ", range_str.strip())

        # Range: "D. [M.]-D. M. YYYY"
        m = re.match(
            r"^(\d{1,2})\.\s*(\d{1,2})?\.?\s*-\s*(\d{1,2})\.\s*(\d{1,2})\.\s*(\d{4})$", s
        )
        if m:
            d1, m1_raw, d2, m2, yyyy = m.groups()
            year = int(yyyy)
            month2 = int(m2)
            month1 = int(m1_raw) if m1_raw else month2  # omitted → same month as end
            start = date(year, month1, int(d1))
            end = date(year, month2, int(d2))
            # Cross-year range, e.g. "28. 12.-2. 1. 2026": the printed year
            # belongs to the end date, so the start is in the previous year.
            # Without this, start > end and the containment check in
            # is_range_included passes for ANY window, leaking winter events
            # into every month.
            if start > end:
                start = date(year - 1, month1, int(d1))
            return start, end

        # Single day: "D. M. YYYY"
        m = re.match(r"^(\d{1,2})\.\s*(\d{1,2})\.\s*(\d{4})$", s)
        if m:
            d1, m1, yyyy = m.groups()
            single = date(int(yyyy), int(m1), int(d1))
            return single, single

        raise ValueError(f"Cannot parse European range: '{range_str}'")

    def is_range_included(
            self,
            european_range_str: str,
            window_start: date,
            window_end: date,
    ) -> bool:
        """
        Returns True if the European range falls entirely within [window_start, window_end].

        Both boundaries are inclusive: start >= window_start AND end <= window_end.

        Args:
            european_range_str: e.g. "28. 11.-2. 12. 2025"
            window_start:       Start of the reference window (inclusive).
            window_end:         End of the reference window (inclusive).

        Returns:
            True if the range is fully contained, False otherwise.
        """
        start, end = self.parse_european_range(european_range_str)
        return start >= window_start and end <= window_end

