import time
import pandas as pd
import concurrent.futures
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn
from assets.fct.fctlog import logger
from assets.fct import fctcore
from scripts.czech_scraper.parser.seasons import SeasonParser
from scripts.czech_scraper.parser.tournament import TournamentParser
from scripts.czech_scraper.parser.details import DetailsParser
from scripts import helper
from app_spiders.models import jobsModel

start_dt = time.time()

def run(*args):
    params = list(args)
    job_id = int(params[0])
    spider_name = params[1]
    folder_path = params[2]
    max_workers = int(params[3])

    base_file = f'{spider_name}__{job_id}__{fctcore.current_date("%Y-%m-%d_%H-%M")}.csv'

    job_obj = jobsModel.objects.get(id=job_id)
    spider_id = job_obj.spider_id
    job_settings = job_obj.job_settings
    job_tournament_url = job_settings.get('tournament_url', '')
    job_range_date = job_settings.get('range_date', '')
    job_start_date = job_end_date = ''
    if job_range_date and ' to ' in job_range_date:
        job_tab_date = job_range_date.split(' to ')
        job_start_date = fctcore.convert_string_to_date_format(date_str=job_tab_date[0], in_format='%m/%d/%Y', out_format='%Y-%m-%d')
        job_end_date = fctcore.convert_string_to_date_format(date_str=job_tab_date[1], in_format='%m/%d/%Y', out_format='%Y-%m-%d')
    logger.info(f'spider_name: {spider_name} | job_id: {job_id} | job_range_date: {job_range_date} | job_start_date: {job_start_date} | job_end_date: {job_end_date} | job_tournament_url: {job_tournament_url}')

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(), TextColumn("{task.completed}/{task.total}"), TimeElapsedColumn(), TimeRemainingColumn(), transient=False) as progress:
        if not job_tournament_url:
            df_season = SeasonParser().parse_season()
            logger.info(f'df_season: {len(df_season)}')

            if not df_season.empty:
                season_list = df_season.to_dict("records")
                season_chunks = list(fctcore.split_list_into_chunks(lst=season_list, max_workers=max_workers))
                if max_workers > len(season_chunks): max_workers=len(season_chunks)

                futures = []
                with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                    main_task = progress.add_task(description=f'{spider_name}_tournament', total=len(season_list))
                    for thread_id, season_chunk in enumerate(season_chunks):
                        thread_task = progress.add_task(f"Thread {thread_id + 1}", total=len(season_chunk))
                        future = executor.submit(TournamentParser(progress, job_start_date, job_end_date).parse_tournament, season_chunk, main_task, thread_task, progress)
                        futures.append(future)

                results = [f.result() for f in concurrent.futures.as_completed(futures)]
                df_tournament = pd.concat(results, ignore_index=True)

                logger.info(f'df_tournament: {(df_tournament)}')
                logger.info(f'df_tournament: {len(df_tournament)}')

                # df_tournament.to_excel("df_tournament.xlsx")
                # fctcore.exit()

            if not df_tournament.empty:
                tournament_list = df_tournament.to_dict("records")
                tournament_chunks = list(fctcore.split_list_into_chunks(lst=tournament_list, max_workers=max_workers))
                if max_workers > len(tournament_chunks): max_workers=len(tournament_chunks)

                with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                    main_task = progress.add_task(description=f'{spider_name}_results', total=len(tournament_list))
                    for thread_id, tournament_chunk in enumerate(tournament_chunks):
                        thread_task = progress.add_task(f"Thread {thread_id + 1}", total=len(tournament_chunk))
                        executor.submit(DetailsParser(progress).parse_site, spider_id, job_id, tournament_chunk, main_task, thread_task, progress)

        else:
            df_tournament = pd.DataFrame([{
                "tournament_url": job_tournament_url,
            }])

            if not df_tournament.empty:
                tournament_list = df_tournament.to_dict("records")
                main_task = progress.add_task(description=f'{spider_name}_results', total=len(tournament_list))
                thread_task = progress.add_task("Sequential", total=len(tournament_list))
                DetailsParser(progress).parse_site(spider_id, job_id, tournament_list, main_task, thread_task, progress)

        helper.finalize_items_from_db(job_obj, folder_path, base_file)
        helper.finalize_job(job_obj, base_file, folder_path)

    logger.info(f'script take {round(time.time()-start_dt, 2)} sec to finished')
