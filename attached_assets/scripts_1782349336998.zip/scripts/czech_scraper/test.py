html_text1 = '''

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="author" content="OKsystem a.s.">
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
	<meta name="viewport" content="width=device-width">

	<meta name="robots" content="index, follow">
	<meta name="description" content="">

	<meta property="og:title" content="Tenis Semice a.s. (D - 400) | Český tenisový svaz">
	<meta property="og:image" content="https://www.cztenis.cz/fb.jpg">
	<meta property="og:locale" content="cs_CZ">
	<meta property="og:description" content="">

	<title>Tenis Semice a.s. (D - 400) | Český tenisový svaz</title>
</head>
<body>
</body>
</html>
'''

import logging
import re
import coloredlogs
from scrapy.selector import Selector
from datetime import datetime

logger = logging.getLogger("scraper")
logger.setLevel(logging.INFO)
coloredlogs.install(level="INFO", logger=logger)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _parse_start_date(raw: str) -> str:
    """'8.-9. 5. 2026' or '07.05.2026 …'  →  m/d/yyyy"""
    raw = raw.strip()
    m = re.match(r"(\d+)\.\s*(?:-\s*\d+\.)?\s*(\d+)\.\s*(\d{4})", raw)
    if m:
        return f"{int(m.group(2))}/{int(m.group(1))}/{m.group(3)}"
    m = re.match(r"(\d{2})\.(\d{2})\.(\d{4})", raw)
    if m:
        return f"{int(m.group(2))}/{int(m.group(1))}/{m.group(3)}"
    return raw


def _parse_end_date(raw: str) -> str:
    """'8.-9. 5. 2026'  →  end date as m/d/yyyy; single day → same as start."""
    raw = raw.strip()
    m = re.match(r"\d+\.\s*-\s*(\d+)\.\s*(\d+)\.\s*(\d{4})", raw)
    if m:
        return f"{int(m.group(2))}/{int(m.group(1))}/{m.group(3)}"
    return _parse_start_date(raw)


def _normalise_name(raw: str) -> str:
    """
    Czech pages list names as 'Lastname Firstname' (sometimes with extra spaces).
    Convert to 'Lastname, Firstname'.
    """
    raw = re.sub(r"\s+", " ", raw.strip())
    parts = raw.split(" ", 1)
    return f"{parts[0]}, {parts[1]}" if len(parts) == 2 else raw


def _info_blocks(sel: Selector) -> dict:
    """Return {label: value} for every <p class="info"> on the page."""
    result = {}
    for p in sel.css("p.info"):
        label = p.css("span::text").get("").strip()
        if not label:
            continue
        texts = [t.strip() for t in p.css("*::text").getall()
                 if t.strip() and t.strip() != label]
        result[label] = " ".join(texts).strip()
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Tournament-level parsing
# ─────────────────────────────────────────────────────────────────────────────

def parse_tournament(sel: Selector) -> dict:
    """Parse all tournament-level fields from the page."""

    info = _info_blocks(sel)

    # ── Name ──────────────────────────────────────────────────────────────
    tournament_name = sel.css("h1::text").get("").strip()

    # ── Draw name (section header in the blue summary box) ────────────────
    draw_name = sel.css("div.box--blue h4::text").get("").strip()

    # ── Dates ─────────────────────────────────────────────────────────────
    date_raw              = info.get("Datum", "")
    tournament_start_date = _parse_start_date(date_raw)
    tournament_end_date   = _parse_end_date(date_raw)
    date                  = tournament_start_date   # match date = event start

    # ── Surface ───────────────────────────────────────────────────────────
    # "3 • antuka"  →  "Antuka"
    surface_raw = next(
        (v for k, v in info.items() if "Dvorců" in k or "povrch" in k), ""
    )
    tournament_surface = (
        surface_raw.split("•")[-1].strip().capitalize() if "•" in surface_raw
        else surface_raw.strip().capitalize()
    )

    # ── Ball type ─────────────────────────────────────────────────────────
    ball_type = info.get("Míče", "Yellow").strip().capitalize() or "Yellow"

    # ── Organiser / host / city ───────────────────────────────────────────
    # e.g. "Tenis Semice a.s. (D - 400), Semice 346, Semice"
    organiser_raw = info.get("Pořadatel", "")
    org_parts = [x.strip() for x in organiser_raw.split(",")]
    tournament_host = org_parts[0] if org_parts else ""
    tournament_city = org_parts[-1] if len(org_parts) >= 2 else ""

    # ── Tournament URL ────────────────────────────────────────────────────
    first_link = sel.xpath('//a[contains(@href, "/turnaj/")]/@href').get("")
    tid_m = re.search(r"/turnaj/(\d+)", first_link)
    tid = tid_m.group(1) if tid_m else ""
    tournament_url = f"https://cesky-tenis.cz/turnaj/{tid}" if tid else ""

    # ── Gender (inferred from the "back" breadcrumb link) ─────────────────
    back_href = sel.xpath('//a[contains(@href, "/jednotlivci/")]/@href').get("")
    draw_gender = "F" if "zen" in back_href.lower() else "M"

    return {
        # Draw
        "draw_name":                draw_name,
        "draw_team_type":           "Singles",
        "draw_gender":              draw_gender,
        "draw_bracket_value":       "",
        "draw_bracket_type":        "",
        "draw_type":                "",
        # Ball
        "ball_type":                ball_type,
        # Tournament
        "tournament_name":          tournament_name,
        "tournament_host":          tournament_host,
        "tournament_city":          tournament_city,
        "tournament_state":         "",
        "tournament_country":       "Czech",
        "tournament_country_code":  "CZ",
        "tournament_surface":       tournament_surface,
        "tournament_location_type": "",
        "tournament_event_category":"",
        "tournament_event_grade":   "",
        "tournament_import_source": "",
        "tournament_sanction_body": "",
        "tournament_event_type":    "",
        "tournament_url":           tournament_url,
        "tournament_start_date":    tournament_start_date,
        "tournament_end_date":      tournament_end_date,
        # Match defaults
        "date":                     date,
        "outcome":                  "Completed",
        "id_type":                  "Czech",
        "winner_1_country":         "Czech",
        "loser_1_country":          "Czech",
        "winner_2_country":         "",
        "loser_2_country":          "",
    }


# ─────────────────────────────────────────────────────────────────────────────
# Player parsing
# ─────────────────────────────────────────────────────────────────────────────

def parse_players(sel: Selector, draw_gender: str) -> dict:
    """
    Returns {third_party_id: player_dict} for every player in every
    registration table on the page (main draw, alternates, withdrawn).
    """
    players = {}
    for row in sel.xpath("//table/tbody/tr"):
        tds = row.xpath("td")
        if len(tds) < 3:
            continue
        link = tds[1].xpath("a/@href").get("") or ""
        mid  = re.search(r"/hrac/(\d+)", link)
        pid  = mid.group(1) if mid else ""
        if not pid or pid in players:
            continue
        raw_name = (
            tds[1].xpath("a/@title").get("")
            or tds[1].xpath("a/text()").get("")
            or ""
        )
        name = _normalise_name(raw_name)
        yob  = tds[2].xpath("text()").get("").strip()
        players[pid] = {
            "name":           name,
            "gender":         draw_gender,
            "third_party_id": pid,
            "dob":            f"1/1/{yob}" if yob else "",
            "city":           "",
            "state":          "",
            "country":        "Czech",
            "college":        "",
        }
    return players


# ─────────────────────────────────────────────────────────────────────────────
# Match record builder
# ─────────────────────────────────────────────────────────────────────────────

def build_match_record(
    tournament:     dict,
    winner:         dict,
    loser:          dict,
    score:          str = "",
    draw_team_type: str = "Singles",
    winner2:        dict | None = None,
    loser2:         dict | None = None,
) -> dict:
    """
    Combine tournament fields + winner + loser into a full flat match record.
    Pass winner2 / loser2 for Doubles.
    """
    def player_fields(prefix: str, p: dict | None) -> dict:
        if p is None:
            return {
                f"{prefix}_name": "", f"{prefix}_gender": "",
                f"{prefix}_third_party_id": "", f"{prefix}_city": "",
                f"{prefix}_state": "", f"{prefix}_country": "",
                f"{prefix}_college": "", f"{prefix}_dob": "",
            }
        return {
            f"{prefix}_name":           p["name"],
            f"{prefix}_gender":         p["gender"],
            f"{prefix}_third_party_id": p["third_party_id"],
            f"{prefix}_city":           p["city"],
            f"{prefix}_state":          p["state"],
            f"{prefix}_country":        p["country"],
            f"{prefix}_college":        p["college"],
            f"{prefix}_dob":            p["dob"],
        }

    rec = {
        "ball_type":          tournament["ball_type"],
        "draw_bracket_value": tournament["draw_bracket_value"],
        "draw_name":          tournament["draw_name"],
        "draw_team_type":     draw_team_type,
        "date":               tournament["date"],
        "score":              score,
        "outcome":            tournament["outcome"],
        "id_type":            tournament["id_type"],
        "draw_gender":        tournament["draw_gender"],
        "draw_bracket_type":  tournament["draw_bracket_type"],
        "draw_type":          tournament["draw_type"],
    }
    rec.update(player_fields("winner_1", winner))
    rec.update(player_fields("winner_2", winner2))
    rec.update(player_fields("loser_1",  loser))
    rec.update(player_fields("loser_2",  loser2))
    rec.update({
        "tournament_name":           tournament["tournament_name"],
        "tournament_city":           tournament["tournament_city"],
        "tournament_state":          tournament["tournament_state"],
        "tournament_country":        tournament["tournament_country"],
        "tournament_country_code":   tournament["tournament_country_code"],
        "tournament_host":           tournament["tournament_host"],
        "tournament_location_type":  tournament["tournament_location_type"],
        "tournament_surface":        tournament["tournament_surface"],
        "tournament_event_category": tournament["tournament_event_category"],
        "tournament_event_grade":    tournament["tournament_event_grade"],
        "tournament_import_source":  tournament["tournament_import_source"],
        "tournament_sanction_body":  tournament["tournament_sanction_body"],
        "tournament_event_type":     tournament["tournament_event_type"],
        "tournament_url":            tournament["tournament_url"],
        "tournament_start_date":     tournament["tournament_start_date"],
        "tournament_end_date":       tournament["tournament_end_date"],
    })
    return rec


# ─────────────────────────────────────────────────────────────────────────────
# Main Parser class
# ─────────────────────────────────────────────────────────────────────────────

class Parser:

    def __init__(self, spider_name: str, sel: Selector):
        self.spider_name = spider_name
        self.sel         = sel
        self.tournament  = parse_tournament(sel)
        self.players     = parse_players(sel, self.tournament["draw_gender"])

    def get_players(self) -> list:
        """Return all registered players as a list of dicts."""
        return list(self.players.values())

    def _lookup_player(self, pid: str) -> dict:
        return self.players.get(pid, {
            "name": "", "gender": self.tournament["draw_gender"],
            "third_party_id": pid, "dob": "",
            "city": "", "state": "", "country": "Czech", "college": "",
        })

    def parse_match(self, game_sel: Selector) -> dict:
        """
        Parse one match block from the 'Hrací plány' (draw/results) tab.

        Expected HTML shape (adjust selectors to the live markup):

            <div class="game">
              <div class="game__player game__player--winner">
                <a href="/hrac/123456">Novák Jan</a>
              </div>
              <div class="game__player">
                <a href="/hrac/654321">Dvořák Petr</a>
              </div>
              <div class="game__score">6-2, 6-3</div>
            </div>

        NOTE: This HTML is the registration-list tab (seznam) — it has no
        match blocks.  Match results live on the 'Hrací plány' tab:
            https://cesky-tenis.cz/turnaj/<id>?sezona=L26#tabs
        Fetch that page separately and pass each game selector here.
        """

        def get_player(css_sel: str) -> dict:
            div  = game_sel.css(css_sel)
            link = div.xpath(".//a/@href").get("") or ""
            mid  = re.search(r"/hrac/(\d+)", link)
            pid  = mid.group(1) if mid else ""
            p    = self._lookup_player(pid)
            if not p["name"]:
                raw = (
                    div.xpath(".//a/@title").get("")
                    or div.xpath(".//a/text()").get("")
                    or ""
                )
                p["name"] = _normalise_name(raw)
            return p

        winner = get_player(".game__player--winner")
        loser  = get_player(".game__player:not(.game__player--winner)")

        # Score always from the winner's perspective
        raw_score = game_sel.css(".game__score::text").get("").strip()
        score = f"{raw_score};" if raw_score and not raw_score.endswith(";") else raw_score

        return build_match_record(
            self.tournament, winner, loser, score,
            self.tournament["draw_team_type"]
        )


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    html1  = Selector(text=html_text1)
    parser = Parser("spider_name", html1)

    logger.info("=== Tournament fields ===")
    for k, v in parser.tournament.items():
        logger.info(f"  {k:35s}: {v!r}")

    logger.info(f"\n=== Registered players ({len(parser.players)}) ===")
    for p in parser.get_players():
        logger.info(
            f"  [{p['third_party_id']:>8}]  {p['name']:<30}  dob={p['dob']}"
        )

    # ── Match results come from a different tab; no game divs on this page ──
    # When you fetch the draw/results page do:
    #
    #   results_html = Selector(text=<fetched HTML>)
    #   for game_div in results_html.css("div.game"):
    #       match = parser.parse_match(game_div)
    #       logger.info(f"match: {match}")
