import traceback, re
from scrapy.selector import Selector
from urllib.parse import urljoin
from datetime import datetime
from os.path import basename, dirname, abspath
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts import helper
from scripts.log_items import ItemsLogger
from scripts.tennis_europe.parser.utils import Utils
from app_spiders.models import ItemsTennisEuropeModel, PlayersTennisEuropeModel

class DetailsParser:

    def __init__(self, progress):
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=True, use_cffi=False, use_proxy=self.use_proxy)

        self.df_tournaments = ItemsLogger()
        self.spider_name = basename(dirname(dirname(abspath(__file__))))

        self.Utils = Utils(self.proxies, self.fctrequest)
        self.Utils.accept_cookies()

        self.DetailsTournamentParser = DetailsTournamentParser(self.Utils, self.spider_name, self.progress, self.proxies, self.use_proxy, self.fctrequest)
        self.DetailsSportParser = DetailsSportParser(self.Utils, self.spider_name, self.progress, self.proxies, self.use_proxy, self.fctrequest)


    def parse_site(self, spider_id, job_id, tournaments_chunk, main_task, thread_task, progress):
        try:
            for tournaments_data in tournaments_chunk:
                progress.update(main_task, advance=1)
                progress.update(thread_task, advance=1)
                close_old_connections()

                try:
                    tournament_id = tournaments_data.get("tournament_id", "")
                    tournament_name = tournaments_data.get("tournament_name", "")
                    tournament_url = tournaments_data.get("tournament_url", "")
                    tournament_start_date = tournaments_data.get("tournament_start_date", "")
                    tournament_end_date = tournaments_data.get("tournament_end_date", "")
                    tournament_city = tournaments_data.get("tournament_city", "")
                    tournament_country = tournaments_data.get("tournament_country", "")

                    logger.info(f'tournament_name: {tournament_name} | tournament_start_date: {tournament_start_date} | tournament_end_date: {tournament_end_date} | tournament_city: {tournament_city} | tournament_country: {tournament_country} | {tournament_url}')

                    data_found = self.DetailsTournamentParser.parse_players(spider_id, job_id, tournament_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_city, tournament_country)

                    if not data_found:
                        self.DetailsSportParser.parse_players(spider_id, job_id, tournament_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_city, tournament_country)

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())


class DetailsSportParser:

    def __init__(self, Utils, spider_name, progress, proxies, use_proxy, fctrequest):
        self.Utils = Utils
        self.progress = progress
        self.proxies = proxies
        self.use_proxy = use_proxy
        self.fctrequest = fctrequest
        self.spider_name = spider_name


    def parse_players(self, spider_id, job_id, tournament_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_city, tournament_country):
        data_found = False
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0',
            }
            index_link = f'https://te.tournamentsoftware.com/sport/players.aspx?id={tournament_id}'
            response1 = self.fctrequest.request(method='GET', link=index_link, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    for d1 in html1.xpath('//table[@class="players"]//tr//td//a[contains(@href, "/sport/player.aspx")]'):
                        data_found = True
                        player_name = fctcore.parse_field('./text()', d1)
                        player_url = urljoin(f'https://te.tournamentsoftware.com/', fctcore.parse_field('./@href', d1))

                        logger.info(f'player_name: {player_name} | player_url: {player_url}')
                        self.parse_matches(spider_id, job_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_city, tournament_country, player_url)

        except Exception:
            logger.error(traceback.format_exc())

        return data_found


    def parse_matches(self, spider_id, job_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_city, tournament_country, player_url):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=player_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    for d1 in html1.xpath('//div[@id="content"]//table[contains(@class, "matches")]//tbody//tr'):
                        match_round = ''
                        draw_name = fctcore.parse_field('./td[3]', d1)

                        match_date = ''
                        try:
                            match_date_pre = fctcore.parse_field('./td[1]', d1)
                            m = re.search(r"\b\d{2}/\d{2}/\d{4}\b", match_date_pre)
                            if m:
                                date_str = m.group()  # 03/01/2025
                                match_date = datetime.strptime(date_str, "%d/%m/%Y").strftime("%m/%d/%Y")
                        except Exception:
                            ''

                        logger.info(f'match_data d1: {d1.get()}')

                        match_data = self.parse_match(d1)
                        logger.info(f'match_data: {match_data}')

                        draw_team_type = match_data.get("draw_team_type", "")
                        outcome = match_data.get("outcome", "")
                        score = match_data.get("score", "")

                        winner_1_name = match_data.get("winner_1", {}).get('name', '')
                        winner_1_url = match_data.get("winner_1", {}).get('profile_url', '')
                        winner_1_country = match_data.get("winner_1", {}).get('player_country', '')

                        winner_2_name = match_data.get("winner_2", {}).get('name', '')
                        winner_2_url = match_data.get("winner_2", {}).get('profile_url', '')
                        winner_2_country = match_data.get("winner_2", {}).get('player_country', '')

                        loser_1_name = match_data.get("loser_1", {}).get('name', '')
                        loser_1_url = match_data.get("loser_1", {}).get('profile_url', '')
                        loser_1_country = match_data.get("loser_1", {}).get('player_country', '')

                        loser_2_name = match_data.get("loser_2", {}).get('name', '')
                        loser_2_url = match_data.get("loser_2", {}).get('profile_url', '')
                        loser_2_country = match_data.get("loser_2", {}).get('player_country', '')

                        if score:
                            logger.info(f'tournament_name: {tournament_name}')
                            logger.info(f'tournament_url: {tournament_url}')
                            logger.info(f'draw_name: {draw_name}')
                            logger.info(f'draw_team_type: {draw_team_type}')
                            logger.info(f'score: {score}')
                            logger.info(f'winner_1_name: {winner_1_name} | winner_1_country: {winner_1_country} | winner_2_name: {winner_2_name} | winner_2_country: {winner_2_country}')
                            logger.info(f'loser_1_name: {loser_1_name} | loser_1_country: {loser_1_country} | loser_2_name: {loser_2_name} | loser_2_country: {loser_2_country}')

                            self.parse_page(spider_id, job_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_city, tournament_country, draw_name,draw_team_type, score, outcome, winner_1_name, winner_2_name, loser_1_name, loser_2_name, winner_1_url, winner_2_url, loser_1_url, loser_2_url, winner_1_country, winner_2_country, loser_1_country, loser_2_country, match_round, match_date)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_page(self, spider_id, job_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_city, tournament_country, draw_name,draw_team_type, score, outcome, winner_1_name, winner_2_name, loser_1_name, loser_2_name, winner_1_url, winner_2_url, loser_1_url, loser_2_url, winner_1_country, winner_2_country, loser_1_country, loser_2_country, match_round, match_date):
        try:
            if not match_date:
                match_date = tournament_start_date

            id_type = 'Europe'
            match_id = ""
            ball_type = "Yellow"
            draw_bracket_value = ""
            draw_gender = ""
            date = match_date
            winner_1_city = ""
            winner_1_state = ""
            winner_2_city = ""
            winner_2_state = ""
            loser_1_city = ""
            loser_1_state = ""
            loser_2_city = ""
            loser_2_state = ""
            draw_bracket_type = ""
            draw_type = ""
            tournament_state = ""
            tournament_host = ""
            tournament_location_type = ""
            tournament_surface = ""
            tournament_event_category = ""
            tournament_event_grade = ""
            tournament_sanction_body = "Tennis Europe"
            winner_2_college = ""
            loser_2_college = ""
            tournament_event_type = "Tournament"
            winner_1_college = ""
            loser_1_college = ""

            winner_1_name, winner_1_third_party_id, winner_1_dob, winner_1_gender = self.parse_page_player(winner_1_url)
            winner_2_name, winner_2_third_party_id, winner_2_dob, winner_2_gender = self.parse_page_player(winner_2_url)
            loser_1_name, loser_1_third_party_id, loser_1_dob, loser_1_gender = self.parse_page_player(loser_1_url)
            loser_2_name, loser_2_third_party_id, loser_2_dob, loser_2_gender = self.parse_page_player(loser_2_url)

            tournament_import_source = 'Tennis Europe'
            tournament_country_code = tournament_country[0:3].upper()

            if winner_1_gender == 'M':
                draw_gender = "Male"
            elif winner_1_gender == 'F':
                draw_gender = "Female"

            if not ItemsTennisEuropeModel.objects.filter(spider_id=spider_id, job_id=job_id, winner_1_name=winner_1_name, loser_1_name=loser_1_name, winner_2_name=winner_2_name, loser_2_name=loser_2_name, score=score).exists():
                if 'local_' in winner_1_third_party_id: winner_1_third_party_id = ''
                if 'local_' in winner_2_third_party_id: winner_2_third_party_id = ''
                if 'local_' in loser_1_third_party_id: loser_1_third_party_id = ''
                if 'local_' in loser_2_third_party_id: loser_2_third_party_id = ''

                logger.info(f'match_id: {match_id}')
                logger.info(f'draw_name: {draw_name}')
                logger.info(f'draw_team_type: {draw_team_type}')
                logger.info(f'tournament_name: {tournament_name}')
                logger.info(f'date: {date}')
                logger.info(f'score: {score}')
                logger.info(f'winner_1_name: {winner_1_name}')
                logger.info(f'winner_1_gender: {winner_1_gender}')
                logger.info(f'winner_1_third_party_id: {winner_1_third_party_id}')
                logger.info(f'winner_1_dob: {winner_1_dob}')
                logger.info(f'winner_2_name: {winner_2_name}')
                logger.info(f'winner_2_gender: {winner_2_gender}')
                logger.info(f'winner_2_third_party_id: {winner_2_third_party_id}')
                logger.info(f'winner_2_dob: {winner_2_dob}')
                logger.info(f'loser_1_name: {loser_1_name}')
                logger.info(f'loser_1_gender: {loser_1_gender}')
                logger.info(f'loser_1_third_party_id: {loser_1_third_party_id}')
                logger.info(f'loser_1_dob: {loser_1_dob}')
                logger.info(f'loser_2_name: {loser_2_name}')
                logger.info(f'loser_2_gender: {loser_2_gender}')
                logger.info(f'loser_2_third_party_id: {loser_2_third_party_id}')
                logger.info(f'loser_2_dob: {loser_2_dob}')
                logger.info(f'outcome: {outcome}')
                logger.info(f'draw_gender: {draw_gender}')
                logger.info(f'tournament_city: {tournament_city}')
                logger.info(f'tournament_country_code: {tournament_country_code}')
                logger.info(f'tournament_url: {tournament_url}')
                logger.info(f'tournament_country: {tournament_country}')
                logger.info(f'tournament_start_date: {tournament_start_date}')
                logger.info(f'tournament_end_date: {tournament_end_date}')
                logger.info(f'match_round: {match_round}')
                logger.info('*' * 50)

                ItemsTennisEuropeModel(
                    spider_id=spider_id,
                    job_id=job_id,
                    match_id=match_id,
                    ball_type=ball_type,
                    draw_bracket_value=draw_bracket_value,
                    draw_name=draw_name,
                    draw_team_type=draw_team_type,
                    tournament_name=tournament_name,
                    date=date,
                    score=score,
                    winner_1_name=winner_1_name,
                    winner_1_gender=winner_1_gender,
                    winner_1_third_party_id=winner_1_third_party_id,
                    winner_1_city=winner_1_city,
                    winner_1_country=winner_1_country,
                    winner_1_state=winner_1_state,
                    winner_2_name=winner_2_name,
                    winner_2_gender=winner_2_gender,
                    winner_2_third_party_id=winner_2_third_party_id,
                    winner_2_city=winner_2_city,
                    winner_2_state=winner_2_state,
                    loser_1_name=loser_1_name,
                    loser_1_gender=loser_1_gender,
                    loser_1_third_party_id=loser_1_third_party_id,
                    loser_1_city=loser_1_city,
                    loser_1_state=loser_1_state,
                    loser_1_country=loser_1_country,
                    loser_2_name=loser_2_name,
                    loser_2_gender=loser_2_gender,
                    loser_2_third_party_id=loser_2_third_party_id,
                    loser_2_city=loser_2_city,
                    loser_2_state=loser_2_state,
                    outcome=outcome,
                    id_type=id_type,
                    draw_gender=draw_gender,
                    draw_bracket_type=draw_bracket_type,
                    draw_type=draw_type,
                    tournament_city=tournament_city,
                    tournament_state=tournament_state,
                    tournament_country_code=tournament_country_code,
                    tournament_host=tournament_host,
                    tournament_location_type=tournament_location_type,
                    tournament_surface=tournament_surface,
                    tournament_event_category=tournament_event_category,
                    tournament_event_grade=tournament_event_grade,
                    tournament_import_source=tournament_import_source,
                    tournament_sanction_body=tournament_sanction_body,
                    winner_2_country=winner_2_country,
                    winner_2_college=winner_2_college,
                    loser_2_country=loser_2_country,
                    loser_2_college=loser_2_college,
                    tournament_event_type=tournament_event_type,
                    winner_1_college=winner_1_college,
                    loser_1_college=loser_1_college,
                    tournament_url=tournament_url,
                    winner_1_dob=winner_1_dob,
                    winner_2_dob=winner_2_dob,
                    loser_1_dob=loser_1_dob,
                    loser_2_dob=loser_2_dob,
                    tournament_country=tournament_country,
                    tournament_start_date=tournament_start_date,
                    tournament_end_date=tournament_end_date,
                    round=match_round,
                ).save()

        except Exception:
            logger.error(traceback.format_exc())



    def parse_page_player(self, player_url):
        player_name = ''
        third_party_id = ''
        player_dob = ''
        player_gender = ''
        if player_url:
            try:
                headers = {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                    'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
                }

                response1 = self.fctrequest.request(method='GET', link=player_url, headers=headers, proxies=self.proxies, tries=3)
                if response1:
                    if response1.status_code in range(200, 300):
                        html1 = Selector(text=response1.text)

                        player_profile_pre = fctcore.parse_field('//div[@id="content"]//div[@class="subtitle"]//h2/a[@class="button"]/@href', html1)
                        logger.info(f'player_profile_pre: {player_profile_pre}')

                        if player_profile_pre:
                            third_party_id = ''
                            try:
                                third_party_id = player_profile_pre.split('/')[-1].strip().lower()
                            except Exception:
                                ''
                            logger.info(f'third_party_id: {third_party_id}')

                            if not third_party_id:
                                third_party_id = helper.sha256_id(player_name)

                            if third_party_id:
                                objs = PlayersTennisEuropeModel.objects.filter(spider_name=self.spider_name, third_party_id=third_party_id)
                                if objs.exists():
                                    obj = objs.first()
                                    player_name = obj.player_name
                                    player_dob = obj.dob
                                    player_gender = obj.gender

            except Exception:
                logger.error(traceback.format_exc())

        return player_name, third_party_id, player_dob, player_gender


    def parse_match(self, row):
        # ── Extract players from a side <td> ──────────────────────────────────────
        def extract_players(td: Selector) -> list[dict]:
            players = []
            for a in td.xpath(".//a[contains(@href, 'player.aspx')]"):
                country = td.xpath(".//a[contains(@href, 'matches.aspx')]/img/@title").get("")
                # Check if the <a> tag is directly inside a <strong> tag
                is_winner = bool(a.xpath("parent::strong").get())
                players.append({
                    "name": a.xpath("normalize-space(.)").get(""),
                    "profile_url": a.xpath("@href").get(""),
                    "highlighted": is_winner,
                    "country": country,
                })
            return players

        # FIX: use .//td[N] so it works when row is a full document selector
        left_players = extract_players(row.xpath(".//td[4]"))
        right_players = extract_players(row.xpath(".//td[6]"))

        # ── Determine winner by <strong> tag ──────────────────────────────────────
        left_wins = any(p["highlighted"] for p in left_players)

        winners = left_players if left_wins else right_players
        losers = right_players if left_wins else left_players

        # ── draw_team_type ────────────────────────────────────────────────────────
        draw_team_type = "Doubles" if len(winners) == 2 else "Singles"

        # ── Score ─────────────────────────────────────────────────────────────────
        raw_scores = row.xpath(".//span[@class='score']/span/text()").getall()

        # ── Outcome ───────────────────────────────────────────────────────────────
        outcome = "Completed"
        if row.xpath('.//*[contains(normalize-space(.), "Retired")]'):
            outcome = "Retired"
            raw_scores = [s for s in raw_scores if "retired" not in s.lower()]

        # FIX: flip each set score so it reflects the winner's perspective
        def flip_set(s: str) -> str:
            tb_match = re.search(r'(\(\d+\))$', s)
            tiebreak = tb_match.group(1) if tb_match else ""
            clean = s[:tb_match.start()] if tb_match else s
            parts = clean.split("-")
            if len(parts) == 2:
                return f"{parts[1]}-{parts[0]}{tiebreak}"
            return s

        if not left_wins:
            raw_scores = [flip_set(s) for s in raw_scores]

        score = ", ".join(raw_scores) + ";" if raw_scores else ""

        # ── Helper ────────────────────────────────────────────────────────────────
        def _player(lst: list[dict], idx: int) -> dict:
            if idx < len(lst):
                profile_url_pre = lst[idx]["profile_url"]
                if profile_url_pre:
                    profile_url = f'https://te.tournamentsoftware.com/sport/{profile_url_pre}'
                    return {
                        "name": self.clean_name(lst[idx]["name"]),
                        "profile_url": profile_url,
                        "player_country": lst[idx]["country"],
                    }
            return {}

        match_data = {
            "draw_team_type": draw_team_type,
            "outcome": outcome,
            "score": score,
            "winner_1": _player(winners, 0),
            "winner_2": _player(winners, 1),
            "loser_1": _player(losers, 0),
            "loser_2": _player(losers, 1),
        }
        return match_data


    def clean_name(self, name: str) -> str:
        return re.sub(r"\s*\[[^\]]+\]\s*$", "", name).strip()




class DetailsTournamentParser:

    def __init__(self, Utils, spider_name, progress, proxies, use_proxy, fctrequest):
        self.Utils = Utils
        self.progress = progress
        self.proxies = proxies
        self.use_proxy = use_proxy
        self.fctrequest = fctrequest
        self.spider_name = spider_name


    def parse_players(self, spider_id, job_id, tournament_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_city, tournament_country):
        data_found = False
        try:
            headers = {
                'accept': '*/*',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
                'x-requested-with': 'XMLHttpRequest',
            }

            data = {
                'X-Requested-With': 'XMLHttpRequest',
            }

            index_link = f'https://te.tournamentsoftware.com/tournament/{tournament_id.lower()}/Players/GetPlayersContent'
            response1 = self.fctrequest.request(method='POST', link=index_link, data=data, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    for d1 in html1.xpath('//div[@id="PlayersView"]//ol//li[contains(@class, "list__item")]//h5/a'):
                        data_found = True
                        player_name = fctcore.parse_field('./span[@class="nav-link__value"]', d1)
                        player_url = urljoin(f'https://te.tournamentsoftware.com/', fctcore.parse_field('./@href', d1))

                        logger.info(f'player_name: {player_name}')
                        self.parse_matches(spider_id, job_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_city, tournament_country, player_url)

        except Exception:
            logger.error(traceback.format_exc())

        return data_found


    def parse_matches(self, spider_id, job_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_city, tournament_country, player_url):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
            }

            response1 = self.fctrequest.request(method='GET', link=player_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)

                    for d1 in html1.xpath('//div[@class="module-container"]/ul/li[@class="match-group__item"]/div[@class="match"]'):
                        if d1.xpath('.//div[@class="match__body"]//div[contains(@class,"match__result")]//ul[@class="points"]').get():
                            match_round = fctcore.parse_field('./div[@class="match__header"]/ul[@class="match__header-title"]//li[@class="match__header-title-item"][1]/span[@class="nav-link"]/span[@class="nav-link__value"]', d1)
                            draw_name = fctcore.parse_field('./div[@class="match__header"]/ul[@class="match__header-title"]//li[@class="match__header-title-item"][2]/a[@class="nav-link"]/span[@class="nav-link__value"]', d1)

                            if not draw_name and len(d1.xpath('./div[@class="match__header"]/ul[@class="match__header-title"]//li[@class="match__header-title-item"]')) == 1:
                                draw_name = fctcore.parse_field('./div[@class="match__header"]/ul[@class="match__header-title"]//li[@class="match__header-title-item"][1]/a[@class="nav-link"]/span[@class="nav-link__value"]', d1)

                            match_date = ''
                            try:
                                match_date_pre = fctcore.parse_field('./div[@class="match__footer"]/ul[@class="match__footer-list"]//li[@class="match__footer-list-item"][1]/span[@class="nav-link"]/span[@class="nav-link__value"]', d1)
                                m = re.search(r"\b\d{2}/\d{2}/\d{4}\b", match_date_pre)
                                if m:
                                    date_str = m.group()  # 03/01/2025
                                    match_date = datetime.strptime(date_str, "%d/%m/%Y").strftime("%m/%d/%Y")
                            except Exception:
                                ''

                            match_data = self.parse_match(Selector(text=d1.xpath('.//div[@class="match__body"]').get()))
                            logger.info(f'match_data: {match_data}')

                            draw_team_type = match_data.get("draw_team_type", "")
                            outcome = match_data.get("outcome", "")
                            score = match_data.get("score", "")

                            winner_1_name = match_data.get("winner_1", {}).get('name', '')
                            winner_1_url = match_data.get("winner_1", {}).get('profile_url', '')

                            winner_2_name = match_data.get("winner_2", {}).get('name', '')
                            winner_2_url = match_data.get("winner_2", {}).get('profile_url', '')

                            loser_1_name = match_data.get("loser_1", {}).get('name', '')
                            loser_1_url = match_data.get("loser_1", {}).get('profile_url', '')

                            loser_2_name = match_data.get("loser_2", {}).get('name', '')
                            loser_2_url = match_data.get("loser_2", {}).get('profile_url', '')

                            if score:
                                logger.info(f'tournament_name: {tournament_name}')
                                logger.info(f'tournament_url: {tournament_url}')
                                logger.info(f'draw_name: {draw_name}')
                                logger.info(f'draw_team_type: {draw_team_type}')
                                logger.info(f'score: {score}')
                                logger.info(f'winner_1_name: {winner_1_name} | winner_2_name: {winner_2_name}')
                                logger.info(f'loser_1_name: {loser_1_name} | loser_2_name: {loser_2_name}')

                                self.parse_page(spider_id, job_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_city, tournament_country, draw_name,draw_team_type, score, outcome, winner_1_name, winner_2_name, loser_1_name, loser_2_name, winner_1_url, winner_2_url, loser_1_url, loser_2_url, match_round, match_date)

        except Exception:
            logger.error(traceback.format_exc())


    def parse_page(self, spider_id, job_id, tournament_name, tournament_url, tournament_start_date, tournament_end_date, tournament_city, tournament_country, draw_name,draw_team_type, score, outcome, winner_1_name, winner_2_name, loser_1_name, loser_2_name, winner_1_url, winner_2_url, loser_1_url, loser_2_url, match_round, match_date):
        try:
            if not match_date:
                match_date = tournament_start_date

            id_type = 'Europe'
            match_id = ""
            ball_type = "Yellow"
            draw_bracket_value = ""
            draw_gender = ""
            date = match_date
            winner_1_city = ""
            winner_1_state = ""
            winner_2_city = ""
            winner_2_state = ""
            loser_1_city = ""
            loser_1_state = ""
            loser_2_city = ""
            loser_2_state = ""
            draw_bracket_type = ""
            draw_type = ""
            tournament_state = ""
            tournament_host = ""
            tournament_location_type = ""
            tournament_surface = ""
            tournament_event_category = ""
            tournament_event_grade = ""
            tournament_sanction_body = "Tennis Europe"
            winner_2_college = ""
            loser_2_college = ""
            tournament_event_type = "Tournament"
            winner_1_college = ""
            loser_1_college = ""

            winner_1_name, winner_1_third_party_id, winner_1_dob, winner_1_gender, winner_1_country = self.parse_page_player(winner_1_url)
            winner_2_name, winner_2_third_party_id, winner_2_dob, winner_2_gender, winner_2_country = self.parse_page_player(winner_2_url)
            loser_1_name, loser_1_third_party_id, loser_1_dob, loser_1_gender, loser_1_country = self.parse_page_player(loser_1_url)
            loser_2_name, loser_2_third_party_id, loser_2_dob, loser_2_gender, loser_2_country = self.parse_page_player(loser_2_url)

            tournament_import_source = 'Tennis Europe'
            tournament_country_code = tournament_country[0:3].upper()

            if winner_1_gender == 'M':
                draw_gender = "Male"
            elif winner_1_gender == 'F':
                draw_gender = "Female"

            if not ItemsTennisEuropeModel.objects.filter(spider_id=spider_id, job_id=job_id, winner_1_name=winner_1_name, loser_1_name=loser_1_name, winner_2_name=winner_2_name, loser_2_name=loser_2_name, score=score).exists():
                if 'local_' in winner_1_third_party_id: winner_1_third_party_id = ''
                if 'local_' in winner_2_third_party_id: winner_2_third_party_id = ''
                if 'local_' in loser_1_third_party_id: loser_1_third_party_id = ''
                if 'local_' in loser_2_third_party_id: loser_2_third_party_id = ''

                logger.info(f'match_id: {match_id}')
                logger.info(f'draw_name: {draw_name}')
                logger.info(f'draw_team_type: {draw_team_type}')
                logger.info(f'tournament_name: {tournament_name}')
                logger.info(f'date: {date}')
                logger.info(f'score: {score}')
                logger.info(f'winner_1_name: {winner_1_name}')
                logger.info(f'winner_1_gender: {winner_1_gender}')
                logger.info(f'winner_1_third_party_id: {winner_1_third_party_id}')
                logger.info(f'winner_1_dob: {winner_1_dob}')
                logger.info(f'winner_2_name: {winner_2_name}')
                logger.info(f'winner_2_gender: {winner_2_gender}')
                logger.info(f'winner_2_third_party_id: {winner_2_third_party_id}')
                logger.info(f'winner_2_dob: {winner_2_dob}')
                logger.info(f'loser_1_name: {loser_1_name}')
                logger.info(f'loser_1_gender: {loser_1_gender}')
                logger.info(f'loser_1_third_party_id: {loser_1_third_party_id}')
                logger.info(f'loser_1_dob: {loser_1_dob}')
                logger.info(f'loser_2_name: {loser_2_name}')
                logger.info(f'loser_2_gender: {loser_2_gender}')
                logger.info(f'loser_2_third_party_id: {loser_2_third_party_id}')
                logger.info(f'loser_2_dob: {loser_2_dob}')
                logger.info(f'outcome: {outcome}')
                logger.info(f'draw_gender: {draw_gender}')
                logger.info(f'tournament_city: {tournament_city}')
                logger.info(f'tournament_country_code: {tournament_country_code}')
                logger.info(f'tournament_url: {tournament_url}')
                logger.info(f'tournament_country: {tournament_country}')
                logger.info(f'tournament_start_date: {tournament_start_date}')
                logger.info(f'tournament_end_date: {tournament_end_date}')
                logger.info(f'match_round: {match_round}')
                logger.info('*' * 50)

                ItemsTennisEuropeModel(
                    spider_id=spider_id,
                    job_id=job_id,
                    match_id=match_id,
                    ball_type=ball_type,
                    draw_bracket_value=draw_bracket_value,
                    draw_name=draw_name,
                    draw_team_type=draw_team_type,
                    tournament_name=tournament_name,
                    date=date,
                    score=score,
                    winner_1_name=winner_1_name,
                    winner_1_gender=winner_1_gender,
                    winner_1_third_party_id=winner_1_third_party_id,
                    winner_1_city=winner_1_city,
                    winner_1_country=winner_1_country,
                    winner_1_state=winner_1_state,
                    winner_2_name=winner_2_name,
                    winner_2_gender=winner_2_gender,
                    winner_2_third_party_id=winner_2_third_party_id,
                    winner_2_city=winner_2_city,
                    winner_2_state=winner_2_state,
                    loser_1_name=loser_1_name,
                    loser_1_gender=loser_1_gender,
                    loser_1_third_party_id=loser_1_third_party_id,
                    loser_1_city=loser_1_city,
                    loser_1_state=loser_1_state,
                    loser_1_country=loser_1_country,
                    loser_2_name=loser_2_name,
                    loser_2_gender=loser_2_gender,
                    loser_2_third_party_id=loser_2_third_party_id,
                    loser_2_city=loser_2_city,
                    loser_2_state=loser_2_state,
                    outcome=outcome,
                    id_type=id_type,
                    draw_gender=draw_gender,
                    draw_bracket_type=draw_bracket_type,
                    draw_type=draw_type,
                    tournament_city=tournament_city,
                    tournament_state=tournament_state,
                    tournament_country_code=tournament_country_code,
                    tournament_host=tournament_host,
                    tournament_location_type=tournament_location_type,
                    tournament_surface=tournament_surface,
                    tournament_event_category=tournament_event_category,
                    tournament_event_grade=tournament_event_grade,
                    tournament_import_source=tournament_import_source,
                    tournament_sanction_body=tournament_sanction_body,
                    winner_2_country=winner_2_country,
                    winner_2_college=winner_2_college,
                    loser_2_country=loser_2_country,
                    loser_2_college=loser_2_college,
                    tournament_event_type=tournament_event_type,
                    winner_1_college=winner_1_college,
                    loser_1_college=loser_1_college,
                    tournament_url=tournament_url,
                    winner_1_dob=winner_1_dob,
                    winner_2_dob=winner_2_dob,
                    loser_1_dob=loser_1_dob,
                    loser_2_dob=loser_2_dob,
                    tournament_country=tournament_country,
                    tournament_start_date=tournament_start_date,
                    tournament_end_date=tournament_end_date,
                    round=match_round,
                ).save()

        except Exception:
            logger.error(traceback.format_exc())


    def parse_page_player(self, player_url):
        player_name = ''
        third_party_id = ''
        player_dob = ''
        player_gender = ''
        player_country = ''
        if player_url:
            try:
                headers = {
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                    'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
                }

                response1 = self.fctrequest.request(method='GET', link=player_url, headers=headers, proxies=self.proxies, tries=3)
                if response1:
                    if response1.status_code in range(200, 300):
                        html1 = Selector(text=response1.text)

                        player_profile_pre = fctcore.parse_field('//div[contains(@class, "page-subhead")]//div[@class="media__content"]//h4[contains(@class, "media__title")]/a/@href', html1)
                        logger.info(f'player_profile_pre: {player_profile_pre}')

                        if player_profile_pre:
                            player_profile = urljoin(f'https://te.tournamentsoftware.com/', player_profile_pre)
                            logger.info(f'player_profile: {player_profile}')

                            third_party_id = player_profile_pre.split('/')[-1].strip()
                            logger.info(f'third_party_id: {third_party_id}')

                            if not third_party_id:
                                player_name_profile = fctcore.parse_field('//div[contains(@class, "page-subhead")]//div[@class="media__content"]//h4[contains(@class, "media__title")]//span[@class="nav-link__value"]', html1)
                                third_party_id = helper.sha256_id(player_name_profile)

                            if third_party_id:
                                objs = PlayersTennisEuropeModel.objects.filter(spider_name=self.spider_name, third_party_id=third_party_id)
                                if objs.exists():
                                    obj = objs.first()
                                    player_name = obj.player_name
                                    player_dob = obj.dob
                                    player_gender = obj.gender
                                    player_country = obj.country

            except Exception:
                logger.error(traceback.format_exc())

        return player_name, third_party_id, player_dob, player_gender, player_country

    def parse_match(self, sel):
        # -------- OUTCOME --------
        outcome = "Completed"
        if sel.xpath('.//*[contains(normalize-space(.),"Retired")]'):
            outcome = "Retired"

        # -------- PLAYERS (KEEP ROW ORDER) --------
        rows = sel.xpath(
            './/div[contains(@class,"match__row-wrapper")]/div[contains(@class,"match__row")]'
        )

        row_players = []  # index 0 = top row, index 1 = bottom row
        winner_row_index = None

        for idx, row in enumerate(rows):
            players = []
            for a in row.xpath('.//a[contains(@class,"nav-link")]'):
                name = a.xpath('.//span[@class="nav-link__value"]/text()').get()
                href = a.xpath('./@href').get()
                if name and href:
                    players.append({
                        "name": self.clean_name(name),
                        "profile_url": urljoin(
                            "https://te.tournamentsoftware.com/",
                            href.strip()
                        )
                    })

            row_players.append(players)

            if 'has-won' in row.attrib.get('class', ''):
                winner_row_index = idx

        loser_row_index = 1 - winner_row_index

        winners = row_players[winner_row_index]
        losers = row_players[loser_row_index]

        # -------- SCORE (ROW ORDER BASED) --------
        scores = []

        for ul in sel.xpath('//div[contains(@class,"match__result")]//ul[@class="points"]'):
            cells = [c.xpath('normalize-space(text())').get() for c in ul.xpath('./li')]
            if len(cells) != 2:
                continue

            winner_games = cells[winner_row_index]
            loser_games = cells[loser_row_index]

            scores.append(f"{winner_games}-{loser_games}")

        draw_team_type = "Doubles" if len(winners) == 2 else "Singles"

        match_data = {
            "draw_team_type": draw_team_type,
            "outcome": outcome,
            "score": ", ".join(scores) + ";" if scores else "",

            "winner_1": winners[0] if len(winners) > 0 else {},
            "winner_2": winners[1] if len(winners) > 1 else {},

            "loser_1": losers[0] if len(losers) > 0 else {},
            "loser_2": losers[1] if len(losers) > 1 else {},
        }

        logger.info(f'match_data: {match_data}')

        return match_data


    def clean_name(self, name: str) -> str:
        return re.sub(r"\s*\[[^\]]+\]\s*$", "", name).strip()
