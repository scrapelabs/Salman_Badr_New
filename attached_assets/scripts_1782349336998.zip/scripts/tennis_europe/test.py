html_text1 = '''
<tr style="background-color: transparent;">
			<td align="right">Fri 06/02/2026</td><td>MS2</td><td><a href="./draw.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;draw=1">B16 – B16 – Main</a></td><td class="nowrap" align="right"><a class="teamname" href="teammatch.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;match=7">Luxembourg</a><a href="matches.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;c=LUX"><img src="//static.tournamentsoftware.com/content/images/flags/LUX.svg" class="intext flag" width="16" height="14" alt="Luxembourg" title="Luxembourg"><span class="printonly flag">[LUX] </span></a><br><a href="player.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;player=10">Tommaso CAVALLERIS</a><img src="//static.tournamentsoftware.com/content/images/flags/LUX.svg" class="intext flag" width="16" height="14" alt="LUX" title="LUX"><span class="printonly flag">[LUX] </span></td><td align="center">-</td><td class="nowrap"><a href="matches.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;c=SWE"><img src="//static.tournamentsoftware.com/content/images/flags/SWE.svg" class="intext flag" width="16" height="14" alt="Sweden" title="Sweden"><span class="printonly flag">[SWE] </span></a><a class="teamname" href="teammatch.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;match=7">Sweden</a><br><img src="//static.tournamentsoftware.com/content/images/flags/SWE.svg" class="intext flag" width="16" height="14" alt="SWE" title="SWE"><span class="printonly flag">[SWE] </span><strong><a class="highlighted" href="player.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;player=3">Eric TEN</a></strong></td><td><span class="score"><span>6-7(2)</span> <span>0-6</span></span></td><td><a href="matchcalendarhandler.ashx?code=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;id=25&amp;LCID=2057&amp;typeID=11" class="icon-calendar inline-icalendar" title="Export Calendar">Export Calendar</a></td><td>0-1</td><td></td><td></td><td align="right"></td><td><a href="./court.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;crtid=4">Tennishal Asten - 4</a></td>
		</tr>
'''


import re, logging, coloredlogs
from scrapy.selector import Selector

logger = logging.getLogger("scraper")
logger.setLevel(logging.INFO)
coloredlogs.install(level="INFO", logger=logger)

class ParseSport:
    def __init__(self):
        pass

    def parse_match(self, row):
        # ── Extract players from a side <td> ──────────────────────────────────────
        def extract_players(td: Selector) -> list[dict]:
            players = []
            for a in td.xpath(".//a[contains(@href, 'player.aspx')]"):
                country = td.xpath(".//a[contains(@href, 'matches.aspx')]/img/@title").get("")
                # Check if the <a> tag is directly inside a <strong> tag
                is_winner = bool(a.xpath("parent::strong").get())
                players.append({
                    "name": a.xpath("normalize-space(.)").get(""),
                    "profile_url": a.xpath("@href").get(""),
                    "highlighted": is_winner,
                    "country": country,
                })
            return players

        # FIX: use .//td[N] so it works when row is a full document selector
        left_players = extract_players(row.xpath(".//td[4]"))
        right_players = extract_players(row.xpath(".//td[6]"))

        # ── Determine winner by <strong> tag ──────────────────────────────────────
        left_wins = any(p["highlighted"] for p in left_players)

        winners = left_players if left_wins else right_players
        losers = right_players if left_wins else left_players

        # ── draw_team_type ────────────────────────────────────────────────────────
        draw_team_type = "Doubles" if len(winners) == 2 else "Singles"

        # ── Score ─────────────────────────────────────────────────────────────────
        raw_scores = row.xpath(".//span[@class='score']/span/text()").getall()

        # ── Outcome ───────────────────────────────────────────────────────────────
        outcome = "Completed"
        if row.xpath('.//*[contains(normalize-space(.), "Retired")]'):
            outcome = "Retired"
            raw_scores = [s for s in raw_scores if "retired" not in s.lower()]

        # FIX: flip each set score so it reflects the winner's perspective
        def flip_set(s: str) -> str:
            tb_match = re.search(r'(\(\d+\))$', s)
            tiebreak = tb_match.group(1) if tb_match else ""
            clean = s[:tb_match.start()] if tb_match else s
            parts = clean.split("-")
            if len(parts) == 2:
                return f"{parts[1]}-{parts[0]}{tiebreak}"
            return s

        if not left_wins:
            raw_scores = [flip_set(s) for s in raw_scores]

        score = ", ".join(raw_scores) + ";" if raw_scores else ""

        # ── Helper ────────────────────────────────────────────────────────────────
        def _player(lst: list[dict], idx: int) -> dict:
            if idx < len(lst):
                profile_url_pre = lst[idx]["profile_url"]
                if profile_url_pre:
                    profile_url = f'https://te.tournamentsoftware.com/sport/{profile_url_pre}'
                    return {
                        "name": self.clean_name(lst[idx]["name"]),
                        "profile_url": profile_url,
                        "player_country": lst[idx]["country"],
                    }
            return {}

        match_data = {
            "draw_team_type": draw_team_type,
            "outcome": outcome,
            "score": score,
            "winner_1": _player(winners, 0),
            "winner_2": _player(winners, 1),
            "loser_1": _player(losers, 0),
            "loser_2": _player(losers, 1),
        }
        return match_data

    def clean_name(self, name: str) -> str:
        return re.sub(r"\s*\[[^\]]+\]\s*$", "", name).strip()


if __name__ == "__main__":
    html1 = Selector(text=html_text1)
    for d1 in html1.xpath('//tr'):
        match_data = ParseSport().parse_match(d1)
        logger.info(f'match_data: {match_data}')
