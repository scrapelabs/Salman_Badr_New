import traceback, re
from urllib.parse import urljoin
from scrapy.selector import Selector
from django.db import close_old_connections
from django.conf import settings
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from app_spiders.models import JobsItemsPolandResultsModel


class DetailsParser:

    def __init__(self, spider_id, job_id, main_task, thread_task, progress):
        self.spider_id = spider_id
        self.job_id = job_id
        self.main_task = main_task
        self.thread_task = thread_task
        self.progress = progress
        self.proxies = settings.PROXIES
        self.use_proxy = False
        self.fctrequest = Request(use_session=True, use_cffi=True, use_proxy=self.use_proxy)


    def parse_site(self, tournaments_chunk):
        try:
            for tournaments_data in tournaments_chunk:
                self.progress.update(self.main_task, advance=1)
                self.progress.update(self.thread_task, advance=1)
                close_old_connections()

                tournament_url = tournaments_data['tournament_url']
                tournament_url = tournament_url.replace('TournamentResults', 'TournamentOrderOfPlay')
                tournament_url = tournament_url.replace('TournamentDrawsheet', 'TournamentOrderOfPlay')
                logger.info(f'tournament_url: {tournament_url}')

                try:
                    headers = {
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                        'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                        'upgrade-insecure-requests': '1',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0',
                    }

                    response1 = self.fctrequest.request(method='GET', link=tournament_url, headers=headers, proxies=self.proxies, tries=3)
                    if response1:
                        if response1.status_code in range(200, 300):
                            html1 = Selector(text=response1.text)
                            for d1 in html1.xpath('//div[@id="ctl00_cphMainContainer_updPanel"]//div[contains(@class, "tournamentcalendar")]/a'):
                                pre_link = fctcore.parse_field('./@href', d1)
                                if pre_link:
                                    tournament_date_url = urljoin('https://portal.pzt.pl/', pre_link)
                                    logger.info(f'tournament_date_url: {tournament_date_url}')

                                    self.parse_dates(tournament_date_url)

                except Exception:
                    logger.error(traceback.format_exc())

        except Exception:
            logger.error(traceback.format_exc())


    def parse_dates(self, tournament_date_url):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0',
            }
            response1 = self.fctrequest.request(method='GET', link=tournament_date_url, headers=headers, proxies=self.proxies, tries=3)
            if response1:
                if response1.status_code in range(200, 300):
                    html1 = Selector(text=response1.text)
                    for d1 in html1.xpath('//table[@class="listBlue"]//tr[td]'):
                        Parser(self.spider_id, self.job_id, html1).parse_match(d1)

        except Exception:
            logger.error(traceback.format_exc())



POLISH_MONTHS = {
    "styczeń": 1, "stycznia": 1, "sty": 1,
    "luty": 2, "lutego": 2, "lut": 2,
    "marzec": 3, "marca": 3, "mar": 3,
    "kwiecień": 4, "kwietnia": 4, "kwi": 4,
    "maj": 5, "maja": 5,
    "czerwiec": 6, "czerwca": 6, "cze": 6,
    "lipiec": 7, "lipca": 7, "lip": 7,
    "sierpień": 8, "sierpnia": 8, "sie": 8,
    "wrzesień": 9, "września": 9, "wrz": 9,
    "październik": 10, "października": 10, "paź": 10,
    "listopad": 11, "listopada": 11, "lis": 11,
    "grudzień": 12, "grudnia": 12, "gru": 12,
}


def clean(text):
    """Collapse whitespace and strip."""
    if text is None:
        return ""
    return re.sub(r"\s+", " ", text).strip()


def format_name(raw_name):
    """'Kurzawa Filip' -> 'Kurzawa, Filip' (PZT shows Surname Firstname)."""
    parts = clean(raw_name).split(" ")
    if len(parts) < 2:
        return clean(raw_name)
    return parts[0] + ", " + " ".join(parts[1:])


def to_us_date(y, m, d):
    """M/D/YYYY without leading zeros, like the samples (5/23/2026)."""
    return f"{int(m)}/{int(d)}/{int(y)}"


class Parser:
    def __init__(self, spider_id, job_id, page):
        self.spider_id = spider_id
        self.job_id = job_id
        self.page = page
        self._page_info = self._parse_page_info()

    # ---------- page-level info (same for all matches on the page) ----------
    def _parse_page_info(self):
        info = {}
        try:
            info["tournament_name"] = clean(
                self.page.xpath('//div[@class="tournAppName_B"]/text()').get()
            )

            # "Od: 2026.06.06" / "Do: 2026.06.08"
            dates_txt = clean(" ".join(
                self.page.xpath('//div[@class="tournAppTopCent_B"]//text()').getall()
            ))
            m = re.search(r"Od:\s*(\d{4})\.(\d{2})\.(\d{2})", dates_txt)
            info["tournament_start_date"] = to_us_date(m.group(1), m.group(2), m.group(3)) if m else ""
            m = re.search(r"Do:\s*(\d{4})\.(\d{2})\.(\d{2})", dates_txt)
            info["tournament_end_date"] = to_us_date(m.group(1), m.group(2), m.group(3)) if m else ""

            # Match date: prefer Date=YYYY-MM-DD in the form action / active calendar link
            action = self.page.xpath('//form[@id="aspnetForm"]/@action').get() or ""
            m = re.search(r"Date=(\d{4})-(\d{2})-(\d{2})", action)
            if not m:
                # fallback: "Kolejność rozgrywanych meczów w dniu 07 czerwiec 2026"
                title = clean(self.page.xpath('//div[@class="titleOrderOfPlay"]/text()').get())
                m2 = re.search(r"(\d{1,2})\s+(\wfffd*\w+)\s+(\d{4})", title)
                if m2 and m2.group(2).lower() in POLISH_MONTHS:
                    info["date"] = to_us_date(m2.group(3), POLISH_MONTHS[m2.group(2).lower()], m2.group(1))
                else:
                    info["date"] = ""
            else:
                info["date"] = to_us_date(m.group(1), m.group(2), m.group(3))

            # City: "Miejsce turnieju: 99-210 Uniejów, ul. Sportowa ..."
            place = clean(" ".join(self.page.xpath(
                '//div[@class="tournAppPlaceOfGame_B"]//div[@class="tournAppPlaceOfGameR_B"]//text()'
            ).getall()))
            m = re.search(r"\d{2}-\d{3}\s+([^,]+)", place)
            info["tournament_city"] = clean(m.group(1)) if m else place.split(",")[0]

            tid = re.search(r"TournamentID=([0-9A-Fa-f-]+)", action)
            info["tournament_url"] = (
                f"http://portal.pzt.pl/TournamentOrderOfPlay.aspx?TournamentID={tid.group(1)}" if tid else ""
            )
        except Exception:
            logger.error(traceback.format_exc())
        return info

    # ---------- helpers ----------
    @staticmethod
    def _winner_side(sets):
        """sets = [(left, right), ...] -> 'left' or 'right' by sets won."""
        left = sum(1 for a, b in sets if a > b)
        right = sum(1 for a, b in sets if b > a)
        return "left" if left > right else "right"

    @staticmethod
    def _format_score(sets, winner_side):
        """Score from the winner's perspective, semicolon at the end: '6-3, 6-2;'"""
        parts = []
        for a, b in sets:
            if winner_side == "left":
                parts.append(f"{a}-{b}")
            else:
                parts.append(f"{b}-{a}")
        return ", ".join(parts) + ";"

    @staticmethod
    def _gender_from_draw(draw_name):
        d = draw_name.lower()
        if "chłopcy" in d or "mężczyźni" in d or "chlopcy" in d or "mezczyzni" in d:
            return "Male", "M"
        if "dziewczęta" in d or "kobiety" in d or "dziewczeta" in d:
            return "Female", "F"
        return "", ""

    # ---------- one match row ----------
    def parse_match(self, row):
        match_data = {}
        try:
            tds = row.xpath("./td")
            if len(tds) < 5:
                return None  # header / court row

            # Draw name, e.g. "Juniorzy - do 18 lat" + "Gra pojedyncza, Chłopcy"
            draw_name = clean(" ".join(tds[2].xpath(".//text()").getall()))
            if not draw_name:
                return None

            # Players: links with UserID inside the 4th td
            links = tds[3].xpath('.//a[contains(@href, "PlayerProfile.aspx")]')
            players = []
            for a in links:
                name = clean(" ".join(a.xpath(".//text()").getall()))
                href = a.xpath("./@href").get() or ""
                pid = ""
                m = re.search(r"UserID=([A-Z]{3}\d+)", href)
                if m:
                    pid = m.group(1)
                players.append({"name": format_name(name), "id": pid})
            if len(players) < 2:
                return None

            is_doubles = len(players) == 4
            left_players = players[: 2 if is_doubles else 1]
            right_players = players[2:] if is_doubles else players[1:]

            # Score cells in the last td, e.g. ['3:6', '6:2', '10:6']
            raw_sets = [clean(t) for t in tds[4].xpath(".//td/text()").getall() if clean(t)]
            sets = []
            for s in raw_sets:
                m = re.match(r"^(\d+)\s*:\s*(\d+)", s)
                if m:
                    sets.append((int(m.group(1)), int(m.group(2))))
            if not sets:
                logger.info(f"Skipping not-played match: "
                            f"{left_players[0]['name']} vs {right_players[0]['name']}")
                return None

            winner_side = self._winner_side(sets)
            winners = left_players if winner_side == "left" else right_players
            losers = right_players if winner_side == "left" else left_players

            gender, player_gender = self._gender_from_draw(draw_name)
            info = self._page_info

            match_data = {
                "match_id": "",
                "ball_type": "Yellow",
                "draw_bracket_value": "",
                "draw_name": draw_name,
                "draw_team_type": "Doubles" if is_doubles else "Singles",
                "tournament_name": info.get("tournament_name", ""),
                "date": info.get("date", ""),
                "round": "",
                "score": self._format_score(sets, winner_side),
                "winner_1_name": winners[0]["name"],
                "winner_1_gender": player_gender,
                "winner_1_third_party_id": winners[0]["id"],
                "winner_1_city": "",
                "winner_1_country": "Poland",
                "winner_1_state": "",
                "winner_2_name": winners[1]["name"] if is_doubles else "",
                "winner_2_gender": player_gender if is_doubles else "",
                "winner_2_third_party_id": winners[1]["id"] if is_doubles else "",
                "winner_2_city": "",
                "winner_2_state": "",
                "loser_1_name": losers[0]["name"],
                "loser_1_gender": player_gender,
                "loser_1_third_party_id": losers[0]["id"],
                "loser_1_city": "",
                "loser_1_state": "",
                "loser_1_country": "Poland",
                "loser_2_name": losers[1]["name"] if is_doubles else "",
                "loser_2_gender": player_gender if is_doubles else "",
                "loser_2_third_party_id": losers[1]["id"] if is_doubles else "",
                "loser_2_city": "",
                "loser_2_state": "",
                "outcome": "Completed",
                "id_type": "Poland",
                "draw_gender": gender,
                "draw_bracket_type": "",
                "draw_type": "",
                "tournament_city": info.get("tournament_city", ""),
                "tournament_state": "",
                "tournament_country_code": "POL",
                "tournament_host": "",
                "tournament_location_type": "",
                "tournament_surface": "",
                "tournament_event_category": "",
                "tournament_event_grade": "",
                "tournament_import_source": "Poland",
                "tournament_sanction_body": "Tennis Poland",
                "winner_2_country": "Poland" if is_doubles else "",
                "winner_2_college": "",
                "loser_2_country": "Poland" if is_doubles else "",
                "loser_2_college": "",
                "tournament_event_type": "Tournament",
                "winner_1_college": "",
                "loser_1_college": "",
                "tournament_url": info.get("tournament_url", ""),
                "winner_1_dob": "",
                "winner_2_dob": "",
                "loser_1_dob": "",
                "loser_2_dob": "",
                "tournament_country": "Poland",
                "tournament_start_date": info.get("tournament_start_date", ""),
                "tournament_end_date": info.get("tournament_end_date", ""),
            }

            JobsItemsPolandResultsModel(
                spider_id=self.spider_id,
                job_id=self.job_id,
                match_id=match_data.get('match_id', ''),
                ball_type=match_data.get('ball_type', ''),
                draw_bracket_value=match_data.get('draw_bracket_value', ''),
                draw_name=match_data.get('draw_name', ''),
                draw_team_type=match_data.get('draw_team_type', ''),
                tournament_name=match_data.get('tournament_name', ''),
                date=match_data.get('date', ''),
                round=match_data.get('round', ''),
                score=match_data.get('score', ''),
                winner_1_name=match_data.get('winner_1_name', ''),
                winner_1_gender=match_data.get('winner_1_gender', ''),
                winner_1_third_party_id=match_data.get('winner_1_third_party_id', ''),
                winner_1_city=match_data.get('winner_1_city', ''),
                winner_1_country=match_data.get('winner_1_country', ''),
                winner_1_state=match_data.get('winner_1_state', ''),
                winner_2_name=match_data.get('winner_2_name', ''),
                winner_2_gender=match_data.get('winner_2_gender', ''),
                winner_2_third_party_id=match_data.get('winner_2_third_party_id', ''),
                winner_2_city=match_data.get('winner_2_city', ''),
                winner_2_state=match_data.get('winner_2_state', ''),
                loser_1_name=match_data.get('loser_1_name', ''),
                loser_1_gender=match_data.get('loser_1_gender', ''),
                loser_1_third_party_id=match_data.get('loser_1_third_party_id', ''),
                loser_1_city=match_data.get('loser_1_city', ''),
                loser_1_state=match_data.get('loser_1_state', ''),
                loser_1_country=match_data.get('loser_1_country', ''),
                loser_2_name=match_data.get('loser_2_name', ''),
                loser_2_gender=match_data.get('loser_2_gender', ''),
                loser_2_third_party_id=match_data.get('loser_2_third_party_id', ''),
                loser_2_city=match_data.get('loser_2_city', ''),
                loser_2_state=match_data.get('loser_2_state', ''),
                outcome=match_data.get('outcome', ''),
                id_type=match_data.get('id_type', ''),
                draw_gender=match_data.get('draw_gender', ''),
                draw_bracket_type=match_data.get('draw_bracket_type', ''),
                draw_type=match_data.get('draw_type', ''),
                tournament_city=match_data.get('tournament_city', ''),
                tournament_state=match_data.get('tournament_state', ''),
                tournament_country_code=match_data.get('tournament_country_code', ''),
                tournament_host=match_data.get('tournament_host', ''),
                tournament_location_type=match_data.get('tournament_location_type', ''),
                tournament_surface=match_data.get('tournament_surface', ''),
                tournament_event_category=match_data.get('tournament_event_category', ''),
                tournament_event_grade=match_data.get('tournament_event_grade', ''),
                tournament_import_source=match_data.get('tournament_import_source', ''),
                tournament_sanction_body=match_data.get('tournament_sanction_body', ''),
                winner_2_country=match_data.get('winner_2_country', ''),
                winner_2_college=match_data.get('winner_2_college', ''),
                loser_2_country=match_data.get('loser_2_country', ''),
                loser_2_college=match_data.get('loser_2_college', ''),
                tournament_event_type=match_data.get('tournament_event_type', ''),
                winner_1_college=match_data.get('winner_1_college', ''),
                loser_1_college=match_data.get('loser_1_college', ''),
                tournament_url=match_data.get('tournament_url', ''),
                winner_1_dob=match_data.get('winner_1_dob', ''),
                winner_2_dob=match_data.get('winner_2_dob', ''),
                loser_1_dob=match_data.get('loser_1_dob', ''),
                loser_2_dob=match_data.get('loser_2_dob', ''),
                tournament_country=match_data.get('tournament_country', ''),
                tournament_start_date=match_data.get('tournament_start_date', ''),
                tournament_end_date=match_data.get('tournament_end_date', ''),
            ).save()

        except Exception:
            logger.error(traceback.format_exc())
            return None



