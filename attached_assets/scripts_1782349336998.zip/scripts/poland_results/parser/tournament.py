import traceback, re
import concurrent.futures
from datetime import date, datetime
from django.db import close_old_connections
from django.conf import settings
from urllib.parse import urljoin
from scrapy.selector import Selector
from assets.fct.fctlog import logger
from assets.fct import fctcore
from assets.requests.fctrequest import Request
from scripts.log_items import ItemsLogger


class TournamentParser:

    def __init__(self, spider_name, max_workers, progress, job_start_date, job_end_date):
        self.spider_name = spider_name
        self.progress = progress
        self.max_workers = max_workers
        self.job_start_date = job_start_date
        self.job_end_date = job_end_date
        self.proxies = settings.PROXIES
        self.use_proxy = settings.USE_PROXY
        self.fctrequest = Request(use_session=True, use_cffi=False, use_proxy=self.use_proxy)
        self.df_tournaments = ItemsLogger()

        self.headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,fr;q=0.8,en-GB;q=0.7,ar;q=0.6',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0',
        }

        self.summaries_list = [
            {"name": "SKRZATY", "link": "https://portal.pzt.pl/TournamentsResults.aspx?CategoryID=12&Male=M"},
            {"name": "SKRZATKI", "link": "https://portal.pzt.pl/TournamentsResults.aspx?CategoryID=12&Male=K"},
            {"name": "MŁODZICY", "link": "https://portal.pzt.pl/TournamentsResults.aspx?CategoryID=14&Male=M"},
            {"name": "MŁODZICZKI", "link": "https://portal.pzt.pl/TournamentsResults.aspx?CategoryID=14&Male=K"},
            {"name": "KADECI", "link": "https://portal.pzt.pl/TournamentsResults.aspx?CategoryID=16&Male=M"},
            {"name": "KADETKI", "link": "https://portal.pzt.pl/TournamentsResults.aspx?CategoryID=16&Male=K"},
            {"name": "JUNIORZY", "link": "https://portal.pzt.pl/TournamentsResults.aspx?CategoryID=18&Male=M"},
            {"name": "JUNIORKI", "link": "https://portal.pzt.pl/TournamentsResults.aspx?CategoryID=18&Male=K"},
            {"name": "MĘŻCZYŹNI", "link": "https://portal.pzt.pl/TournamentsResults.aspx?CategoryID=19&Male=M"},
            {"name": "KOBIETY", "link": "https://portal.pzt.pl/TournamentsResults.aspx?CategoryID=19&&Male=K"},
            {"name": "SENIORZY I AMATORZY", "link": "https://portal.pzt.pl/TournamentsResults.aspx?CategoryID=AIS"},
        ]


    def parse_tournaments(self):
        try:
            summaries_chunks = list(fctcore.split_list_into_chunks(lst=self.summaries_list, max_workers=self.max_workers))
            if self.max_workers > len(summaries_chunks): self.max_workers = len(summaries_chunks)
            logger.info(f'max_workers: {self.max_workers}')

            with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                main_task = self.progress.add_task(description=f'{self.spider_name}_tournaments', total=len(self.summaries_list))
                for thread_id, summaries_chunk in enumerate(summaries_chunks):
                    thread_task = self.progress.add_task(f"Thread {thread_id + 1}", total=len(summaries_chunk))
                    executor.submit(self.parse_tournament, summaries_chunk, main_task, thread_task)

        except Exception:
            logger.error(traceback.format_exc())

        return self.df_tournaments.get_df()


    def parse_tournament(self, summaries_chunk, main_task, thread_task):
        try:
            for summarie_data in summaries_chunk:
                self.progress.update(main_task, advance=1)
                self.progress.update(thread_task, advance=1)
                close_old_connections()

                index_link = summarie_data['link']
                response1 = self.fctrequest.request(method='GET', link=index_link, headers=self.headers, proxies=self.proxies, tries=3)
                if response1:
                    if response1.status_code in range(200, 300):
                        html1 = Selector(text=response1.text)

                        for d1 in html1.xpath('//table[@class="tabRB"]//tr[not(th)]'):
                            pre_link = fctcore.parse_field('./td[2]/a/@href', d1)
                            tournament_date = fctcore.parse_field('./td[4]', d1)
                            if pre_link and tournament_date:
                                tournament_url = urljoin('https://portal.pzt.pl/', pre_link)

                                is_included = self.is_fully_inside(tournament_date, self.job_start_date, self.job_end_date)
                                if is_included:
                                    logger.info(f'tournament_date: {tournament_date} | tournament_url: {tournament_url}')

                                    if tournament_url:
                                        self.df_tournaments.log({
                                            "tournament_url": tournament_url,
                                        })

        except Exception:
            logger.error(traceback.format_exc())

    def parse_single_date(self, text: str) -> date:
        """Parse one date in ISO ('2024-04-21') or European ('21. 4. 2024') format."""
        text = text.strip()

        # ISO format: YYYY-MM-DD
        try:
            return datetime.strptime(text, "%Y-%m-%d").date()
        except ValueError:
            pass

        # European format: 'D. M. YYYY' (with flexible spacing/dots)
        m = re.match(r"^(\d{1,2})\.\s*(\d{1,2})\.\s*(\d{4})$", text)
        if m:
            day, month, year = map(int, m.groups())
            return date(year, month, day)

        raise ValueError(f"Unrecognized date format: {text!r}")

    def parse_range(self, range_str: str) -> tuple[date, date]:
        """
        Parse a date range string into (start, end).

        Supports:
          - ISO:      '2024-04-21 - 2024-04-22'
          - European: '28. 11.-2. 12. 2025'  (year applies to both parts)
        """
        range_str = range_str.strip()

        # ISO range: split on the dash between the two dates
        if re.match(r"^\d{4}-\d{2}-\d{2}\s*-\s*\d{4}-\d{2}-\d{2}$", range_str):
            start_str, end_str = re.split(r"\s*-\s*(?=\d{4}-)", range_str, maxsplit=1)
            return self.parse_single_date(start_str), self.parse_single_date(end_str)

        # European range: '28. 11.-2. 12. 2025' or '28. 11. 2025 - 2. 12. 2025'
        parts = re.split(r"\s*[-–]\s*", range_str)
        if len(parts) == 2:
            start_part, end_part = parts[0].strip(), parts[1].strip()
            # Year is usually only on the end part: '28. 11.' + '2. 12. 2025'
            year_match = re.search(r"(\d{4})\s*$", end_part)
            if year_match and not re.search(r"\d{4}", start_part):
                start_part = start_part.rstrip(". ") + ". " + year_match.group(1)
            return self.parse_single_date(start_part), self.parse_single_date(end_part)

        raise ValueError(f"Unrecognized range format: {range_str!r}")

    def is_range_included(self, range_str: str, window_start: str, window_end: str) -> bool:
        """
        True if the tournament range OVERLAPS the job window [window_start, window_end].

        Returns True when any day of the tournament falls inside the window —
        including when the tournament fully covers the window.
        Both boundaries are inclusive.
        """
        start, end = self.parse_range(range_str)
        w_start = self.parse_single_date(window_start)
        w_end = self.parse_single_date(window_end)
        return start <= w_end and end >= w_start

    def is_fully_inside(self, range_str: str, window_start: str, window_end: str) -> bool:
        """
        True only if the tournament range falls ENTIRELY within the window.
        (The old, stricter behavior — kept in case you need it.)
        """
        start, end = self.parse_range(range_str)
        w_start = self.parse_single_date(window_start)
        w_end = self.parse_single_date(window_end)
        return start >= w_start and end <= w_end