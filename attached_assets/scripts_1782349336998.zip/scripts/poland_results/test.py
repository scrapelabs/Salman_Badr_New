html_text1 = '''<html xmlns="http://www.w3.org/1999/xhtml"><head id="ctl00_Head1"><title>
	Tenis w Polsce - Polski Związek Tenisowy - PZT.pl
</title><meta name="description" content="PZT"><meta name="keywords" content="PZT"><meta name="Classification" content="PZT"><meta name="author" content="PZT"><link href="/App_Themes/PZT/PZT.css?v=90" rel="stylesheet"><link rel="shortcut icon" href="/favicon.ico"><meta http-equiv="content-type" content="text/html; charset=utf-8"><link href="/calendar/jquery-ui.css" rel="stylesheet" type="text/css"><link href="/Scripts/jquery.cluetip.css" rel="stylesheet">
    <script src="/Scripts/jquery-1.7.1.min.js" type="text/javascript"></script>
	<script src="/Scripts/menuHorizontal.js" type="text/javascript"></script>
    <script type="text/javascript" src="/swfobject.js"></script>
    <link href="/Images/apple-touch-icon.png" rel="apple-touch-icon"><link href="/Images/apple-touch-icon-76x76.png" rel="apple-touch-icon" sizes="76x76"><link href="/Images/apple-touch-icon-120x120.png" rel="apple-touch-icon" sizes="120x120"><link href="/Images/apple-touch-icon-152x152.png" rel="apple-touch-icon" sizes="152x152"><style rel="stylesheet" type="text/css">#cookie_info{ z-index:999; position:fixed; bottom:0; width:100%;} .user_information{margin:0 auto;} .user_information:before{content:' '; display:block;} .options{float:right; margin-top:10px} .options a{margin-right:15px}</style><style class="automa-element-selector">@font-face { font-family: "Inter var"; font-weight: 100 900; font-display: swap; font-style: normal; font-named-instance: "Regular"; src: url("chrome-extension://infppggnoaenmfagbfknfkancpbljcca/Inter-roman-latin.var.woff2") format("woff2") }
.automa-element-selector { direction: ltr } 
 [automa-isDragging] { user-select: none } 
 [automa-el-list] {outline: 2px dashed #6366f1;}</style></head>
<body>
    <form name="aspnetForm" method="post" action="./TournamentOrderOfPlay.aspx?TournamentID=68BB044F-7797-4D35-AA7F-8E4E46316FC5&amp;Date=2026-06-07" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="">
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="">
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUJLTEwMTY4MjY3D2QWAmYPZBYCAgQPZBYCAgEPFgIeBFRleHQFUiA8YSBocmVmPSJodHRwOi8vd3d3LnB6dC5wbC8iIHN0eWxlPSJkaXNwbGF5OmJsb2NrOyB3aWR0aDoxMDAlOyBoZWlnaHQ6OTlweDsiPjwvYT5kGAEFGWN0bDAwJGNCb3hMb2dpbiRtdkRlZmF1bHQPD2RmZNiN3GrugHQEIE2SAzftUVxR0U33cizIXovTsKHhTMgf">
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=YdiO0PHW0jpJ1LPeKZ_HHCY2KsjGd4Llr4ovYb3GRPmmuN-U-RSf2XIdgz955GwafINSKE4ajMvhxQm-TlUt1b1YLSg7HPqTh0RKBgA3XJc1&amp;t=637454105640000000" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=uINzvDd2ZQ4ebceZHDDhxqvKJ-lHT6OHzggOFW7NG0eQIZy-14TwA0ZQVMshIeWf-3T-6HeMmUvk6bKxACy2eBsknobbj4RT8JYKCMU7J-DLfY4LrhWDSXZo5QBpB3mP6YVG_fLA4GIICev4JpPVD2Za_WGUo7saiv8qd5wtQjGuAPqCx14-HF_mdbU6_GOP0&amp;t=2fe674eb" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
if (typeof(Sys) === 'undefined') throw new Error('Ładowanie struktury strony klienta ASP.NET Ajax nie powiodło się.');
//]]>
</script>

<script src="/ScriptResource.axd?d=wg8R8uBssWV5bvwzTB2zMy7DUYdjjlpvA1N0z4Lh0BjhI-3aIfww5t8FRyMgk7BuFBmpL9wWJmgnnL9dE_6Z2Og0NQwG_kNMxm1BHR6BVOeuH4x5_cnJYHMSTJnfULnwm0LPaHIfKYYIn2f0fjyTe-w0tiE7OGYFeyOZzH3SXLmmRvwWX_q2l0gkfWh32Oq70&amp;t=2fe674eb" type="text/javascript"></script>
<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="D71DAEA0">
</div>
    <script src="/Scripts/jquery.cluetip.js" type="text/javascript"></script>
    <script src="/Scripts/PZT.js?v=2" type="text/javascript"></script>
        <div id="body2BG">
            <div class="main">
                <div class="headerContainer">
                    <div class="headerLogo"> <a href="http://www.pzt.pl/" style="display:block; width:100%; height:99px;"></a></div>
                    <div class="headerCenter"></div>
                    <div class="headerRight">
<script type="text/javascript">
    $(document).ready(function () {
        $('.boxPasswordClear').show();
        $('.txtBoxPassword').hide();
        $('.boxPasswordClear').focus(function () {
            $('.boxPasswordClear').hide();
            $('.txtBoxPassword').show();
            $('.txtBoxPassword').focus();
        });
        $('.txtBoxPassword').blur(function () {
            if ($('.txtBoxPassword').val() == '') {
                $('.boxPasswordClear').show();
                $('.txtBoxPassword').hide();
            }
        });
        $('.txtBoxLogin').each(function () {
            var default_value = this.value;
            $(this).focus(function () {
                if (this.value == default_value) {
                    this.value = '';
                }
            });
            $(this).blur(function () {
                if (this.value == '') {
                    this.value = default_value;
                }
            });
        });
    });
</script>
<div class="boxLoginMain">

            <div id="ctl00_cBoxLogin_pnlLogIn" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'ctl00_cBoxLogin_lbtnLogin')">

                <div class="boxLogin">
                    <div class="boxLoginLoginInput">
                        <a title="Login?" id="load-local" class="load-local" href="#helpLogin" rel="#helpLogin" style="float:left;"><img src="/Images/help.png" alt="?" width="12" height="12"></a>
                        <input name="ctl00$cBoxLogin$txtLogin" type="text" value="Podaj Login" maxlength="15" id="ctl00_cBoxLogin_txtLogin" tabindex="1" class="txtBoxLogin">
                    <div data-lastpass-icon-root="" style="position: relative !important; height: 0px !important; width: 0px !important; display: initial !important; float: left !important;"><template shadowrootmode="closed"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-lastpass-icon="true" data-testid="infield-icon" style="position: absolute; cursor: pointer; height: 22px; max-height: 22px; width: 22px; max-width: 22px; top: 6px; left: -31px; z-index: auto; color: rgb(186, 192, 202);"><rect x="0.680176" y="0.763062" width="22.6392" height="22.4737" rx="4" fill="currentColor"></rect><path fill-rule="evenodd" clip-rule="evenodd" d="M19.7935 7.9516C19.7935 7.64414 20.0427 7.3949 20.3502 7.3949C20.6576 7.3949 20.9069 7.64414 20.9069 7.9516V16.0487C20.9069 16.3562 20.6576 16.6054 20.3502 16.6054C20.0427 16.6054 19.7935 16.3562 19.7935 16.0487V7.9516Z" fill="white"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M4.76288 13.6577C5.68525 13.6577 6.43298 12.9154 6.43298 11.9998C6.43298 11.0842 5.68525 10.3419 4.76288 10.3419C3.8405 10.3419 3.09277 11.0842 3.09277 11.9998C3.09277 12.9154 3.8405 13.6577 4.76288 13.6577Z" fill="white"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M10.3298 13.6577C11.2521 13.6577 11.9999 12.9154 11.9999 11.9998C11.9999 11.0842 11.2521 10.3419 10.3298 10.3419C9.4074 10.3419 8.65967 11.0842 8.65967 11.9998C8.65967 12.9154 9.4074 13.6577 10.3298 13.6577Z" fill="white"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M15.8964 13.6577C16.8188 13.6577 17.5665 12.9154 17.5665 11.9998C17.5665 11.0842 16.8188 10.3419 15.8964 10.3419C14.974 10.3419 14.2263 11.0842 14.2263 11.9998C14.2263 12.9154 14.974 13.6577 15.8964 13.6577Z" fill="white"></path></svg></template></div></div>
                    <div class="boxLoginPasswordInput">
                        <a title="Hasło?" id="A1" class="load-local" href="#helpPass" rel="#helpPass" style="float:left;"><img src="/Images/help.png" alt="?" width="12" height="12"></a>
                        <input name="ctl00$cBoxLogin$txtPasswordClear" type="text" value="Hasło" maxlength="20" id="ctl00_cBoxLogin_txtPasswordClear" tabindex="2" class="boxPasswordClear">
                        <input name="ctl00$cBoxLogin$txtPassword" type="password" maxlength="20" id="ctl00_cBoxLogin_txtPassword" class="txtBoxPassword" style="display:none;">
                    </div>
                    <div class="boxLoginBtnMain">
                        <a id="ctl00_cBoxLogin_lbtnLogin" tabindex="3" title="Zaloguj" class="btnLogin" href="javascript:__doPostBack('ctl00$cBoxLogin$lbtnLogin','')"></a>
                    </div>
                <div data-lastpass-icon-root="" style="position: relative !important; height: 0px !important; width: 0px !important; display: initial !important; float: left !important;"><template shadowrootmode="closed"></template></div></div>
                <div class="boxLoginRemind">
                    <a href="/RemindIPIN.aspx">nie znam swojego loginu</a> / <a href="/RemindPassword.aspx">przypomnij hasło</a>
                </div>  

</div>

</div>
<div id="ctl00_cBoxLogin_dReg" class="headerContNotification">
    <a href="/Notification.aspx" id="ctl00_cBoxLogin_btnNot" class="btnHeadContNotification" title="Zgłoszenie / rejestracja online">Zgłoszenie / rejestracja online</a>

</div>
<div style="display:none;">
<div id="helpLogin" style="line-height: 16px; display: none;">
    Login to indywidualny identyfikator każdego użytkownika składający się z 10 znaków: 3 liter będących początkiem nazwiska bez polskich znaków oraz 7 cyfr np: dla Jana Kowalskiego login może mieć formę KOW1409871.<br><br>
    Jeżeli nie pamiętasz swojego loginu lub go do tej pory nie otrzymałeś to skorzystaj z funkcji <a href="/RemindIPIN.aspx" class="helpLink">nie znam swojego loginu</a>.<br><br>
    Jeżeli jesteś lub chcesz zostać nowym członkiem PZT i nigdy do tej pory nie korzystałeś z systemów PZT to skorzystaj z opcji <a href="/Notification.aspx" class="helpLink">rejestracja online</a>. Rejestracja online pozwala złożyć wniosek o przydzielenie dostępu do portalu PZT.<br><br>
    UWAGA. Maile z loginem bądź hasłem mogą „wpadać” do SPAMU. Jeżeli email z loginem nie dociera w ciągu kilku minut to sprawdź folder spam w swoim kliencie pocztowym.
</div>
<div id="helpPass" style="display: none;">
    Hasło w połączeniu z loginem pozwala uzyskać dostęp do portalu.<br><br>
    Jeżeli nie pamiętasz swojego hasła lub go do tej pory nie otrzymałeś to skorzystaj z funkcji <a href="/RemindPassword.aspx" class="helpLink">przypomnij hasło</a><br><br>
    Jeżeli jesteś lub chcesz zostać nowym członkiem PZT i nigdy do tej pory nie korzystałeś z systemów PZT to skorzystaj z opcji <a href="/Notification.aspx" class="helpLink">rejestracja online</a>. Rejestracja online pozwala złożyć wniosek o przydzielenie dostępu do portalu PZT.<br><br>
    Po pierwszym logowaniu zalecamy zmienić hasło.<br><br>
    UWAGA. Maile z loginem bądź hasłem mogą „wpadać” do SPAMU. Jeżeli email z hasłem nie dociera w ciągu kilku minut to sprawdź folder spam w swoim kliencie pocztowym.
</div>
<div id="helpMP">
    Dokument uprawniający do gry w Mistrzostwach Polski taki jak:<br><br>
- Karta Polaka;<br><br>
- Karta stałego pobytu w Polsce przez okres minimum 36 kolejnych miesięcy;<br><br>

</div>

<div id="CoachQuestionHelpEducationSpecialist" style="line-height:16px;">
    <ul class="listItemMaT8">
        <li><b>trener PRO</b> - szkoleniowiec o najwyższych kwalifikacjach przygotowany do pracy na wszystkich poziomach zaawansowania, także z zawodnikami profesjonalnymi</li>
        <li><b>trener</b> - szkoleniowiec przygotowany do pracy z początkującymi, zaawansowanymi oraz wyczynowymi tenisistami</li>
        <li><b>coach</b> - były lub aktualny zawodnik z dużym doświadczeniem na arenie międzynarodowej</li>
        <li><b>instruktor</b> - przygotowany do pracy z początkującymi tenisistami - dziećmi, młodzieżą i dorosłymi</li>
        <li><b>animator</b> - przygotowany do pracy z początkującymi dziećmi w wieku od 5 do 10 lat</li>
        <li><b>sparingpartner</b> - były lub aktualny zawodnik z dużym doświadczeniem na arenie krajowej</li> 
        <li><b>asystent</b> - przygotowany</li>
    </ul>
</div>
<div id="CoachQuestionHelpLicense" style="line-height:16px;">
    <ul class="listItemMaT8">
        <li><b>licencja złota (Mistrza)</b> - minimum 10 lat doświadczenia i wybitne osiągnięcia szkoleniowe</li>
        <li><b>licencja srebrna (Eksperta)</b> - minimum 5 lat doświadczenia i znaczące osiągnięcia szkoleniowe</li>
        <li><b>licencja brązowa</b> - minimum 2 lata doświadczenia i pierwsze osiągnięcia szkoleniowe</li>
        <li><b>licencja podstawowa</b> - szkoleniowiec posiada specjalistyczne wykształcenie</li>
    </ul>
</div>
</div>
    <script type="text/javascript">
        window.onunload = hideWB;
        function hideWB() {
            document.getElementById("waitBox").style.display = 'none';
            document.getElementById("waitBgrd").style.display = 'none';
        }
        function showWB() {
            var wb = document.getElementById("waitBox");
            wb.style.display = 'block';

            var wbb = document.getElementById("waitBgrd");
            wbb.style.display = 'block';
        }
    </script>
<div id="waitBgrd" class="loadingBG" style="position: fixed; display: none;"></div>
<div id="waitBox" class="loading" style="color: black; position: fixed; display: none;">
        Proszę czekać<br><img alt="" src="/Images/spin.gif">
</div>
<script language="javascript" type="text/javascript">
    showWB();
    hideWB();
</script></div>
                </div>
            </div>
            <div class="main">
                <div class="menuContainer">

<div id="mainMenuHorizontal" class="dMenuMain">      
    <ul id="uMenuMain">
        <li><a href="/Calendar.aspx">KALENDARZ</a><span class="menuSep"></span></li>
        <li><a href="/Ranking.aspx?RCatID=M">KLASYFIKACJE</a><span class="menuSep"></span></li>
        <li><a rel="ddsubtkr">KLUB ROKU</a><span class="menuSep"></span>

        </li>
        <li><a href="/Results.aspx">WYNIKI</a><span class="menuSep"></span></li>
        <li><a href="/LicenseTab.aspx">LICENCJE</a><span class="menuSep"></span></li>
        <li><a href="/PlayerProfile.aspx">BAZA ZAWODNIKÓW</a></li>
    </ul>
</div>


</div>
            </div>
            <div class="main">
                <div class="pathContainerMain">
                    <div class="pathContainer">

        <div class="pathContainerBtnHome">
            <a href="/"><img src="/Images/btnHome.png" alt=""></a>
        </div>
        <div class="pathContainerContent">Znajdujesz się: <a href="/Results.aspx">Wyniki</a>  &gt; <a href="/TournamentsResults.aspx?CategoryID=&amp;Male="></a> &gt; <a href="/TournamentResults.aspx?CategoryID=&amp;Male=&amp;TournamentID=68BB044F-7797-4D35-AA7F-8E4E46316FC5">Turniej</a> &gt; Mecze</div>

                    </div>
                </div>
            </div>
            <div class="main">
                <div class="mainContainer">
                    <div class="mainContainerBig">
                        <div class="mainContainerBigTop">

    <h3 class="h3FLef">Turniej</h3>
    <div class="mainContainerBigTopConRight">Status: Zakończony</div>

                        </div>
                        <div class="mainContainerBigCenterNew">


        <div style="margin:1px 5px 0px 1px; min-height:340px;">
            <div class="tournAppContainer_BVis">
                <div class="tournAppTopMain1_BVi">
                    <div class="tournAppTopMain2_BVi">
                        <div class="tournAppTop_BVi">
                            <div class="tournAppTopLeft_B_1">
                                <div class="tournAppTopLeft_B">
                                    <div class="tournAppStatus_B">
                                        <div class="tournAppStatusNo"></div>
                                    </div>
                                    <div class="tournAppName_B">
                                        WTK - 👋U18 chł🎾dz😀Uniejów😀turniej grupowy🥇🥈🥉
                                    </div>
                                    <div class="tournAppRang_B_main">
                                        <div class="tournAppRang_B"><div class="tournAppRangCount">5</div><div class="tournAppRangContent">Ranga</div></div>
                                    </div>
                                </div>
                                <div class="tournAppTopCent_B">
                                    <span style="margin-right:20px;">Od: 2026.06.06</span>Do: 2026.06.08
                                </div>
                                <div class="tournAppClubName_B"><div class="tournAppPlaceOfGameL_B">Organizator:</div><div class="tournAppPlaceOfGameR_B">MMKT Łęczyca</div></div>
                                <div class="tournAppPlaceOfGame_B"><div class="tournAppPlaceOfGameL_B">Miejsce turnieju:</div><div class="tournAppPlaceOfGameR_B">99-210 Uniejów, ul. Sportowa obok Kompleksu⚽️im. Wł. Smolarka</div></div> 

                            </div>
                            <div class="tournAppTopRight_B">
                                <div class="tournAppTopRightCon_B">
                                    <div class="tournAppTopRightConDate"><span>Turniej gł.:</span> 2026-06-06</div>

                                </div>
                                <div class="tournAppTopRightBtn"></div>
                            </div>
                        </div>
                    </div>
                </div>



<div class="TabsTournamentResult">
<div class="tabBlue"><div class="tabBlue_z1"><div class="tabBlue_z2"><a href="/TournamentOrderOfPlay.aspx?CategoryID=&amp;Male=&amp;TournamentID=68BB044F-7797-4D35-AA7F-8E4E46316FC5">Plan gier</a></div></div></div><div class="tabGrey"><div class="tabGrey_z1"><div class="tabGrey_z2"><a href="/TournamentDrawsheet.aspx?CategoryID=&amp;Male=&amp;TournamentID=68BB044F-7797-4D35-AA7F-8E4E46316FC5">Drabinki</a></div></div></div><div class="tabGrey"><div class="tabGrey_z1"><div class="tabGrey_z2"><a href="/TournamentMatchesPlay.aspx?CategoryID=&amp;Male=&amp;TournamentID=68BB044F-7797-4D35-AA7F-8E4E46316FC5">Mecze</a></div></div></div><div class="tabGrey"><div class="tabGrey_z1"><div class="tabGrey_z2"><a href="/TournamentTabResults.aspx?CategoryID=&amp;Male=&amp;TournamentID=68BB044F-7797-4D35-AA7F-8E4E46316FC5">Zwycięzcy</a></div></div></div><div class="tabGrey"><div class="tabGrey_z1"><div class="tabGrey_z2"><a href="/TournamentRelation.aspx?CategoryID=&amp;Male=&amp;TournamentID=68BB044F-7797-4D35-AA7F-8E4E46316FC5">Relacja z turnieju</a></div></div></div>

</div>
                <div class="tournAppContent_BVi" "="">
                    <div class="tournAppContent3_BVi">
                        <div class="tournAppContentRow_B" style="width:968px;">
                            <div class="TabsTournamentResultBel2"></div>
                            <div class="dLeft968">
                                <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$cphMainContainer$sm', 'aspnetForm', ['tctl00$cphMainContainer$updPanel',''], [], [], 90, 'ctl00');
//]]>
</script>

                                <div id="ctl00_cphMainContainer_updPanel">


                                        <div class="tournamentcalendar"><a href="/TournamentOrderOfPlay.aspx?TournamentID=68BB044F-7797-4D35-AA7F-8E4E46316FC5&amp;Date=2026-06-06"><span class="weekday">So</span><span class="day">06</span><span class="month">cze</span></a></div><div class="tournamentcalendar act"><a class="act" href="/TournamentOrderOfPlay.aspx?TournamentID=68BB044F-7797-4D35-AA7F-8E4E46316FC5&amp;Date=2026-06-07"><span class="weekday">N</span><span class="day">07</span><span class="month">cze</span></a></div><div class="tournamentcalendar"><a href="/TournamentOrderOfPlay.aspx?TournamentID=68BB044F-7797-4D35-AA7F-8E4E46316FC5&amp;Date=2026-06-08"><span class="weekday">Pn</span><span class="day">08</span><span class="month">cze</span></a></div>


                                        <div class="titleOrderOfPlay">Kolejność rozgrywanych meczów w dniu 07 czerwiec 2026</div>                                     

                                                <table class="listBlue">
                                                    <tbody><tr>
                                                        <th class="bor borBottWhite b" style="width:40px;">Lp.</th>
                                                        <th class="bor borBottWhite b" style="width:120px;">Czas</th>
                                                        <th class="bor borBottWhite b" style="width:210px;">Rozgrywka</th>
                                                        <th class="bor borBottWhite b"></th>
                                                        <th class="borBlue borBottWhite b">Wynik</th>
                                                    </tr>



                                                    <tr>
                                                        <th class="borBlue b" colspan="5">Kort 01</th>
                                                    </tr>
                                                    <tr><td class="first">1.</td><td>Początek 11:00</td><td>Juniorzy - do 18 lat<br>Gra pojedyncza, Chłopcy</td><td style="padding:0px;"><table class="borderNone" style=" margin: 0 auto; "><tbody><tr><td class="r" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=KUR1635190 " target="_blank">Kurzawa Filip</a></td><td> vs </td><td class="l" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=PAW1939440 " target="_blank">Pawełoszek Jan</a></td></tr></tbody></table></td><td class="last" style="padding:0px;"><table class="borderNone"><tbody><tr><td>3:6</td><td>6:2</td><td>10:6</td></tr></tbody></table></td></tr><tr class="a"><td class="first">2.</td><td>Po odpoczynku</td><td>Juniorzy - do 18 lat<br>Gra pojedyncza, Chłopcy</td><td style="padding:0px;"><table class="borderNone" style=" margin: 0 auto; "><tbody><tr><td class="r" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=PER1940343 " target="_blank">Perliński Bartosz</a></td><td> vs </td><td class="l" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=PAW1939440 " target="_blank">Pawełoszek Jan</a></td></tr></tbody></table></td><td class="last" style="padding:0px;"><table class="borderNone"><tbody><tr><td>7:6</td><td>7:5</td><td></td></tr></tbody></table></td></tr><tr><td class="first">3.</td><td>Po odpoczynku</td><td>Juniorzy - do 18 lat<br>Gra pojedyncza, Chłopcy</td><td style="padding:0px;"><table class="borderNone" style=" margin: 0 auto; "><tbody><tr><td class="r" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=PER1940343 " target="_blank">Perliński Bartosz</a></td><td> vs </td><td class="l" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=KUR1635190 " target="_blank">Kurzawa Filip</a></td></tr></tbody></table></td><td class="last" style="padding:0px;"><table class="borderNone"><tbody><tr><td></td><td></td><td></td></tr></tbody></table></td></tr>



                                                    <tr>
                                                        <th class="borBlue b" colspan="5">Kort 02</th>
                                                    </tr>
                                                    <tr><td class="first">1.</td><td>Początek 11:00</td><td>Juniorzy - do 18 lat<br>Gra pojedyncza, Chłopcy</td><td style="padding:0px;"><table class="borderNone" style=" margin: 0 auto; "><tbody><tr><td class="r" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=WIE1838173 " target="_blank">Więcek Mikołaj</a></td><td> vs </td><td class="l" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=DRU2577568 " target="_blank">Drukker  ERIK</a></td></tr></tbody></table></td><td class="last" style="padding:0px;"><table class="borderNone"><tbody><tr><td>6:1</td><td>6:2</td><td></td></tr></tbody></table></td></tr><tr class="a"><td class="first">2.</td><td>Po odpoczynku</td><td>Juniorzy - do 18 lat<br>Gra pojedyncza, Chłopcy</td><td style="padding:0px;"><table class="borderNone" style=" margin: 0 auto; "><tbody><tr><td class="r" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=PER2368431 " target="_blank">Perkowski Igor</a></td><td> vs </td><td class="l" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=DRU2577568 " target="_blank">Drukker  ERIK</a></td></tr></tbody></table></td><td class="last" style="padding:0px;"><table class="borderNone"><tbody><tr><td>6:3</td><td>6:0</td><td></td></tr></tbody></table></td></tr><tr><td class="first">3.</td><td>Po odpoczynku</td><td>Juniorzy - do 18 lat<br>Gra pojedyncza, Chłopcy</td><td style="padding:0px;"><table class="borderNone" style=" margin: 0 auto; "><tbody><tr><td class="r" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=PER2368431 " target="_blank">Perkowski Igor</a></td><td> vs </td><td class="l" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=WIE1838173 " target="_blank">Więcek Mikołaj</a></td></tr></tbody></table></td><td class="last" style="padding:0px;"><table class="borderNone"><tbody><tr><td>6:2</td><td>6:1</td><td></td></tr></tbody></table></td></tr>



                                                    <tr>
                                                        <th class="borBlue b" colspan="5">Kort 03</th>
                                                    </tr>
                                                    <tr><td class="first">1.</td><td>Początek 11:00</td><td>Juniorzy - do 18 lat<br>Gra pojedyncza, Dziewczęta</td><td style="padding:0px;"><table class="borderNone" style=" margin: 0 auto; "><tbody><tr><td class="r" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=MIC2158319 " target="_blank">Michaś Zofia</a></td><td> vs </td><td class="l" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=ROS2148451 " target="_blank">Rosińska Hanna</a></td></tr></tbody></table></td><td class="last" style="padding:0px;"><table class="borderNone"><tbody><tr><td>4:6</td><td>6:4</td><td>11:9</td></tr></tbody></table></td></tr><tr class="a"><td class="first">2.</td><td>Po odpoczynku</td><td>Juniorzy - do 18 lat<br>Gra pojedyncza, Dziewczęta</td><td style="padding:0px;"><table class="borderNone" style=" margin: 0 auto; "><tbody><tr><td class="r" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=JAS1633755 " target="_blank">Jasińska Nadia</a></td><td> vs </td><td class="l" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=ROS2148451 " target="_blank">Rosińska Hanna</a></td></tr></tbody></table></td><td class="last" style="padding:0px;"><table class="borderNone"><tbody><tr><td>6:1</td><td>6:2</td><td></td></tr></tbody></table></td></tr><tr><td class="first">3.</td><td>Następnie</td><td>Juniorzy - do 18 lat<br>Gra pojedyncza, Dziewczęta</td><td style="padding:0px;"><table class="borderNone" style=" margin: 0 auto; "><tbody><tr><td class="r" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=JAS1633755 " target="_blank">Jasińska Nadia</a></td><td> vs </td><td class="l" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=MIC2158319 " target="_blank">Michaś Zofia</a></td></tr></tbody></table></td><td class="last" style="padding:0px;"><table class="borderNone"><tbody><tr><td>6:1</td><td>6:0</td><td></td></tr></tbody></table></td></tr>



                                                    <tr>
                                                        <th class="borBlue b" colspan="5">Kort 04</th>
                                                    </tr>
                                                    <tr><td class="first">1.</td><td>Początek 11:00</td><td>Juniorzy - do 18 lat<br>Gra pojedyncza, Dziewczęta</td><td style="padding:0px;"><table class="borderNone" style=" margin: 0 auto; "><tbody><tr><td class="r" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=KOP2574700 " target="_blank">Kopeć Laura </a></td><td> vs </td><td class="l" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=BOG1938744 " target="_blank">Bogusz Milena</a></td></tr></tbody></table></td><td class="last" style="padding:0px;"><table class="borderNone"><tbody><tr><td>6:1</td><td>6:0</td><td></td></tr></tbody></table></td></tr><tr class="a"><td class="first">2.</td><td>Po odpoczynku</td><td>Juniorzy - do 18 lat<br>Gra pojedyncza, Dziewczęta</td><td style="padding:0px;"><table class="borderNone" style=" margin: 0 auto; "><tbody><tr><td class="r" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=TOM2470965 " target="_blank">Tomczyk Lidia </a></td><td> vs </td><td class="l" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=BOG1938744 " target="_blank">Bogusz Milena</a></td></tr></tbody></table></td><td class="last" style="padding:0px;"><table class="borderNone"><tbody><tr><td>6:1</td><td>6:2</td><td></td></tr></tbody></table></td></tr><tr><td class="first">3.</td><td>Po odpoczynku</td><td>Juniorzy - do 18 lat<br>Gra pojedyncza, Dziewczęta</td><td style="padding:0px;"><table class="borderNone" style=" margin: 0 auto; "><tbody><tr><td class="r" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=KOP2574700 " target="_blank">Kopeć Laura </a></td><td> vs </td><td class="l" style="width:200px;"><a href="/PlayerProfile.aspx?UserID=TOM2470965 " target="_blank">Tomczyk Lidia </a></td></tr></tbody></table></td><td class="last" style="padding:0px;"><table class="borderNone"><tbody><tr><td>7:5</td><td>6:3</td><td></td></tr></tbody></table></td></tr>

                                                </tbody></table>




</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

                        </div>
                        <div class="mainContainerBigBottom"></div>                                                        
                    </div>
                </div>
            </div>
            <div class="main">
                <div class="m_boxTransferuj"><img src="/Images/tpay-820x45.png" alt=""></div>
            </div>



    <div class="main">
        <div class="dFooterContainerMain">
            <div class="dFooterTop">
                <div class="dFooterTopLeft">
                    <div class="dFooterTopRight">
                        <div class="dFooterTopCenter"></div>
                    </div>
                </div>
                <div class="dFooterTopContent">
                    <div class="dFooterTopContentLeft">POLSKI ZWIĄZEK TENISOWY <br>ul. Konduktorska 4 lok.19/U <br>(wejście I, parter).<br>00-775 Warszawa <br>tel. (48-22) 122 12 00, 122 12 01<br>fax. (48-22) 122 12 11<br>e-mail: pzt@pzt.pl</div><div class="dFooterTopContentCenter"></div><div class="dFooterTopContentRight">Rachunek opłat statutowych: Bank Pekao S.A. <br>20 1240 1037 1111 0011 1172 8672<br>Rachunek Kolegium Sędziów: Bank Pekao S.A. <br>61 1240 1037 1111 0011 1172 8904<br>Dane do faktur: <br>Polski Związek Tenisowy <br>ul. Konduktorska 4 lok.19/U <br>00-775 Warszawa<br>NIP: 526-21-70-384 <br></div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="dFooterBottom">
                <div class="dFooterLeft">Copyright Polski Związek Tenisowy.<br>All rights reserved</div>
                <div class="dFooterRight">projekt i wykonanie <a href="http://www.e-ares.pl" id="ctl00_cFooter_A1" target="_blank">e-ARES Sp. z o.o.</a></div>
            </div>
        </div>
    </div>

    <div id="dProgressM">
        <div id="waitBgrd" class="loadingBG_v2"></div>
        <div id="waitBox" class="loading_v2">Proszę czekać<br>
            <div class="progress_v2"></div>
        </div> 
    </div>  
<script src="/Scripts/cookies.js" type="text/javascript"></script>
        </div>
        <div id="bodyBG"></div>
    </form>

<div id="cluetip-waitimage" style="position: absolute; display: none;"></div><div id="cluetip" style="position: absolute; display: none;"><div class="cluetip-outer" style="position: relative; z-index: 97;"><h3 class="cluetip-title ui-widget-header ui-cluetip-header" style="font-size:14px; padding: 8px 10px 4px; background:#ededed;"></h3><div class="cluetip-inner ui-widget-content ui-cluetip-content" style="font-size:12px; background:#ffffff; color:#000000;"></div></div><div class="cluetip-extra"></div></div><div class="menuHorizontalSubMenu" style="z-index: 2000; left: 0px; top: 0px; visibility: hidden;"><ul id="ddsubtkr" style="left: 0px; top: -1000px; visibility: hidden;">
				<li><a href="http://www.pzt.pl/1_532/klub-roku-pro.aspx" target="_blank">KLUB ROKU TENIS PRO</a></li>
				<li><a href="/RankT10.aspx">KLUB ROKU TENIS 10</a></li>
				<li><a href="/RankLTT.aspx">KLUB ROKU LTT by BABOLAT</a></li>
				<li><a href="/RankSIA.aspx">KLUB ROKU TOP</a></li>



			</ul></div><div id="cookie_info"><div id="cookies-message" class="contCookiesInfo"><a id="close_info_cookie" class="cooClose"><img src="/Images/close.png"></a><div class="text">Strona portal.pzt.pl używa plików cookies. Korzystanie z witryny bez zmiany ustawień Twojej przeglądarki oznacza, że będą one umieszczane w Twoim urządzeniu końcowym.</div></div></div><div id="automa-palette"><template shadowrootmode="open"><style>.tippy-box[data-animation=shift-toward-subtle][data-state=hidden]{opacity:0}.tippy-box[data-animation=shift-toward-subtle][data-state=hidden][data-placement^=top][data-state=hidden]{transform:translateY(-5px)}.tippy-box[data-animation=shift-toward-subtle][data-state=hidden][data-placement^=bottom][data-state=hidden]{transform:translateY(5px)}.tippy-box[data-animation=shift-toward-subtle][data-state=hidden][data-placement^=left][data-state=hidden]{transform:translateX(-5px)}.tippy-box[data-animation=shift-toward-subtle][data-state=hidden][data-placement^=right][data-state=hidden]{transform:translateX(5px)}

.input-ui input[type='color'] {
  padding-top: 0 !important;
  padding-bottom: 0 !important;
}


.root {
  font-size: 16px;
  z-index: 99999;
  line-height: 1.5 !important;
  font-family: 'Inter var', sans-serif;
  font-feature-settings: 'cv02', 'cv03', 'cv04', 'cv11';
}
.root-card:hover .drag-button {
  transform: scale(1);
}
.drag-button {
  transform: scale(0);
  transition: transform 200ms ease-in-out;
}
.main-tab {
  background-color: transparent !important;
  padding: 0 !important;
}
.main-tab .ui-tab.is-active.fill {
  --tw-bg-opacity: 1 !important;
  background-color: rgb(var(--color-accent) / var(--tw-bg-opacity, 1)) !important;
  --tw-text-opacity: 1 !important;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1)) !important;
}


.ui-tab[data-v-681b5d14] {
  z-index: 1;
  border-bottom-width: 2px;
  border-color: transparent;
  padding-top: 12px;
  padding-bottom: 12px;
  padding-left: 8px;
  padding-right: 8px;
}
.ui-tab.small[data-v-681b5d14] {
  padding: 8px;
}
.ui-tab.fill[data-v-681b5d14] {
  border-radius: 8px;
  border-bottom-width: 0px;
  padding-left: 16px;
  padding-right: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
}
.ui-tab.fill.small[data-v-681b5d14] {
  padding: 8px;
}
.ui-tab.is-active[data-v-681b5d14] {
  --tw-border-opacity: 1;
  border-color: rgb(var(--color-accent) / var(--tw-border-opacity, 1));
  --tw-text-opacity: 1;
  color: rgb(39 39 42 / var(--tw-text-opacity, 1));
}
.ui-tab.is-active[data-v-681b5d14]:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(244 244 245 / var(--tw-border-opacity, 1));
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}
.ui-tab.is-active.fill[data-v-681b5d14] {
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.ui-tab.is-active.fill[data-v-681b5d14]:is(.dark *) {
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.ui-tab.is-active[data-v-681b5d14] {
  --tw-border-opacity: 1;
  border-color: rgb(var(--color-accent) / var(--tw-border-opacity, 1));
  --tw-text-opacity: 1;
  color: rgb(39 39 42 / var(--tw-text-opacity, 1));
}
.ui-tab.is-active[data-v-681b5d14]:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(244 244 245 / var(--tw-border-opacity, 1));
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}


.ui-tabs__indicator {
  min-height: 24px;
  min-width: 50px;
  transition-duration: 200ms;
  transition-property: transform, width;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}


.button-loading {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}


.ui-select__arrow {
  top: 50%;
  transform: translateY(-50%) rotate(90deg);
}
.ui-select option,
.ui-select optgroup {
  --tw-bg-opacity: 1;
  background-color: rgb(244 244 245 / var(--tw-bg-opacity, 1));
}
.ui-select option:is(.dark *),
.ui-select optgroup:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(63 63 70 / var(--tw-bg-opacity, 1));
}


.ui-switch[data-v-cc5de7b2] {
  overflow: hidden;
  transition: all 250ms ease;
}
.ui-switch[data-v-cc5de7b2]:active {
  transform: scale(0.93);
}
.ui-switch__ball[data-v-cc5de7b2] {
  transition: all 250ms ease;
  left: 6px;
}
.ui-switch__background[data-v-cc5de7b2] {
  transition: all 250ms ease;
  margin-left: -100%;
}
.ui-switch:hover .ui-switch__ball[data-v-cc5de7b2] {
  transform: scale(1.1);
}
.ui-switch input:focus ~ .ui-switch__ball[data-v-cc5de7b2] {
  transform: scale(1.1);
}
.ui-switch input:checked ~ .ui-switch__ball[data-v-cc5de7b2]:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(24 24 27 / var(--tw-bg-opacity, 1));
}
.ui-switch input:checked ~ .ui-switch__ball[data-v-cc5de7b2] {
  background-color: white;
  left: calc(100% - 21px);
}
.ui-switch input:checked ~ .ui-switch__background[data-v-cc5de7b2] {
  margin-left: 0;
}


.checkbox-ui__input:checked ~ .checkbox-ui__mark .v-remixicon[data-v-32d46196],
.checkbox-ui__input.indeterminate ~ .checkbox-ui__mark .v-remixicon[data-v-32d46196] {
  transform: scale(1) !important;
}
.checkbox-ui .v-remixicon[data-v-32d46196] {
  transform: scale(0);
}
.checkbox-ui__input:checked ~ .checkbox-ui__mark[data-v-32d46196],
.checkbox-ui__input.indeterminate ~ .checkbox-ui__mark[data-v-32d46196] {
  --tw-border-opacity: 1;
  border-color: rgb(var(--color-accent) / var(--tw-border-opacity, 1));
  background-color: rgb(var(--color-accent) / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 1;
}
.checkbox-ui__mark[data-v-32d46196] {
  width: 100%;
  height: 100%;
  transition-property: background-color, border-color;
  transition-timing-function: ease;
  transition-duration: 200ms;
  display: flex;
  align-items: center;
  justify-content: center;
}
.checkbox-ui__mark .v-remixicon[data-v-32d46196] {
  transform: scale(0) !important;
  transition: transform 200ms ease;
}


.expand-enter-active,
.expand-leave-active {
  transition: height 0.2s ease-in-out;
  overflow: hidden;
}
.expand-enter,
.expand-leave-to {
  height: 0;
}

*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}

::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}/*
! tailwindcss v3.4.17 | MIT License | https://tailwindcss.com
*//*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: #e4e4e7; /* 2 */
}

::before,
::after {
  --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured `sans` font-family by default.
5. Use the user's configured `sans` font-feature-settings by default.
6. Use the user's configured `sans` font-variation-settings by default.
7. Disable tap highlights on iOS
*/

html,
:host {
  line-height: 1.5; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
  -moz-tab-size: 4; /* 3 */
  -o-tab-size: 4;
     tab-size: 4; /* 3 */
  font-family: Poppins, sans-serif; /* 4 */
  font-feature-settings: normal; /* 5 */
  font-variation-settings: normal; /* 6 */
  -webkit-tap-highlight-color: transparent; /* 7 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from `html` so users can set them as a class directly on the `html` element.
*/

body {
  margin: 0; /* 1 */
  line-height: inherit; /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
  border-top-width: 1px; /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  -webkit-text-decoration: underline dotted;
          text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
1. Use the user's configured `mono` font-family by default.
2. Use the user's configured `mono` font-feature-settings by default.
3. Use the user's configured `mono` font-variation-settings by default.
4. Correct the odd `em` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: Source Code Pro, monospace; /* 1 */
  font-feature-settings: normal; /* 2 */
  font-variation-settings: normal; /* 3 */
  font-size: 1em; /* 4 */
}

/*
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
Prevent `sub` and `sup` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
  border-collapse: collapse; /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-feature-settings: inherit; /* 1 */
  font-variation-settings: inherit; /* 1 */
  font-size: 100%; /* 1 */
  font-weight: inherit; /* 1 */
  line-height: inherit; /* 1 */
  letter-spacing: inherit; /* 1 */
  color: inherit; /* 1 */
  margin: 0; /* 2 */
  padding: 0; /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/

button,
select {
  text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/

button,
input:where([type='button']),
input:where([type='reset']),
input:where([type='submit']) {
  -webkit-appearance: button; /* 1 */
  background-color: transparent; /* 2 */
  background-image: none; /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
Remove the additional `:invalid` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield; /* 1 */
  outline-offset: -2px; /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to `inherit` in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

fieldset {
  margin: 0;
  padding: 0;
}

legend {
  padding: 0;
}

ol,
ul,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/*
Reset default styling for dialogs.
*/
dialog {
  padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/

input::-moz-placeholder, textarea::-moz-placeholder {
  opacity: 1; /* 1 */
  color: #a1a1aa; /* 2 */
}

input::placeholder,
textarea::placeholder {
  opacity: 1; /* 1 */
  color: #a1a1aa; /* 2 */
}

/*
Set the default cursor for buttons.
*/

button,
[role="button"] {
  cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/
:disabled {
  cursor: default;
}

/*
1. Make replaced elements `display: block` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add `vertical-align: middle` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */
[hidden]:where(:not([hidden="until-found"])) {
  display: none;
}
.\!container {
  width: 100% !important;
  margin-right: auto !important;
  margin-left: auto !important;
  padding-right: 1rem !important;
  padding-left: 1rem !important;
}
.container {
  width: 100%;
  margin-right: auto;
  margin-left: auto;
  padding-right: 1rem;
  padding-left: 1rem;
}
@media (min-width: 640px) {

  .\!container {
    max-width: 640px !important;
    padding-right: 2rem !important;
    padding-left: 2rem !important;
  }

  .container {
    max-width: 640px;
    padding-right: 2rem;
    padding-left: 2rem;
  }
}
@media (min-width: 768px) {

  .\!container {
    max-width: 768px !important;
  }

  .container {
    max-width: 768px;
  }
}
@media (min-width: 1024px) {

  .\!container {
    max-width: 1024px !important;
  }

  .container {
    max-width: 1024px;
  }
}
@media (min-width: 1280px) {

  .\!container {
    max-width: 1280px !important;
  }

  .container {
    max-width: 1280px;
  }
}
@media (min-width: 1536px) {

  .\!container {
    max-width: 1536px !important;
  }

  .container {
    max-width: 1536px;
  }
}
.prose {
  color: var(--tw-prose-body);
  max-width: 65ch;
}
.prose :where(p):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.25em;
  margin-bottom: 1.25em;
}
.prose :where([class~="lead"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-lead);
  font-size: 1.25em;
  line-height: 1.6;
  margin-top: 1.2em;
  margin-bottom: 1.2em;
}
.prose :where(a):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-links);
  text-decoration: underline;
  font-weight: 500;
}
.prose :where(strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-bold);
  font-weight: 600;
}
.prose :where(a strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(blockquote strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(thead th strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(ol):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: decimal;
  margin-top: 1.25em;
  margin-bottom: 1.25em;
  padding-inline-start: 1.625em;
}
.prose :where(ol[type="A"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: upper-alpha;
}
.prose :where(ol[type="a"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: lower-alpha;
}
.prose :where(ol[type="A" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: upper-alpha;
}
.prose :where(ol[type="a" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: lower-alpha;
}
.prose :where(ol[type="I"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: upper-roman;
}
.prose :where(ol[type="i"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: lower-roman;
}
.prose :where(ol[type="I" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: upper-roman;
}
.prose :where(ol[type="i" s]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: lower-roman;
}
.prose :where(ol[type="1"]):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: decimal;
}
.prose :where(ul):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  list-style-type: disc;
  margin-top: 1.25em;
  margin-bottom: 1.25em;
  padding-inline-start: 1.625em;
}
.prose :where(ol > li):not(:where([class~="not-prose"],[class~="not-prose"] *))::marker {
  font-weight: 400;
  color: var(--tw-prose-counters);
}
.prose :where(ul > li):not(:where([class~="not-prose"],[class~="not-prose"] *))::marker {
  color: var(--tw-prose-bullets);
}
.prose :where(dt):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  margin-top: 1.25em;
}
.prose :where(hr):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-color: var(--tw-prose-hr);
  border-top-width: 1px;
  margin-top: 3em;
  margin-bottom: 3em;
}
.prose :where(blockquote):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 500;
  font-style: italic;
  color: var(--tw-prose-quotes);
  border-inline-start-width: 0.25rem;
  border-inline-start-color: var(--tw-prose-quote-borders);
  quotes: "\201C""\201D""\2018""\2019";
  margin-top: 1.6em;
  margin-bottom: 1.6em;
  padding-inline-start: 1em;
}
.prose :where(blockquote p:first-of-type):not(:where([class~="not-prose"],[class~="not-prose"] *))::before {
  content: open-quote;
}
.prose :where(blockquote p:last-of-type):not(:where([class~="not-prose"],[class~="not-prose"] *))::after {
  content: close-quote;
}
.prose :where(h1):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 800;
  font-size: 2.25em;
  margin-top: 0;
  margin-bottom: 0.8888889em;
  line-height: 1.1111111;
}
.prose :where(h1 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 900;
  color: inherit;
}
.prose :where(h2):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 700;
  font-size: 1.5em;
  margin-top: 2em;
  margin-bottom: 1em;
  line-height: 1.3333333;
}
.prose :where(h2 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 800;
  color: inherit;
}
.prose :where(h3):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  font-size: 1.25em;
  margin-top: 1.6em;
  margin-bottom: 0.6em;
  line-height: 1.6;
}
.prose :where(h3 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 700;
  color: inherit;
}
.prose :where(h4):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  margin-top: 1.5em;
  margin-bottom: 0.5em;
  line-height: 1.5;
}
.prose :where(h4 strong):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 700;
  color: inherit;
}
.prose :where(img):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 2em;
  margin-bottom: 2em;
}
.prose :where(picture):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  display: block;
  margin-top: 2em;
  margin-bottom: 2em;
}
.prose :where(video):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 2em;
  margin-bottom: 2em;
}
.prose :where(kbd):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  font-weight: 500;
  font-family: inherit;
  color: var(--tw-prose-kbd);
  box-shadow: 0 0 0 1px rgb(var(--tw-prose-kbd-shadows) / 10%), 0 3px 0 rgb(var(--tw-prose-kbd-shadows) / 10%);
  font-size: 0.875em;
  border-radius: 0.3125rem;
  padding-top: 0.1875em;
  padding-inline-end: 0.375em;
  padding-bottom: 0.1875em;
  padding-inline-start: 0.375em;
}
.prose :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-code);
  font-weight: 600;
  font-size: 0.875em;
}
.prose :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *))::before {
  content: "`";
}
.prose :where(code):not(:where([class~="not-prose"],[class~="not-prose"] *))::after {
  content: "`";
}
.prose :where(a code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(h1 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(h2 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
  font-size: 0.875em;
}
.prose :where(h3 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
  font-size: 0.9em;
}
.prose :where(h4 code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(blockquote code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(thead th code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: inherit;
}
.prose :where(pre):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-pre-code);
  background-color: var(--tw-prose-pre-bg);
  overflow-x: auto;
  font-weight: 400;
  font-size: 0.875em;
  line-height: 1.7142857;
  margin-top: 1.7142857em;
  margin-bottom: 1.7142857em;
  border-radius: 0.375rem;
  padding-top: 0.8571429em;
  padding-inline-end: 1.1428571em;
  padding-bottom: 0.8571429em;
  padding-inline-start: 1.1428571em;
}
.prose :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  background-color: transparent;
  border-width: 0;
  border-radius: 0;
  padding: 0;
  font-weight: inherit;
  color: inherit;
  font-size: inherit;
  font-family: inherit;
  line-height: inherit;
}
.prose :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *))::before {
  content: none;
}
.prose :where(pre code):not(:where([class~="not-prose"],[class~="not-prose"] *))::after {
  content: none;
}
.prose :where(table):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  width: 100%;
  table-layout: auto;
  margin-top: 2em;
  margin-bottom: 2em;
  font-size: 0.875em;
  line-height: 1.7142857;
}
.prose :where(thead):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-bottom-width: 1px;
  border-bottom-color: var(--tw-prose-th-borders);
}
.prose :where(thead th):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-headings);
  font-weight: 600;
  vertical-align: bottom;
  padding-inline-end: 0.5714286em;
  padding-bottom: 0.5714286em;
  padding-inline-start: 0.5714286em;
}
.prose :where(tbody tr):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-bottom-width: 1px;
  border-bottom-color: var(--tw-prose-td-borders);
}
.prose :where(tbody tr:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-bottom-width: 0;
}
.prose :where(tbody td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  vertical-align: baseline;
}
.prose :where(tfoot):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  border-top-width: 1px;
  border-top-color: var(--tw-prose-th-borders);
}
.prose :where(tfoot td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  vertical-align: top;
}
.prose :where(th, td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  text-align: start;
}
.prose :where(figure > *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
  margin-bottom: 0;
}
.prose :where(figcaption):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  color: var(--tw-prose-captions);
  font-size: 0.875em;
  line-height: 1.4285714;
  margin-top: 0.8571429em;
}
.prose {
  --tw-prose-body: #374151;
  --tw-prose-headings: #111827;
  --tw-prose-lead: #4b5563;
  --tw-prose-links: #111827;
  --tw-prose-bold: #111827;
  --tw-prose-counters: #6b7280;
  --tw-prose-bullets: #d1d5db;
  --tw-prose-hr: #e5e7eb;
  --tw-prose-quotes: #111827;
  --tw-prose-quote-borders: #e5e7eb;
  --tw-prose-captions: #6b7280;
  --tw-prose-kbd: #111827;
  --tw-prose-kbd-shadows: 17 24 39;
  --tw-prose-code: #111827;
  --tw-prose-pre-code: #e5e7eb;
  --tw-prose-pre-bg: #1f2937;
  --tw-prose-th-borders: #d1d5db;
  --tw-prose-td-borders: #e5e7eb;
  --tw-prose-invert-body: #d1d5db;
  --tw-prose-invert-headings: #fff;
  --tw-prose-invert-lead: #9ca3af;
  --tw-prose-invert-links: #fff;
  --tw-prose-invert-bold: #fff;
  --tw-prose-invert-counters: #9ca3af;
  --tw-prose-invert-bullets: #4b5563;
  --tw-prose-invert-hr: #374151;
  --tw-prose-invert-quotes: #f3f4f6;
  --tw-prose-invert-quote-borders: #374151;
  --tw-prose-invert-captions: #9ca3af;
  --tw-prose-invert-kbd: #fff;
  --tw-prose-invert-kbd-shadows: 255 255 255;
  --tw-prose-invert-code: #fff;
  --tw-prose-invert-pre-code: #d1d5db;
  --tw-prose-invert-pre-bg: rgb(0 0 0 / 50%);
  --tw-prose-invert-th-borders: #4b5563;
  --tw-prose-invert-td-borders: #374151;
  font-size: 1rem;
  line-height: 1.75;
}
.prose :where(picture > img):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
  margin-bottom: 0;
}
.prose :where(li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.5em;
  margin-bottom: 0.5em;
}
.prose :where(ol > li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0.375em;
}
.prose :where(ul > li):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0.375em;
}
.prose :where(.prose > ul > li p):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.75em;
  margin-bottom: 0.75em;
}
.prose :where(.prose > ul > li > p:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.25em;
}
.prose :where(.prose > ul > li > p:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-bottom: 1.25em;
}
.prose :where(.prose > ol > li > p:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.25em;
}
.prose :where(.prose > ol > li > p:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-bottom: 1.25em;
}
.prose :where(ul ul, ul ol, ol ul, ol ol):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.75em;
  margin-bottom: 0.75em;
}
.prose :where(dl):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 1.25em;
  margin-bottom: 1.25em;
}
.prose :where(dd):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0.5em;
  padding-inline-start: 1.625em;
}
.prose :where(hr + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}
.prose :where(h2 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}
.prose :where(h3 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}
.prose :where(h4 + *):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}
.prose :where(thead th:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0;
}
.prose :where(thead th:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-end: 0;
}
.prose :where(tbody td, tfoot td):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-top: 0.5714286em;
  padding-inline-end: 0.5714286em;
  padding-bottom: 0.5714286em;
  padding-inline-start: 0.5714286em;
}
.prose :where(tbody td:first-child, tfoot td:first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-start: 0;
}
.prose :where(tbody td:last-child, tfoot td:last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  padding-inline-end: 0;
}
.prose :where(figure):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 2em;
  margin-bottom: 2em;
}
.prose :where(.prose > :first-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-top: 0;
}
.prose :where(.prose > :last-child):not(:where([class~="not-prose"],[class~="not-prose"] *)) {
  margin-bottom: 0;
}
.prose-zinc {
  --tw-prose-body: #3f3f46;
  --tw-prose-headings: #18181b;
  --tw-prose-lead: #52525b;
  --tw-prose-links: #18181b;
  --tw-prose-bold: #18181b;
  --tw-prose-counters: #71717a;
  --tw-prose-bullets: #d4d4d8;
  --tw-prose-hr: #e4e4e7;
  --tw-prose-quotes: #18181b;
  --tw-prose-quote-borders: #e4e4e7;
  --tw-prose-captions: #71717a;
  --tw-prose-kbd: #18181b;
  --tw-prose-kbd-shadows: 24 24 27;
  --tw-prose-code: #18181b;
  --tw-prose-pre-code: #e4e4e7;
  --tw-prose-pre-bg: #27272a;
  --tw-prose-th-borders: #d4d4d8;
  --tw-prose-td-borders: #e4e4e7;
  --tw-prose-invert-body: #d4d4d8;
  --tw-prose-invert-headings: #fff;
  --tw-prose-invert-lead: #a1a1aa;
  --tw-prose-invert-links: #fff;
  --tw-prose-invert-bold: #fff;
  --tw-prose-invert-counters: #a1a1aa;
  --tw-prose-invert-bullets: #52525b;
  --tw-prose-invert-hr: #3f3f46;
  --tw-prose-invert-quotes: #f4f4f5;
  --tw-prose-invert-quote-borders: #3f3f46;
  --tw-prose-invert-captions: #a1a1aa;
  --tw-prose-invert-kbd: #fff;
  --tw-prose-invert-kbd-shadows: 255 255 255;
  --tw-prose-invert-code: #fff;
  --tw-prose-invert-pre-code: #d4d4d8;
  --tw-prose-invert-pre-bg: rgb(0 0 0 / 50%);
  --tw-prose-invert-th-borders: #52525b;
  --tw-prose-invert-td-borders: #3f3f46;
}
.pointer-events-none {
  pointer-events: none;
}
.pointer-events-auto {
  pointer-events: auto;
}
.visible {
  visibility: visible;
}
.invisible {
  visibility: hidden;
}
.static {
  position: static;
}
.fixed {
  position: fixed;
}
.absolute {
  position: absolute;
}
.relative {
  position: relative;
}
.sticky {
  position: sticky;
}
.-right-2 {
  right: -8px;
}
.-top-1 {
  top: -4px;
}
.-top-2 {
  top: -8px;
}
.bottom-0 {
  bottom: 0px;
}
.bottom-2 {
  bottom: 8px;
}
.bottom-5 {
  bottom: 20px;
}
.bottom-8 {
  bottom: 32px;
}
.left-0 {
  left: 0px;
}
.left-1\/2 {
  left: 50%;
}
.left-2 {
  left: 8px;
}
.right-0 {
  right: 0px;
}
.right-2 {
  right: 8px;
}
.right-4 {
  right: 16px;
}
.right-8 {
  right: 32px;
}
.top-0 {
  top: 0px;
}
.top-1\/2 {
  top: 50%;
}
.top-2 {
  top: 8px;
}
.top-4 {
  top: 16px;
}
.top-8 {
  top: 32px;
}
.top-full {
  top: 100%;
}
.z-0 {
  z-index: 0;
}
.z-10 {
  z-index: 10;
}
.z-20 {
  z-index: 20;
}
.z-40 {
  z-index: 40;
}
.z-50 {
  z-index: 50;
}
.z-\[1\] {
  z-index: 1;
}
.col-span-1 {
  grid-column: span 1 / span 1;
}
.col-span-2 {
  grid-column: span 2 / span 2;
}
.col-span-3 {
  grid-column: span 3 / span 3;
}
.col-span-4 {
  grid-column: span 4 / span 4;
}
.col-span-5 {
  grid-column: span 5 / span 5;
}
.col-span-6 {
  grid-column: span 6 / span 6;
}
.m-4 {
  margin: 16px;
}
.m-5 {
  margin: 20px;
}
.mx-1 {
  margin-left: 4px;
  margin-right: 4px;
}
.mx-2 {
  margin-left: 8px;
  margin-right: 8px;
}
.mx-4 {
  margin-left: 16px;
  margin-right: 16px;
}
.mx-auto {
  margin-left: auto;
  margin-right: auto;
}
.my-1 {
  margin-top: 4px;
  margin-bottom: 4px;
}
.my-2 {
  margin-top: 8px;
  margin-bottom: 8px;
}
.my-4 {
  margin-top: 16px;
  margin-bottom: 16px;
}
.my-6 {
  margin-top: 24px;
  margin-bottom: 24px;
}
.my-8 {
  margin-top: 32px;
  margin-bottom: 32px;
}
.-ml-1 {
  margin-left: -4px;
}
.-ml-2 {
  margin-left: -8px;
}
.-ml-6 {
  margin-left: -24px;
}
.-mr-1 {
  margin-right: -4px;
}
.-mr-2 {
  margin-right: -8px;
}
.-mt-1 {
  margin-top: -4px;
}
.-mt-2 {
  margin-top: -8px;
}
.mb-1 {
  margin-bottom: 4px;
}
.mb-10 {
  margin-bottom: 40px;
}
.mb-12 {
  margin-bottom: 48px;
}
.mb-2 {
  margin-bottom: 8px;
}
.mb-4 {
  margin-bottom: 16px;
}
.mb-6 {
  margin-bottom: 24px;
}
.mb-8 {
  margin-bottom: 32px;
}
.ml-1 {
  margin-left: 4px;
}
.ml-12 {
  margin-left: 48px;
}
.ml-2 {
  margin-left: 8px;
}
.ml-3 {
  margin-left: 12px;
}
.ml-4 {
  margin-left: 16px;
}
.ml-6 {
  margin-left: 24px;
}
.mr-0\.5 {
  margin-right: 2px;
}
.mr-1 {
  margin-right: 4px;
}
.mr-12 {
  margin-right: 48px;
}
.mr-2 {
  margin-right: 8px;
}
.mr-3 {
  margin-right: 12px;
}
.mr-4 {
  margin-right: 16px;
}
.mr-6 {
  margin-right: 24px;
}
.mr-8 {
  margin-right: 32px;
}
.mt-1 {
  margin-top: 4px;
}
.mt-10 {
  margin-top: 40px;
}
.mt-12 {
  margin-top: 48px;
}
.mt-2 {
  margin-top: 8px;
}
.mt-3 {
  margin-top: 12px;
}
.mt-4 {
  margin-top: 16px;
}
.mt-5 {
  margin-top: 20px;
}
.mt-6 {
  margin-top: 24px;
}
.mt-8 {
  margin-top: 32px;
}
.\!block {
  display: block !important;
}
.block {
  display: block;
}
.inline-block {
  display: inline-block;
}
.inline {
  display: inline;
}
.\!flex {
  display: flex !important;
}
.flex {
  display: flex;
}
.inline-flex {
  display: inline-flex;
}
.\!table {
  display: table !important;
}
.table {
  display: table;
}
.grid {
  display: grid;
}
.hidden {
  display: none;
}
.\!h-8 {
  height: 32px !important;
}
.h-10 {
  height: 40px;
}
.h-12 {
  height: 48px;
}
.h-28 {
  height: 112px;
}
.h-3 {
  height: 12px;
}
.h-32 {
  height: 128px;
}
.h-4 {
  height: 16px;
}
.h-40 {
  height: 160px;
}
.h-48 {
  height: 192px;
}
.h-5 {
  height: 20px;
}
.h-56 {
  height: 224px;
}
.h-6 {
  height: 24px;
}
.h-7 {
  height: 28px;
}
.h-72 {
  height: 288px;
}
.h-8 {
  height: 32px;
}
.h-\[105px\] {
  height: 105px;
}
.h-\[1px\] {
  height: 1px;
}
.h-\[22px\] {
  height: 22px;
}
.h-full {
  height: 100%;
}
.h-screen {
  height: 100vh;
}
.max-h-56 {
  max-height: 224px;
}
.max-h-60 {
  max-height: 240px;
}
.max-h-80 {
  max-height: 320px;
}
.max-h-96 {
  max-height: 384px;
}
.w-10 {
  width: 40px;
}
.w-11\/12 {
  width: 91.666667%;
}
.w-12 {
  width: 48px;
}
.w-14 {
  width: 56px;
}
.w-16 {
  width: 64px;
}
.w-2 {
  width: 8px;
}
.w-2\/12 {
  width: 16.666667%;
}
.w-20 {
  width: 80px;
}
.w-24 {
  width: 96px;
}
.w-28 {
  width: 112px;
}
.w-3 {
  width: 12px;
}
.w-3\/12 {
  width: 25%;
}
.w-32 {
  width: 128px;
}
.w-36 {
  width: 144px;
}
.w-4 {
  width: 16px;
}
.w-4\/12 {
  width: 33.333333%;
}
.w-40 {
  width: 160px;
}
.w-44 {
  width: 176px;
}
.w-48 {
  width: 192px;
}
.w-5 {
  width: 20px;
}
.w-5\/12 {
  width: 41.666667%;
}
.w-52 {
  width: 208px;
}
.w-56 {
  width: 224px;
}
.w-6\/12 {
  width: 50%;
}
.w-60 {
  width: 240px;
}
.w-64 {
  width: 256px;
}
.w-72 {
  width: 288px;
}
.w-8 {
  width: 32px;
}
.w-8\/12 {
  width: 66.666667%;
}
.w-80 {
  width: 320px;
}
.w-96 {
  width: 384px;
}
.w-full {
  width: 100%;
}
.w-px {
  width: 1px;
}
.min-w-\[52px\] {
  min-width: 52px;
}
.min-w-\[90px\] {
  min-width: 90px;
}
.max-w-2xl {
  max-width: 672px;
}
.max-w-3xl {
  max-width: 768px;
}
.max-w-4xl {
  max-width: 896px;
}
.max-w-5xl {
  max-width: 1024px;
}
.max-w-\[170px\] {
  max-width: 170px;
}
.max-w-lg {
  max-width: 512px;
}
.max-w-md {
  max-width: 448px;
}
.max-w-none {
  max-width: none;
}
.max-w-sm {
  max-width: 384px;
}
.max-w-xl {
  max-width: 576px;
}
.flex-1 {
  flex: 1 1 0%;
}
.flex-shrink {
  flex-shrink: 1;
}
.flex-shrink-0 {
  flex-shrink: 0;
}
.shrink-0 {
  flex-shrink: 0;
}
.grow {
  flex-grow: 1;
}
.-translate-x-1\/2 {
  --tw-translate-x: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.-translate-y-1 {
  --tw-translate-y: -4px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.-translate-y-1\/2 {
  --tw-translate-y: -50%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.rotate-180 {
  --tw-rotate: 180deg;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.scale-0 {
  --tw-scale-x: 0;
  --tw-scale-y: 0;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
.transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}
@keyframes ping {

  75%, 100% {
    transform: scale(2);
    opacity: 0;
  }
}
.animate-ping {
  animation: ping 1s cubic-bezier(0, 0, 0.2, 1) infinite;
}
@keyframes pulse {

  50% {
    opacity: .5;
  }
}
.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
@keyframes spin {

  to {
    transform: rotate(360deg);
  }
}
.animate-spin {
  animation: spin 1s linear infinite;
}
.cursor-default {
  cursor: default;
}
.cursor-grab {
  cursor: grab;
}
.cursor-grabbing {
  cursor: grabbing;
}
.cursor-move {
  cursor: move;
}
.cursor-not-allowed {
  cursor: not-allowed;
}
.cursor-pointer {
  cursor: pointer;
}
.select-none {
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
}
.resize-none {
  resize: none;
}
.resize {
  resize: both;
}
.list-inside {
  list-style-position: inside;
}
.list-decimal {
  list-style-type: decimal;
}
.list-disc {
  list-style-type: disc;
}
.appearance-none {
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none;
}
.grid-cols-1 {
  grid-template-columns: repeat(1, minmax(0, 1fr));
}
.grid-cols-12 {
  grid-template-columns: repeat(12, minmax(0, 1fr));
}
.grid-cols-2 {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
.grid-cols-5 {
  grid-template-columns: repeat(5, minmax(0, 1fr));
}
.grid-cols-6 {
  grid-template-columns: repeat(6, minmax(0, 1fr));
}
.grid-cols-7 {
  grid-template-columns: repeat(7, minmax(0, 1fr));
}
.flex-col {
  flex-direction: column;
}
.flex-col-reverse {
  flex-direction: column-reverse;
}
.flex-wrap {
  flex-wrap: wrap;
}
.items-start {
  align-items: flex-start;
}
.items-end {
  align-items: flex-end;
}
.items-center {
  align-items: center;
}
.\!items-stretch {
  align-items: stretch !important;
}
.justify-end {
  justify-content: flex-end;
}
.justify-center {
  justify-content: center;
}
.justify-between {
  justify-content: space-between;
}
.justify-items-center {
  justify-items: center;
}
.gap-1 {
  gap: 4px;
}
.gap-2 {
  gap: 8px;
}
.gap-3 {
  gap: 12px;
}
.gap-4 {
  gap: 16px;
}
.gap-x-2 {
  -moz-column-gap: 8px;
       column-gap: 8px;
}
.gap-x-4 {
  -moz-column-gap: 16px;
       column-gap: 16px;
}
.gap-y-2 {
  row-gap: 8px;
}
.space-x-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(4px * var(--tw-space-x-reverse));
  margin-left: calc(4px * calc(1 - var(--tw-space-x-reverse)));
}
.space-x-2 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(8px * var(--tw-space-x-reverse));
  margin-left: calc(8px * calc(1 - var(--tw-space-x-reverse)));
}
.space-x-3 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(12px * var(--tw-space-x-reverse));
  margin-left: calc(12px * calc(1 - var(--tw-space-x-reverse)));
}
.space-x-4 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(16px * var(--tw-space-x-reverse));
  margin-left: calc(16px * calc(1 - var(--tw-space-x-reverse)));
}
.space-x-6 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-x-reverse: 0;
  margin-right: calc(24px * var(--tw-space-x-reverse));
  margin-left: calc(24px * calc(1 - var(--tw-space-x-reverse)));
}
.space-y-1 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(4px * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(4px * var(--tw-space-y-reverse));
}
.space-y-2 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(8px * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(8px * var(--tw-space-y-reverse));
}
.space-y-4 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(16px * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(16px * var(--tw-space-y-reverse));
}
.divide-y > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-y-reverse: 0;
  border-top-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width: calc(1px * var(--tw-divide-y-reverse));
}
.overflow-auto {
  overflow: auto;
}
.overflow-hidden {
  overflow: hidden;
}
.overflow-x-auto {
  overflow-x: auto;
}
.overflow-y-auto {
  overflow-y: auto;
}
.overflow-y-hidden {
  overflow-y: hidden;
}
.whitespace-nowrap {
  white-space: nowrap;
}
.whitespace-pre-wrap {
  white-space: pre-wrap;
}
.rounded {
  border-radius: 4px;
}
.rounded-full {
  border-radius: 9999px;
}
.rounded-lg {
  border-radius: 8px;
}
.rounded-md {
  border-radius: 6px;
}
.rounded-sm {
  border-radius: 2px;
}
.rounded-b-2xl {
  border-bottom-right-radius: 16px;
  border-bottom-left-radius: 16px;
}
.rounded-l-lg {
  border-top-left-radius: 8px;
  border-bottom-left-radius: 8px;
}
.rounded-l-none {
  border-top-left-radius: 0px;
  border-bottom-left-radius: 0px;
}
.rounded-r-lg {
  border-top-right-radius: 8px;
  border-bottom-right-radius: 8px;
}
.rounded-r-none {
  border-top-right-radius: 0px;
  border-bottom-right-radius: 0px;
}
.rounded-t-none {
  border-top-left-radius: 0px;
  border-top-right-radius: 0px;
}
.rounded-bl-\[22px\] {
  border-bottom-left-radius: 22px;
}
.rounded-bl-lg {
  border-bottom-left-radius: 8px;
}
.rounded-br-lg {
  border-bottom-right-radius: 8px;
}
.rounded-tr-lg {
  border-top-right-radius: 8px;
}
.border {
  border-width: 1px;
}
.border-2 {
  border-width: 2px;
}
.border-x {
  border-left-width: 1px;
  border-right-width: 1px;
}
.border-b {
  border-bottom-width: 1px;
}
.border-b-0 {
  border-bottom-width: 0px;
}
.border-b-2 {
  border-bottom-width: 2px;
}
.border-l {
  border-left-width: 1px;
}
.border-r {
  border-right-width: 1px;
}
.border-r-0 {
  border-right-width: 0px;
}
.border-t {
  border-top-width: 1px;
}
.border-dashed {
  border-style: dashed;
}
.border-none {
  border-style: none;
}
.border-accent {
  --tw-border-opacity: 1;
  border-color: rgb(var(--color-accent) / var(--tw-border-opacity, 1));
}
.border-blue-200 {
  --tw-border-opacity: 1;
  border-color: rgb(191 219 254 / var(--tw-border-opacity, 1));
}
.border-blue-500 {
  --tw-border-opacity: 1;
  border-color: rgb(59 130 246 / var(--tw-border-opacity, 1));
}
.border-cyan-200 {
  --tw-border-opacity: 1;
  border-color: rgb(165 243 252 / var(--tw-border-opacity, 1));
}
.border-gray-100 {
  --tw-border-opacity: 1;
  border-color: rgb(244 244 245 / var(--tw-border-opacity, 1));
}
.border-gray-200 {
  --tw-border-opacity: 1;
  border-color: rgb(228 228 231 / var(--tw-border-opacity, 1));
}
.border-gray-300 {
  --tw-border-opacity: 1;
  border-color: rgb(212 212 216 / var(--tw-border-opacity, 1));
}
.border-green-200 {
  --tw-border-opacity: 1;
  border-color: rgb(187 247 208 / var(--tw-border-opacity, 1));
}
.border-lime-200 {
  --tw-border-opacity: 1;
  border-color: rgb(217 249 157 / var(--tw-border-opacity, 1));
}
.border-orange-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 215 170 / var(--tw-border-opacity, 1));
}
.border-red-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 202 202 / var(--tw-border-opacity, 1));
}
.border-red-500 {
  --tw-border-opacity: 1;
  border-color: rgb(239 68 68 / var(--tw-border-opacity, 1));
}
.border-transparent {
  border-color: transparent;
}
.border-yellow-200 {
  --tw-border-opacity: 1;
  border-color: rgb(254 240 138 / var(--tw-border-opacity, 1));
}
.bg-\[\#79FFEB\] {
  --tw-bg-opacity: 1;
  background-color: rgb(121 255 235 / var(--tw-bg-opacity, 1));
}
.bg-\[\#e4e4e7\] {
  --tw-bg-opacity: 1;
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
}
.bg-\[\#f2f2f2\] {
  --tw-bg-opacity: 1;
  background-color: rgb(242 242 242 / var(--tw-bg-opacity, 1));
}
.bg-accent {
  --tw-bg-opacity: 1;
  background-color: rgb(var(--color-accent) / var(--tw-bg-opacity, 1));
}
.bg-amber-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(253 230 138 / var(--tw-bg-opacity, 1));
}
.bg-black {
  --tw-bg-opacity: 1;
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
}
.bg-blue-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(191 219 254 / var(--tw-bg-opacity, 1));
}
.bg-blue-300 {
  --tw-bg-opacity: 1;
  background-color: rgb(147 197 253 / var(--tw-bg-opacity, 1));
}
.bg-blue-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(59 130 246 / var(--tw-bg-opacity, 1));
}
.bg-blue-600 {
  --tw-bg-opacity: 1;
  background-color: rgb(37 99 235 / var(--tw-bg-opacity, 1));
}
.bg-cyan-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(165 243 252 / var(--tw-bg-opacity, 1));
}
.bg-gray-100 {
  --tw-bg-opacity: 1;
  background-color: rgb(244 244 245 / var(--tw-bg-opacity, 1));
}
.bg-gray-300 {
  --tw-bg-opacity: 1;
  background-color: rgb(212 212 216 / var(--tw-bg-opacity, 1));
}
.bg-gray-50 {
  --tw-bg-opacity: 1;
  background-color: rgb(250 250 250 / var(--tw-bg-opacity, 1));
}
.bg-gray-700 {
  --tw-bg-opacity: 1;
  background-color: rgb(63 63 70 / var(--tw-bg-opacity, 1));
}
.bg-gray-900 {
  --tw-bg-opacity: 1;
  background-color: rgb(24 24 27 / var(--tw-bg-opacity, 1));
}
.bg-green-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(187 247 208 / var(--tw-bg-opacity, 1));
}
.bg-green-300 {
  --tw-bg-opacity: 1;
  background-color: rgb(134 239 172 / var(--tw-bg-opacity, 1));
}
.bg-indigo-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(199 210 254 / var(--tw-bg-opacity, 1));
}
.bg-indigo-500 {
  --tw-bg-opacity: 1;
  background-color: rgb(99 102 241 / var(--tw-bg-opacity, 1));
}
.bg-lime-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(217 249 157 / var(--tw-bg-opacity, 1));
}
.bg-orange-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 215 170 / var(--tw-bg-opacity, 1));
}
.bg-primary {
  --tw-bg-opacity: 1;
  background-color: rgb(var(--color-primary) / var(--tw-bg-opacity, 1));
}
.bg-red-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 202 202 / var(--tw-bg-opacity, 1));
}
.bg-red-300 {
  --tw-bg-opacity: 1;
  background-color: rgb(252 165 165 / var(--tw-bg-opacity, 1));
}
.bg-red-400 {
  --tw-bg-opacity: 1;
  background-color: rgb(248 113 113 / var(--tw-bg-opacity, 1));
}
.bg-sky-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(186 230 253 / var(--tw-bg-opacity, 1));
}
.bg-transparent {
  background-color: transparent;
}
.bg-white {
  --tw-bg-opacity: 1;
  background-color: rgb(255 255 255 / var(--tw-bg-opacity, 1));
}
.bg-yellow-200 {
  --tw-bg-opacity: 1;
  background-color: rgb(254 240 138 / var(--tw-bg-opacity, 1));
}
.bg-opacity-10 {
  --tw-bg-opacity: 0.1;
}
.bg-opacity-20 {
  --tw-bg-opacity: 0.2;
}
.bg-opacity-30 {
  --tw-bg-opacity: 0.3;
}
.bg-opacity-5 {
  --tw-bg-opacity: 0.05;
}
.bg-opacity-50 {
  --tw-bg-opacity: 0.5;
}
.bg-opacity-75 {
  --tw-bg-opacity: 0.75;
}
.bg-scroll {
  background-attachment: scroll;
}
.bg-center {
  background-position: center;
}
.bg-no-repeat {
  background-repeat: no-repeat;
}
.fill-blue-200 {
  fill: #bfdbfe;
}
.fill-cyan-200 {
  fill: #a5f3fc;
}
.fill-green-200 {
  fill: #bbf7d0;
}
.fill-lime-200 {
  fill: #d9f99d;
}
.fill-orange-200 {
  fill: #fed7aa;
}
.fill-red-200 {
  fill: #fecaca;
}
.fill-yellow-200 {
  fill: #fef08a;
}
.\!p-0 {
  padding: 0px !important;
}
.p-0 {
  padding: 0px;
}
.p-0\.5 {
  padding: 2px;
}
.p-1 {
  padding: 4px;
}
.p-2 {
  padding: 8px;
}
.p-3 {
  padding: 12px;
}
.p-4 {
  padding: 16px;
}
.p-5 {
  padding: 20px;
}
.p-6 {
  padding: 24px;
}
.\!px-3 {
  padding-left: 12px !important;
  padding-right: 12px !important;
}
.\!py-2 {
  padding-top: 8px !important;
  padding-bottom: 8px !important;
}
.px-1 {
  padding-left: 4px;
  padding-right: 4px;
}
.px-2 {
  padding-left: 8px;
  padding-right: 8px;
}
.px-3 {
  padding-left: 12px;
  padding-right: 12px;
}
.px-4 {
  padding-left: 16px;
  padding-right: 16px;
}
.px-5 {
  padding-left: 20px;
  padding-right: 20px;
}
.py-1 {
  padding-top: 4px;
  padding-bottom: 4px;
}
.py-12 {
  padding-top: 48px;
  padding-bottom: 48px;
}
.py-16 {
  padding-top: 64px;
  padding-bottom: 64px;
}
.py-2 {
  padding-top: 8px;
  padding-bottom: 8px;
}
.py-3 {
  padding-top: 12px;
  padding-bottom: 12px;
}
.py-4 {
  padding-top: 16px;
  padding-bottom: 16px;
}
.py-6 {
  padding-top: 24px;
  padding-bottom: 24px;
}
.py-8 {
  padding-top: 32px;
  padding-bottom: 32px;
}
.py-px {
  padding-top: 1px;
  padding-bottom: 1px;
}
.pb-1 {
  padding-bottom: 4px;
}
.pb-2 {
  padding-bottom: 8px;
}
.pb-4 {
  padding-bottom: 16px;
}
.pb-5 {
  padding-bottom: 20px;
}
.pb-8 {
  padding-bottom: 32px;
}
.pl-1 {
  padding-left: 4px;
}
.pl-10 {
  padding-left: 40px;
}
.pl-14 {
  padding-left: 56px;
}
.pl-16 {
  padding-left: 64px;
}
.pl-2 {
  padding-left: 8px;
}
.pl-4 {
  padding-left: 16px;
}
.pl-6 {
  padding-left: 24px;
}
.pl-8 {
  padding-left: 32px;
}
.pl-\[28px\] {
  padding-left: 28px;
}
.pr-10 {
  padding-right: 40px;
}
.pr-4 {
  padding-right: 16px;
}
.pt-1 {
  padding-top: 4px;
}
.pt-2 {
  padding-top: 8px;
}
.pt-24 {
  padding-top: 96px;
}
.pt-4 {
  padding-top: 16px;
}
.pt-8 {
  padding-top: 32px;
}
.text-left {
  text-align: left;
}
.text-center {
  text-align: center;
}
.text-right {
  text-align: right;
}
.align-baseline {
  vertical-align: baseline;
}
.align-middle {
  vertical-align: middle;
}
.align-bottom {
  vertical-align: bottom;
}
.align-text-top {
  vertical-align: text-top;
}
.align-text-bottom {
  vertical-align: text-bottom;
}
.align-sub {
  vertical-align: sub;
}
.font-mono {
  font-family: Source Code Pro, monospace;
}
.text-2xl {
  font-size: 24px;
  line-height: 32px;
}
.text-3xl {
  font-size: 30px;
  line-height: 36px;
}
.text-\[14px\] {
  font-size: 14px;
}
.text-\[16px\] {
  font-size: 16px;
}
.text-base {
  font-size: 16px;
  line-height: 24px;
}
.text-lg {
  font-size: 18px;
  line-height: 28px;
}
.text-sm {
  font-size: 14px;
  line-height: 20px;
}
.text-xl {
  font-size: 20px;
  line-height: 28px;
}
.text-xs {
  font-size: 12px;
  line-height: 16px;
}
.font-semibold {
  font-weight: 600;
}
.uppercase {
  text-transform: uppercase;
}
.lowercase {
  text-transform: lowercase;
}
.\!capitalize {
  text-transform: capitalize !important;
}
.capitalize {
  text-transform: capitalize;
}
.italic {
  font-style: italic;
}
.tabular-nums {
  --tw-numeric-spacing: tabular-nums;
  font-variant-numeric: var(--tw-ordinal) var(--tw-slashed-zero) var(--tw-numeric-figure) var(--tw-numeric-spacing) var(--tw-numeric-fraction);
}
.leading-\[24px\] {
  line-height: 24px;
}
.leading-none {
  line-height: 1;
}
.leading-normal {
  line-height: 1.5;
}
.leading-tight {
  line-height: 1.25;
}
.text-accent {
  --tw-text-opacity: 1;
  color: rgb(var(--color-accent) / var(--tw-text-opacity, 1));
}
.text-black {
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity, 1));
}
.text-blue-300 {
  --tw-text-opacity: 1;
  color: rgb(147 197 253 / var(--tw-text-opacity, 1));
}
.text-blue-400 {
  --tw-text-opacity: 1;
  color: rgb(96 165 250 / var(--tw-text-opacity, 1));
}
.text-gray-100 {
  --tw-text-opacity: 1;
  color: rgb(244 244 245 / var(--tw-text-opacity, 1));
}
.text-gray-200 {
  --tw-text-opacity: 1;
  color: rgb(228 228 231 / var(--tw-text-opacity, 1));
}
.text-gray-300 {
  --tw-text-opacity: 1;
  color: rgb(212 212 216 / var(--tw-text-opacity, 1));
}
.text-gray-400 {
  --tw-text-opacity: 1;
  color: rgb(161 161 170 / var(--tw-text-opacity, 1));
}
.text-gray-500 {
  --tw-text-opacity: 1;
  color: rgb(113 113 122 / var(--tw-text-opacity, 1));
}
.text-gray-600 {
  --tw-text-opacity: 1;
  color: rgb(82 82 91 / var(--tw-text-opacity, 1));
}
.text-gray-700 {
  --tw-text-opacity: 1;
  color: rgb(63 63 70 / var(--tw-text-opacity, 1));
}
.text-gray-800 {
  --tw-text-opacity: 1;
  color: rgb(39 39 42 / var(--tw-text-opacity, 1));
}
.text-green-400 {
  --tw-text-opacity: 1;
  color: rgb(74 222 128 / var(--tw-text-opacity, 1));
}
.text-green-500 {
  --tw-text-opacity: 1;
  color: rgb(34 197 94 / var(--tw-text-opacity, 1));
}
.text-green-600 {
  --tw-text-opacity: 1;
  color: rgb(22 163 74 / var(--tw-text-opacity, 1));
}
.text-primary {
  --tw-text-opacity: 1;
  color: rgb(var(--color-primary) / var(--tw-text-opacity, 1));
}
.text-red-400 {
  --tw-text-opacity: 1;
  color: rgb(248 113 113 / var(--tw-text-opacity, 1));
}
.text-red-500 {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}
.text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}
.text-yellow-400 {
  --tw-text-opacity: 1;
  color: rgb(250 204 21 / var(--tw-text-opacity, 1));
}
.text-yellow-500 {
  --tw-text-opacity: 1;
  color: rgb(234 179 8 / var(--tw-text-opacity, 1));
}
.underline {
  text-decoration-line: underline;
}
.opacity-0 {
  opacity: 0;
}
.opacity-25 {
  opacity: 0.25;
}
.opacity-50 {
  opacity: 0.5;
}
.opacity-70 {
  opacity: 0.7;
}
.opacity-75 {
  opacity: 0.75;
}
.shadow {
  --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-2xl {
  --tw-shadow: 0 25px 50px -12px rgb(0 0 0 / 0.25);
  --tw-shadow-colored: 0 25px 50px -12px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-lg {
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-md {
  --tw-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.shadow-xl {
  --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}
.outline {
  outline-style: solid;
}
.ring {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.ring-2 {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}
.ring-accent {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(var(--color-accent) / var(--tw-ring-opacity, 1));
}
.ring-red-400 {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(248 113 113 / var(--tw-ring-opacity, 1));
}
.blur {
  --tw-blur: blur(8px);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.invert {
  --tw-invert: invert(100%);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}
.backdrop-blur {
  --tw-backdrop-blur: blur(8px);
  -webkit-backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.backdrop-filter {
  -webkit-backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}
.transition {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, -webkit-backdrop-filter;
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter, -webkit-backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.transition-transform {
  transition-property: transform;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}
.duration-200 {
  transition-duration: 200ms;
}
.ease-out {
  transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
}
.hoverable:hover {
  background-color: rgb(39 39 42 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.hoverable:hover:is(.dark *) {
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.bg-input {
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.bg-input:hover {
  --tw-bg-opacity: 0.1;
}
.bg-input:is(.dark *) {
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.bg-input:hover:is(.dark *) {
  --tw-bg-opacity: 0.1;
}
.bg-box-transparent {
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.bg-box-transparent:is(.dark *) {
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.bg-box-transparent-2 {
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.1;
}
.bg-box-transparent-2:is(.dark *) {
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.1;
}

:host, :root {
  --color-primary: 59 130 246;
  --color-secondary: 96 165 250;
  --color-accent: 24 24 27;
}
.dark {
  --color-primary: 96 165 250;
  --color-secondary: 59 130 246;
  --color-accent: 244 244 245;
}

*:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(63 63 70 / var(--tw-border-opacity, 1));
}

html.dark {
  --tw-bg-opacity: 1;
  background-color: rgb(24 24 27 / var(--tw-bg-opacity, 1));
}

body, :host {
  font-family: 'Inter var', sans-serif !important;
  font-size: 16px !important;
  font-feature-settings: 'cv02', 'cv03', 'cv04', 'cv11';
  --tw-bg-opacity: 1;
  background-color: rgb(250 250 250 / var(--tw-bg-opacity, 1));
  line-height: 1.5;
}

body:is(.dark *), :host:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(24 24 27 / var(--tw-bg-opacity, 1));
}
table th,
table td {
  padding-top: 8px;
  padding-bottom: 8px;
  padding-left: 16px;
  padding-right: 16px;
}
input:focus,
button:focus,
textarea:focus,
select:focus,
[role='button']:focus {
  outline: none;
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(var(--color-accent) / var(--tw-ring-opacity, 1));
}
input:focus:is(.dark *),
button:focus:is(.dark *),
textarea:focus:is(.dark *),
select:focus:is(.dark *),
[role='button']:focus:is(.dark *) {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(228 228 231 / var(--tw-ring-opacity, 1));
}

.text-overflow {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.line-clamp {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
}


.custom-table thead {
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}


.custom-table thead:is(.dark *) {
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.05;
}
.custom-table thead th {
  font-weight: 600;
}
.custom-table thead th:first-child {
  border-top-left-radius: 8px;
  border-bottom-left-radius: 8px;
}
.custom-table thead th:last-child {
  border-top-right-radius: 8px;
  border-bottom-right-radius: 8px;
}
.custom-table tbody > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-y-reverse: 0;
  border-top-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width: calc(1px * var(--tw-divide-y-reverse));
}



pre {
  font-size: 15px;
}

.scroll::-webkit-scrollbar, .scroll .cm-scroller::-webkit-scrollbar {
    width: 7px;
    height: 9px;
  }

.scroll::-webkit-scrollbar-thumb, .scroll .cm-scroller::-webkit-scrollbar-thumb {
  --tw-bg-opacity: 1;
  background-color: rgb(212 212 216 / var(--tw-bg-opacity, 1));
}

.scroll:is(.dark *)::-webkit-scrollbar-thumb, .scroll .cm-scroller:is(.dark *)::-webkit-scrollbar-thumb {
  --tw-bg-opacity: 1;
  background-color: rgb(63 63 70 / var(--tw-bg-opacity, 1));
}

.scroll::-webkit-scrollbar-thumb, .scroll .cm-scroller::-webkit-scrollbar-thumb {
    border-radius: 8px;
  }

.scroll::-webkit-scrollbar-track, .scroll .cm-scroller::-webkit-scrollbar-track {
    background: transparent;
  }

.scroll.scroll-xs::-webkit-scrollbar, .scroll .cm-scroller.scroll-xs::-webkit-scrollbar {
    width: 5px;
    height: 5px;
  }


.tippy-box[data-theme~='tooltip-theme'] {
  border-radius: 6px;
  --tw-bg-opacity: 1;
  background-color: rgb(24 24 27 / var(--tw-bg-opacity, 1));
  padding-left: 8px;
  padding-right: 8px;
  padding-top: 4px;
  padding-bottom: 4px;
  font-size: 14px;
  line-height: 20px;
  --tw-text-opacity: 1;
  color: rgb(228 228 231 / var(--tw-text-opacity, 1));
}


.tippy-box[data-theme~='tooltip-theme']:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity, 1));
}
.Vue-Toastification__toast {
  font-family: inherit !important;
}
.ProseMirror > * + * {
  margin-top: 0.75em;
}
.ProseMirror img {
  max-width: 100%;
  height: auto;
}
.ProseMirror img.ProseMirror-selectednode {
  outline: 3px solid #68CEF8;
}

.input-label {
  margin-left: 4px;
  font-size: 14px;
  line-height: 20px;
  --tw-text-opacity: 1;
  color: rgb(82 82 91 / var(--tw-text-opacity, 1));
}

.input-label:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(228 228 231 / var(--tw-text-opacity, 1));
}

.dark\:prose-invert:is(.dark *) {
  --tw-prose-body: var(--tw-prose-invert-body);
  --tw-prose-headings: var(--tw-prose-invert-headings);
  --tw-prose-lead: var(--tw-prose-invert-lead);
  --tw-prose-links: var(--tw-prose-invert-links);
  --tw-prose-bold: var(--tw-prose-invert-bold);
  --tw-prose-counters: var(--tw-prose-invert-counters);
  --tw-prose-bullets: var(--tw-prose-invert-bullets);
  --tw-prose-hr: var(--tw-prose-invert-hr);
  --tw-prose-quotes: var(--tw-prose-invert-quotes);
  --tw-prose-quote-borders: var(--tw-prose-invert-quote-borders);
  --tw-prose-captions: var(--tw-prose-invert-captions);
  --tw-prose-kbd: var(--tw-prose-invert-kbd);
  --tw-prose-kbd-shadows: var(--tw-prose-invert-kbd-shadows);
  --tw-prose-code: var(--tw-prose-invert-code);
  --tw-prose-pre-code: var(--tw-prose-invert-pre-code);
  --tw-prose-pre-bg: var(--tw-prose-invert-pre-bg);
  --tw-prose-th-borders: var(--tw-prose-invert-th-borders);
  --tw-prose-td-borders: var(--tw-prose-invert-td-borders);
}

.placeholder\:text-black::-moz-placeholder {
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity, 1));
}

.placeholder\:text-black::placeholder {
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity, 1));
}

.focus-within\:ring-2:focus-within {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.focus-within\:ring-accent:focus-within {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(var(--color-accent) / var(--tw-ring-opacity, 1));
}

.focus-within\:bg-box-transparent-2:focus-within {
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.1;
}

.focus-within\:bg-box-transparent-2:focus-within:is(.dark *) {
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
  --tw-bg-opacity: 0.1;
}

.hover\:-translate-y-1:hover {
  --tw-translate-y: -4px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.hover\:scale-110:hover {
  --tw-scale-x: 1.1;
  --tw-scale-y: 1.1;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.hover\:bg-gray-100:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(244 244 245 / var(--tw-bg-opacity, 1));
}

.hover\:bg-gray-700:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(63 63 70 / var(--tw-bg-opacity, 1));
}

.hover\:bg-red-400:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(248 113 113 / var(--tw-bg-opacity, 1));
}

.hover\:bg-secondary:hover {
  --tw-bg-opacity: 1;
  background-color: rgb(var(--color-secondary) / var(--tw-bg-opacity, 1));
}

.hover\:text-black:hover {
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity, 1));
}

.hover\:shadow-xl:hover {
  --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.hover\:ring-2:hover {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.hover\:ring-accent:hover {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(var(--color-accent) / var(--tw-ring-opacity, 1));
}

.hover\:ring-gray-900:hover {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(24 24 27 / var(--tw-ring-opacity, 1));
}

.focus\:outline-none:focus {
  outline: 2px solid transparent;
  outline-offset: 2px;
}

.focus\:ring-0:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.focus\:ring-2:focus {
  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.focus\:ring-red-400:focus {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(248 113 113 / var(--tw-ring-opacity, 1));
}

.group:hover .group-hover\:visible {
  visibility: visible;
}

.group:hover .group-hover\:invisible {
  visibility: hidden;
}

.group:hover .group-hover\:scale-100 {
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.dark\:divide-gray-700:is(.dark *) > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(63 63 70 / var(--tw-divide-opacity, 1));
}

.dark\:divide-gray-800:is(.dark *) > :not([hidden]) ~ :not([hidden]) {
  --tw-divide-opacity: 1;
  border-color: rgb(39 39 42 / var(--tw-divide-opacity, 1));
}

.dark\:border-accent:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(var(--color-accent) / var(--tw-border-opacity, 1));
}

.dark\:border-blue-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(147 197 253 / var(--tw-border-opacity, 1));
}

.dark\:border-blue-400:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(96 165 250 / var(--tw-border-opacity, 1));
}

.dark\:border-cyan-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(103 232 249 / var(--tw-border-opacity, 1));
}

.dark\:border-gray-100:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(244 244 245 / var(--tw-border-opacity, 1));
}

.dark\:border-gray-700:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(63 63 70 / var(--tw-border-opacity, 1));
}

.dark\:border-gray-800:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(39 39 42 / var(--tw-border-opacity, 1));
}

.dark\:border-green-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(134 239 172 / var(--tw-border-opacity, 1));
}

.dark\:border-lime-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(190 242 100 / var(--tw-border-opacity, 1));
}

.dark\:border-orange-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(253 186 116 / var(--tw-border-opacity, 1));
}

.dark\:border-red-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(252 165 165 / var(--tw-border-opacity, 1));
}

.dark\:border-transparent:is(.dark *) {
  border-color: transparent;
}

.dark\:border-yellow-300:is(.dark *) {
  --tw-border-opacity: 1;
  border-color: rgb(253 224 71 / var(--tw-border-opacity, 1));
}

.dark\:border-opacity-40:is(.dark *) {
  --tw-border-opacity: 0.4;
}

.dark\:border-opacity-50:is(.dark *) {
  --tw-border-opacity: 0.5;
}

.dark\:bg-\[\#2DD4BF\]:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(45 212 191 / var(--tw-bg-opacity, 1));
}

.dark\:bg-amber-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(252 211 77 / var(--tw-bg-opacity, 1));
}

.dark\:bg-blue-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(147 197 253 / var(--tw-bg-opacity, 1));
}

.dark\:bg-cyan-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(103 232 249 / var(--tw-bg-opacity, 1));
}

.dark\:bg-gray-100:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(244 244 245 / var(--tw-bg-opacity, 1));
}

.dark\:bg-gray-200:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
}

.dark\:bg-gray-600:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(82 82 91 / var(--tw-bg-opacity, 1));
}

.dark\:bg-gray-700:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(63 63 70 / var(--tw-bg-opacity, 1));
}

.dark\:bg-gray-800:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(39 39 42 / var(--tw-bg-opacity, 1));
}

.dark\:bg-gray-900:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(24 24 27 / var(--tw-bg-opacity, 1));
}

.dark\:bg-green-200:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(187 247 208 / var(--tw-bg-opacity, 1));
}

.dark\:bg-green-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(134 239 172 / var(--tw-bg-opacity, 1));
}

.dark\:bg-indigo-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(165 180 252 / var(--tw-bg-opacity, 1));
}

.dark\:bg-indigo-400:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(129 140 248 / var(--tw-bg-opacity, 1));
}

.dark\:bg-lime-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(190 242 100 / var(--tw-bg-opacity, 1));
}

.dark\:bg-orange-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(253 186 116 / var(--tw-bg-opacity, 1));
}

.dark\:bg-red-200:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(254 202 202 / var(--tw-bg-opacity, 1));
}

.dark\:bg-red-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(252 165 165 / var(--tw-bg-opacity, 1));
}

.dark\:bg-red-400:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(248 113 113 / var(--tw-bg-opacity, 1));
}

.dark\:bg-red-500:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(239 68 68 / var(--tw-bg-opacity, 1));
}

.dark\:bg-secondary:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(var(--color-secondary) / var(--tw-bg-opacity, 1));
}

.dark\:bg-sky-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(125 211 252 / var(--tw-bg-opacity, 1));
}

.dark\:bg-yellow-300:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(253 224 71 / var(--tw-bg-opacity, 1));
}

.dark\:bg-opacity-10:is(.dark *) {
  --tw-bg-opacity: 0.1;
}

.dark\:bg-opacity-60:is(.dark *) {
  --tw-bg-opacity: 0.6;
}

.dark\:bg-none:is(.dark *) {
  background-image: none;
}

.dark\:fill-blue-300:is(.dark *) {
  fill: #93c5fd;
}

.dark\:fill-cyan-300:is(.dark *) {
  fill: #67e8f9;
}

.dark\:fill-green-300:is(.dark *) {
  fill: #86efac;
}

.dark\:fill-lime-300:is(.dark *) {
  fill: #bef264;
}

.dark\:fill-orange-300:is(.dark *) {
  fill: #fdba74;
}

.dark\:fill-red-300:is(.dark *) {
  fill: #fca5a5;
}

.dark\:fill-yellow-300:is(.dark *) {
  fill: #fde047;
}

.dark\:text-black:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(0 0 0 / var(--tw-text-opacity, 1));
}

.dark\:text-gray-100:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(244 244 245 / var(--tw-text-opacity, 1));
}

.dark\:text-gray-200:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(228 228 231 / var(--tw-text-opacity, 1));
}

.dark\:text-gray-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(212 212 216 / var(--tw-text-opacity, 1));
}

.dark\:text-gray-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(161 161 170 / var(--tw-text-opacity, 1));
}

.dark\:text-gray-600:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(82 82 91 / var(--tw-text-opacity, 1));
}

.dark\:text-gray-900:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(24 24 27 / var(--tw-text-opacity, 1));
}

.dark\:text-green-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(74 222 128 / var(--tw-text-opacity, 1));
}

.dark\:text-red-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(252 165 165 / var(--tw-text-opacity, 1));
}

.dark\:text-red-400:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(248 113 113 / var(--tw-text-opacity, 1));
}

.dark\:text-red-500:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(239 68 68 / var(--tw-text-opacity, 1));
}

.dark\:text-red-600:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(220 38 38 / var(--tw-text-opacity, 1));
}

.dark\:text-secondary:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(var(--color-secondary) / var(--tw-text-opacity, 1));
}

.dark\:text-yellow-300:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(253 224 71 / var(--tw-text-opacity, 1));
}

.dark\:invert:is(.dark *) {
  --tw-invert: invert(100%);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}

.dark\:hover\:bg-gray-200:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(228 228 231 / var(--tw-bg-opacity, 1));
}

.dark\:hover\:bg-gray-700:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(63 63 70 / var(--tw-bg-opacity, 1));
}

.dark\:hover\:bg-primary:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(var(--color-primary) / var(--tw-bg-opacity, 1));
}

.dark\:hover\:bg-red-500:hover:is(.dark *) {
  --tw-bg-opacity: 1;
  background-color: rgb(239 68 68 / var(--tw-bg-opacity, 1));
}

.dark\:hover\:text-gray-100:hover:is(.dark *) {
  --tw-text-opacity: 1;
  color: rgb(244 244 245 / var(--tw-text-opacity, 1));
}

.dark\:hover\:ring-gray-200:hover:is(.dark *) {
  --tw-ring-opacity: 1;
  --tw-ring-color: rgb(228 228 231 / var(--tw-ring-opacity, 1));
}

@media (min-width: 768px) {

  .md\:relative {
    position: relative;
  }

  .md\:-ml-1 {
    margin-left: -4px;
  }

  .md\:mb-0 {
    margin-bottom: 0px;
  }

  .md\:ml-0 {
    margin-left: 0px;
  }

  .md\:ml-4 {
    margin-left: 16px;
  }

  .md\:mt-0 {
    margin-top: 0px;
  }

  .md\:block {
    display: block;
  }

  .md\:flex {
    display: flex;
  }

  .md\:hidden {
    display: none;
  }

  .md\:w-auto {
    width: auto;
  }

  .md\:flex-1 {
    flex: 1 1 0%;
  }

  .md\:grid-cols-2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .md\:items-center {
    align-items: center;
  }

  .md\:justify-between {
    justify-content: space-between;
  }

  .md\:space-x-4 > :not([hidden]) ~ :not([hidden]) {
    --tw-space-x-reverse: 0;
    margin-right: calc(16px * var(--tw-space-x-reverse));
    margin-left: calc(16px * calc(1 - var(--tw-space-x-reverse)));
  }

  .md\:px-4 {
    padding-left: 16px;
    padding-right: 16px;
  }

  .md\:pr-60 {
    padding-right: 240px;
  }

  .md\:text-left {
    text-align: left;
  }
}

@media (min-width: 1024px) {

  .lg\:mb-0 {
    margin-bottom: 0px;
  }

  .lg\:ml-8 {
    margin-left: 32px;
  }

  .lg\:mt-0 {
    margin-top: 0px;
  }

  .lg\:block {
    display: block;
  }

  .lg\:inline-block {
    display: inline-block;
  }

  .lg\:flex {
    display: flex;
  }

  .lg\:hidden {
    display: none;
  }

  .lg\:w-4\/12 {
    width: 33.333333%;
  }

  .lg\:w-auto {
    width: auto;
  }

  .lg\:flex-1 {
    flex: 1 1 0%;
  }

  .lg\:grid-cols-3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }

  .lg\:flex-row {
    flex-direction: row;
  }

  .lg\:items-center {
    align-items: center;
  }

  .lg\:justify-between {
    justify-content: space-between;
  }
}

@media (min-width: 1536px) {

  .\32xl\:grid-cols-4 {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
}

</style><style>.list-item-active svg { visibility: visible }</style><div id="app" data-v-app=""><!----></div></template></div></body></html>'''

import logging, json
import re
import traceback

logger = logging.getLogger("scraper")
logger.setLevel(logging.INFO)
try:
    import coloredlogs

    coloredlogs.install(level="INFO", logger=logger)
except ImportError:
    logging.basicConfig(level=logging.INFO)

# Use scrapy's Selector if available, otherwise fall back to lxml with the same API
try:
    from scrapy.selector import Selector
except ImportError:
    from lxml import html as _lxml_html


    class _SelWrap:
        def __init__(self, el):
            self._el = el

        def xpath(self, q):
            res = self._el.xpath(q)
            return _SelList(_SelWrap(r) if not isinstance(r, str) else _Str(r) for r in res)

        def get(self):
            return _lxml_html.tostring(self._el, encoding="unicode")


    class _Str(str):
        def get(self):
            return str(self)


    class _SelList(list):
        def get(self):
            return self[0].get() if self else None

        def getall(self):
            return [s.get() for s in self]


    def Selector(text):
        return _SelWrap(_lxml_html.fromstring(text))

POLISH_MONTHS = {
    "styczeń": 1, "stycznia": 1, "sty": 1,
    "luty": 2, "lutego": 2, "lut": 2,
    "marzec": 3, "marca": 3, "mar": 3,
    "kwiecień": 4, "kwietnia": 4, "kwi": 4,
    "maj": 5, "maja": 5,
    "czerwiec": 6, "czerwca": 6, "cze": 6,
    "lipiec": 7, "lipca": 7, "lip": 7,
    "sierpień": 8, "sierpnia": 8, "sie": 8,
    "wrzesień": 9, "września": 9, "wrz": 9,
    "październik": 10, "października": 10, "paź": 10,
    "listopad": 11, "listopada": 11, "lis": 11,
    "grudzień": 12, "grudnia": 12, "gru": 12,
}


def clean(text):
    """Collapse whitespace and strip."""
    if text is None:
        return ""
    return re.sub(r"\s+", " ", text).strip()


def format_name(raw_name):
    """'Kurzawa Filip' -> 'Kurzawa, Filip' (PZT shows Surname Firstname)."""
    parts = clean(raw_name).split(" ")
    if len(parts) < 2:
        return clean(raw_name)
    return parts[0] + ", " + " ".join(parts[1:])


def to_us_date(y, m, d):
    """M/D/YYYY without leading zeros, like the samples (5/23/2026)."""
    return f"{int(m)}/{int(d)}/{int(y)}"


class Parser:
    def __init__(self, spider_name, page):
        self.spider_name = spider_name
        self.page = page
        self._page_info = self._parse_page_info()

    # ---------- page-level info (same for all matches on the page) ----------
    def _parse_page_info(self):
        info = {}
        try:
            info["tournament_name"] = clean(
                self.page.xpath('//div[@class="tournAppName_B"]/text()').get()
            )

            # "Od: 2026.06.06" / "Do: 2026.06.08"
            dates_txt = clean(" ".join(
                self.page.xpath('//div[@class="tournAppTopCent_B"]//text()').getall()
            ))
            m = re.search(r"Od:\s*(\d{4})\.(\d{2})\.(\d{2})", dates_txt)
            info["tournament_start_date"] = to_us_date(m.group(1), m.group(2), m.group(3)) if m else ""
            m = re.search(r"Do:\s*(\d{4})\.(\d{2})\.(\d{2})", dates_txt)
            info["tournament_end_date"] = to_us_date(m.group(1), m.group(2), m.group(3)) if m else ""

            # Match date: prefer Date=YYYY-MM-DD in the form action / active calendar link
            action = self.page.xpath('//form[@id="aspnetForm"]/@action').get() or ""
            m = re.search(r"Date=(\d{4})-(\d{2})-(\d{2})", action)
            if not m:
                # fallback: "Kolejność rozgrywanych meczów w dniu 07 czerwiec 2026"
                title = clean(self.page.xpath('//div[@class="titleOrderOfPlay"]/text()').get())
                m2 = re.search(r"(\d{1,2})\s+(\wfffd*\w+)\s+(\d{4})", title)
                if m2 and m2.group(2).lower() in POLISH_MONTHS:
                    info["date"] = to_us_date(m2.group(3), POLISH_MONTHS[m2.group(2).lower()], m2.group(1))
                else:
                    info["date"] = ""
            else:
                info["date"] = to_us_date(m.group(1), m.group(2), m.group(3))

            # City: "Miejsce turnieju: 99-210 Uniejów, ul. Sportowa ..."
            place = clean(" ".join(self.page.xpath(
                '//div[@class="tournAppPlaceOfGame_B"]//div[@class="tournAppPlaceOfGameR_B"]//text()'
            ).getall()))
            m = re.search(r"\d{2}-\d{3}\s+([^,]+)", place)
            info["tournament_city"] = clean(m.group(1)) if m else place.split(",")[0]

            tid = re.search(r"TournamentID=([0-9A-Fa-f-]+)", action)
            info["tournament_url"] = (
                f"http://portal.pzt.pl/TournamentOrderOfPlay.aspx?TournamentID={tid.group(1)}" if tid else ""
            )
        except Exception:
            logger.error(traceback.format_exc())
        return info

    # ---------- helpers ----------
    @staticmethod
    def _winner_side(sets):
        """sets = [(left, right), ...] -> 'left' or 'right' by sets won."""
        left = sum(1 for a, b in sets if a > b)
        right = sum(1 for a, b in sets if b > a)
        return "left" if left > right else "right"

    @staticmethod
    def _format_score(sets, winner_side):
        """Score from the winner's perspective, semicolon at the end: '6-3, 6-2;'"""
        parts = []
        for a, b in sets:
            if winner_side == "left":
                parts.append(f"{a}-{b}")
            else:
                parts.append(f"{b}-{a}")
        return ", ".join(parts) + ";"

    @staticmethod
    def _gender_from_draw(draw_name):
        d = draw_name.lower()
        if "chłopcy" in d or "mężczyźni" in d or "chlopcy" in d or "mezczyzni" in d:
            return "Male"
        if "dziewczęta" in d or "kobiety" in d or "dziewczeta" in d:
            return "Female"
        return ""

    # ---------- one match row ----------
    def parse_match(self, row):
        match_data = {}
        try:
            tds = row.xpath("./td")
            if len(tds) < 5:
                return None  # header / court row

            # Draw name, e.g. "Juniorzy - do 18 lat" + "Gra pojedyncza, Chłopcy"
            draw_name = clean(" ".join(tds[2].xpath(".//text()").getall()))
            if not draw_name:
                return None

            # Players: links with UserID inside the 4th td
            links = tds[3].xpath('.//a[contains(@href, "PlayerProfile.aspx")]')
            players = []
            for a in links:
                name = clean(" ".join(a.xpath(".//text()").getall()))
                href = a.xpath("./@href").get() or ""
                pid = ""
                m = re.search(r"UserID=([A-Z]{3}\d+)", href)
                if m:
                    pid = m.group(1)
                players.append({"name": format_name(name), "id": pid})
            if len(players) < 2:
                return None

            is_doubles = len(players) == 4
            left_players = players[: 2 if is_doubles else 1]
            right_players = players[2:] if is_doubles else players[1:]

            # Score cells in the last td, e.g. ['3:6', '6:2', '10:6']
            raw_sets = [clean(t) for t in tds[4].xpath(".//td/text()").getall() if clean(t)]
            sets = []
            for s in raw_sets:
                m = re.match(r"^(\d+)\s*:\s*(\d+)", s)
                if m:
                    sets.append((int(m.group(1)), int(m.group(2))))
            if not sets:
                logger.info(f"Skipping not-played match: "
                            f"{left_players[0]['name']} vs {right_players[0]['name']}")
                return None

            winner_side = self._winner_side(sets)
            winners = left_players if winner_side == "left" else right_players
            losers = right_players if winner_side == "left" else left_players

            gender = self._gender_from_draw(draw_name)
            info = self._page_info

            match_data = {
                "match_id": "",
                "ball_type": "Yellow",
                "draw_bracket_value": "",
                "draw_name": draw_name,
                "draw_team_type": "Doubles" if is_doubles else "Singles",
                "tournament_name": info.get("tournament_name", ""),
                "date": info.get("date", ""),
                "round": "",
                "score": self._format_score(sets, winner_side),
                "winner_1_name": winners[0]["name"],
                "winner_1_gender": gender,
                "winner_1_third_party_id": winners[0]["id"],
                "winner_1_city": "",
                "winner_1_country": "Poland",
                "winner_1_state": "",
                "winner_2_name": winners[1]["name"] if is_doubles else "",
                "winner_2_gender": gender if is_doubles else "",
                "winner_2_third_party_id": winners[1]["id"] if is_doubles else "",
                "winner_2_city": "",
                "winner_2_state": "",
                "loser_1_name": losers[0]["name"],
                "loser_1_gender": gender,
                "loser_1_third_party_id": losers[0]["id"],
                "loser_1_city": "",
                "loser_1_state": "",
                "loser_1_country": "Poland",
                "loser_2_name": losers[1]["name"] if is_doubles else "",
                "loser_2_gender": gender if is_doubles else "",
                "loser_2_third_party_id": losers[1]["id"] if is_doubles else "",
                "loser_2_city": "",
                "loser_2_state": "",
                "outcome": "Completed",
                "id_type": "Poland",
                "draw_gender": gender,
                "draw_bracket_type": "",
                "draw_type": "",
                "tournament_city": info.get("tournament_city", ""),
                "tournament_state": "",
                "tournament_country_code": "POL",
                "tournament_host": "",
                "tournament_location_type": "",
                "tournament_surface": "",
                "tournament_event_category": "",
                "tournament_event_grade": "",
                "tournament_import_source": "Poland",
                "tournament_sanction_body": "Tennis Poland",
                "winner_2_country": "Poland" if is_doubles else "",
                "winner_2_college": "",
                "loser_2_country": "Poland" if is_doubles else "",
                "loser_2_college": "",
                "tournament_event_type": "Tournament",
                "winner_1_college": "",
                "loser_1_college": "",
                "tournament_url": info.get("tournament_url", ""),
                "winner_1_dob": "",
                "winner_2_dob": "",
                "loser_1_dob": "",
                "loser_2_dob": "",
                "tournament_country": "Poland",
                "tournament_start_date": info.get("tournament_start_date", ""),
                "tournament_end_date": info.get("tournament_end_date", ""),
            }
        except Exception:
            logger.error(traceback.format_exc())
            return None

        return match_data


if __name__ == "__main__":
    html1 = Selector(text=html_text1)
    parser = Parser("spider_name", html1)

    matchs_data = []
    # Match rows live inside <table class="listBlue">; court headers are <th> rows
    for d1 in html1.xpath('//table[@class="listBlue"]//tr[td]'):
        match = parser.parse_match(d1)
        if match:
            matchs_data.append(match)

    logger.info(json.dumps(matchs_data))

    logger.info(f"total matches parsed: {len(matchs_data)}")
    logger.info(f"tournament: {matchs_data[0]['tournament_name'] if matchs_data else '-'} | "
                f"date: {matchs_data[0]['date'] if matchs_data else '-'} | "
                f"{matchs_data[0]['tournament_start_date'] if matchs_data else ''} - "
                f"{matchs_data[0]['tournament_end_date'] if matchs_data else ''} | "
                f"city: {matchs_data[0]['tournament_city'] if matchs_data else ''}")
