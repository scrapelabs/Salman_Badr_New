html_text1 = '''
<tr style="background-color: transparent;">
			<td align="right">Fri 06/02/2026</td><td>MS2</td><td><a href="./draw.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;draw=1">B16 – B16 – Main</a></td><td class="nowrap" align="right"><a class="teamname" href="teammatch.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;match=7">Luxembourg</a><a href="matches.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;c=LUX"><img src="//static.tournamentsoftware.com/content/images/flags/LUX.svg" class="intext flag" width="16" height="14" alt="Luxembourg" title="Luxembourg"><span class="printonly flag">[LUX] </span></a><br><a href="player.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;player=10">Tommaso CAVALLERIS</a><img src="//static.tournamentsoftware.com/content/images/flags/LUX.svg" class="intext flag" width="16" height="14" alt="LUX" title="LUX"><span class="printonly flag">[LUX] </span></td><td align="center">-</td><td class="nowrap"><a href="matches.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;c=SWE"><img src="//static.tournamentsoftware.com/content/images/flags/SWE.svg" class="intext flag" width="16" height="14" alt="Sweden" title="Sweden"><span class="printonly flag">[SWE] </span></a><a class="teamname" href="teammatch.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;match=7">Sweden</a><br><img src="//static.tournamentsoftware.com/content/images/flags/SWE.svg" class="intext flag" width="16" height="14" alt="SWE" title="SWE"><span class="printonly flag">[SWE] </span><strong><a class="highlighted" href="player.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;player=3">Eric TEN</a></strong></td><td><span class="score"><span>6-7(2)</span> <span>0-6</span></span></td><td><a href="matchcalendarhandler.ashx?code=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;id=25&amp;LCID=2057&amp;typeID=11" class="icon-calendar inline-icalendar" title="Export Calendar">Export Calendar</a></td><td>0-1</td><td></td><td></td><td align="right"></td><td><a href="./court.aspx?id=B1B32533-F65D-45B7-9B82-A0A4AA4D9985&amp;crtid=4">Tennishal Asten - 4</a></td>
		</tr>
'''


import re, logging, coloredlogs
from scrapy.selector import Selector
from urllib.parse import urljoin

logger = logging.getLogger("scraper")
logger.setLevel(logging.INFO)
coloredlogs.install(level="INFO", logger=logger)

class Parse:
    def __init__(self):
        pass

    def parse_match(self, sel):
        # -------- OUTCOME --------
        outcome = "Completed"
        if sel.xpath('.//*[contains(normalize-space(.),"Retired")]'):
            outcome = "Retired"

        # -------- PLAYERS (KEEP ROW ORDER) --------
        rows = sel.xpath(
            './/div[contains(@class,"match__row-wrapper")]/div[contains(@class,"match__row")]'
        )

        row_players = []  # index 0 = top row, index 1 = bottom row
        winner_row_index = None

        for idx, row in enumerate(rows):
            players = []
            for a in row.xpath('.//a[contains(@class,"nav-link")]'):
                name = a.xpath('.//span[@class="nav-link__value"]/text()').get()
                href = a.xpath('./@href').get()
                if name and href:
                    players.append({
                        "name": self.clean_name(name),
                        "profile_url": urljoin(
                            "https://hts.tournamentsoftware.com/",
                            href.strip()
                        )
                    })

            row_players.append(players)

            if 'has-won' in row.attrib.get('class', ''):
                winner_row_index = idx

        loser_row_index = 1 - winner_row_index

        winners = row_players[winner_row_index]
        losers = row_players[loser_row_index]

        # -------- SCORE (ROW ORDER BASED) --------
        scores = []

        for ul in sel.xpath('//div[contains(@class,"match__result")]//ul[@class="points"]'):
            cells = [c.xpath('normalize-space(text())').get() for c in ul.xpath('./li')]
            if len(cells) != 2:
                continue

            winner_games = cells[winner_row_index]
            loser_games = cells[loser_row_index]

            scores.append(f"{winner_games}-{loser_games}")

        draw_team_type = "Doubles" if len(winners) == 2 else "Singles"

        match_data = {
            "draw_team_type": draw_team_type,
            "outcome": outcome,
            "score": ", ".join(scores) + ";" if scores else "",

            "winner_1": winners[0] if len(winners) > 0 else {},
            "winner_2": winners[1] if len(winners) > 1 else {},

            "loser_1": losers[0] if len(losers) > 0 else {},
            "loser_2": losers[1] if len(losers) > 1 else {},
        }

        logger.info(f'match_data: {match_data}')

        return match_data

    def clean_name(self, name: str) -> str:
        return re.sub(r"\s*\[[^\]]+\]\s*$", "", name).strip()


if __name__ == "__main__":
    html1 = Selector(text=html_text1)
    for d1 in html1.xpath('//tr'):
        match_data = Parse().parse_match(d1)
        logger.info(f'match_data: {match_data}')
